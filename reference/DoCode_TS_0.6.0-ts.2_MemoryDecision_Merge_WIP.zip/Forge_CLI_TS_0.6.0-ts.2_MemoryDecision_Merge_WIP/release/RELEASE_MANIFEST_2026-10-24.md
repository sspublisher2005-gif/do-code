# Forge CLI TypeScript v0.6.0-ts.2 — development manifest

**Status:** WIP/development preview, not a production release.

## Lineage
- Base: `0.6.0-ts.1` TypeScript worktree from October 23, preserved unchanged in the master handoff.
- Selectively ported from: `0.5.0` Memory/Decision WIP branch from October 22, also preserved unchanged.
- Branch label: `0.6.0-ts.2` (private merge worktree).

## Verified
- `npm run check:release`: PASS; TypeScript typecheck/build, **92 tests passed / 0 failed / 0 skipped**, and a structural file/shebang hash check.
- `npm pack`: PASS; produced `forge-coding-harness-0.6.0-ts.2.tgz`.
- Offline consumer smoke: PASS. Fresh temporary project installed the packed tarball with `npm install --offline --ignore-scripts`; version/help/init/doctor/memory list/offline pilot/sandbox status succeeded.
- Consent/secret guard tests: no live Decision Arena request without both flags; obvious credential-shaped decision text is rejected before sending; `privacy.mode = local-only` blocks remote pilot endpoint; the opt-in payload fixture excludes repository source and memory.
- Exact package checksum is recorded in `forge-coding-harness-0.6.0-ts.2.tgz.sha256` in this release folder and the separate deliverable checksum sidecar.

## Not verified / release blockers
- No committed `package-lock.json`; no clean `npm ci` with locked dependencies.
- No external model request or model-backed coding result; tests use local HTTP fixtures.
- Memory vault-wide concurrent writer locking and fully transactional bulk import are not implemented; see merge report.
- Linux sandbox remains prototype-only: no Landlock/seccomp-bpf, `productionReady=false`, not registered for general execution. macOS/Windows drivers are not present.
- Hosted CI results, SBOM/license audit, independent security review, controlled benchmark and customer validation are not available.

**Do not publish or label production-ready based on these local tests.**
