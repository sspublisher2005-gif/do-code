Fixtures reserved for a clean workspace, symlink escape attempts, and a vulnerable demo app. Future fixtures must contain no real credentials, network side effects or user data.
