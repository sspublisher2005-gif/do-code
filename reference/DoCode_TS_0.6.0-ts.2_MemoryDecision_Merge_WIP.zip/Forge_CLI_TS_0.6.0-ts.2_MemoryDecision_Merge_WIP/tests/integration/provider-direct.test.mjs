import test from 'node:test';
import assert from 'node:assert/strict';
import { AnthropicProvider } from '../../dist/providers/anthropic.js';
import { GoogleGenAIProvider } from '../../dist/providers/google.js';

const request = { model: 'test-model', role: 'coder', system: 'System instruction', messages: [{ role: 'user', content: 'Say ok' }], maxOutputTokens: 32, timeoutMs: 3000 };

test('Anthropic adapter maps messages, key header and usage without inventing cost', async () => {
  let seen;
  const provider = new AnthropicProvider({ baseUrl: 'https://api.anthropic.com', apiKey: 'anthropic-test-secret', fetchImpl: async (url, init) => {
    seen = { url: String(url), headers: init.headers, body: JSON.parse(init.body) };
    return new Response(JSON.stringify({ id: 'msg_test', model: 'test-model', content: [{ type: 'text', text: 'ok' }], usage: { input_tokens: 11, output_tokens: 4 } }), { status: 200, headers: { 'content-type': 'application/json', 'request-id': 'req-anthropic' } });
  } });
  const result = await provider.generate(request);
  assert.equal(seen.url, 'https://api.anthropic.com/v1/messages');
  assert.equal(seen.headers['x-api-key'], 'anthropic-test-secret');
  assert.equal(seen.body.system, 'System instruction');
  assert.equal(seen.body.messages[0].role, 'user');
  assert.equal(result.text, 'ok');
  assert.equal(result.usage.inputTokens, 11);
  assert.equal(result.usage.outputTokens, 4);
  assert.equal(result.usage.costKnown, false);
  assert.equal(result.requestId, 'req-anthropic');
});

test('Google GenAI adapter maps roles and normalizes provider-reported usage', async () => {
  let seen;
  const provider = new GoogleGenAIProvider({ baseUrl: 'https://generativelanguage.googleapis.com/v1beta', apiKey: 'google-test-secret', fetchImpl: async (url, init) => {
    seen = { url: String(url), headers: init.headers, body: JSON.parse(init.body) };
    return new Response(JSON.stringify({ responseId: 'resp-google', modelVersion: 'test-model', candidates: [{ content: { parts: [{ text: 'ok' }] } }], usageMetadata: { promptTokenCount: 13, candidatesTokenCount: 5 } }), { status: 200, headers: { 'content-type': 'application/json' } });
  } });
  const result = await provider.generate({ ...request, messages: [{ role: 'assistant', content: 'earlier' }, { role: 'user', content: 'Say ok' }] });
  assert.match(seen.url, /\/models\/test-model:generateContent$/);
  assert.equal(seen.headers['x-goog-api-key'], 'google-test-secret');
  assert.equal(seen.body.contents[0].role, 'model');
  assert.equal(result.text, 'ok');
  assert.equal(result.usage.inputTokens, 13);
  assert.equal(result.usage.outputTokens, 5);
  assert.equal(result.usage.costKnown, false);
});

test('direct provider health checks do not send a request unless consent is explicit', async () => {
  let calls = 0;
  const fetchImpl = async () => { calls += 1; return new Response('{}'); };
  const providers = [new AnthropicProvider({ baseUrl:'https://api.anthropic.com', apiKey:'key', fetchImpl }), new GoogleGenAIProvider({ baseUrl:'https://generativelanguage.googleapis.com/v1beta', apiKey:'key', fetchImpl })];
  for (const p of providers) { const result = await p.healthCheck(); assert.equal(result.ok, false); assert.match(result.detail, /explicit networkConsent/); }
  assert.equal(calls, 0);
});
