import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { MissionStore } from '../../dist/persistence/mission-store.js';
import { ForgeError } from '../../dist/core/errors.js';
import { recordPatchApplyFailure } from '../../dist/agents/workflow.js';

test('failed patch application marks the mission failed rather than leaving it running', async (t) => {
  const root = await mkdtemp(join(tmpdir(), 'forge-apply-failure-'));
  t.after(() => rm(root, { recursive: true, force: true }));
  const store = await MissionStore.open(root);
  const mission = await store.create('Update existing file carefully');
  await store.transition(mission.id, 'ready');
  await store.transition(mission.id, 'running');
  await store.update(mission.id, current => {
    const step = current.steps.find(item => item.kind === 'implement');
    step.status = 'running';
    step.startedAt = new Date().toISOString();
    step.attempt = 1;
    return current;
  });
  const failed = await recordPatchApplyFailure(root, mission.id, new ForgeError('PATCH_CONFLICT', 'File changed after review'));
  assert.equal(failed.status, 'failed');
  const implementation = failed.steps.find(item => item.kind === 'implement');
  assert.equal(implementation.status, 'failed');
  assert.equal(implementation.failureCode, 'PATCH_CONFLICT');
  assert.ok(implementation.finishedAt);
});
