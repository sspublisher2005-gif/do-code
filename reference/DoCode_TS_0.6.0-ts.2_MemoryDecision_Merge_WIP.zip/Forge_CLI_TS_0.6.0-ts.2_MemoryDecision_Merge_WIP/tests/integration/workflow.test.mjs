import test from 'node:test';
import assert from 'node:assert/strict';
import { createServer } from 'node:http';
import { once } from 'node:events';
import { mkdtemp, mkdir, readFile, writeFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { planTask, runCodingTask } from '../../dist/agents/workflow.js';
import { MissionStore } from '../../dist/persistence/mission-store.js';
import { readProposedPatch, beginPatchApply, recordPatchApplied } from '../../dist/agents/workflow.js';
import { applyPatch } from '../../dist/tools/patch-apply.js';

test('planned mission reuses hash-bound context, creates a proposal, tracks advisory/blocked steps, and applies only after approval', async (t) => {
  const root = await mkdtemp(join(tmpdir(), 'forge-workflow-e2e-'));
  t.after(() => rm(root, { recursive: true, force: true }));
  await mkdir(join(root, 'src'));
  await writeFile(join(root, 'README.md'), '# Fixture project\nA tiny test project.\n');
  await writeFile(join(root, 'src', 'math.ts'), 'export const total = 1;\n');

  const roles = [];
  const server = createServer(async (req, res) => {
    let raw = ''; for await (const chunk of req) raw += chunk;
    const body = JSON.parse(raw);
    const system = body.messages.find((m) => m.role === 'system')?.content ?? '';
    const role = /ROLE: ([a-z]+)/i.exec(system)?.[1]?.toLowerCase();
    roles.push(role);
    let content;
    if (role === 'researcher') content = 'The value is declared in src/math.ts.';
    else if (role === 'architect') content = 'Plan: inspect the declaration, change the value, then verify with tests.';
    else if (role === 'tester') content = 'Test plan only: assert total equals 2; no tests have been executed.';
    else if (role === 'coder') content = JSON.stringify({ files: [{ path: 'src/math.ts', content: 'export const total = 2;\n', reason: 'Correct the total used by the fixture.' }] });
    else if (role === 'reviewer') content = 'Advisory review: proposal is small; tests were not run.';
    else if (role === 'security') content = 'Advisory security review only; independent sandbox verification is still required.';
    else content = 'Unexpected role in test fixture.';
    res.writeHead(200, { 'content-type': 'application/json' });
    res.end(JSON.stringify({ id: `req-${roles.length}`, model: body.model, choices: [{ message: { content } }], usage: { prompt_tokens: 20, completion_tokens: 12 } }));
  });
  server.listen(0, '127.0.0.1'); await once(server, 'listening');
  const address = server.address();
  const beforeEnv = { base: process.env.FORGE_BASE_URL, key: process.env.OPENAI_API_KEY };
  process.env.FORGE_BASE_URL = `http://127.0.0.1:${address.port}/v1`;
  process.env.OPENAI_API_KEY = 'workflow-fixture-key';
  t.after(async () => {
    if (beforeEnv.base === undefined) delete process.env.FORGE_BASE_URL; else process.env.FORGE_BASE_URL = beforeEnv.base;
    if (beforeEnv.key === undefined) delete process.env.OPENAI_API_KEY; else process.env.OPENAI_API_KEY = beforeEnv.key;
    await new Promise((resolve) => server.close(resolve));
  });

  const objective = 'Fix the total value declared in src/math.ts to 2';
  const consent = { live: true, approveContextSharing: true, maxOutputTokens: 2000, maxDurationMs: 60000 };
  const planned = await planTask(root, objective, consent);
  assert.equal(planned.mission.status, 'needs_review');
  assert.equal(planned.usage.requestCount, 2);
  assert.equal(planned.mission.steps.find((s) => s.kind === 'research').status, 'passed');
  assert.equal(planned.mission.steps.find((s) => s.kind === 'plan').status, 'passed');

  const result = await runCodingTask(root, objective, consent, planned.mission.id);
  assert.equal(result.mission.status, 'needs_review');
  assert.deepEqual(roles, ['researcher', 'architect', 'tester', 'coder', 'reviewer', 'security']);
  assert.equal(result.usage.requestCount, 4, 'the saved research/plan outputs are reused instead of calling the model again');
  assert.equal(result.mission.steps.find((s) => s.kind === 'implement').status, 'awaiting_approval');
  assert.equal(result.mission.steps.find((s) => s.kind === 'test').status, 'blocked');
  assert.equal(result.mission.steps.find((s) => s.kind === 'review').status, 'passed');
  assert.equal(result.mission.steps.find((s) => s.kind === 'security').status, 'blocked');
  assert.equal(await readFile(join(root, 'src', 'math.ts'), 'utf8'), 'export const total = 1;\n', 'the coding workflow itself must not write files');
  const saved = await readProposedPatch(root, planned.mission.id);
  assert.equal(saved.patch.files[0].path, 'src/math.ts');

  await beginPatchApply(root, planned.mission.id); // stands for explicit user approval in this integration fixture
  const applied = await applyPatch(root, saved.patch, true);
  const afterApply = await recordPatchApplied(root, planned.mission.id, applied.checkpointId, applied.changedPaths);
  assert.equal(await readFile(join(root, 'src', 'math.ts'), 'utf8'), 'export const total = 2;\n');
  assert.equal(afterApply.status, 'verifying');
  const persisted = await (await MissionStore.open(root)).get(planned.mission.id);
  assert.ok(persisted.approvedCapabilities.includes('model'));
  assert.ok(persisted.approvedCapabilities.includes('write_workspace'));
});
