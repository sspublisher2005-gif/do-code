import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, writeFile, readFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { createHash, randomUUID } from 'node:crypto';
import { applyPatch, listCheckpoints, parseModelPatch, previewPatch, undoCheckpoint } from '../../dist/tools/patch-apply.js';
import { freezeWorkspace } from '../../dist/safety/freeze.js';
const sha = text => createHash('sha256').update(text, 'utf8').digest('hex');

async function setup(t) {
  const root = await mkdtemp(join(tmpdir(), 'forge-patch-'));
  t.after(() => rm(root, { recursive: true, force: true }));
  await writeFile(join(root, 'file.ts'), 'export const value = 1;\n');
  return root;
}

test('model patch is limited to context files and expected content hashes', async (t) => {
  const root = await setup(t); const missionId = randomUUID();
  const before = await readFile(join(root, 'file.ts'), 'utf8');
  const allowed = new Map([['file.ts', { sha256: sha(before), content: before }]]);
  const patch = parseModelPatch(JSON.stringify({ files: [{ path: 'file.ts', content: 'export const value = 2;\n', reason: 'fix' }] }), missionId, allowed);
  assert.equal(patch.files[0].expectedSha256, sha(before));
  assert.throws(() => parseModelPatch(JSON.stringify({ files: [{ path: '../outside', content: 'x' }] }), missionId, allowed));
  assert.throws(() => parseModelPatch(JSON.stringify({ files: [{ path: 'outside.ts', content: 'x' }] }), missionId, allowed), /not included in the task context/);
});

test('patch preview is non-mutating; approved patch gets checkpoint; undo restores exact content', async (t) => {
  const root = await setup(t); const missionId = randomUUID();
  const before = await readFile(join(root, 'file.ts'), 'utf8');
  const patch = parseModelPatch(JSON.stringify({ files: [{ path: 'file.ts', content: 'export const value = 2;\n', reason: 'change value' }] }), missionId, new Map([['file.ts', { sha256: sha(before), content: before }]]));
  const preview = await previewPatch(root, patch);
  assert.match(preview, /NO FILES HAVE BEEN MODIFIED/);
  assert.equal(await readFile(join(root, 'file.ts'), 'utf8'), before);
  await assert.rejects(applyPatch(root, patch, false), e => e.code === 'PATCH_APPROVAL_REQUIRED');
  const result = await applyPatch(root, patch, true);
  assert.deepEqual(result.changedPaths, ['file.ts']);
  assert.equal(await readFile(join(root, 'file.ts'), 'utf8'), 'export const value = 2;\n');
  assert.ok((await listCheckpoints(root, missionId)).includes(result.checkpointId));
  const undo = await undoCheckpoint(root, missionId, result.checkpointId, true);
  assert.deepEqual(undo.restoredPaths, ['file.ts']);
  assert.equal(await readFile(join(root, 'file.ts'), 'utf8'), before);
});

test('undo refuses to overwrite a subsequent user edit', async (t) => {
  const root = await setup(t); const missionId = randomUUID();
  const before = await readFile(join(root, 'file.ts'), 'utf8');
  const patch = parseModelPatch(JSON.stringify({ files: [{ path: 'file.ts', content: 'export const value = 2;\n', reason: 'change value' }] }), missionId, new Map([['file.ts', { sha256: sha(before), content: before }]]));
  const result = await applyPatch(root, patch, true);
  await writeFile(join(root, 'file.ts'), 'user edited after Forge\n');
  await assert.rejects(undoCheckpoint(root, missionId, result.checkpointId, true), e => e.code === 'UNDO_CONFLICT');
  assert.equal(await readFile(join(root, 'file.ts'), 'utf8'), 'user edited after Forge\n');
});

test('workspace freeze blocks patch application without changing target files', async (t) => {
  const root = await setup(t); const missionId = randomUUID();
  const before = await readFile(join(root, 'file.ts'), 'utf8');
  const patch = parseModelPatch(JSON.stringify({ files: [{ path: 'file.ts', content: 'export const value = 3;\n', reason: 'change value' }] }), missionId, new Map([['file.ts', { sha256: sha(before), content: before }]]));
  await freezeWorkspace(root, 'incident');
  await assert.rejects(applyPatch(root, patch, true), e => e.code === 'WORKSPACE_FROZEN');
  assert.equal(await readFile(join(root, 'file.ts'), 'utf8'), before);
});


test('patch proposal refuses content that resembles a credential', async (t) => {
  const root = await setup(t); const missionId = randomUUID();
  const before = await readFile(join(root, 'file.ts'), 'utf8');
  const allowed = new Map([['file.ts', { sha256: sha(before), content: before }]]);
  assert.throws(() => parseModelPatch(JSON.stringify({ files: [{ path: 'file.ts', content: 'const key = "sk-12345678901234567890abcdef";\n', reason: 'bad' }] }), missionId, allowed), e => e.code === 'PATCH_SECRET_SUSPECTED');
});
