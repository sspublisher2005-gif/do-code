import test from 'node:test';
import assert from 'node:assert/strict';
import { createServer } from 'node:http';
import { once } from 'node:events';
import { mkdtemp, readFile, writeFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';

const execFileAsync = promisify(execFile);
const cli = resolve('dist/cli/main.js');
async function run(args, cwd = process.cwd(), env = process.env) {
  return execFileAsync(process.execPath, [cli, ...args], { cwd, env, timeout: 10000, maxBuffer: 2 * 1024 * 1024 });
}
async function initialize(root) { await run(['init', '--root', root]); }

function proposal(root, vault, extra = []) {
  return ['memory', 'propose', '--root', root, '--type', 'decision', '--title', 'Prefer local PDF export', '--problem', 'Documents may contain private information', '--decision', 'Generate PDFs in the browser', '--reason', 'This avoids uploading document contents', '--rejected', 'Third-party conversion API', '--evidence', 'Recorded decision from test fixture', '--confidence', '0.85', '--scope', 'global', ...extra];
}

test('memory commands appear in CLI help and offline pilot never invents scores', async (t) => {
  const root = await mkdtemp(join(tmpdir(), 'forge-ts2-help-'));
  t.after(() => rm(root, { recursive: true, force: true }));
  const help = await run(['--help']);
  assert.match(help.stdout, /forge memory/);
  assert.match(help.stdout, /forge pilot/);
  await initialize(root);
  const result = await run(['pilot', '--root', root, '--risk', 'high', '--option', 'Local-first architecture', '--option', 'Hosted architecture', 'Choose', 'a', 'privacy-preserving', 'document', 'workflow'], root);
  assert.match(result.stdout, /DECISION ARENA LITE/);
  assert.match(result.stdout, /decision has high stated risk/);
  assert.match(result.stdout, /No options were scored or ranked/);
  assert.match(result.stdout, /no model or external research was used/i);
  await assert.rejects(run(['pilot', '--root', root, '--live', 'Choose', 'an', 'architecture'], root), (error) => {
    assert.match(error.stderr, /CONSENT_REQUIRED/);
    return true;
  });
});

test('memory proposal is not stored without explicit confirmation in non-interactive use', async (t) => {
  const root = await mkdtemp(join(tmpdir(), 'forge-ts2-memory-propose-'));
  const vault = join(root, 'local-vault');
  t.after(() => rm(root, { recursive: true, force: true }));
  await initialize(root);
  const env = { ...process.env, FORGE_MEMORY_DIR: vault };
  const proposed = await run(proposal(root, vault), root, env);
  assert.match(proposed.stdout, /MEMORY PROPOSAL — not saved yet/);
  assert.match(proposed.stdout, /Not saved/);
  assert.match(proposed.stdout, /User confirmed: not yet/);
  assert.equal(JSON.parse((await run(['memory', 'list', '--root', root], root, env)).stdout).length, 0);
});

test('confirmed memory has scoped local persistence, index verification, export/import and explicit deletion', async (t) => {
  const root = await mkdtemp(join(tmpdir(), 'forge-ts2-memory-flow-'));
  const vault = join(root, 'vault');
  t.after(() => rm(root, { recursive: true, force: true }));
  await initialize(root);
  const env = { ...process.env, FORGE_MEMORY_DIR: vault };
  const saved = await run(proposal(root, vault, ['--confirm']), root, env);
  const id = saved.stdout.match(/Saved confirmed memory: ([0-9a-f-]{36})/i)?.[1];
  assert.ok(id);
  assert.match(saved.stdout, /No memory profile or note content was sent/);
  const audit = await readFile(join(root, '.forge', 'audit.jsonl'), 'utf8');
  assert.match(audit, /memory\.note_saved/);
  assert.doesNotMatch(audit, /Documents may contain private information|Generate PDFs in the browser|Third-party conversion API/);
  const projectOnly = JSON.parse((await run(['memory', 'list', '--root', root, '--scope', 'project'], root, env)).stdout);
  assert.equal(projectOnly.length, 0);
  const searched = await run(['memory', 'search', '--root', root, '--scope', 'global', 'local', 'PDF', 'export'], root, env);
  assert.match(searched.stdout, new RegExp(id));
  const verified = await run(['memory', 'verify', '--root', root, id], root, env);
  assert.match(verified.stdout, /integrity verified/i);
  const exportPath = join(root, 'memory-export.json');
  assert.match((await run(['memory', 'export', '--root', root, exportPath], root, env)).stdout, /Exported 1 confirmed memory note/);
  await assert.rejects(run(['memory', 'forget', '--root', root, id], root, env), (error) => {
    assert.match(error.stderr, /MEMORY_CONFIRM_REQUIRED/);
    return true;
  });
  assert.match((await run(['memory', 'forget', '--root', root, id, '--confirm'], root, env)).stdout, /Forgot memory/);
  assert.equal(JSON.parse((await run(['memory', 'list', '--root', root], root, env)).stdout).length, 0);
  assert.match((await run(['memory', 'import', '--root', root, exportPath, '--confirm'], root, env)).stdout, /Imported 1 note/);
  assert.equal(JSON.parse((await run(['memory', 'list', '--root', root], root, env)).stdout).length, 1);
  assert.match((await run(['memory', 'reset', '--root', root, '--scope', 'global', '--confirm'], root, env)).stdout, /Deleted 1 memory note/);
});

test('live Decision Arena requires explicit consent and sends neither repository source nor local memory', async (t) => {
  const root = await mkdtemp(join(tmpdir(), 'forge-ts2-pilot-live-'));
  const vault = join(root, 'vault');
  t.after(() => rm(root, { recursive: true, force: true }));
  await initialize(root);
  const env = { ...process.env, FORGE_MEMORY_DIR: vault };
  await run(proposal(root, vault, ['--confirm']), root, env);
  await writeFile(join(root, 'private-source.txt'), 'REPOSITORY_SECRET_SENTINEL');

  let captured = '';
  const server = createServer(async (req, res) => {
    let body = '';
    for await (const chunk of req) body += chunk;
    captured = body;
    res.writeHead(200, { 'content-type': 'application/json' });
    res.end(JSON.stringify({ id: 'pilot-fixture', model: 'fixture-model', choices: [{ message: { content: '# Decision report\n\n## Recommendation\nChoose option A.' } }], usage: { prompt_tokens: 50, completion_tokens: 25 } }));
  });
  server.listen(0, '127.0.0.1');
  await once(server, 'listening');
  const address = server.address();
  try {
    const liveEnv = { ...env, FORGE_BASE_URL: `http://127.0.0.1:${address.port}/v1`, OPENAI_API_KEY: 'fixture-only-key' };
    const output = await run(['pilot', '--root', root, '--live', '--approve-context-sharing', '--option', 'Option A', '--option', 'Option B', 'Choose', 'between', 'Option A', 'and', 'Option B'], root, liveEnv);
    assert.match(output.stdout, /Choose option A/);
    assert.match(output.stdout, /no repository source, project\/global memory, private files/i);
    assert.match(captured, /Choose between Option A and Option B/);
    assert.doesNotMatch(captured, /DO_NOT_SEND_PRIVATE_MEMORY|REPOSITORY_SECRET_SENTINEL|private-source\.txt|Prefer local PDF export/);
  } finally {
    await new Promise((resolve, reject) => server.close((error) => error ? reject(error) : resolve()));
  }
});

test('live Decision Arena is blocked by local-only privacy mode for a remote endpoint', async (t) => {
  const root = await mkdtemp(join(tmpdir(), 'forge-ts2-pilot-local-only-'));
  t.after(() => rm(root, { recursive: true, force: true }));
  await initialize(root);
  const config = join(root, 'forge.config.toml');
  const text = await readFile(config, 'utf8');
  await writeFile(config, text.replace('mode = "ask"', 'mode = "local-only"'));
  await assert.rejects(run(['pilot', '--root', root, '--live', '--approve-context-sharing', 'Choose', 'a', 'local', 'architecture'], root, { ...process.env, OPENAI_API_KEY: 'test-only-key' }), (error) => {
    assert.match(error.stderr, /PRIVACY_REMOTE_BLOCKED/);
    return true;
  });
});


test('live Decision Arena rejects obvious credential-shaped decision text before sending it', async (t) => {
  const root = await mkdtemp(join(tmpdir(), 'forge-ts2-pilot-secret-'));
  t.after(() => rm(root, { recursive: true, force: true }));
  await initialize(root);
  let requests = 0;
  const server = createServer(async (_req, res) => {
    requests += 1;
    res.writeHead(200, { 'content-type': 'application/json' });
    res.end(JSON.stringify({ choices: [{ message: { content: 'should not be reached' } }] }));
  });
  server.listen(0, '127.0.0.1');
  await once(server, 'listening');
  const address = server.address();
  try {
    const liveEnv = { ...process.env, FORGE_BASE_URL: `http://127.0.0.1:${address.port}/v1`, OPENAI_API_KEY: 'fixture-only-key' };
    await assert.rejects(run(['pilot', '--root', root, '--live', '--approve-context-sharing', 'Configure secret sk-123456789012345678901234 for the test'], root, liveEnv), (error) => {
      assert.match(error.stderr, /PILOT_SECRET_SUSPECTED/);
      return true;
    });
    assert.equal(requests, 0);
  } finally {
    await new Promise((resolve, reject) => server.close((error) => error ? reject(error) : resolve()));
  }
});
