import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, writeFile, mkdir, symlink, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { buildRepositoryIndex, saveRepositoryIndex, loadRepositoryIndex, buildTaskContextPack } from '../../dist/context/repository.js';

test('repository index extracts heuristic symbols/imports and context pack observes limits', async (t) => {
  const root = await mkdtemp(join(tmpdir(), 'forge-context-'));
  t.after(() => rm(root, { recursive: true, force: true }));
  await mkdir(join(root, 'src'));
  await writeFile(join(root, 'FORGE.md'), '# Project guidance\nPrefer small safe edits.');
  await writeFile(join(root, 'src', 'math.ts'), 'export function calculateTotal(items: number[]) { return items.reduce((a,b) => a+b, 0); }\n');
  await writeFile(join(root, 'src', 'app.ts'), 'import { calculateTotal } from "./math.js";\nexport const total = calculateTotal([1,2]);\n');
  await writeFile(join(root, '.env'), 'API_KEY=super-secret');
  const index = await buildRepositoryIndex(root, { maxFiles: 100, maxTotalBytes: 1024 * 1024 });
  assert.ok(index.files.some(f => f.path === 'src/math.ts' && f.symbols.includes('calculateTotal')));
  assert.ok(index.edges.some(e => e.from === 'src/app.ts' && e.resolved));
  assert.ok(!index.files.some(f => f.path.includes('.env')));
  await saveRepositoryIndex(root, index);
  const loaded = await loadRepositoryIndex(root);
  assert.equal(loaded.root, index.root);
  const pack = await buildTaskContextPack(root, 'calculateTotal in math.ts', { maxFiles: 2, maxChars: 3000 });
  assert.ok(pack.files.some(f => f.path === 'src/math.ts'));
  assert.ok(pack.usedChars <= pack.maxChars);
  assert.ok(pack.warnings.some(w => /untrusted input/.test(w)));
});

test('repository index fails closed when stored index belongs to another project', async (t) => {
  const a = await mkdtemp(join(tmpdir(), 'forge-index-a-'));
  const b = await mkdtemp(join(tmpdir(), 'forge-index-b-'));
  t.after(async () => { await rm(a,{recursive:true,force:true}); await rm(b,{recursive:true,force:true}); });
  await writeFile(join(a,'README.md'),'alpha');
  await writeFile(join(b,'README.md'),'beta');
  await saveRepositoryIndex(a, await buildRepositoryIndex(a));
  await assert.rejects(loadRepositoryIndex(b), (error) => error.code === 'INDEX_NOT_FOUND');
});


test('secret-like source content is excluded from the index and context pack at build time', async (t) => {
  const root = await mkdtemp(join(tmpdir(), 'forge-secret-context-'));
  t.after(() => rm(root, { recursive: true, force: true }));
  await mkdir(join(root, 'src'));
  await writeFile(join(root, 'README.md'), '# safe project');
  await writeFile(join(root, 'src', 'leak.ts'), 'export const leaked = "sk-12345678901234567890abcdef";\n');
  await saveRepositoryIndex(root, await buildRepositoryIndex(root));
  const loaded = await loadRepositoryIndex(root);
  assert.ok(!loaded.files.some(f => f.path === 'src/leak.ts'));
  assert.ok(loaded.warnings.some(w => /secret-like content/i.test(w)));
  const pack = await buildTaskContextPack(root, 'leaked', { maxFiles: 10, maxChars: 5000 });
  assert.ok(!pack.files.some(f => f.path === 'src/leak.ts'));
  assert.ok(!pack.files.some(f => f.content.includes('sk-12345678901234567890abcdef')));
  assert.ok(pack.warnings.some(w => /secret-like content/i.test(w))); 
});

test('context builder rejects a task that appears to contain a secret', async (t) => {
  const root = await mkdtemp(join(tmpdir(), 'forge-secret-task-'));
  t.after(() => rm(root, { recursive: true, force: true }));
  await writeFile(join(root, 'README.md'), '# project');
  await saveRepositoryIndex(root, await buildRepositoryIndex(root));
  await assert.rejects(buildTaskContextPack(root, 'use api_key=abcd1234secret'), e => e.code === 'CONTEXT_SECRET_SUSPECTED');
});


test('repository index honors common .gitignore patterns but still enforces secret filtering', async (t) => {
  const root = await mkdtemp(join(tmpdir(), 'forge-gitignore-'));
  t.after(() => rm(root, { recursive: true, force: true }));
  await mkdir(join(root, 'build'), { recursive: true });
  await mkdir(join(root, 'src'), { recursive: true });
  await writeFile(join(root, '.gitignore'), 'build/\n*.generated.ts\n!keep.generated.ts\n');
  await writeFile(join(root, 'build', 'generated.ts'), 'export const shouldSkip = true;');
  await writeFile(join(root, 'src', 'remove.generated.ts'), 'export const shouldSkipToo = true;');
  await writeFile(join(root, 'keep.generated.ts'), 'export const reinclude = true;');
  await writeFile(join(root, '.env'), 'SECRET=still-blocked');
  const index = await buildRepositoryIndex(root);
  assert.ok(!index.files.some(f => f.path === 'build/generated.ts'));
  assert.ok(!index.files.some(f => f.path === 'src/remove.generated.ts'));
  assert.ok(index.files.some(f => f.path === 'keep.generated.ts'));
  assert.ok(!index.files.some(f => f.path === '.env'));
});

test('context pack never truncates a file that may later be replaced wholesale', async (t) => {
  const root = await mkdtemp(join(tmpdir(), 'forge-context-budget-'));
  t.after(() => rm(root, { recursive: true, force: true }));
  await writeFile(join(root, 'FORGE.md'), '# guidance\n'.padEnd(100, 'x'));
  await writeFile(join(root, 'src-large.txt'), 'A'.repeat(1950));
  await writeFile(join(root, 'README.md'), 'small readme');
  await saveRepositoryIndex(root, await buildRepositoryIndex(root));
  const pack = await buildTaskContextPack(root, 'review README src-large', { maxFiles: 10, maxChars: 2000 });
  assert.ok(pack.usedChars <= 2000);
  assert.ok(!pack.files.some(f => f.content.includes('FORGE: file excerpt truncated')));
  assert.ok(pack.omitted.some(f => /complete file exceeds remaining context budget/.test(f.reason)));
});
