import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, writeFile, readFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { SafeFileTools } from '../../dist/tools/safe-files.js';

test('file tools can preview proposed contents without mutating workspace hashes', async (t) => {
  const root = await mkdtemp(join(tmpdir(), 'forge-dry-run-'));
  t.after(() => rm(root, { recursive: true, force: true }));
  const path = join(root, 'current.txt');
  await writeFile(path, 'unchanged');
  const before = await readFile(path, 'utf8');
  const files = await SafeFileTools.create(root);
  const preview = files.writePreview('current.txt', 'proposed');
  assert.equal(preview.mutationPerformed, false);
  assert.equal(await readFile(path, 'utf8'), before);
  assert.equal(preview.preview, 'proposed');
});
