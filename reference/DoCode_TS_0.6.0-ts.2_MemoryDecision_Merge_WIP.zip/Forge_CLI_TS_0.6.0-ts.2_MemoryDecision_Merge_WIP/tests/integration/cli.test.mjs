import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, readFile, lstat, rm, symlink } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
const execFileAsync = promisify(execFile);
const cli = resolve('dist/cli/main.js');

async function run(args, cwd = process.cwd(), env = process.env) {
  return execFileAsync(process.execPath, [cli, ...args], { cwd, env, timeout: 8000, maxBuffer: 1024 * 1024 });
}

test('CLI help and version are deterministic and do not initialize project state', async () => {
  const help = await run(['--help']);
  assert.match(help.stdout, /Forge CLI v0\.6\.0-ts\.2/);
  assert.match(help.stdout, /forge run/);
  assert.match(help.stdout, /General host shell\/tests remain blocked/);
  const version = await run(['--version']);
  assert.equal(version.stdout.trim(), '0.6.0-ts.2');
});

test('forge init is local-only and preserves existing files on repeat runs', async (t) => {
  const root = await mkdtemp(join(tmpdir(), 'forge-cli-init-'));
  t.after(() => rm(root, { recursive: true, force: true }));
  const first = await run(['init', '--root', root]);
  assert.match(first.stdout, /Network: not used/);
  const configBefore = await readFile(join(root, 'forge.config.toml'), 'utf8');
  const memoryBefore = await readFile(join(root, 'FORGE.md'), 'utf8');
  await run(['init', '--root', root]);
  assert.equal(await readFile(join(root, 'forge.config.toml'), 'utf8'), configBefore);
  assert.equal(await readFile(join(root, 'FORGE.md'), 'utf8'), memoryBefore);
  const privateHome = await lstat(join(root, '.forge'));
  assert.equal(privateHome.isDirectory(), true);
  const log = await readFile(join(root, '.forge', 'audit.jsonl'), 'utf8');
  assert.equal(log.trim().split('\n').length, 2);
});

test('model test defaults to config-only and rejects live request without context-sharing approval', async (t) => {
  const root = await mkdtemp(join(tmpdir(), 'forge-cli-model-'));
  t.after(() => rm(root, { recursive: true, force: true }));
  await run(['init', '--root', root]);
  const offline = await run(['model', 'test', '--root', root]);
  assert.match(offline.stdout, /no model\/network request was sent/i);
  await assert.rejects(run(['model', 'test', '--root', root, '--live']), (error) => {
    assert.match(error.stderr, /CONSENT_REQUIRED/);
    return true;
  });
});

test('coding workflow is implemented but fails closed without explicit remote-context consent', async (t) => {
  const root = await mkdtemp(join(tmpdir(), 'forge-cli-run-consent-'));
  t.after(() => rm(root, { recursive: true, force: true }));
  await run(['init', '--root', root]);
  await assert.rejects(run(['run', 'do something', '--root', root]), (error) => {
    assert.match(error.stderr, /CONSENT_REQUIRED/);
    return true;
  });
});


test('CLI entrypoint executes when invoked through a symlink like npm-installed binaries', async (t) => {
  const root = await mkdtemp(join(tmpdir(), 'forge-cli-symlink-'));
  t.after(() => rm(root, { recursive: true, force: true }));
  const linked = join(root, 'forge');
  await symlink(cli, linked);
  const result = await execFileAsync(process.execPath, [linked, '--version'], { cwd: root, timeout: 8000 });
  assert.equal(result.stdout.trim(), '0.6.0-ts.2');
});


test('sandbox self-test runs only a fixed isolated fixture and reports non-production status', { skip: process.platform !== 'linux' }, async () => {
  const result = await run(['sandbox', 'self-test']);
  const parsed = JSON.parse(result.stdout);
  assert.equal(parsed.status, 'passed');
  assert.equal(parsed.productionReady, false);
  assert.equal(parsed.landlock, false);
  assert.equal(parsed.seccompBpf, false);
});
