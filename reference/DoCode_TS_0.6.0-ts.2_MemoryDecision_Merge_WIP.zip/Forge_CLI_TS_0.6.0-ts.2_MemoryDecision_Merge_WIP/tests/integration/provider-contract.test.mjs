import test from 'node:test';
import assert from 'node:assert/strict';
import { createServer } from 'node:http';
import { once } from 'node:events';
import { OpenAICompatibleProvider } from '../../dist/providers/openai-compatible.js';

async function withServer(handler, run) {
  const server = createServer(handler);
  server.listen(0, '127.0.0.1');
  await once(server, 'listening');
  const address = server.address();
  try { await run(`http://127.0.0.1:${address.port}/v1`, server); }
  finally { await new Promise((resolve, reject) => server.close((e) => e ? reject(e) : resolve())); }
}

test('OpenAI-compatible adapter maps text, usage, request ID and unknown cost', async () => {
  await withServer(async (req, res) => {
    let body = '';
    for await (const chunk of req) body += chunk;
    assert.equal(req.method, 'POST');
    assert.equal(req.url, '/v1/chat/completions');
    assert.equal(req.headers.authorization, 'Bearer test-key');
    const request = JSON.parse(body);
    assert.equal(request.model, 'fixture-model');
    assert.equal(request.messages[0].role, 'system');
    res.writeHead(200, { 'content-type': 'application/json' });
    res.end(JSON.stringify({ id: 'req-fixture', model: 'fixture-model', choices: [{ message: { content: 'FORGE_TEST_OK' } }], usage: { prompt_tokens: 7, completion_tokens: 3, cost: 0.001 } }));
  }, async (baseUrl) => {
    const provider = new OpenAICompatibleProvider({ baseUrl, apiKey: 'test-key' });
    const response = await provider.generate({ model: 'fixture-model', role: 'orchestrator', system: 'You are testing.', messages: [{ role: 'user', content: 'Reply ok' }], maxOutputTokens: 20, timeoutMs: 3000 });
    assert.equal(response.text, 'FORGE_TEST_OK');
    assert.equal(response.usage.inputTokens, 7);
    assert.equal(response.usage.outputTokens, 3);
    assert.equal(response.usage.costKnown, false);
    assert.equal(response.usage.costUsd, undefined);
    assert.equal(response.requestId, 'req-fixture');
  });
});

test('OpenAI-compatible adapter does not leak provider error bodies', async () => {
  await withServer((_req, res) => {
    res.writeHead(500, { 'content-type': 'application/json' });
    res.end(JSON.stringify({ error: 'private detail sk-111111111111111111111111' }));
  }, async (baseUrl) => {
    const provider = new OpenAICompatibleProvider({ baseUrl, apiKey: 'test-key' });
    await assert.rejects(provider.generate({ model: 'fixture-model', role: 'orchestrator', system: 'test', messages: [{ role: 'user', content: 'hi' }], maxOutputTokens: 8, timeoutMs: 3000 }), (error) => {
      assert.match(error.message, /HTTP 500/);
      assert.doesNotMatch(error.message, /private detail|sk-111/);
      return true;
    });
  });
});


test('healthCheck is network-silent unless explicit network consent is passed', async () => {
  let requests = 0;
  const provider = new OpenAICompatibleProvider({
    baseUrl: 'https://provider.example/v1',
    apiKey: 'test-key',
    fetchImpl: async () => {
      requests += 1;
      return new Response(JSON.stringify({ data: [] }), { status: 200, headers: { 'content-type': 'application/json' } });
    },
  });
  const offline = await provider.healthCheck();
  assert.equal(offline.ok, false);
  assert.match(offline.detail, /explicit networkConsent/);
  assert.equal(requests, 0);
  const live = await provider.healthCheck({ networkConsent: true });
  assert.equal(live.ok, true);
  assert.equal(requests, 1);
});

test('adapter only treats explicit cost_usd as USD-denominated cost', async () => {
  await withServer(async (_req, res) => {
    res.writeHead(200, { 'content-type': 'application/json' });
    res.end(JSON.stringify({ choices: [{ message: { content: 'ok' } }], usage: { prompt_tokens: 1, completion_tokens: 1, cost: 1 } }));
  }, async (baseUrl) => {
    const provider = new OpenAICompatibleProvider({ baseUrl, apiKey: 'test-key' });
    const response = await provider.generate({ model: 'fixture-model', role: 'orchestrator', system: 'test', messages: [{ role: 'user', content: 'hi' }], maxOutputTokens: 8, timeoutMs: 3000 });
    assert.equal(response.usage.costKnown, false);
    assert.equal(response.usage.costUsd, undefined);
  });
});


test('provider adapter rejects oversized responses without parsing them', async () => {
  const provider = new OpenAICompatibleProvider({
    baseUrl: 'https://provider.example/v1',
    apiKey: 'test-key',
    fetchImpl: async () => new Response('x'.repeat(2 * 1024 * 1024 + 16), { status: 200 }),
  });
  await assert.rejects(
    provider.generate({ model: 'fixture-model', role: 'orchestrator', system: 'test', messages: [{ role: 'user', content: 'hi' }], maxOutputTokens: 8, timeoutMs: 3000 }),
    /2-byte|2097152-byte limit/
  );
});
