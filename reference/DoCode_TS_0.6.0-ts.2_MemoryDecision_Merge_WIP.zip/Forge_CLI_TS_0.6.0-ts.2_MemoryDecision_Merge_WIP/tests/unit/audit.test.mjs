import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, readFile, appendFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { appendAudit, readAuditTail } from '../../dist/audit/jsonl.js';

test('audit log is JSONL, sequenced, and redacts common secrets before persistence', async (t) => {
  const root = await mkdtemp(join(tmpdir(), 'forge-audit-'));
  t.after(() => rm(root, { recursive: true, force: true }));
  await appendAudit(root, { event: 'unit.first', outcome: 'succeeded', details: { token: 'super-secret', message: 'Authorization: Bearer abcdefghijklmnopqrstuvwxyz', plain: 'safe' } });
  await appendAudit(root, { event: 'unit.second', outcome: 'info', details: { value: 'sk-123456789012345678901234' } });
  const path = join(root, '.forge', 'audit.jsonl');
  const raw = await readFile(path, 'utf8');
  assert.ok(!raw.includes('super-secret'));
  assert.ok(!raw.includes('abcdefghijklmnopqrstuvwxyz'));
  assert.ok(!raw.includes('sk-123456789012345678901234'));
  const tail = await readAuditTail(root, 10);
  assert.equal(tail.events.length, 2);
  assert.equal(tail.events[0].sequence, 1);
  assert.equal(tail.events[1].sequence, 2);
});

test('audit reader tolerates a corrupt trailing line without treating it as valid evidence', async (t) => {
  const root = await mkdtemp(join(tmpdir(), 'forge-audit-corrupt-'));
  t.after(() => rm(root, { recursive: true, force: true }));
  await appendAudit(root, { event: 'good', outcome: 'succeeded' });
  await appendFile(join(root, '.forge', 'audit.jsonl'), '{bad-json\n');
  const tail = await readAuditTail(root, 10);
  assert.equal(tail.events.length, 1);
  assert.equal(tail.corruptLines, 1);
});


test('audit rejects a single oversized event before changing the log', async (t) => {
  const root = await mkdtemp(join(tmpdir(), 'forge-audit-large-'));
  t.after(() => rm(root, { recursive: true, force: true }));
  await appendAudit(root, { event: 'good', outcome: 'succeeded' });
  const path = join(root, '.forge', 'audit.jsonl');
  const before = await readFile(path, 'utf8');
  await assert.rejects(appendAudit(root, { event: 'large', outcome: 'info', details: { message: 'x'.repeat(20 * 1024) } }), /16 KiB per-event limit/);
  assert.equal(await readFile(path, 'utf8'), before);
});
