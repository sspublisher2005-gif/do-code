import test from 'node:test';
import assert from 'node:assert/strict';
import { shouldTriggerDecisionArena } from '../../dist/decisions/trigger.js';

test('simple task does not trigger Decision Arena', () => {
  const result = shouldTriggerDecisionArena({});
  assert.equal(result.shouldRun, false);
  assert.equal(result.reasonCode, 'SIMPLE_TASK_NO_ARENA');
  assert.deepEqual(result.reasons, []);
});

test('explicit comparison, high risk, cost threshold, security, or two failures trigger Decision Arena', () => {
  for (const signal of [
    { explicitRequest: true },
    { comparisonRequested: true },
    { risk: 'high' },
    { estimatedCostUsd: 5 },
    { priorFailures: 2 },
    { securitySensitive: true },
    { privacySensitive: true },
    { financialImpact: true },
    { productionImpact: true },
    { strategicImportance: true },
    { architectureAlternatives: 2 },
    { uncertainty: 'high' },
  ]) assert.equal(shouldTriggerDecisionArena(signal).shouldRun, true, JSON.stringify(signal));
});

test('cost threshold can be tuned and prior failure count below two does not trigger alone', () => {
  assert.equal(shouldTriggerDecisionArena({ estimatedCostUsd: 4.99 }).shouldRun, false);
  assert.equal(shouldTriggerDecisionArena({ estimatedCostUsd: 4.99, costThresholdUsd: 4 }).shouldRun, true);
  assert.equal(shouldTriggerDecisionArena({ priorFailures: 1 }).shouldRun, false);
});
