import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, readFile, writeFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { EvidenceStore } from '../../dist/evidence/store.js';
import { randomUUID } from 'node:crypto';

test('evidence is content-addressed, private, and verified when loaded', async (t) => {
  const root = await mkdtemp(join(tmpdir(), 'forge-evidence-'));
  t.after(() => rm(root, { recursive: true, force: true }));
  const missionId = randomUUID();
  const store = await EvidenceStore.open(root);
  const ref = await store.put({ missionId, kind: 'test_log', producedBy: 'test-fixture', content: 'TEST PASS', metadata: { exitCode: 0 } });
  assert.equal(ref.verified, true);
  assert.equal(ref.byteLength, 9);
  const read = await store.get(missionId, ref.id);
  assert.equal(read.content.toString(), 'TEST PASS');
  assert.equal(read.ref.sha256, ref.sha256);
  assert.equal((await store.list(missionId)).length, 1);
});

test('evidence inspection surfaces corrupted blobs instead of silently losing them', async (t) => {
  const root = await mkdtemp(join(tmpdir(), 'forge-evidence-corrupt-'));
  t.after(() => rm(root, { recursive: true, force: true }));
  const missionId = randomUUID();
  const store = await EvidenceStore.open(root);
  const ref = await store.put({ missionId, kind: 'model_response', producedBy: 'test-fixture', content: 'original' });
  await writeFile(join(root, '.forge', 'evidence', missionId, `${ref.id}.bin`), 'tampered');
  await assert.rejects(store.get(missionId, ref.id), (error) => error.code === 'EVIDENCE_HASH_MISMATCH');
  const inspection = await store.inspect(missionId);
  assert.equal(inspection.refs.length, 0);
  assert.deepEqual(inspection.corruptArtifacts, [ref.id]);
});

test('evidence rejects oversize and invalid IDs before writing', async (t) => {
  const root = await mkdtemp(join(tmpdir(), 'forge-evidence-limits-'));
  t.after(() => rm(root, { recursive: true, force: true }));
  const store = await EvidenceStore.open(root);
  await assert.rejects(store.put({ missionId: 'wrong', kind: 'test_log', producedBy: 'test', content: 'x' }), (error) => error.code === 'EVIDENCE_ID_INVALID');
  await assert.rejects(store.put({ missionId: randomUUID(), kind: 'test_log', producedBy: 'test', content: Buffer.alloc(10 * 1024 * 1024 + 1) }), (error) => error.code === 'EVIDENCE_TOO_LARGE');
});


test('string evidence and metadata are redacted before persistence', async (t) => {
  const root = await mkdtemp(join(tmpdir(), 'forge-evidence-redact-'));
  t.after(() => rm(root, { recursive: true, force: true }));
  const store = await EvidenceStore.open(root); const missionId = randomUUID();
  const ref = await store.put({ missionId, kind: 'model_response', producedBy: 'test', content: 'response sk-12345678901234567890abcdef', metadata: { note: 'Bearer super-secret-token' } });
  const loaded = await store.get(missionId, ref.id);
  assert.ok(!loaded.content.toString().includes('sk-12345678901234567890abcdef'));
  assert.match(loaded.content.toString(), /REDACTED_OPENAI_KEY/);
  assert.ok(!String(ref.metadata.note).includes('super-secret-token'));
});
