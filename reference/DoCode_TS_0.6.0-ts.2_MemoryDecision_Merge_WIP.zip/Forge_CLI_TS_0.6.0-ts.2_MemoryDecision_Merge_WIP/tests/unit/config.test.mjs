import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, writeFile, symlink, mkdir, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { parseTomlSubset, validateConfig } from '../../dist/config/schema.js';
import { DEFAULT_CONFIG } from '../../dist/config/defaults.js';
import { loadConfig } from '../../dist/config/load.js';

const valid = `[project]\nname = "test"\n\n[model]\nprovider = "openai-compatible"\nmodel = "example-model"\nbase_url = "https://api.example.test/v1"\napi_key_env = "OPENAI_API_KEY"\nmax_output_tokens = 100\ntimeout_ms = 10000\n\n[privacy]\nmode = "ask"\ntelemetry = false\n\n[limits]\nmax_read_bytes = 2048\nmax_files = 25\nmax_search_matches = 10\n`;

test('config defaults are stable and telemetry is disabled', () => {
  assert.equal(DEFAULT_CONFIG.privacy.telemetry, false);
  assert.equal(DEFAULT_CONFIG.privacy.mode, 'ask');
  assert.equal(DEFAULT_CONFIG.model.provider, 'openai-compatible');
});

test('strict TOML subset parses config and validates known values', () => {
  const cfg = validateConfig(parseTomlSubset(valid), DEFAULT_CONFIG);
  assert.equal(cfg.project.name, 'test');
  assert.equal(cfg.model.max_output_tokens, 100);
  assert.equal(cfg.limits.max_files, 25);
});

test('unknown config keys and sections fail closed', () => {
  assert.throws(() => parseTomlSubset(`[model]\nmodel = "x"\nunknown = true\n`), /Unknown config key/);
  assert.throws(() => parseTomlSubset(`[shell]\ncommand = "sh"\n`), /Unknown config section/);
});

test('unsafe endpoint schemes, credential-bearing URLs and telemetry enablement are rejected', () => {
  assert.throws(() => validateConfig(parseTomlSubset(valid.replace('https://api.example.test/v1', 'http://api.example.test/v1')), DEFAULT_CONFIG), /HTTPS/);
  assert.throws(() => validateConfig(parseTomlSubset(valid.replace('https://api.example.test/v1', 'https://user:pass@api.example.test/v1')), DEFAULT_CONFIG), /HTTPS|credentials/);
  assert.throws(() => validateConfig(parseTomlSubset(valid.replace('telemetry = false', 'telemetry = true')), DEFAULT_CONFIG), /telemetry/);
});

test('missing config returns defaults; symlink config is rejected', async (t) => {
  const root = await mkdtemp(join(tmpdir(), 'forge-config-'));
  t.after(() => rm(root, { recursive: true, force: true }));
  const missing = await loadConfig(root);
  assert.equal(missing.exists, false);
  await writeFile(join(root, 'external.toml'), valid);
  await symlink(join(root, 'external.toml'), join(root, 'forge.config.toml'));
  await assert.rejects(loadConfig(root), /regular file|symlink/i);
});


test('config rejects unrelated environment variables as model API key sources', () => {
  const config = `[project]\nname = "test"\n\n[model]\nprovider = "openai-compatible"\napi_key_env = "AWS_SECRET_ACCESS_KEY"\n`;
  assert.throws(() => validateConfig(parseTomlSubset(config), DEFAULT_CONFIG), /documented model-credential environment variable/);
});
