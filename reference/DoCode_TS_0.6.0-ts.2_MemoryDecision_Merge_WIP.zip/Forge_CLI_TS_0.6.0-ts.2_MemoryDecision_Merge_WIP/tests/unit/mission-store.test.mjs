import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, readFile, writeFile, rm, mkdir, utimes } from 'node:fs/promises';
import { tmpdir, hostname } from 'node:os';
import { join } from 'node:path';
import { MissionStore } from '../../dist/persistence/mission-store.js';

async function workspace(t) {
  const root = await mkdtemp(join(tmpdir(), 'forge-missions-'));
  t.after(() => rm(root, { recursive: true, force: true }));
  return root;
}

test('mission persistence binds state to a project and uses a legal state machine', async (t) => {
  const root = await workspace(t);
  const store = await MissionStore.open(root);
  const created = await store.create('Add input validation');
  assert.equal(created.status, 'draft');
  assert.equal(created.steps.length >= 6, true);
  assert.equal(created.steps[1].dependsOn[0], created.steps[0].id);
  assert.deepEqual(await store.list().then(xs => xs.map(x => x.id)), [created.id]);
  await store.transition(created.id, 'ready');
  await store.transition(created.id, 'running');
  await assert.rejects(store.transition(created.id, 'completed'), (error) => error.code === 'INVALID_MISSION_TRANSITION');
  const read = await store.get(created.id);
  assert.equal(read.status, 'running');
  assert.equal(read.repoRoot, root);
});

test('tampered mission state is detected and never overwritten by update', async (t) => {
  const root = await workspace(t);
  const store = await MissionStore.open(root);
  const mission = await store.create('Integrity check');
  const file = join(root, '.forge', 'missions', `${mission.id}.json`);
  const raw = JSON.parse(await readFile(file, 'utf8'));
  raw.mission.objective = 'tampered';
  await writeFile(file, JSON.stringify(raw));
  await assert.rejects(store.get(mission.id), (error) => error.code === 'MISSION_STATE_INTEGRITY');
  await assert.rejects(store.update(mission.id, m => m), (error) => error.code === 'MISSION_STATE_INTEGRITY');
});

test('mission update lock rejects concurrent mutation and does not steal a fresh lock', async (t) => {
  const root = await workspace(t);
  const store = await MissionStore.open(root);
  const mission = await store.create('Lock test');
  let release;
  const hold = new Promise(resolve => { release = resolve; });
  const first = store.withLock(mission.id, async () => { await hold; return 'done'; });
  await new Promise(resolve => setTimeout(resolve, 25));
  await assert.rejects(store.withLock(mission.id, async () => 'should not run'), (error) => error.code === 'MISSION_LOCKED');
  release();
  assert.equal(await first, 'done');
});

test('stale lock is recovered only for a dead local process and matching root', async (t) => {
  const root = await workspace(t);
  const store = await MissionStore.open(root);
  const mission = await store.create('Stale lock');
  const lockPath = join(root, '.forge', 'locks', `${mission.id}.lock`);
  await writeFile(lockPath, JSON.stringify({ token: 'dead-token', pid: 2147483647, host: hostname(), createdAt: new Date(Date.now() - 120000).toISOString(), root }));
  const ok = await store.withLock(mission.id, async () => 'recovered');
  assert.equal(ok, 'recovered');
});


test('mission store does not persist an objective that appears to contain a credential', async (t) => {
  const root = await workspace(t);
  const store = await MissionStore.open(root);
  await assert.rejects(store.create('Deploy with api_key=abcd1234secret'), e => e.code === 'MISSION_SECRET_SUSPECTED');
  assert.deepEqual(await store.list(), []);
});
