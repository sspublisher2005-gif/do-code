import test from 'node:test';
import assert from 'node:assert/strict';
import { assertMissionTransition, assertStepTransition } from '../../dist/core/mission-state.js';

test('mission state machine permits only explicit transitions', () => {
  assert.doesNotThrow(() => assertMissionTransition('draft', 'ready'));
  assert.doesNotThrow(() => assertMissionTransition('verifying', 'completed'));
  assert.throws(() => assertMissionTransition('completed', 'running'), /not allowed/);
  assert.throws(() => assertMissionTransition('draft', 'completed'), /not allowed/);
});

test('step state machine blocks a failed step from claiming pass', () => {
  assert.doesNotThrow(() => assertStepTransition('running', 'passed'));
  assert.throws(() => assertStepTransition('running', 'skipped'), /not allowed/);
  assert.throws(() => assertStepTransition('passed', 'running'), /not allowed/);
});
