import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, readFile, writeFile, rm, symlink, mkdir } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { findMemoryNote, listMemoryNotes, parseMarkdown, proposeMemory, reindexMemory, saveMemoryNote, searchMemory, verifyMemoryNote } from '../../dist/memory/markdown-store.js';

async function withVault(t) {
  const old = process.env.FORGE_MEMORY_DIR;
  const dir = await mkdtemp(join(tmpdir(), 'forge-vault-'));
  process.env.FORGE_MEMORY_DIR = join(dir, 'vault');
  t.after(async () => { if (old === undefined) delete process.env.FORGE_MEMORY_DIR; else process.env.FORGE_MEMORY_DIR = old; await rm(dir, { recursive: true, force: true }); });
  const root = await mkdtemp(join(tmpdir(), 'forge-memory-project-'));
  t.after(() => rm(root, { recursive: true, force: true }));
  return { root, base: process.env.FORGE_MEMORY_DIR };
}

const decision = (scope = 'global', overrides = {}) => ({ type: 'decision', title: 'Prefer local PDF export', problem: 'A privacy-sensitive document export must be implemented', decision: 'Use client-side PDF export', reason: 'It avoids uploading user documents to a third party', rejectedOptions: ['Third-party conversion API'], limitations: ['Very large documents may use more browser memory'], evidence: ['Mission 4 chose local export', 'Mission 9 rejected an external API'], confidence: 0.85, scope, ...overrides });

test('memory notes require a structured decision and are stored as human-readable Obsidian Markdown plus JSON index', async (t) => {
  const { root, base } = await withVault(t);
  const note = await proposeMemory(root, decision());
  const saved = await saveMemoryNote(root, note, { confirmed: true });
  assert.match(saved.raw, /^---\nforge_schema_version: 1/m);
  assert.match(saved.raw, /## Rejected options/);
  assert.match(saved.raw, /Third-party conversion API/);
  assert.equal((await verifyMemoryNote(root, note.id)).integrity, 'verified');
  const index = JSON.parse(await readFile(join(base, 'global', 'index.json'), 'utf8'));
  assert.equal(index.schemaVersion, 1);
  assert.equal(index.entries[0].id, note.id);
});

test('memory keyword search ranks title hits and separates global from project scope', async (t) => {
  const { root } = await withVault(t);
  const globalNote = await proposeMemory(root, decision('global'));
  await saveMemoryNote(root, globalNote, { confirmed: true });
  const projectNote = await proposeMemory(root, decision('project', { title: 'Keep project API local' }));
  await saveMemoryNote(root, projectNote, { confirmed: true });
  assert.equal((await listMemoryNotes(root, 'global')).length, 1);
  assert.equal((await listMemoryNotes(root, 'project')).length, 1);
  const hits = await searchMemory(root, 'local PDF export');
  assert.equal(hits[0].note.id, globalNote.id);
  const otherRoot = await mkdtemp(join(tmpdir(), 'forge-memory-other-'));
  t.after(() => rm(otherRoot, { recursive: true, force: true }));
  assert.deepEqual((await listMemoryNotes(otherRoot, 'project')), []);
});

test('solution/research/failure/workflow memories require evidence references', async (t) => {
  const { root } = await withVault(t);
  for (const type of ['solution', 'research', 'failure', 'workflow']) {
    await assert.rejects(proposeMemory(root, decision('global', { type, evidence: [] })), (error) => error.code === 'MEMORY_EVIDENCE_REQUIRED');
  }
});

test('memory verifier detects stale index after external edit and reindex explicitly accepts the reviewed edit', async (t) => {
  const { root } = await withVault(t);
  const note = await proposeMemory(root, decision());
  const saved = await saveMemoryNote(root, note, { confirmed: true });
  const changed = saved.raw.replace('client-side PDF export', 'browser-side PDF export');
  await writeFile(saved.path, changed, { mode: 0o600 });
  await assert.rejects(verifyMemoryNote(root, note.id), (error) => error.code === 'MEMORY_INDEX_STALE');
  await reindexMemory(root, 'global');
  const verified = await verifyMemoryNote(root, note.id);
  assert.equal(verified.integrity, 'verified');
  assert.match(parseMarkdown(await readFile(saved.path, 'utf8')).decision, /browser-side/);
});

test('malformed frontmatter is rejected', async () => {
  assert.throws(() => parseMarkdown('---\nforge_id: "not-a-uuid"\n---\n# invalid\n'), /schema|invalid/i);
});

test('configured vault root symlink is rejected', async (t) => {
  const parent = await mkdtemp(join(tmpdir(), 'forge-vault-symlink-'));
  const target = join(parent, 'target');
  const alias = join(parent, 'alias');
  await mkdir(target);
  await symlink(target, alias);
  const old = process.env.FORGE_MEMORY_DIR;
  process.env.FORGE_MEMORY_DIR = alias;
  t.after(async () => { if (old === undefined) delete process.env.FORGE_MEMORY_DIR; else process.env.FORGE_MEMORY_DIR = old; await rm(parent, { recursive: true, force: true }); });
  const root = await mkdtemp(join(tmpdir(), 'forge-memory-root-'));
  t.after(() => rm(root, { recursive: true, force: true }));
  await assert.rejects(listMemoryNotes(root), (error) => error.code === 'MEMORY_VAULT_UNSAFE');
});

test('memory import pre-validates project scope and refuses an entire cross-project bundle before writing anything', async (t) => {
  const { root, base } = await withVault(t);
  const globalNote = await proposeMemory(root, decision('global'));
  await saveMemoryNote(root, globalNote, { confirmed: true });
  const projectNote = await proposeMemory(root, decision('project', { title: 'Project-specific rule' }));
  await saveMemoryNote(root, projectNote, { confirmed: true });
  const exportPath = join(base, 'test-export.json');
  const { exportMemory, importMemory } = await import('../../dist/memory/markdown-store.js');
  await exportMemory(root, exportPath, 'all');
  const otherDir = await mkdtemp(join(tmpdir(), 'forge-other-vault-'));
  const oldVault = process.env.FORGE_MEMORY_DIR;
  process.env.FORGE_MEMORY_DIR = join(otherDir, 'vault');
  const otherRoot = await mkdtemp(join(tmpdir(), 'forge-other-project-'));
  t.after(async () => {
    if (oldVault === undefined) delete process.env.FORGE_MEMORY_DIR; else process.env.FORGE_MEMORY_DIR = oldVault;
    await rm(otherDir, { recursive: true, force: true });
    await rm(otherRoot, { recursive: true, force: true });
  });
  await assert.rejects(importMemory(otherRoot, exportPath, { confirmed: true }), (error) => error.code === 'MEMORY_PROJECT_MISMATCH');
  assert.equal((await listMemoryNotes(otherRoot, 'all')).length, 0);
});

test('prepared memory remains explicitly unconfirmed until the storage call carries confirmation', async (t) => {
  const { root } = await withVault(t);
  const draft = await proposeMemory(root, decision());
  assert.equal(draft.userConfirmed, false);
  await assert.rejects(saveMemoryNote(root, draft, { confirmed: false }), (error) => error.code === 'MEMORY_CONFIRM_REQUIRED');
  assert.equal((await listMemoryNotes(root)).length, 0);
  const saved = await saveMemoryNote(root, draft, { confirmed: true });
  assert.equal(saved.note.userConfirmed, true);
  assert.equal((await listMemoryNotes(root)).length, 1);
});

test('memory core rejects common credential-shaped fields, not only CLI callers', async (t) => {
  const { root } = await withVault(t);
  await assert.rejects(proposeMemory(root, decision('global', { decision: 'Configure api_key=do-not-store-this' })), (error) => error.code === 'MEMORY_SECRET_SUSPECTED');
});
