import test from 'node:test';
import assert from 'node:assert/strict';
import { decideToolCall } from '../../dist/safety/policy-engine.js';

function tool(risk, caps) {
  return { id: 'tool-1', missionId: 'mission-1', stepId: 'step-1', toolName: 'files.read', input: {}, risk, requestedCapabilities: caps, status: 'requested', outputEvidenceIds: [], createdAt: new Date().toISOString() };
}

test('approved read-only workspace tool may be allowed; writes and processes are blocked in M1', () => {
  assert.equal(decideToolCall({ toolCall: tool('read_only', ['read_workspace']), approvedCapabilities: ['read_workspace'] }).outcome, 'allow');
  assert.equal(decideToolCall({ toolCall: tool('read_only', ['read_workspace']), approvedCapabilities: [] }).outcome, 'deny');
  const write = decideToolCall({ toolCall: tool('workspace_write', ['write_workspace']), approvedCapabilities: ['write_workspace'] });
  assert.equal(write.outcome, 'deny');
  assert.ok(write.ruleIds.includes('M1_WRITE_TOOLS_DISABLED'));
  const process = decideToolCall({ toolCall: tool('process', ['sandbox_command']), approvedCapabilities: ['sandbox_command'] });
  assert.equal(process.outcome, 'deny');
  assert.ok(process.ruleIds.includes('SANDBOX_REQUIRED'));
});
