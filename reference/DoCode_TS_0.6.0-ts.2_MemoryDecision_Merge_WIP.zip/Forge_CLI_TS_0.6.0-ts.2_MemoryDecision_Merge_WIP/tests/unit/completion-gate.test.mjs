import test from 'node:test';
import assert from 'node:assert/strict';
import { evaluateCompletion } from '../../dist/verification/completion-gate.js';

const at = '2026-10-22T00:00:00.000Z';
function fixture(overrides = {}) {
  return evaluateCompletion({
    missionId: 'mission-1',
    checks: [{ id: 'check-1', name: 'tests', status: 'passed', required: true, exitCode: 0, evidenceIds: ['ev-test'] }],
    criteria: [{ criterionId: 'criterion-1', required: true, passed: true, evidenceIds: ['ev-test'] }],
    reviewPassed: true,
    blockingSecurityWarnings: [],
    startedAt: at,
    finishedAt: at,
    policyVersion: 'test-policy',
    ...overrides,
  });
}

test('completion requires passed checks, criterion evidence, review, and no blocking security warnings', () => {
  const result = fixture();
  assert.equal(result.status, 'passed');
  assert.equal(result.completionAllowed, true);
});

test('failed tests and missing evidence cannot be overridden by a passing review', () => {
  const failed = fixture({ checks: [{ id: 'check-1', name: 'tests', status: 'failed', required: true, exitCode: 1, evidenceIds: ['ev-test'] }] });
  assert.equal(failed.status, 'failed');
  assert.equal(failed.completionAllowed, false);
  const missingEvidence = fixture({ criteria: [{ criterionId: 'criterion-1', required: true, passed: true, evidenceIds: [] }] });
  assert.equal(missingEvidence.status, 'incomplete');
  assert.equal(missingEvidence.completionAllowed, false);
});

test('blocking security warning always prevents completion', () => {
  const result = fixture({ blockingSecurityWarnings: ['sandbox verification missing'] });
  assert.equal(result.status, 'failed');
  assert.equal(result.completionAllowed, false);
});
