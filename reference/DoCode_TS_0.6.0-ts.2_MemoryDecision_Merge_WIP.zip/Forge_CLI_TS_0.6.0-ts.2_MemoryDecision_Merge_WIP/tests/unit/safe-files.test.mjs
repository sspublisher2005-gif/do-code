import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, mkdir, writeFile, symlink, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { SafeFileTools } from '../../dist/tools/safe-files.js';

test('safe file tools list, read and literal-search regular workspace files', async (t) => {
  const root = await mkdtemp(join(tmpdir(), 'forge-files-'));
  t.after(() => rm(root, { recursive: true, force: true }));
  await mkdir(join(root, 'src'));
  await writeFile(join(root, 'src', 'app.ts'), 'export const answer = 42;\n// test needle\n');
  await writeFile(join(root, '.env'), 'API_KEY=should-not-be-read');
  const files = await SafeFileTools.create(root, { maxReadBytes: 2048, maxFiles: 10, maxSearchMatches: 10 });
  assert.equal(await files.read('src/app.ts'), 'export const answer = 42;\n// test needle\n');
  const list = await files.list('.');
  assert.ok(list.some((item) => item.path === 'src/app.ts'));
  assert.ok(!list.some((item) => item.path === '.env'));
  const matches = await files.search('needle');
  assert.equal(matches.length, 1);
  assert.equal(matches[0].path, 'src/app.ts');
});

test('safe file tools reject path traversal, symlinks, binary files and oversized reads', async (t) => {
  const root = await mkdtemp(join(tmpdir(), 'forge-safe-files-'));
  const outside = await mkdtemp(join(tmpdir(), 'forge-safe-outside-'));
  t.after(async () => { await rm(root, { recursive: true, force: true }); await rm(outside, { recursive: true, force: true }); });
  await writeFile(join(root, 'large.txt'), '123456789');
  await writeFile(join(root, 'image.png'), Buffer.from([0x89, 0x50, 0x4e, 0x47]));
  await writeFile(join(outside, 'secret.txt'), 'do not read');
  await symlink(join(outside, 'secret.txt'), join(root, 'linked.txt'));
  const files = await SafeFileTools.create(root, { maxReadBytes: 8, maxFiles: 20, maxSearchMatches: 10 });
  await assert.rejects(files.read('../secret.txt'), /traversal/i);
  await assert.rejects(files.read('linked.txt'), /symlink/i);
  await assert.rejects(files.read('large.txt'), /exceeds/i);
  await assert.rejects(files.read('image.png'), /Binary/i);
});

test('write preview is non-mutating and reports mutationPerformed false', async (t) => {
  const root = await mkdtemp(join(tmpdir(), 'forge-preview-'));
  t.after(() => rm(root, { recursive: true, force: true }));
  const files = await SafeFileTools.create(root);
  const preview = files.writePreview('new-file.txt', 'planned contents');
  assert.equal(preview.mutationPerformed, false);
  assert.equal(preview.bytes, 16);
});
