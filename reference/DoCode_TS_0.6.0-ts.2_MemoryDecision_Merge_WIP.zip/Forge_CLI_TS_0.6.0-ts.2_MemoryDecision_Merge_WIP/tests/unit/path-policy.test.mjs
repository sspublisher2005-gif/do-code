import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, mkdir, writeFile, symlink, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { validateRelativePath, resolveExistingPath } from '../../dist/safety/path-policy.js';

test('relative path policy rejects traversal, absolute paths and private credential locations', () => {
  assert.throws(() => validateRelativePath('../outside.txt'), /traversal/i);
  assert.throws(() => validateRelativePath('/etc/passwd'), /absolute/i);
  assert.throws(() => validateRelativePath('C:\\Users\\person\\.ssh\\id_rsa'), /absolute|sensitive/i);
  assert.throws(() => validateRelativePath('.env.production'), /credential|private|sensitive/i);
  assert.throws(() => validateRelativePath('.forge/audit.jsonl'), /credential|private|sensitive/i);
});

test('path policy rejects symlinks and special non-file/non-directory targets', async (t) => {
  const root = await mkdtemp(join(tmpdir(), 'forge-path-'));
  const outside = await mkdtemp(join(tmpdir(), 'forge-outside-'));
  t.after(async () => { await rm(root, { recursive: true, force: true }); await rm(outside, { recursive: true, force: true }); });
  await writeFile(join(outside, 'external.txt'), 'private');
  await symlink(outside, join(root, 'linked'));
  await assert.rejects(resolveExistingPath(root, 'linked/external.txt', 'file'), /symlink/i);
  await mkdir(join(root, 'folder'));
  await assert.rejects(resolveExistingPath(root, 'folder', 'file'), /regular file/i);
});
