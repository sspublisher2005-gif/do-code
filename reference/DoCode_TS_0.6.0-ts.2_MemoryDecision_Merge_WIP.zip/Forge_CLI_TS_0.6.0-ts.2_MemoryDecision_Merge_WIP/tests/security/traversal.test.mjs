import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, writeFile, symlink, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { SafeFileTools } from '../../dist/tools/safe-files.js';

test('adversarial workspace paths cannot read outside-workspace sentinel or traverse secrets', async (t) => {
  const root = await mkdtemp(join(tmpdir(), 'forge-sec-root-'));
  const outside = await mkdtemp(join(tmpdir(), 'forge-sec-outside-'));
  t.after(async () => { await rm(root, { recursive: true, force: true }); await rm(outside, { recursive: true, force: true }); });
  await writeFile(join(outside, 'sentinel.txt'), 'OUTSIDE_SECRET_SENTINEL');
  await writeFile(join(root, '.env.production'), 'API_KEY=top-secret');
  await symlink(join(outside, 'sentinel.txt'), join(root, 'shortcut.txt'));
  const tools = await SafeFileTools.create(root);
  await assert.rejects(tools.read('../forge-sec-outside/sentinel.txt'));
  await assert.rejects(tools.read('shortcut.txt'));
  await assert.rejects(tools.read('.env.production'));
  const listed = await tools.list('.');
  assert.ok(!listed.some((entry) => entry.path.includes('sentinel') || entry.path.includes('.env')));
});
