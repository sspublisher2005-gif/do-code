import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { spawn } from 'node:child_process';
import { readAuditTail } from '../../dist/audit/jsonl.js';

function spawnWriter(root, writer) {
  const modulePath = resolve('dist/audit/jsonl.js').replaceAll('\\', '/');
  const script = `import { appendAudit } from ${JSON.stringify(new URL(`file://${modulePath}`).href)};\nconst root=process.argv[1];const writer=process.argv[2];for(let i=0;i<10;i++){await appendAudit(root,{event:'parallel.test',outcome:'info',details:{writer,index:i}});}`;
  return new Promise((resolvePromise, rejectPromise) => {
    const child = spawn(process.execPath, ['--input-type=module', '-e', script, root, String(writer)], { stdio: ['ignore', 'pipe', 'pipe'] });
    let stderr = '';
    child.stderr.setEncoding('utf8'); child.stderr.on('data', chunk => { stderr += chunk; });
    child.once('error', rejectPromise);
    child.once('close', code => code === 0 ? resolvePromise() : rejectPromise(new Error(`writer exit ${code}: ${stderr}`)));
  });
}

test('audit sequencing remains unique across concurrent Node processes', async (t) => {
  const root = await mkdtemp(join(tmpdir(), 'forge-audit-race-'));
  t.after(() => rm(root, { recursive: true, force: true }));
  await Promise.all([spawnWriter(root, 1), spawnWriter(root, 2), spawnWriter(root, 3), spawnWriter(root, 4)]);
  const result = await readAuditTail(root, 100);
  assert.equal(result.corruptLines, 0);
  assert.equal(result.events.length, 40);
  assert.deepEqual(result.events.map(event => event.sequence).sort((a, b) => a - b), Array.from({ length: 40 }, (_, index) => index + 1));
});
