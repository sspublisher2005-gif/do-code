import test from 'node:test';
import assert from 'node:assert/strict';
import { redactString, redactValue } from '../../dist/safety/secret-redaction.js';

test('secret redaction covers common token patterns and bearer headers', () => {
  const result = redactString('key=abc123; Bearer tokenvalue1234567890; sk-123456789012345678901234');
  assert.doesNotMatch(result, /Bearer tokenvalue|sk-123456/);
  assert.match(result, /REDACTED/);
});

test('secret-shaped object keys are redacted recursively', () => {
  const value = redactValue({ api_key: 'secret-1', nested: { token: 'secret-2', note: 'harmless' } });
  assert.equal(value.api_key, '[REDACTED]');
  assert.equal(value.nested.token, '[REDACTED]');
  assert.equal(value.nested.note, 'harmless');
});
