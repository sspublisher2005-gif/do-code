import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, mkdir, readFile, writeFile, access, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { symlink } from 'node:fs/promises';
import net from 'node:net';
import { createLinuxNamespacePrototypeDriver } from '../../dist/sandbox/linux/namespace-driver.js';

const enabled = process.platform === 'linux';
let driver;
let capabilities;
if (enabled) {
  driver = await createLinuxNamespacePrototypeDriver();
  capabilities = await driver.probe();
}
const runnable = enabled && capabilities?.filesystemIsolation === true;
const skipReason = !enabled ? 'Linux-specific prototype' : 'Kernel/runtime does not permit the required unprivileged namespaces and mounts';

async function fixture(t) {
  const root = await mkdtemp(join(tmpdir(), 'forge-sandbox-test-'));
  t.after(() => rm(root, { recursive: true, force: true }));
  await writeFile(join(root, 'README.md'), 'fixture-ok\n');
  await writeFile(join(root, '.env'), 'API_KEY=not-a-real-secret\n');
  await mkdir(join(root, '.forge'), { mode: 0o700 });
  await writeFile(join(root, '.forge', 'token'), 'forge_test_private_value\n');
  return root;
}

function request(workspaceRoot, argv, overrides = {}) {
  return {
    executable: '/bin/sh',
    argv,
    workspaceRoot,
    writablePaths: [],
    environment: {},
    network: 'deny_all',
    limits: { timeoutMs: 5000, memoryBytes: 512 * 1024 * 1024, cpuQuotaPercent: 100, maxProcesses: 32, maxOutputBytes: 64 * 1024 },
    ...overrides,
  };
}

test('Linux namespace prototype reports productionReady=false until Landlock/seccomp and review are real', { skip: !enabled }, async () => {
  assert.equal(capabilities?.productionReady, false);
  assert.equal(capabilities?.landlock, false);
  assert.equal(capabilities?.seccompBpf, false);
});

test('Linux sandbox keeps guest writes inside disposable workspace and rootfs system paths read-only', { skip: !runnable, skipReason }, async (t) => {
  const root = await fixture(t);
  const res = await driver.run(request(root, ['-c', 'printf "sandbox-ok\\n"; cat README.md; test ! -e .env; test ! -d .forge; test ! -w /usr/bin; printf guest-write > guest-write.txt; test -f guest-write.txt; if (printf escaped > /root/escape.txt) 2>/dev/null; then exit 4; else echo outside-write-blocked; fi']));
  assert.equal(res.exitCode, 0, `sandbox command failed: ${res.stderr}`);
  assert.match(res.stdout, /sandbox-ok/);
  assert.match(res.stdout, /fixture-ok/);
  assert.match(res.stdout, /outside-write-blocked/);
  await assert.rejects(access(join(root, 'guest-write.txt')));
  assert.equal((await readFile(join(root, 'README.md'), 'utf8')), 'fixture-ok\n');
});

test('Linux sandbox masks credential paths and does not expose host home or SSH directories', { skip: !runnable, skipReason }, async (t) => {
  const root = await fixture(t);
  const res = await driver.run(request(root, ['-c', 'test ! -s /etc/shadow; test ! -d /root/.ssh; test ! -d /home; test ! -e .env; test ! -d .forge; echo masked']));
  assert.equal(res.exitCode, 0, `credential-mask test failed: ${res.stderr}`);
  assert.match(res.stdout, /masked/);
});

test('Linux sandbox network namespace cannot connect to a host localhost TCP listener', { skip: !runnable, skipReason }, async (t) => {
  const root = await fixture(t);
  const server = net.createServer((socket) => socket.end('host-network-reached'));
  await new Promise((resolve, reject) => { server.once('error', reject); server.listen(0, '127.0.0.1', resolve); });
  t.after(() => new Promise((resolve) => server.close(() => resolve())));
  const port = server.address().port;
  const code = `if (echo probe > /dev/tcp/127.0.0.1/${port}) 2>/dev/null; then echo CONNECTED; exit 3; else echo BLOCKED; fi`;
  const res = await driver.run(request(root, ['-c', code], { executable: '/bin/bash' }));
  assert.equal(res.exitCode, 0, `network-denial probe errored: ${res.stderr}`);
  assert.match(res.stdout, /BLOCKED|TIMEOUT/);
  assert.doesNotMatch(res.stdout, /CONNECTED/);
});

test('Linux sandbox kills timed-out processes and removes temporary snapshots', { skip: !runnable, skipReason }, async (t) => {
  const root = await fixture(t);
  const started = Date.now();
  const res = await driver.run(request(root, ['-c', 'sleep 20'], { limits: { timeoutMs: 300, memoryBytes: 512 * 1024 * 1024, cpuQuotaPercent: 100, maxProcesses: 32, maxOutputBytes: 4096 } }));
  assert.equal(res.cancelled, true);
  assert.ok(Date.now() - started < 5000, 'timeout did not terminate promptly');
  assert.equal(await readFile(join(root, 'README.md'), 'utf8'), 'fixture-ok\n');
  assert.equal(await readFile(join(root, '.env'), 'utf8'), 'API_KEY=not-a-real-secret\n');
});


test('Linux sandbox does not follow workspace symlinks into external paths', { skip: !runnable, skipReason }, async (t) => {
  const root = await fixture(t);
  const outside = await mkdtemp(join(tmpdir(), 'forge-sandbox-outside-'));
  t.after(() => rm(outside, { recursive: true, force: true }));
  await writeFile(join(outside, 'sentinel.txt'), 'host-outside-sentinel\n');
  await symlink(join(outside, 'sentinel.txt'), join(root, 'leak.txt'));
  const res = await driver.run(request(root, ['-c', 'test ! -e leak.txt; echo symlink-excluded']));
  assert.equal(res.exitCode, 0, `symlink isolation failed: ${res.stderr}`);
  assert.match(res.stdout, /symlink-excluded/);
  assert.equal(await readFile(join(outside, 'sentinel.txt'), 'utf8'), 'host-outside-sentinel\n');
});

test('Linux sandbox rejects unapproved environment variables before executing a command', { skip: !runnable, skipReason }, async (t) => {
  const root = await fixture(t);
  await assert.rejects(
    driver.run(request(root, ['-c', 'echo SHOULD_NOT_RUN'], { environment: { OPENAI_API_KEY: 'fixture-secret' } })),
    (error) => error?.code === 'SANDBOX_ENVIRONMENT_DENIED',
  );
  assert.equal(await readFile(join(root, 'README.md'), 'utf8'), 'fixture-ok\n');
});

test('Linux sandbox bounds captured output and terminates an output flood', { skip: !runnable, skipReason }, async (t) => {
  const root = await fixture(t);
  const res = await driver.run(request(root, ['-c', 'while :; do printf 1234567890; done'], { limits: { timeoutMs: 5000, memoryBytes: 512 * 1024 * 1024, cpuQuotaPercent: 100, maxProcesses: 32, maxOutputBytes: 2048 } }));
  assert.equal(res.cancelled, true);
  assert.ok(Buffer.byteLength(res.stdout) + Buffer.byteLength(res.stderr) < 3000);
  assert.match(res.stderr, /output limit exceeded/);
});

test('Linux sandbox cancels a process through AbortSignal', { skip: !runnable, skipReason }, async (t) => {
  const root = await fixture(t);
  const controller = new AbortController();
  const abortTimer = setTimeout(() => controller.abort(), 200);
  try {
    const started = Date.now();
    const res = await driver.run(request(root, ['-c', 'sleep 20'], { signal: controller.signal, limits: { timeoutMs: 5000, memoryBytes: 512 * 1024 * 1024, cpuQuotaPercent: 100, maxProcesses: 32, maxOutputBytes: 4096 } }));
    assert.equal(res.cancelled, true);
    assert.ok(Date.now() - started < 4000);
  } finally {
    clearTimeout(abortTimer);
  }
});
