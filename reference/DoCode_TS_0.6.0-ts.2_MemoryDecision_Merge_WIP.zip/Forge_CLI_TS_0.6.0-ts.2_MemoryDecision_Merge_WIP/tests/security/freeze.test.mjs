import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { assertWorkspaceNotFrozen, freezeWorkspace, readFreezeState, unfreezeWorkspace } from '../../dist/safety/freeze.js';

test('workspace freeze blocks guarded actions until explicit approved unfreeze', async (t) => {
  const root = await mkdtemp(join(tmpdir(), 'forge-freeze-'));
  t.after(() => rm(root, { recursive: true, force: true }));
  assert.equal(await readFreezeState(root), undefined);
  await freezeWorkspace(root, 'Incident response');
  assert.equal((await readFreezeState(root)).reason, 'Incident response');
  await assert.rejects(assertWorkspaceNotFrozen(root, 'test action'), (error) => error.code === 'WORKSPACE_FROZEN');
  await assert.rejects(unfreezeWorkspace(root, false), (error) => error.code === 'UNFREEZE_APPROVAL_REQUIRED');
  await unfreezeWorkspace(root, true);
  assert.equal(await readFreezeState(root), undefined);
});

test('corrupt freeze record fails closed', async (t) => {
  const root = await mkdtemp(join(tmpdir(), 'forge-freeze-corrupt-'));
  t.after(() => rm(root, { recursive: true, force: true }));
  await freezeWorkspace(root, 'initial');
  const { writeFile } = await import('node:fs/promises');
  await writeFile(join(root, '.forge', 'FROZEN.json'), '{invalid');
  await assert.rejects(assertWorkspaceNotFrozen(root, 'model call'), (error) => error.code === 'FREEZE_STATE_CORRUPT');
});
