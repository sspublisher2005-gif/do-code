import test from 'node:test';
import assert from 'node:assert/strict';
import { validateBaseUrl } from '../../dist/providers/openai-compatible.js';

test('provider base URL rejects plain remote HTTP, userinfo, query and endpoint URLs', () => {
  assert.throws(() => validateBaseUrl('http://api.example.test/v1'), /HTTPS/);
  assert.throws(() => validateBaseUrl('https://user:pass@api.example.test/v1'), /credentials/i);
  assert.throws(() => validateBaseUrl('https://api.example.test/v1?leak=yes'), /credentials/i);
  assert.throws(() => validateBaseUrl('https://api.example.test/v1/chat/completions'), /base path/i);
  assert.equal(validateBaseUrl('http://127.0.0.1:11434/v1').hostname, '127.0.0.1');
});

test('private endpoint credentials are never included in errors', () => {
  try { validateBaseUrl('https://user:super-secret@example.test/v1'); }
  catch (error) {
    assert.doesNotMatch(error.message, /super-secret/);
    return;
  }
  assert.fail('expected the URL to be rejected');
});
