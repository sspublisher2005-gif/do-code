# Forge Unified v0.4.2 — session and privacy verification

**Verification date:** 21 October 2026  
**Environment:** Debian GNU/Linux 13 (trixie), Node.js v22.16.0, npm 10.9.2  
**Artifact status:** local review build only; not published, deployed, or pushed to a remote repository.

## Implemented in this review increment

- Added project-bound session files under the private user-state directory, outside the repository. Each record is bound to the project UUID, canonical root path, and binding epoch.
- Authenticated the full session record with HMAC-SHA-256 and a private 32-byte per-user key. Session records with invalid signatures, wrong roots, copied/rebound identities, or malformed fields fail closed.
- Added AES-256-GCM encryption for saved task text. The encryption key is derived from the per-user key with a separate purpose label; session metadata uses a keyed task fingerprint rather than storing plaintext or an unkeyed task digest.
- Hardened `FORGE_HOME` validation to reject paths that reach into the repository through a symlinked parent directory.
- Added `forge sessions list`, `forge sessions show SESSION_ID`, `forge sessions delete SESSION_ID`, and `forge resume SESSION_ID`.
- Added exact, session-specific confirmation before deletion and exact confirmation before restarting. Session deletion removes only the selected session file; it does not undo code changes, erase audit logs, or guarantee forensic erasure.
- Resume semantics are explicit: Forge starts the saved task from the beginning against current working files. It does not restore a previous model transcript or internal tool step, and it does not roll back partial changes.
- Session status is derived from Forge audit events. Unavailable usage/cost is reported as unknown rather than being silently shown as zero.
- Expanded competitive research with official product documentation, public issue reports and individual Reddit discussions. Anecdotes are identified as such; no population-level frequency is claimed.

## Automated test results

Commands run from the source tree and from a fresh npm installation:

```text
npm test
# tests 108
# pass 108
# fail 0
# skipped 0

npm run check
# Syntax OK: 28 JavaScript files checked.
```

The session tests cover encrypted task storage, authenticated session lifecycle and outcome, tamper rejection, storage outside the project, symlink-parent aliases, cross-project/copy/rebind rejection, completed-session restart refusal, project-scoped deletion, non-interactive deletion refusal, and non-interactive resume refusal before a provider call.

## Package and CLI smoke

- `npm pack` produced `forge-coding-harness@0.4.2`; release output is 229,405 bytes packed and 746,851 bytes unpacked, containing 112 files. Detailed verification/evidence logs are intentionally excluded from the npm runtime tarball; the complete source archive retains them.
- A clean temporary prefix installed the local tarball without adding external runtime dependencies.
- The installed CLI returned version `0.4.2`; help includes session list/show/delete and resume commands.
- In a disposable project, `forge init` succeeded without making a provider request. `forge sessions list` returned an empty project-scoped list.
- A pseudo-terminal smoke test created a session, supplied the exact `DELETE SESSION <full-session-id>` confirmation to the installed CLI, and verified that the session record could no longer be loaded.
- Both installed-package and source-tree test suites passed: 108/108, with 28 JavaScript files passing syntax checks.

## Competitive/customer findings and how they changed implementation

Official Codex CLI and Gemini CLI documentation make the separation between approval UX and actual sandbox boundaries clear. Gemini documentation also exposes checkpointing and recovery as product features. OpenCode and Gemini public issue reports describe session/context recovery problems; Reddit discussions describe context drift after compaction, usage-limit surprises, cleanup work after code generation, and local-first trust questions. These reports are anecdotal and do not establish prevalence.

Forge's response in this increment is durable project-scoped task state, encrypted task text, explicit restart behavior, exact-confirmation deletion, and truthful session/usage reporting. The next high-value step is not to add more agents; it is to enforce and validate a real operating-system/container sandbox and then test model-backed end-to-end coding on controlled fixtures.

Research record: [`../docs/COMPETITOR_AND_USER_PAINPOINTS_2026-10-21.md`](../docs/COMPETITOR_AND_USER_PAINPOINTS_2026-10-21.md).

## Not verified — do not claim these capabilities are complete

- **No OS/container sandbox:** `bwrap`, `firejail`, Docker, Podman and `nsjail` were not available in this environment. Repository scripts and manual commands still run with the current operating system account's permissions after the existing approval policy. Treat untrusted repositories as unsafe until an enforced sandbox is implemented and tested.
- **No provider-backed coding task in this verification:** no live end-to-end change/test/review task was executed against a configured model. Automated tests and mock-provider behavior cannot prove real task success or model quality.
- **No live Playwright/browser session:** browser-policy tests use test doubles and are not proof of real browser launch or successful journeys.
- **No exact conversation/step restoration:** resume is task restart only; stale-process detection, multiprocess locking, session export, and crash-consistency stress testing remain future work.
- **No cross-platform CI run:** only this Linux environment was checked. Windows and macOS behavior remains unverified.
- **No independent security review, penetration test, dependency audit, matched competitor benchmark, customer interviews, retention data, or willingness-to-pay validation.** Public docs/issue reports/Reddit discussions generated hypotheses, not product-market-fit evidence.
- **No remote Git push, publication or deployment** was performed. The current artifacts were made from the supplied local source archive; a canonical upstream repository URL was not available in the task context.

## Release gate decision

**Status: experimental review build, not production-ready.** The session-resume/privacy increment is locally tested, but the enforced sandbox, live end-to-end provider proof, cross-platform CI, independent security review and user validation are still release blockers for a broadly autonomous coding agent.
