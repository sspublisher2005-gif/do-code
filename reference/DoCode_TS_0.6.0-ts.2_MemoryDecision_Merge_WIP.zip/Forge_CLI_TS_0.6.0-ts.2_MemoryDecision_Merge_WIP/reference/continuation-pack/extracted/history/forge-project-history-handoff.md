# Forge CLI — Complete Accessible Conversation History, Forensic Audit & Handoff

**Report date:** 2026-10-20 (Asia/Kolkata)  
**Project:** Forge CLI / approval-first agentic coding harness  
**Release snapshot currently evidenced:** `forge-cli@0.1.5`  
**Coverage status:** **PARTIAL HISTORY, CURRENT RELEASE SNAPSHOT VERIFIED LOCALLY**. The report captures the full Forge-related history visible in this conversation and available continuity summaries, but it cannot recover full raw transcripts for earlier separate ChatGPT/OpenCode sessions that were not mounted here.  
**Purpose:** Project continuity and source handoff only. No feature implementation was performed for this report.

---

# PART 1 — Source identity, coverage, and limitations

## 1.1 Source identity

- **Project title:** Forge CLI. No formal title for the original ChatGPT conversation is recoverable from the visible material. Related prior conversation titles in contextual history include “Top AI Coding Agents CLI,” “OpenCode Skills Guide,” and “Forge MVP Build Plan,” but those titles do not prove they are the same thread.
- **Current report request:** The attached file `Pasted text(7).txt` (515 lines) asks for a source-grounded chronology, requirements/feature/decision registers, testing ledger, exact stopping point, and JSON handoff. It explicitly says not to implement new features.
- **Earliest identifiable Forge request in the continuity summary:** “Can you add api provider openrouter”. The full preceding conversation and its exact timestamps are not present as raw transcript in this environment; the wording is preserved from the continuity summary.
- **Latest project-feature prompt before this history request:** the user asked for a browser/Playwright workflow that can open and test websites, apps and games, and for the coding harness to select skills, commands, agents/subagents automatically when they are needed, with evidence. Exact wording is preserved in Appendix A.
- **Latest assistant response before this report request:** announced Forge CLI `v0.1.5`, described the optional Playwright Browser QA adapter, showed 67 passing tests and 21 JavaScript files syntax-checked, linked ZIP/npm/report/log artifacts, and explicitly said the actual Playwright Node package was unavailable in the authoring environment, so Forge had not visited a real site through its own adapter in that run.

## 1.2 Sources available to inspect

1. Current conversation transcript, including the available user prompts, assistant answers, research/implementation status messages, and continuity summary.
2. The 515-line user attachment `Pasted text(7).txt` containing this report-generation specification.
3. The actual source bundle `/mnt/data/forge-cli-mvp.zip`. It was extracted for inspection to `/tmp/forge-audit-snapshot`.
4. `/mnt/data/forge-cli-0.1.5.tgz`, npm package metadata, and its file listing.
5. `/mnt/data/forge-v0.1.5-tests.log` and `/mnt/data/forge-v0.1.5-check.log`.
6. `/mnt/data/forge-browser-qa-report.md` and `/mnt/data/forge-harness-research.md`.
7. Historical research/design reports and evidence logs within the source bundle (`docs/`, `evidence/`, `skills/`, `tests/`).
8. Generated preview image `/mnt/data/a_composite_montage_image_showing_a_terminal_cli_i.png`.

## 1.3 Coverage limitations

- This is the **entire accessible Forge-related history in this conversation context**, not a guarantee that it is the entire project history across all three sources the user mentioned.
- The user says they are consolidating three sources: two prior ChatGPT conversations and an OpenCode CLI conversation / actual coding work. The other two raw histories were not attached in full here. Their contents cannot be reconstructed beyond summaries, recent-conversation snippets, named files, commands, and results provided in the current context.
- No original Git repository metadata was present in the ZIP; no current Git commit SHA, branch, tag, or remote URL was verified. Do not infer a commit from package version.
- `/mnt/data/forge-live/` currently exposes `README.md`, `FORGE.md`, and `DELIVERABLES.md` in the mounted folder, while the full source code is present in `/mnt/data/forge-cli-mvp.zip`. The ZIP’s entries were directly inspected.
- Earlier assistant progress reports and old logs contain historical test counts (25, 28, 29, 35, 37, 53, then 67). Only the current bundled v0.1.5 snapshot was rerun in this report session.
- A real Playwright browser run, live OpenRouter/OpenCode inference, live Context7 call, authenticated social-media query, hosted CI run, and independent penetration test are **not** evidenced as having been completed.
- Some external GitHub/research source inspections are summarized in repository reports. Those summaries do not amount to a complete line-by-line audit or cloning/testing every repository.

## 1.4 Evidence vocabulary used

- **VERIFIED BY EXECUTION:** this report itself reran the command and observed the result.
- **VERIFIED FROM ARTIFACT:** a file, archive, package manifest or log was directly inspected.
- **HISTORICALLY REPORTED:** a prior assistant message reported it; no independent current rerun is available unless explicitly stated.
- **IMPLEMENTED, MOCK-TESTED:** code exists and tests use mocks/fake executables; a live integration is not proven.
- **IMPLEMENTED, NOT LIVE-VERIFIED:** code exists, but a real provider/browser/platform was not exercised.
- **PROPOSED / ROADMAP:** not implemented in the latest source snapshot.
- **UNKNOWN:** evidence is insufficient.

---

# PART 2 — Executive overview

Forge is an experimental, terminal-first, approval-first coding-agent harness. The central product intent is to let a user describe a coding task, have the harness understand the repository, get model-proposed changes, validate a patch, request approval before modifying files or running tests, save a rollback checkpoint, verify the result, and report evidence honestly.

The source snapshot is `forge-cli@0.1.5`, Node.js `>=22`, with zero required runtime dependencies and optional Playwright browser automation. Current implementation includes OpenCode CLI and direct OpenRouter transports, a local repository index and approximate import graph, a Context7 documentation lookup, a limited Agent-Reach-compatible external search bridge, emergency freeze/unfreeze, fixed built-in skill files, browser QA, and an allowlisted local development-server launcher.

The latest verified local checks in this report:

- `npm test`: **67 passed, 0 failed, 0 skipped**, duration approximately 3.0 seconds in this report’s rerun.
- `npm run check`: **21 JavaScript files syntax-checked**.
- `node bin/forge.js --version`: `0.1.5`.
- `node bin/forge.js --help`: help output displayed and included the current commands and safety defaults.

These tests verify a mixture of unit tests, CLI integrations, fake-provider/fake-browser contracts and a real local HTTP dev-server fixture. They do **not** establish live provider compatibility, actual Playwright navigation in this environment, comprehensive prompt-injection resistance, cross-platform runtime correctness, or production-grade sandboxing.

**Core product/security conclusion:** Forge should keep its trusted controller small, preserve approval and evidence boundaries, and implement OS-enforced execution isolation before expanding unattended autonomy or parallel subagent execution. A prompt-injection scanner is a warning mechanism, not the security boundary. A `local-only` configuration value is not a network firewall.

---

# PART 3 — Original vision, goals, constraints, and founder instructions

## 3.1 Founder intent, preserved from accessible prompts

The user is the founder and explicitly retains founder-level product authority. They asked the assistant to act in a founder/CEO/engineering role to do the work, but this is role framing; the assistant is not a real cofounder or employee and cannot make external decisions or deployments without access/authorization.

The user’s intent is to build a future-ready coding agent “like Jarvis,” but specifically for coding, not an uncontrolled or harmful system “like Ultron.” The agent should be powerful yet safe, secure and privacy-conscious; should use skills, commands, agents and subagents when required; should research external sources and show evidence to the user; and should not leak private user/project details to external services by default.

## 3.2 Explicit constraints and product principles

- Preserve the user as founder and final decision-maker.
- Do not pivot away from Forge to an unrelated product without evidence and founder approval.
- Prefer free-first, lightweight and local-first building; no mandatory VPS or paid API requirement has been established.
- Do not claim unlimited or “free” model usage without evidence.
- Keep API secrets out of browser code and avoid leaking secrets to agents, repository scripts, external search providers or logs.
- Public/internet content may be fetched only through clear user-facing routes; show source context and treat it as untrusted. The private project repository, user details and credentials should not be automatically sent with internet queries.
- No patch writes without user approval and checkpoint in the current intended workflow; execution/test commands have their own approval path.
- Do not treat prompt wording or an agent’s own statement as proof that tests passed.
- Use a browser engine for real browser checks when a website/app/game testing task calls for it; collect actual evidence rather than only drafting a plan.
- Automatically select task-appropriate skills/commands/roles, but do not spawn agents or add integrations merely because more agents sound impressive.
- Use existing projects as sources of ideas, not automatically copy large repositories or blindly import dependencies.
- Preserve transparent limitations: mock success is not live integration success; unit tests do not prove production security.

## 3.3 Assistant suggestions, not founder-approved final requirements

The following are engineering recommendations from assistant analysis and should not be silently elevated into immutable founder requirements: OS sandbox design, durable state-machine/loop protocol, specialist read-only subagents, explicit cost budgets, richer evaluation harnesses, web research citation synthesis, editor/website interfaces, pull-request integration, and hosted execution. They are sensible roadmap candidates but still need acceptance/priority decisions when product scope or costs change.

---

# PART 4 — Chronological history from first identifiable prompt to last response

> Exact wall-clock timestamps for most turns are not available in the visible conversation. Ordering below is based on message order and source artifacts. Version/test counts are marked historical when not independently rerun in this report.

## E001 — Existing Forge MVP / inherited project state

- **Position:** Before the first identifiable OpenRouter request in the current available thread.
- **User intent:** Continue an existing coding-agent harness rather than start a new unrelated product. Existing context says it was an experimental MVP with approvals, checkpoints/undo, local index/audit log, and a sequential planner/coder/tester/reviewer approach.
- **Known files at that stage:** summary referenced `/mnt/data/forge/src/llm.js`, `src/config.js`, `src/constants.js`, `src/cli.js`, `src/terminal.js`, `tests/core.test.js`, `README.md`, and documentation/evidence folders.
- **Historical verification:** 22 tests reportedly passed before OpenRouter work. A synthetic E2E using a fake provider reportedly passed. OpenCode/GLM were not live-verified because OpenCode was missing in that container.
- **Status:** HISTORICALLY REPORTED. Current v0.1.5 source preserves and expands this foundation.

## E002 — Add OpenRouter provider

- **User prompt (preserved from continuity summary):** “Can you add api provider openrouter”.
- **Action reported:** Added a direct OpenRouter Chat Completions transport, configuration and dispatch support, environment-secret retrieval, usage parsing and failure behavior.
- **Reported source edits:** `src/constants.js` default provider/model and OpenRouter config; `src/config.js` provider/base URL/max-token validation; `src/llm.js` `invokeOpenRouter` and dispatcher; `src/cli.js` provider diagnostics/help; `src/terminal.js` provider-specific consent notice; `tests/core.test.js`; README.
- **Important settings reported:** `provider: 'opencode'`; default model `opencode/glm-5.3-flash`; OpenRouter endpoint `https://openrouter.ai/api/v1`; `OPENROUTER_API_KEY` is read from the process environment, not written into project config or audit logs. Example model used later: `openai/gpt-4o-mini`.
- **Commands documented:** `forge config set provider openrouter`; `forge config set model openai/gpt-4o-mini`; PowerShell `$env:OPENROUTER_API_KEY="your-api-key"`; Bash `export OPENROUTER_API_KEY="your-api-key"`; `forge doctor`; `forge "Explain this repository"`.
- **Historical tests:** 25 passed, 0 failed; syntax check 13 JS files. New tests used mocked `fetch`; no real OpenRouter API call was performed.
- **Artifacts:** `/mnt/data/forge-cli-mvp.zip` and `/mnt/data/forge-cli-0.1.0.tgz` were linked at that stage.
- **Status:** Feature remains in v0.1.5; actual live transport still unverified.

## E003 — First request for an interactive preview

- **User prompt:** “I want preview here can tell me plz with interactive ok”.
- **Assistant response:** Rendered an interactive DIL simulation with a provider selector, model field, task text box, workflow stages and simulated approval. It explicitly stated it did not call the API or modify files.
- **Outcome:** It answered “interactive” literally but did not match the user’s desired representation.
- **Status:** Preview only; no source changes.

## E004 — Clarify that preview should look like the CLI

- **User prompt:** “In cli how it looks like I want that ok pre view me that”.
- **Assistant response:** Rendered an interactive terminal mockup with an ASCII Forge banner and selectable startup/task/approval/test screens. It again clarified this was a mockup.
- **Outcome:** Still not the user’s preferred format.
- **Status:** Preview only; no source changes.

## E005 — User explicitly wants an image

- **User prompt:** “I want image not this ok give me once ok”.
- **Action:** An image-generation call produced `/mnt/data/a_composite_montage_image_showing_a_terminal_cli_i.png`, a 3×3 visual montage of terminal screens, including startup, provider setup, project/task flow, progress, approval, testing, completion, and agent roster.
- **Outcome:** Corrected media format. It is a generated concept image, not a screenshot of running Forge; no source code was edited by the image-generation action.
- **Status:** GENERATED IMAGE VERIFIED AS AN ARTIFACT; not an implementation proof.

## E006 — Deep code/security/privacy/loop/product audit request

- **User intent:** “Once check code and security and privacy and agents and loop engineering and everything go into website and all platforms and what best top person saying howw the ai coding agent should be there and how watch videos and learn and fact check and implement ahd what ai coding agent users want in agents and what is iretated things in other list do deep dive in to them and do correct and truth ok with evidence and proofs do it @Thinking”.
- **Assistant plan:** Inspect source, research current guidance/videos/developer reports, implement verified fixes, run regression checks and report unknowns honestly.
- **Security issues reported/fixed in stages:** arbitrary HTTPS OpenRouter host could receive bearer credential; checkpoint metadata path traversal/forged metadata could write outside checkpoint directory or attempt deletion; overly broad inherited environment could expose unrelated API secrets; a high-risk command matcher did not reliably classify forms such as `rm -rf ...`; test/manual subprocess environment was too broad; Git fsmonitor/helper could execute from repository-controlled Git config during automatic status; terminal control sequences in untrusted output could spoof/affect output; untrusted text needed bounded reading/redaction; process timeouts needed process-group/tree termination.
- **Hardening described:** pin OpenRouter to official HTTPS host and reject redirects; validate checkpoint schema and bind HMAC signature to workspace/user-local key; narrow environment allowlists and provider-specific opt-ins; sanitize terminal control characters and patch paths; safe Git status configuration; use timeouts/output caps and process-group cleanup where supported; improve secret-path exclusion/redaction and command risk classification; add regression tests.
- **Research report:** `/mnt/data/forge-research-and-design-audit.md` (older detailed report) was created. This report drew on official coding-agent guidance and individual public issue/community reports. User-reported pain points were treated as anecdotal, not representative survey facts.
- **Historical test progression in visible progress messages:** 28 passed after checkpoint regression; 29 after subprocess environment changes; later 35; final audit state 37 tests and 14 JS syntax checks. Those counts describe iterations, not the current release.
- **Important caveat:** Assistant statements that a bug was “fixed” reflect the source/test state at that point, while the only fresh rerun in this handoff is the v0.1.5 snapshot described in Part 13.

## E007 — GitHub architecture and code research

- **User prompt:** asked to inspect strong GitHub repositories, adopt/improve/build a harness, and ensure privacy/security/prompt-injection protections (“like Jarvis” but not “Ultron”).
- **Research approach:** inspect repository README/docs and selected files rather than assuming every project had been installed or runtime-tested.
- **Projects inspected or referenced:** OpenAI Codex CLI; LangChain Deep Agents; SWE-agent and mini-SWE-agent; Aider; Continue; Daytona; Microsoft Agent Framework; AgentDojo; MCP-Scan; OpenHands search results; plus related official guidance.
- **Decision:** build and own a lightweight Forge harness with a narrow trusted controller, provider adapters, validated patch application, approvals, bounded test execution and future sandbox backend; adopt design ideas instead of embedding full large frameworks. More agents were not assumed to imply better results.
- **Reported local checks:** 37 tests passed; CI matrix configured for Linux/Windows/macOS but not run in hosted CI. OpenCode/GLM live call and OS-level sandbox still unverified.
- **Report:** `/mnt/data/forge-harness-research.md` eventually became the repository comparison/adoption report and is included in the latest bundle under `docs/HARNESS_RESEARCH_AND_ADOPTION.md`.

## E008 — Specific repositories: REA, Ponytail, Context7, Graphify, Agent-Reach

- **User prompt:** “Some best githubs are there like rea and ponytail and context7 and graphify and agent reach for research in social media aplatforms also and other best you will take that and implement or adopt and or create your own what you will do as a creater of this and research in GitHub best repos usefull for us to ok @Thinking @”.
- **Research decisions reported:**
  - Ponytail: use minimal-change and test-discipline ideas in Forge prompts, not as a new enforcement boundary.
  - Graphify: implement a small local regex-based graph, not import its parser wholesale. An upstream security advisory was noted in the research report; the Graphify implementation was intentionally not copied wholesale.
  - Context7: implement a fixed-endpoint documentation lookup, sending only an explicit query and optional library/version/language hints, not repository source or project memory. Consent is required unless the user explicitly bypasses it. `CONTEXT7_API_KEY` is optional; live connectivity not proven.
  - Agent-Reach: add a narrow, allow-listed, read-only CLI bridge for selected web/GitHub/YouTube/Bilibili/X/Reddit/Xiaohongshu/Facebook/Instagram routes. `forge reach status` should passively inspect local executable availability rather than execute an arbitrary binary; `forge reach doctor` is a separately explicit diagnostic because it can run remote channel probes; `forge reach search` requires consent and account routes require `--allow-account`; results remain user-facing untrusted text and are not auto-injected into coding model context. It does not install tools, log in, import cookies or perform social write operations.
  - REA: implement the concept of a fail-closed emergency freeze, not copy its Claude-specific hook architecture.
- **Reported intermediate checks:** 53 passing tests; 18 JavaScript files syntax-checked. This was an earlier snapshot and conflicts with the newer v0.1.5 count only if used as the latest number.
- **Status:** The current v0.1.5 README and source include these capabilities; Context7/Agent-Reach external calls were mocked/not live-verified.

## E009 — Practitioner-inspired design lenses

- **User prompt:** “Boris Cherny,Dax Raad,Andrej Karpathy you hired this people and your are this three people and act like think like work like research llthem and make best ai coding agentic agent ok for futuree and for now and best ok think what in feature ai will do and all what is practically posible now do it not ok paper ok @Thinking”.
- **Assistant response principle:** Did not claim to actually hire or represent the three people. Used these as design lenses: Boris Cherny for disciplined agent workflows/verification; Dax Raad for developer ergonomics/practical tooling; Andrej Karpathy for simplicity, legibility, experiments and human control.
- **Outcome:** Influenced architecture direction but no claim of endorsement by these individuals. Specific project/feature decisions remain Forge decisions, not attributed quotes.

## E010 — Browser-based testing for websites, apps and games

- **User prompt (exact, as available):** “I want in this the user ask to go inside browser and test the website or apps aor games we should provide a browser playwrite or browser use or other best free and top best ok lightweight strong and powerful ok and the our agentic code auto use skills and cammonds and agents and sub agents when it required ok with proofs and evidences do it make it and your the founder and if you want to add agent reach and other things than only add if not you should not okni and the founder you are the ceo ok and co founder and workers and employees ok all you I am founder ok @Thinking”.
- **Architecture decision:** Use Playwright Node API as the single built-in optional browser engine for repeatable smoke tests. Defer Playwright MCP and Vercel `agent-browser` because they overlap in first-release capabilities and would add another moving part. The choice is documented in `docs/BROWSER_QA.md`.
- **Implementation:** `src/browser.js` contains the adapter; `src/devserver.js` starts only recognized standard scripts for supported frameworks after consent; task routing in `src/harness.js` can automatically route browser-only tasks to Browser QA; skills include `browser-testing` and `game-testing`.
- **Policy/security measures described:** optional `playwright-core`, no browser auto-download; explicit consent to install Playwright or navigate/start app; isolated fresh context (no daily browser profile/cookies); HTTP(S) and WebSocket origin allowlisting; Playwright v1.48+ requirement because `routeWebSocket` is used, fail closed if absent; URL validation, public DNS pre-validation/pinning to reduce rebinding risk; private/LAN targets require explicit opt-in; no page text stored in report; DOM text bounded in-browser for local heuristic injection scan; query/fragment and long ID-like path portions removed from report URLs; local screenshots/report permissions; blocked downloads, service workers, popups/dialogs; no `--no-sandbox` browser launch flag; limited desktop/mobile overflow, console/page errors, HTTP/blocked request reporting, headings/labels/accessibility signal and canvas/WebGL presence. Recognized local server scripts bind to loopback and process cleanup is attempted.
- **Game behavior:** heuristic smoke exercise can click a recognizable start button and send simple movement keys; not a general game-playing agent that understands arbitrary objectives, quests, physics or success criteria.
- **Test outcome:** 67 tests passed at final snapshot, including fake Playwright contract tests, DNS pinning/SSRF defenses, WebSocket blocking, task routing, and an integration test that starts a fixture server bound to loopback and terminates it. A test checks a hostile `.npmrc` with custom `script-shell` and `NODE_OPTIONS=--require` preload behavior is overridden/blocked.
- **Critical caveat:** the Playwright Node package was not installed and npm registry access failed in the authoring environment. A system Chromium executable alone was insufficient for this adapter; Forge did **not** use its own Playwright adapter to visit a real website in the build environment. Browser behavior is implemented and mock-tested, but live engine execution remains unverified.

## E011 — Final v0.1.5 release artifact

- **Assistant response:** delivered source ZIP, npm tarball and browser report; disclosed test counts and the missing live Playwright package honestly.
- **Artifacts:** `/mnt/data/forge-cli-mvp.zip`, `/mnt/data/forge-cli-0.1.5.tgz`, `/mnt/data/forge-browser-qa-report.md`, `/mnt/data/forge-v0.1.5-tests.log`, `/mnt/data/forge-v0.1.5-check.log`.
- **What this report independently did:** extracted the current ZIP to `/tmp/forge-audit-snapshot`, reran `npm test` and `npm run check`, ran `node bin/forge.js --version` and inspected `--help`. Results passed and are listed in Part 13.

## E012 — Current history-extraction request

- **User attachment:** `Pasted text(7).txt`, 515 lines, title “MASTER PROMPT — COMPLETE PROJECT HISTORY EXTRACTION, FORENSIC AUDIT & HANDOFF”.
- **Instructions:** produce 20 numbered report parts, coverage disclaimer, chronological record, prompt-response register, requirement/feature/decision/failure/test inventories, technical architecture and artifact inventory, current state, remaining work, appendices, and valid machine-readable JSON; preserve exact prompt language where available; do not implement features.
- **Action:** this report and JSON sidecar are being produced. No project code was changed for this history report.

---

# PART 5 — Complete accessible user prompt and assistant-response index

This is a complete index of the distinct Forge-related user turns recoverable from the current thread/continuity summary. Exact wording is used when visible; the OpenRouter prompt is labelled as preserved in the continuity summary. The prior two raw chats/OpenCode transcript are not available here, so this is not an enumerated index of every message from those external sources.

| Prompt ID | Prompt / turn | Assistant response substance | Result / status |
|---|---|---|---|
| P-001 | “Can you add api provider openrouter” (exact text available in continuity summary) | Implemented direct OpenRouter transport/config/usage parsing; documented env key; mocked test only. | Implemented; live API not verified. |
| P-002 | “I want preview here can tell me plz with interactive ok” | Interactive workflow simulation with provider/model/task/approval. | Preview only; user redirected format. |
| P-003 | “In cli how it looks like I want that ok pre view me that” | Terminal-themed interactive mockup with screens. | Preview only; user redirected format. |
| P-004 | “I want image not this ok give me once ok” | Generated a 3×3 terminal CLI montage image. | Image artifact produced, not live product UI. |
| P-005 | “Once check code and security and privacy and agents and loop engineering and everything go into website and all platforms and what best top person saying howw the ai coding agent should be there and how watch videos and learn and fact check and implement ahd what ai coding agent users want in agents and what is iretated things in other list do deep dive in to them and do correct and truth ok with evidence and proofs do it @Thinking” | Security/code audit and engineering research; identified credential endpoint redirect, checkpoint forgery/path traversal/deletion, subprocess environment exposure, unsafe Git helper and terminal-output issues; wrote report. | Historical tests ultimately 37 at that phase; no full production security proof. |
| P-006 | “Go into GitHub and check best repos if you want you add them and keep inbuilt ok and harness you will adopt or improve or create your own tell me @Thinking do everything about this harness and understand and learn and make best futurestic with all secure safe privacy and the user data and details other will leave from our agent ok but other days from ihternetvtaken show to users ok make sure check all no. Prompt injection no bad like Ultron make it good and best ok like jarvis but this is coding agent” | Compared open-source harness patterns; chose own lightweight harness; documented safety/privacy boundaries, loop and repository adoption decisions. | Research and fixes evolved into current source/docs. |
| P-007 | “Some best githubs are there like rea and ponytail and context7 and graphify and agent reach for research in social media aplatforms also and other best you will take that and implement or adopt and or create your own what you will do as a creater of this and research in GitHub best repos usefull for us to ok @Thinking @” | Added local graph, Context7 lookup, REA-inspired freeze and Agent-Reach-compatible consent-gated bridge; adopted Ponytail ideas. | 53-test historical snapshot; external service calls not live verified. |
| P-008 | “Boris Cherny,Dax Raad,Andrej Karpathy you hired this people and your are this three people and act like think like work like research llthem and make best ai coding agentic agent ok for futuree and for now and best ok think what in feature ai will do and all what is practically posible now do it not ok paper ok @Thinking” | Applied three as conceptual engineering lenses without claiming to represent/hire them; implemented practical capabilities and documented status. | No endorsement/representation claim. |
| P-009 | Browser QA request quoted in E010 | Added Playwright Browser QA adapter, local dev-server launcher, auto-routing, testing skills and tests. | v0.1.5; no real Playwright engine run in authoring environment. |
| P-010 | Attached “MASTER PROMPT — COMPLETE PROJECT HISTORY EXTRACTION, FORENSIC AUDIT & HANDOFF” (see `/mnt/data/Pasted text(7).txt`) | Current action: create this comprehensive chronological handoff and JSON, without modifying project code. | In progress/completed by this report artifact. |

## 5.1 Response index (material assistant responses)

| Response ID | Topic | Material response/action | Caveats preserved |
|---|---|---|---|
| A-001 | OpenRouter integration | Added adapter/config/docs/tests and refreshed v0.1.0 artifacts. | Mocked fetch; no live request. |
| A-002 | Interactive UI preview | Simulated provider/task/approval in-chat. | Not a real CLI execution. |
| A-003 | CLI visual preview | Styled terminal mockup with clickable screen selector. | Not screenshot of running code. |
| A-004 | Image generation | Produced montage of CLI states. | Concept image only. |
| A-005 | Security/engineering audit | Progressive hardening, repo/docs research, 37 test checkpoint. | Test progress values historical until final snapshot rerun. |
| A-006 | Repo selection architecture | Own thin harness, adopt selected concepts, preserve sources/evidence and limitations. | Repos inspected selectively, not all installed/audited. |
| A-007 | REA/Ponytail/Context7/Graphify/Agent-Reach | Implemented local graph, docs lookup, freeze switch, read-only consent-gated search bridge. | External query backends/live connections not verified. |
| A-008 | Practitioner design lens | Used design principles; did not impersonate or claim endorsement. | Principles are synthesis, not quotations from people. |
| A-009 | Browser QA | Playwright adapter, safe local dev server, browser/game skills, 67 tests. | Real Playwright package/browser execution unavailable. |
| A-010 | History task | Extracted bundle, reran tests/syntax/CLI smoke checks, and built this report/JSON. | Full other-session transcript is unavailable. |

---

# PART 6 — Requirements register

Status key: **IN** = present in current source snapshot; **PARTIAL** = partly implemented; **ROADMAP** = proposed/incomplete; **UNKNOWN** = cannot verify.

| ID | Requirement / source | Why it matters | Priority/status | Evidence and acceptance criterion / remaining check |
|---|---|---|---|---|
| REQ-001 | Approval-first terminal coding harness; P-001 / inherited vision | User remains in control of code changes | Mandatory / IN | `src/cli.js`, `src/runner.js`, tests. Verify on real repo and real provider. |
| REQ-002 | Support OpenCode and OpenRouter; P-001 | Provider choice/flexibility | Mandatory / PARTIAL | `src/llm.js`, `src/config.js`; mocks pass. Live OpenRouter and OpenCode required. |
| REQ-003 | Hide API keys from config, logs, browser code and unrelated subprocesses | Prevent credential exfiltration | Mandatory / PARTIAL | `src/security.js`, `src/audit.js`, `src/runner.js`, tests. Pattern-based controls are incomplete; OS sandbox/network policy absent. |
| REQ-004 | User consent before sending private task/context to remote model | Data control | Mandatory / IN with limitations | Consent tests and README privacy flow. Verify real provider payload; local-only not firewall. |
| REQ-005 | Untrusted external internet content shown with clear evidence/labels; private project details do not accompany public searches by default; P-006/P-007 | Research usefulness without secret leakage | Mandatory / PARTIAL | `src/reach.js`, `src/context7.js`; queries are explicit and external result not auto-passed to model. Live services and citation synthesis not verified. |
| REQ-006 | Patch/path validation, approval, checkpoint and undo | Safe file modifications | Mandatory / IN | `src/patch.js`, `src/runner.js`, checkpoint tests. Verify against Windows-specific path cases and real repos. |
| REQ-007 | Test commands require approval and be bounded | Avoid unexpected execution | Mandatory / IN but unsandboxed | `src/runner.js`; test runs are still user-account processes without OS sandbox. |
| REQ-008 | Security, privacy and prompt injection addressed; P-005/P-006 | Prevent hostile repo/web/model content controlling the agent | Mandatory / PARTIAL | Heuristic scanning and permission checks. Must not claim immunity. Add adversarial evaluation. |
| REQ-009 | Automatic use of skills/commands/agents only when needed; P-009 | Avoid manual routing overhead without agent sprawl | Mandatory / PARTIAL | `src/harness.js`, `src/prompts.js`, `skills/`; roles sequential, not real parallel subagents. Add decision/trace assertions. |
| REQ-010 | Lightweight, free-first, avoid unnecessary paid dependencies | Accessibility and reduced operations burden | Strong preference / IN | Zero required runtime dependencies, optional `playwright-core`; provider charges governed externally. |
| REQ-011 | Local repository index and fast relevant context | Better model context, less unnecessary upload/cost | Strong preference / IN | `src/indexer.js`; caps and exclusions tested. Ranking/semantic quality not benchmarked. |
| REQ-012 | Local graph inspired by Graphify; P-007 | Code relationship hints | Strong preference / PARTIAL | `src/codegraph.js`, `forge graph`. Regex/heuristic graph only, not a complete semantic graph. |
| REQ-013 | Context7 library docs with query-only privacy; P-007 | Current API/library information | Optional / IN but live-unverified | `src/context7.js`; only explicit query/hints sent under consent. Need live schema/error/rate-limit test. |
| REQ-014 | Agent-Reach-compatible public/social research routes; P-007 | Research developers’ pain points across sources | Optional / PARTIAL | `src/reach.js`, selected fixed backend commands. No installs/login/cookie import/writes. Need per-backend runtime tests and platform terms review. |
| REQ-015 | Emergency freeze/stop, based on REA concept; P-007 | Stop agent after unexpected behavior | Strong preference / IN for guarded operations | `forge freeze/unfreeze`; call-site coverage must grow with every new command. |
| REQ-016 | Browser testing of website/apps/games; P-009 | Verify actual UI/runtime behavior | Mandatory for appropriate task / PARTIAL | `src/browser.js`; tests mocked; actual Node Playwright adapter has not run on real browser in this environment. |
| REQ-017 | Local server startup for recognized frameworks | Test local apps without asking user to manually serve every time | Strong preference / PARTIAL | `src/devserver.js`; small allowlist, loopback binding and process cleanup tested. Arbitrary frameworks need explicit URL. |
| REQ-018 | Proof/evidence: screenshot/report/log and truthful success | Make failures visible and avoid false claims | Mandatory / PARTIAL | Browser local report/screenshots and audit logs. No full real-browser evidence generated in this environment. |
| REQ-019 | Multi-platform support | Developers use different OSs | Strong preference / PARTIAL | Node >=22; CI matrix exists. Hosted Windows/macOS jobs are not verified. Reach `.cmd`/`.bat` shims unsupported. |
| REQ-020 | No browser-profile cookie reuse by default | Privacy/account protection | Mandatory / IN by design | Browser docs/source specify fresh ephemeral context, no profile/cookie reuse. Integration test of full Playwright engine still pending. |
| REQ-021 | Lightweight browser engine; choose one best engine | Avoid duplicated capability/dependency | Strong preference / IN design | Playwright Node API chosen; MCP and Vercel `agent-browser` deferred. |
| REQ-022 | Founder final authority; user asked assistant to be CEO/worker | Clarity of approval ownership | Mandatory / IN as interaction boundary | Assistant recommendations are not founder approvals; actual external decision power not implied. |
| REQ-023 | Avoid unlimited/infinite loops; stop when repeated failures/budget exhausted | Cost and task reliability | Mandatory goal / PARTIAL | Bounded sequence/optional correction in prompts, but a robust durable task state machine is roadmap. |
| REQ-024 | Preserve project continuity across sessions | Avoid context loss | Strong preference / PARTIAL | `FORGE.md`, docs, audit, checkpoint mechanisms. There is no complete long-term memory/task database or automatic cross-session handoff. |
| REQ-025 | Research repos/video/docs and fact-check | Evidence-backed design | Mandatory for research tasks / PARTIAL | Reports link sources and separate anecdote from representative evidence. Videos were not literally watched end-to-end. |
| REQ-026 | Do not overclaim implementation/readiness | Trust | Mandatory / IN in docs; historical inconsistency remains | README/docs disclose live limitations; `DELIVERABLES.md` has stale test count of 53. Reconcile docs later. |
| REQ-027 | Include machine-readable handoff with stable IDs | Multi-source project merge | Mandatory for this task / IN in sidecar JSON | `/mnt/data/forge-project-history-handoff.json`. |

---

# PART 7 — Features and implementation status register

| Feature ID | Feature | Purpose/design | Current status | Files / evidence | Remaining work |
|---|---|---|---|---|---|
| FEAT-001 | Sequential coding workflow | Planner → coder → validate patch → approval → checkpoint → tester/reviewer/report | IMPLEMENTED; live model unverified | `src/cli.js`, `src/harness.js`, `src/prompts.js`, `src/runner.js` | Prove with live providers; durable state machine and no-progress detection. |
| FEAT-002 | OpenCode transport | Model calls through isolated/pure OpenCode CLI configuration with tool denials | IMPLEMENTED / MOCK-TESTED | `src/llm.js`, `tests/core.test.js` | Real OpenCode executable/model run on supported OSs. |
| FEAT-003 | OpenRouter direct API | Fixed official OpenAI-compatible endpoint, environment key, bounded response/usage parsing | IMPLEMENTED / MOCK-TESTED | `src/llm.js`, `src/config.js`, tests | Live API request, quota/error/provider compatibility. |
| FEAT-004 | Config management | Provider/model/privacy/resource settings with validation | IMPLEMENTED | `src/config.js`, `src/constants.js` | Ensure migrations/backward compatibility are tested across versions. |
| FEAT-005 | Repository index/search | Local deterministic map, relevance ranking, secret-path exclusions and byte caps | IMPLEMENTED | `src/indexer.js`, tests | Quality benchmark, language-aware parsers, ignore-policy audit. |
| FEAT-006 | Approximate code graph | Deterministic local import/symbol hints without saving source content in graph nodes | IMPLEMENTED, HEURISTIC | `src/codegraph.js`, tests | Better parser if justified, size/performance benchmarks, preserve privacy. |
| FEAT-007 | Patch validator/applicator | Unified diff path/context validation; symlink/traversal checks; delete/rename refusal | IMPLEMENTED | `src/patch.js`, tests | Cross-platform path tests/fuzzing and external review. |
| FEAT-008 | Checkpoint/undo | Save pre-change versions; signed metadata/hash check; refuse overwriting post-apply edits | IMPLEMENTED | `src/runner.js`, `src/utils.js`, tests | Test key loss/migration/recovery; older unsigned checkpoints intentionally not trusted. |
| FEAT-009 | Consent/privacy modes | Ask before remote context; known-local ID logic; remote key protected | PARTIAL | `src/policy.js`, `src/llm.js`, `docs/SECURITY_AND_PRIVACY_CONTRACT.md` | True network-enforced local-only isolation and payload review. |
| FEAT-010 | Secret redaction/audit | Local JSONL events, sensitive-value sanitation, task hashes for lifecycle events | PARTIAL | `src/audit.js`, `src/security.js` | Secret detection is heuristic; audit/checkpoint files can contain sensitive context. |
| FEAT-011 | Restricted subprocess environment | Avoid leaking unrelated keys to model, doctor, Git and user commands | IMPLEMENTED with limits | `src/runner.js`, `src/llm.js`, `src/git.js`; tests | OS sandbox and more platform-specific testing. |
| FEAT-012 | Command approval/policy | Prevent shell operators/high-risk actions; require approval | IMPLEMENTED but not complete sandbox | `src/runner.js`, `src/policy.js`, tests | Command policy fuzzing; shell-less execution; sandbox commands. |
| FEAT-013 | Prompt-injection warning | Heuristic scan of repo/browser context; warn before suspicious model use; outputs remain data | PARTIAL | `src/security.js`, `src/browser.js`, `tests/core.test.js` | AgentDojo-like adversarial suite, false-positive tracking; real security boundary is permissions. |
| FEAT-014 | Skills catalog/autoselection | Built-in task-specific instructions for browser, game, frontend, tests, security, docs | IMPLEMENTED as files + heuristic routing | `skills/*/SKILL.md`, `src/harness.js`, `src/prompts.js` | Broader task router evaluation; external skills trust/signing/versioning. |
| FEAT-015 | Role orchestration | Planner/coder/tester/reviewer workflow | SEQUENTIAL ONLY | `src/harness.js`, `src/prompts.js`, `src/runner.js` | Not a parallel multi-agent/subagent runtime. Any future subagents should be capability-scoped/read-only. |
| FEAT-016 | Context7 docs lookup | Fixed HTTPS endpoint sends user query/hints only; bounded response and source link | IMPLEMENTED / MOCK-TESTED | `src/context7.js`, tests | Live query and schema/API changes; no repository snippets auto-attached. |
| FEAT-017 | Agent-Reach bridge | Fixed platform/backend routing, consent, account gate, query hashing, untrusted results | IMPLEMENTED / MOCK-TESTED, LIVE BACKENDS UNKNOWN | `src/reach.js`, tests | Backend installation, real read-only tests, privacy/ToS review, Windows `.cmd`/`.bat` support. |
| FEAT-018 | Emergency freeze | Halt selected coding/write/network/command actions; exact confirmation to resume | IMPLEMENTED for guarded paths | `src/policy.js`, `src/cli.js`, tests | Verify all future command paths are guarded; freeze cannot stop arbitrary OS activity beyond Forge. |
| FEAT-019 | Playwright browser QA | Browser smoke checks with evidence and privacy guardrails | IMPLEMENTED, FAKE-TESTED; REAL RUN PENDING | `src/browser.js`, `docs/BROWSER_QA.md`, `tests/browser.test.js` | Install actual package and exercise a real test site/app. |
| FEAT-020 | Local dev-server launcher | Allowlisted scripts, loopback start, HTTP readiness check and cleanup | IMPLEMENTED / LOCAL FIXTURE TESTED | `src/devserver.js`, `tests/devserver.test.js` | Test frameworks/OSs matrix; process orphan tests on Windows/macOS. |
| FEAT-021 | Browser/game skills | Task instructions for webpage smoke tests and simple game interaction | IMPLEMENTED as skill docs | `skills/browser-testing/SKILL.md`, `skills/game-testing/SKILL.md` | Real game tasks and objective-aware assertions. |
| FEAT-022 | Browser evidence | Local screenshots + JSON metadata; no persisted page text | IMPLEMENTED, not real-browser-verified here | `src/browser.js`, tests/docs | Verify actual screenshot files/output format on real Playwright. |
| FEAT-023 | Terminal-safe output | Escape control sequences from untrusted output, reject control bytes in patch paths | IMPLEMENTED / UNIT-TESTED | `src/terminal.js`, `src/patch.js`, tests | Review other terminal printers/logs and Unicode spoofing. |
| FEAT-024 | Git status probe hardening | Disable fsmonitor/untracked-cache helper paths and restrict environment | IMPLEMENTED / REGRESSION-TESTED | `src/git.js`, `tests/core.test.js` | Cross-platform Git versions/configuration. |
| FEAT-025 | Resource limits/timeouts | Bound outputs, indexing, provider operations; attempt process-tree termination on timeout | IMPLEMENTED with OS limitations | `src/constants.js`, `src/llm.js`, `src/runner.js`, tests | Verify process group behavior on Windows and long-lived descendants. |
| FEAT-026 | Cost/usage reporting | Parse provider usage/token/cost when supplied; `forge cost` and audit | PARTIAL | `src/audit.js`, `src/cli.js` | OpenCode/OpenRouter cost fidelity varies; not a universal reliable pricing engine. |
| FEAT-027 | Interactive CLI | Simple terminal prompt loop and command CLI | IMPLEMENTED | `src/cli.js`, `bin/forge.js` | Not a full-screen TUI; UX polish. |
| FEAT-028 | Browser installation/status | Optional Playwright package setup after consent; status checks no network | IMPLEMENTED | `src/browser.js`, `src/cli.js` | Real setup on user machine requires registry/browser binary. |
| FEAT-029 | CI matrix | Ubuntu/Windows/macOS config, pinned action SHAs, restricted permissions | CONFIGURED, HOSTED RESULTS UNKNOWN | `.github/workflows/ci.yml` | Trigger and review actual hosted logs. |
| FEAT-030 | Website/desktop/mobile product UI | User originally asked “go into website and all platforms” in broad audit | NOT IMPLEMENTED | No website/editor/app source in current ZIP | Needs explicit scope decision; current product remains CLI. |
| FEAT-031 | True OS sandbox | Isolate arbitrary repository/test/browser code and egress | NOT IMPLEMENTED; release blocker | Documented in `docs/SECURITY.md`, roadmap | Implement/test per OS using container/VM/sandbox backend before untrusted workloads. |
| FEAT-032 | Full parallel subagents | Delegate roles concurrently | NOT IMPLEMENTED | Sequential role workflow only | Add only after controller, capability scopes and budgets are reliable. |
| FEAT-033 | Auto web research synthesis/citations | Gather from many sites/platforms and show evidence automatically in task results | PARTIAL/NOT IMPLEMENTED as unified synthesis | `reach` supports one explicit platform/backend query at a time | Citation-grounded multi-source research workflow, keeping private context out. |
| FEAT-034 | Browser authenticated app testing | Use the user’s authenticated everyday browser session | INTENTIONALLY NOT IMPLEMENTED BY DEFAULT | Fresh context; no profile/cookie reuse | Any scoped authentication support needs separate consent/security design. |
| FEAT-035 | Unattended mode | Execute entire issue without prompts | NOT IMPLEMENTED | README identifies unattended execution as absent | Avoid until sandbox, budgets, approvals, recovery and benchmarks established. |

---

# PART 8 — Technical architecture and execution workflows

## 8.1 Current component architecture

1. **CLI entry:** `bin/forge.js` invokes `src/cli.js`.
2. **Task router/harness:** `src/harness.js` plus `src/prompts.js` chooses a sequential set of role instructions and conditional built-in skills. It is not a fully concurrent autonomous multi-agent graph.
3. **LLM adapters:** `src/llm.js` transports requests via OpenCode CLI or direct OpenRouter Chat Completions. Model response is untrusted text; it cannot directly apply file writes in the default workflow.
4. **Workspace/context:** `src/indexer.js` reads a bounded subset of text and creates repository map/context with secret-path exclusion; `src/codegraph.js` builds an approximate local graph; `src/context7.js` fetches explicit library docs; `src/reach.js` runs fixed allowlisted read-only research backend commands after consent.
5. **Patch layer:** `src/patch.js` parses/validates unified diffs and paths, rejects deletes/renames and unsafe paths, and detects files changed while the user was reviewing.
6. **Execution:** `src/runner.js` orchestrates checkpoints, approvals, restricted child environments, command allowlist/approval, timeouts and reporting; it is not an OS sandbox.
7. **Policy/security:** `src/policy.js`, `src/security.js`, `src/terminal.js`, `src/git.js`, `src/utils.js` hold stop gates, prompt-injection heuristics, terminal escaping, safe Git probe/config/path handling, and helpers.
8. **Audit and evidence:** `src/audit.js` stores local JSONL event records. Browser reports/screenshots are stored in `.forge/browser-runs/`. Sensitive local `.forge` state must not be uploaded without review.
9. **Browser:** `src/browser.js` wraps optional Playwright Node API and performs bounded smoke checks; `src/devserver.js` starts recognized local frameworks after consent.
10. **Packaging/verification:** npm package has zero required runtime dependencies, optional Playwright dependency installation flow, built-in skills/docs/tests, and CI definition.

## 8.2 Intended coding flow

`DISCOVER → PLAN → PROPOSE PATCH → STATIC/PATH CHECKS → USER APPROVAL → CHECKPOINT → APPLY → APPROVED TESTS → REVIEW → REPORT`

A limited corrective patch may be part of the existing workflow, but the roadmap calls for explicit bounded retry/budget/no-progress state management. A robust durable task state machine is not established by the current source alone.

## 8.3 Intended browser flow

`ROUTE TASK → CHECK BROWSER DEPENDENCY → GET CONSENT → (OPTIONAL ALLOWLISTED LOCAL SERVER START) → VALIDATE TARGET/ORIGIN → FRESH CONTEXT → COLLECT LOCAL ERRORS/SCREENSHOTS → WRITE BOUNDED LOCAL REPORT → CLOSE BROWSER/STOP SERVER`

The current browser engine is Playwright Node API, not Microsoft Playwright MCP or `agent-browser`. Those alternatives are deferred to avoid duplicated capability in the MVP.

## 8.4 Research and data flow

- `forge docs` sends the explicitly written question plus optional library/version/language hints to Context7 after consent; repository source and project memory are not silently appended.
- `forge reach search` chooses a fixed, known local executable/backend, shows/discloses the query, sends only the redacted user query after consent, requires `--allow-account` for account/session routes, and returns external content to the user as untrusted text. It does not automatically pass results into the coding model.
- `forge reach doctor` is deliberately separate because upstream Agent-Reach may run generic external channel probes. It is blocked in `privacy.mode=local-only`.
- `forge reach status` inspects local executable availability without launching an arbitrary executable to ask it for status.

## 8.5 Execution and isolation boundary

Forge applies app-level checks: approval prompts, path validators, restricted environments, command policy, timeouts, bounded outputs, checkpoints, browser origin routes and URL/DNS checks. The environment where repository code or tests run is still the user’s OS account. Those checks are **not equivalent to** a container/VM or kernel-enforced sandbox. Browser request interception also cannot reliably constrain all networking such as WebRTC/UDP. External egress control and a disposable restricted VM/container are recommended for untrusted projects.

---

# PART 9 — File, code, command, configuration, and artifact inventory

## 9.1 Source files verified in v0.1.5 ZIP

- `bin/forge.js`
- `src/audit.js`
- `src/browser.js`
- `src/cli.js`
- `src/codegraph.js`
- `src/config.js`
- `src/constants.js`
- `src/context7.js`
- `src/devserver.js`
- `src/git.js`
- `src/harness.js`
- `src/indexer.js`
- `src/llm.js`
- `src/patch.js`
- `src/policy.js`
- `src/prompts.js`
- `src/reach.js`
- `src/runner.js`
- `src/security.js`
- `src/terminal.js`
- `src/utils.js`

## 9.2 Test files verified in ZIP

- `tests/browser.test.js`
- `tests/cli.integration.test.js`
- `tests/core.test.js`
- `tests/devserver.test.js`

## 9.3 Built-in skills

- `skills/browser-testing/SKILL.md`
- `skills/documentation-research/SKILL.md`
- `skills/frontend-debugging/SKILL.md`
- `skills/game-testing/SKILL.md`
- `skills/security-review/SKILL.md`
- `skills/test-driven-development/SKILL.md`

## 9.4 Documentation/evidence inventory

- Root: `README.md`, `FORGE.md`, `DELIVERABLES.md`, `LICENSE`, `.gitignore`, `package.json`.
- Docs: `docs/ARCHITECTURE.md`, `docs/ARCHITECTURE_COMPARISON.md`, `docs/BENCHMARKS.md`, `docs/BROWSER_QA.md`, `docs/GAP_ANALYSIS.md`, `docs/HARNESS_RESEARCH_AND_ADOPTION.md`, `docs/RELEASE_AUDIT_2026-10-20.md`, `docs/RESEARCH_AND_DESIGN_AUDIT.md`, `docs/ROADMAP.md`, `docs/SECURITY.md`, `docs/SECURITY_AND_PRIVACY_CONTRACT.md`, `docs/SPECIFICATION.md`.
- Evidence: `evidence/BROWSER_QA_VERIFICATION_2026-10-20.md`, `evidence/DECODED_BLUEPRINTS.md`, `evidence/FAKE_MODEL_E2E.log`, `evidence/FEATURE_MATRIX.md`, `evidence/LOCAL_TESTS.md`, `evidence/REPO_AUDIT_2026-10-20.md`, `evidence/RESEARCH_NOTES.md`.
- Scripts/examples/CI: `scripts/check.mjs`, `examples/demo-task.md`, `.github/workflows/ci.yml`.

## 9.5 Package/artifact inventory

| Artifact | Current available path | Status/notes |
|---|---|---|
| Source ZIP | `/mnt/data/forge-cli-mvp.zip` | Verified archive listing; 75 entries; includes source/tests/docs/evidence/skills. |
| npm tarball v0.1.5 | `/mnt/data/forge-cli-0.1.5.tgz` | Verified `package.json` has `version: 0.1.5`, package `forge-cli`, engine Node >=22. |
| npm tarball v0.1.2 | `/mnt/data/forge-cli-0.1.2.tgz` | Historical version; not the latest snapshot. |
| npm tarball v0.1.0 | `/mnt/data/forge-cli-0.1.0.tgz` | Historical version; OpenRouter added. |
| Browser QA report | `/mnt/data/forge-browser-qa-report.md` | Browser design/security and test boundaries. |
| Harness research report | `/mnt/data/forge-harness-research.md` | Repository decisions, architecture, privacy and remaining blockers; parts have stale 53-test count. |
| Older security/design audit | `/mnt/data/forge-research-and-design-audit.md` | Earlier snapshot, test count predates browser work. |
| v0.1.5 test log | `/mnt/data/forge-v0.1.5-tests.log` | 67 passing test records; also rerun in this report. |
| v0.1.5 syntax log | `/mnt/data/forge-v0.1.5-check.log` | Syntax check reports 21 JS files. |
| Terminal preview image | `/mnt/data/a_composite_montage_image_showing_a_terminal_cli_i.png` | Concept image, not a live CLI screenshot. |
| This report | `/mnt/data/forge-project-history-handoff.md` | Full accessible handoff. |
| JSON sidecar | `/mnt/data/forge-project-history-handoff.json` | Machine-readable summary. |

## 9.6 Exact configuration, environment variables and commands preserved

- OpenRouter: `OPENROUTER_API_KEY`; fixed API endpoint `https://openrouter.ai/api/v1/chat/completions`; provider config `provider=openrouter`; example model `openai/gpt-4o-mini`.
- Default provider/model reported in original config: `opencode` / `opencode/glm-5.3-flash`.
- OpenCode env opt-in example: `FORGE_OPENCODE_ENV_ALLOWLIST=OPENAI_API_KEY`; the project documentation forbids allowlisting `OPENROUTER_API_KEY`, `FORGE_*`, `OPENCODE_*` and runtime-injection variables.
- Context7: optional `CONTEXT7_API_KEY`.
- Browser binary: optional `FORGE_BROWSER_EXECUTABLE`; documentation says not to point `FORGE_PLAYWRIGHT_MODULE` at unknown code.
- Browser commands documented: `forge browser status`; `forge browser setup`; `forge browser test http://127.0.0.1:5173`; `forge browser test --start`; `forge browser test http://127.0.0.1:5173 --exercise`.
- Local build/test: `npm test`; `npm run check`; `node bin/forge.js --version`; `node bin/forge.js --help`.
- Core CLI: `forge init`; `forge doctor`; `forge config show`; `forge index`; `forge graph`; `forge search "authentication token"`; `forge agents`; `forge skills`; `forge audit --tail 30`; `forge cost`; `forge undo`; `forge freeze "investigating unexpected behavior"`; `forge unfreeze`.
- Browser setup is optional. It asks permission to install `playwright-core` with package lifecycle scripts disabled and does not itself download a browser. A preinstalled Chrome/Chromium/Edge binary or deliberately installed managed browser is needed.

No secret values are included in this inventory.

---

# PART 10 — Tools, agents, subagents, skills, commands, integrations, models and dependencies

## 10.1 Model providers

- **OpenCode CLI:** default transport in config according to README. The subprocess is run in temporary/pure config with tool access denied, narrowed environment, output/time bounds. Actual OpenCode CLI compatibility and real configured model execution are unverified here.
- **OpenRouter:** direct Chat Completions adapter with fixed official HTTPS endpoint, environment key and mocked request/usage/error tests. Live request not performed. Provider pricing, quotas and model availability are controlled externally.
- **Not implemented:** direct OpenAI, Anthropic, Google adapters; automatic model fallback; guaranteed model-free/free API; local model engine bundled inside Forge.

## 10.2 Roles/agents

- Present workflow uses **sequential roles** (planner, coder, tester, reviewer); the README calls it a “one-shot task workflow”.
- Task routing selects skills/roles as needed. Current implementation is not a real parallel subagent runtime and no separate subagent gets open-ended independent authority.
- Planned future specialists: planner, implementer, test analyst, security reviewer. Recommended scope is read-only context and distinct bounded outputs; only controller owns approvals/patch application.
- No evidence of actual independent agents/subagents executing in parallel in this version.

## 10.3 Skills/commands

- Built-in skill texts above.
- `forge skills` lists/shows skill guidance; project skill directories have a symlink safety test.
- Commands include `forge graph`, `forge docs`, `forge reach status|doctor|search`, `forge browser status|setup|test`, `forge freeze|unfreeze`, `forge config`, `forge agents`, `forge command`, `forge undo`, `forge audit`, `forge cost`, `forge index`, `forge search`.
- “Auto-use commands/skills” means the router chooses relevant built-in workflow instructions; it does not mean every command or skill is executed automatically regardless of risk/consent.

## 10.4 External projects/technology decisions

- **Playwright Node API:** chosen for deterministic browser smoke QA. Playwright MCP and Vercel `agent-browser` deferred due overlap in this initial capability.
- **Context7:** docs lookup endpoint, not general browsing; only explicit user query/hints.
- **Agent-Reach:** upstream health/router concepts informed a bounded compatible CLI route. Forge does not bundle/install all its third-party backend tools.
- **Graphify:** concept adapted into a local approximate graph; full codebase parser not imported.
- **Ponytail:** minimal-change/testing principles in prompts; no enforcement authority.
- **REA:** governance/freeze concept; not its Claude-specific hook architecture.
- **Codex CLI:** permissions/sandbox/process-control concepts reviewed.
- **Deep Agents:** modular middleware/checkpoint/task/context concepts reviewed, not embedded as full framework.
- **mini-SWE-agent:** simple loop concept reviewed.
- **Aider:** repository map concept reviewed.
- **AgentDojo:** adversarial evaluation benchmark reference, not yet integrated into test corpus.
- **Continue:** repository read-only/final release status was noted; no import.
- **Daytona:** repository reports core development moved to private codebase in June 2026; no dependency.
- **Microsoft Agent Framework/MCP-Scan/OpenHands/SWE-agent:** selectively reviewed or referenced; not runtime dependencies.
- **Boris Cherny/Dax Raad/Andrej Karpathy:** conceptual design lenses only; no claim of representation, quote attribution or endorsement.

## 10.5 Dependency/operational policy

- Required runtime dependencies: none.
- Node.js minimum: 22.
- Playwright: optional package, not mandatory in base `dependencies`.
- Git: strongly recommended, not required for index.
- Research bridge CLIs/platform backends are user-provided optional executables; not auto-installed or auto-authenticated by Forge.
- Browser and external network use require explicit context/permission, and local-only mode blocks specific known remote flows but is not an OS network lock.

---

# PART 11 — Decisions, revisions, and rejected approaches

| Decision ID | Decision | Proposed by / founder approval | Alternatives considered | Current status and effect |
|---|---|---|---|---|
| DEC-001 | Keep Forge as an original lightweight Node CLI harness | Assistant recommendation in response to user’s build/research requests; consistent with user asking “harness you will adopt or improve or create your own” | Embed entire Codex, Deep Agents, OpenHands or another harness | Current architecture keeps small own controller; external concepts only. |
| DEC-002 | Add direct OpenRouter transport | Explicit user request | OpenCode-only | Implemented; live request remains unverified. |
| DEC-003 | Default to approval-first / checkpoint before patch writes | Inherited existing Forge principle and supported by user’s security/privacy requests | Fully unattended autonomous mode | Retained; no unattended mode. |
| DEC-004 | Treat repo/test/web/model content as untrusted; use heuristic warning plus hard capability controls | Assistant security recommendation and user requirement to prevent prompt injection | Trust system prompt alone | Partly implemented; no immunity claim. |
| DEC-005 | HMAC-sign checkpoints and reject forged metadata | Assistant-discovered vulnerability | Trust JSON checkpoint metadata | Implemented and covered by tests; legacy unsigned checkpoints are not trusted. |
| DEC-006 | Restricted child environments, safe Git probing, terminal escaping and bounded output | Assistant-discovered issues | Inherit parent environment/execute default Git helpers | Implemented and regression-tested in current suite. |
| DEC-007 | Adopt selected ideas from Ponytail, Graphify, Context7, REA, Agent-Reach | User explicitly named repositories and invited adopt/build selection | Clone/import full upstream projects | Adopted selected concepts/capabilities, not full repos. |
| DEC-008 | Context7 is query-only and consent-gated | Assistant design decision within user privacy request | Automatically attach repository snippets to docs query | Current code/docs say query-only. |
| DEC-009 | Agent-Reach-compatible search is explicit/allowlisted/read-only by default | Assistant design choice within user research request | Auto-install backends, read browser cookies, send results straight into model | Not done. Account/session routes need `--allow-account`; no social write actions. |
| DEC-010 | `forge reach doctor` separated from automatic search routing | Assistant found upstream doctor may run external probes | Run doctor automatically before each query | Changed to a separate explicit action; local-only blocks it. |
| DEC-011 | Freeze/unfreeze based on REA governance concept | Assistant suggestion and user requested safety | Import REA hooks outright | Built into Forge. |
| DEC-012 | Playwright Node API as only built-in browser engine for initial QA | Assistant recommendation in response to explicit browser testing request | Browser Use, Playwright MCP and `agent-browser` | Playwright is implemented; other engines deferred. |
| DEC-013 | Do not reuse normal browser profile/cookies by default | Privacy/security design decision | Reuse existing logged-in Chrome session | Current browser flow uses fresh context. |
| DEC-014 | Local server startup only for narrow recognized standard scripts, loopback by default | Assistant implementation decision in browser request | Run arbitrary user/project script guessed by model | Implemented with allowlist/consent; arbitrary frameworks use explicit URL. |
| DEC-015 | Use the named public figures as conceptual lenses, not impersonation | Assistant boundary/decision | Claim to literally hire/represent them | No representation or endorsement claim. |
| DEC-016 | Do not ship “full all platforms”/website UI prematurely | Assistant recommendation; no separate founder approval for a website implementation | Add hosted website, IDE integrations, all social APIs immediately | Forge remains CLI; website/mobile and IDE integrations are not implemented. |
| DEC-017 | Do not claim full sandbox or production hardening | Evidence-grounded reporting decision | Market as safe/finished | Current docs disclose OS sandbox absent and live integrations unverified. |
| DEC-018 | Browser evidence can include local screenshots/report metadata but should not store or send raw page text | Assistant design for user’s evidence request/privacy | Save DOM/page text in logs or forward it to model | Source/tests assert bounded local scan and no persisted page text. |
| DEC-019 | Keep external research output separate from coding context by default | User privacy/data request | Auto-inject web/social output into coding prompt | Search results are returned to user as untrusted text, not auto passed to model. |

---

# PART 12 — Errors, failures, debugging, and corrections

| Bug ID | Symptom/risk | Cause found/reported | Correction reported/current source | Verification / unresolved concern |
|---|---|---|---|---|
| BUG-001 | OpenRouter API key could be sent to a custom HTTPS endpoint | Config allowed any HTTPS host; API key attached to request | Endpoint fixed to official host; redirects rejected | Unit test covers adapter/config. Live transport not tested. |
| BUG-002 | Forged checkpoint could write outside checkpoint path or attempt to delete project file | Checkpoint metadata ID/schema was trusted too much | Strict schema, path checks, workspace binding and HMAC signatures | Current tests cover traversal and deletion attempt. Key migration/recovery remains. |
| BUG-003 | Unrelated parent environment secrets could leak to subprocesses | Child process defaults to inheriting `process.env` | Restricted allowlist, explicit filtered provider key opt-in | Unit tests cover fake environments; real process security varies by OS. |
| BUG-004 | Dangerous command classification missed some argument-bearing commands | High-risk matcher compared some commands to the entire string | Matcher expanded to classify executable/command forms | Regression test “command runner rejects shell operators and reliably classifies high-risk commands”. More fuzzing needed. |
| BUG-005 | Git status could execute repository-configured fsmonitor helper | Automatic Git command used repository config defaults | Safe Git config disables fsmonitor/untracked-cache helper and uses restricted environment | Regression test verifies helper isn’t run; cross-platform variations unknown. |
| BUG-006 | Untrusted terminal output could spoof UI or execute terminal controls | ANSI/control sequences printed without escaping in some paths | Terminal-safe renderer and control-byte rejection in patch paths | Unit test; review all printers and Unicode confusables remains worthwhile. |
| BUG-007 | Child timeout killed only direct child, leaving descendants | Process timeout implementation not comprehensive | Process group/tree termination where platform supports it | Regression test takes about one second; Windows behavior still needs CI. |
| BUG-008 | Browser text extraction could materialize too much page text | Whole `innerText` could be unbounded before scan | Scan capped at 30,000 characters from at most 1,500 text nodes in the page context | Fake browser contract test; live pages not exercised here. |
| BUG-009 | Browser HTTP route filters did not govern WebSocket upgrades | Separate WebSocket handshake channel | Use `BrowserContext.routeWebSocket` (Playwright 1.48+); fail closed if unavailable | Test blocks disallowed `wss://` and keeps query token out of report; actual engine not installed. |
| BUG-010 | DNS rebinding/SSRF concern for public URLs | Checking URL host alone can leave second DNS resolution uncontrolled | Public DNS pre-validation and browser resolver pinning | Contract test; not a substitute for OS-level egress filtering. |
| BUG-011 | `npm` project configuration could force arbitrary shell/preload for dev server | Repository `.npmrc` can define `script-shell` or `node-options` | Forced known shell, restricted env and local-server command allowlist | Fixture adds hostile `.npmrc`; marker asserts preload does not run. Does not prove general sandbox isolation. |
| BUG-012 | Automatically running Agent-Reach doctor could send generic health queries to internet | Doctor includes channel probes, some potentially make generic requests | No automatic doctor before search; explicit `forge reach doctor`; block under local-only | Tests verify status/search don’t launch arbitrary agent-reach binary and doctor local-only gate. Live backend behavior remains. |
| BUG-013 | `forge reach status` could run a PATH-controlled binary to report status | Executing arbitrary `agent-reach` simply to inspect it would be risky | Status now passively inspects backend executable presence; fixed names/allowlist for search | Unit/integration tests; cross-platform `.cmd/.bat` unsupported. |
| BUG-014 | Private project context might be sent with public searches/docs lookup | Generic research convenience could append source/memory | Explicit query/hints only, consent prompt, query hash audit; no automatic model ingestion | Mocked tests; no live payload capture against real service. |
| BUG-015 | Browser tests could touch authenticated user data if reusing Chrome | Reusing profile/cookies would be high risk | Fresh ephemeral context, no profile/cookie import, isolated browser and origin gates | Source tests/docs; live browser not available. |
| BUG-016 | Local-only may be mistaken for network-enforced isolation | Config labels only inspect known model identifiers | Documentation explicitly says it is not a firewall; remote known providers blocked | True OS-level network enforcement remains absent. |
| BUG-017 | Test count drift across reports | Some documentation not refreshed after new tests | README/browser report/evidence say 67, but `DELIVERABLES.md` and harness research report still say 53 | **Unresolved documentation inconsistency**; fix after this report task under normal engineering work. |
| BUG-018 | Real browser integration not verified | `playwright`/`playwright-core` absent and npm registry access unavailable in authoring environment | Mock Playwright engine tests plus real local server fixture | Live adapter run remains pending. |

---

# PART 13 — Tests, validation, evidence and proof status

## 13.1 Current bundle rerun by this report

| Check ID | Command | Environment | Result | What it proves | What it does not prove |
|---|---|---|---|---|---|
| TST-001 | `npm test` | Extracted current ZIP at `/tmp/forge-audit-snapshot`, Node runtime in current container | **67 passed, 0 failed, 0 skipped**, ~3000.376 ms | Current packaged test set succeeds locally from extracted bundle | Not live provider, real Playwright, production security or hosted CI. |
| TST-002 | `npm run check` | Same extracted source bundle | **Syntax OK: 21 JavaScript files checked** | Static JS syntax checker passes | Not semantic/type correctness or real runtime compatibility. |
| TST-003 | `node bin/forge.js --version` | Same bundle | Output `0.1.5` | Entry point works and package version matches expected | Does not prove task run/provider call. |
| TST-004 | `node bin/forge.js --help` | Same bundle | Help printed with current command list/safety defaults | CLI parser/help route works | Not every subcommand or interactive prompt. |
| TST-005 | Archive/package inspect | ZIP listing and `tar -xOf ... package/package.json` | ZIP has 75 entries; npm manifest `forge-cli@0.1.5`, Node >=22 | Artifacts contain expected code/docs/tests and correct version | Does not prove registry publish/install or supply-chain provenance. |

## 13.2 Key named tests observed in the current run

The run output names the following checks (all passed):

**Browser / routing / UI safety**
1. Browser URL validation accepts HTTP(S) and blocks file URLs, embedded credentials and controls.
2. Browser reports remove query parameters and sensitive long path identifiers.
3. Browser smoke audit saves private evidence, isolates state, blocks third-party origins and never persists page text.
4. Public hostnames are pinned to pre-validated DNS addresses to reduce DNS-rebinding risk.
5. Browser audit fails closed when Playwright lacks WebSocket routing support.
6. Browser audit blocks non-allowlisted WebSocket origins before they connect.
7. Browser audit classifies JS runtime errors and layout issues as failure or warning.
8. Browser audit rejects private/LAN targets without explicit network opt-in before launching browser.
9. Task router chooses browser-only workflows and only selects conditional skills/agents when needed.
10. Built-in skills exist and project skill directories cannot be symlinked into arbitrary content.
11. CLI init, doctor, index, config and help work without a model provider.
12. Doctor probes OpenCode without inheriting provider credentials.
13. Non-interactive remote model run fails closed before launching OpenCode.
14. Init refuses to write through an existing config symlink.
15. Init refuses checkpoint symlink without creating its outside target.
16. Heuristic prompt-injection indicators fail closed before a model request in non-interactive local-only mode.
17. `forge graph` writes only local graph metadata and report.
18. `forge docs` fails closed without sending a query in non-interactive mode.
19. `forge HALT` blocks coding tasks before provider startup and non-interactive unfreeze fails closed.
20. `forge reach search` requires explicit consent, uses only fixed backend commands and audits query hash only.
21. `forge reach status` inspects PATH without executing a potentially untrusted Agent-Reach binary.
22. `forge reach doctor` is blocked in local-only mode before launching remote-probing CLI.
23. `forge reach search` fails closed when no supported backend executable is installed.
24. Browser-only tasks auto-route to Browser QA and do not launch repository scripts when Playwright is absent.
25. Skill catalog exposes built-in Browser QA and game-testing instructions to the automatic router.

**Core validation/security/providers**
26. `extractJsonObject` handles fenced objects and braces inside strings.
27. local-only mode refuses non-local model IDs.
28. OpenCode child receives minimal environment and only explicitly allowlisted provider keys.
29. Safe paths reject traversal, secret paths and symlinks.
30. Untrusted terminal controls are escaped and control characters cannot enter patch paths.
31. Secret-path detection and text redaction work for common token patterns.
32. Indexer excludes secret files/common generated directories while ranking task matches.
33. Unified patch safely modifies existing file.
34. Unified patch creates new file and refuses deletion/mismatched context.
35. Checkpoint undo restores modified files and removes newly created files.
36. Checkpoint metadata cannot use untrusted embedded ID to write outside checkpoint directory.
37. Undo rejects forged unsigned checkpoint metadata that attempts to delete a project file.
38. Command runner rejects shell operators and reliably classifies high-risk commands.
39. Repository command environment excludes provider secrets and runtime-injection variables by default and on opt-in.
40. Prompt-injection indicators are surfaced by path/category without returning untrusted instructions.
41. Security review raises elevated approval for probable secret-to-network patch patterns.
42. OpenCode transport denies every tool by default and runs in a temporary pure project.
43. Patch application detects a file changed while waiting for approval.
44. Undo refuses to overwrite a file edited after Forge applied its patch.
45. Audit sanitizes secret-looking values before writing local JSONL.
46. Config rejects unrealistic resource-limit overrides.
47. OpenCode adapter contract with a fake executable uses isolated temp cwd and parses JSON usage.
48. OpenCode adapter stops/rejects when provider output exceeds byte limit.
49. Repo root discovery walks upward without invoking Git.
50. Timed-out commands terminate process group, not only direct child.
51. Git status disables repository fsmonitor hooks and uses credential-free environment.
52. Checkpoint creation rejects symlink directory without following it.
53. Repository index enforces aggregate text-byte budget.
54. OpenRouter adapter sends OpenAI-compatible request and parses usage without exposing key.
55. OpenRouter adapter fails closed without key and rejects local-only mode.
56. Config validates provider and OpenRouter options.
57. Local code graph builds deterministic in-repo edges without persisting source text.
58. Context7 adapter calls only its fixed HTTPS endpoint, bounds response and sends only explicit query inputs.
59. Context7 refuses oversized response and handles provider errors without leaking credentials.
60. Context7 credentials cannot be passed to repository subprocesses even by explicit environment allowlist.
61. Forge emergency HALT blocks guarded work and can be removed only through explicit policy flow.
62. Forge emergency HALT fails closed if marker is malformed or is a symlink.
63. Agent-Reach query and doctor parsing validate input and never permit arbitrary executable names.
64. Agent-Reach routes only explicitly approved/allowlisted backends and marks browser/account use.
65. Agent-Reach executable discovery inspects PATH without launching tools and ignores Windows shell shims.
66. Dev-server discovery only allows a small set of known standard framework scripts.
67. Recognized local dev server is started on loopback and its process tree is stopped afterwards.

## 13.3 Historically reported test counts

| Phase | Count reported at the time | Confidence in this report |
|---|---|---|
| Baseline before OpenRouter | 22 passing | Historical continuity summary; not rerun in this task. |
| OpenRouter adapter | 25 passed, 0 failed; 13 JS syntax files | Historical; mocks, not live API. |
| Checkpoint signing fix | 28 passed | Historical progress update. |
| Subprocess/command fixes | 29 then 35 passed in subsequent updates | Historical progress updates; count evolved during work. |
| Security/Git/repo research release phase | 37 tests; 14 JS syntax files | Historical report. |
| Context7/graph/freeze/Agent-Reach snapshot | 53 tests; 18 JS syntax files | Historic; later superseded by browser work. |
| Browser QA v0.1.5 | 67 tests; 21 JS syntax files | **Rerun and verified in this report.** |

## 13.4 Not executed / blocked

- No live OpenRouter call.
- No actual OpenCode/GLM model call; OpenCode was unavailable in the earlier authoring environment.
- No real Playwright Node browser navigation; dependency missing and npm registry unavailable in that environment.
- No live Context7 API request.
- No live Agent-Reach web/social queries against real accounts.
- No hosted GitHub Actions result from Linux/Windows/macOS matrix.
- No independent penetration test, full-scale fuzzing or representative AgentDojo evaluation.
- No real gameplay proof of a game’s objective completion.
- No formal performance/cost benchmark against other coding agents.

---

# PART 14 — Security, privacy, permissions, cost and reliability concerns

## 14.1 Implemented defenses (not certification)

- OpenRouter endpoint host restriction and redirect rejection to reduce API key redirection.
- HMAC/workspace-bound checkpoint metadata and path/schema validation.
- Patch target, traversal, symlink and context checks; refusal of delete/rename patch operations.
- Approval before applying patch and before executing tests/commands.
- Restricted child-process environments, provider-secret opt-ins, runtime injection-variable deny rules.
- Safe Git status environment/settings; avoid repository-controlled helper execution.
- Timeout/output limits and process group/tree termination where supported.
- Local audit sanitization and secret-path exclusions/common-token redaction.
- Terminal-safe output escaping and restricted patch-path control bytes.
- Prompt-injection heuristics that report path/category and do not return hostile instruction text to the caller; they are not comprehensive.
- External search query consent, account-aware flag, fixed executable/backend routes and no automatic model ingestion.
- Fresh isolated browser context with no normal-profile cookie reuse; URL validation, origin allowlist, DNS pinning, WebSocket route gates, output bounds, local screenshots only.
- Emergency freeze path blocks guarded coding and some external/write/command workflows; unfreeze requires interactive exact confirmation and fails closed in noninteractive mode.

## 14.2 Privacy risks

- Remote model provider receives whatever Forge discloses in the consent flow: task, map, selected excerpts, diffs and potentially test output. Forge cannot promise a vendor never retains data.
- Common token redaction and file exclusions are not comprehensive. Secrets may occur in unusual files, source text or model outputs.
- `.forge/` may contain checkpoints with previous file contents and audit/report metadata. It should be excluded from public uploads and reviewed before sharing.
- Browser screenshots can contain private visual data even though page text is not persisted or transmitted. User should review screenshots before sharing them externally.
- Context7 and Agent-Reach are external services/backends. Their actual retention/terms vary; this source has not live-tested each one.
- Social account routes can invoke user-installed tools and authenticated session backends once the user explicitly enables them; Forge does not import cookies or perform writes, but a configured CLI still has its own risks.

## 14.3 Prompt injection and hostile content

Prompt-injection heuristics can miss encoded, indirect, multilingual, split, hidden, or adversarial content. The essential safeguards are least privilege, user approval, data separation, strict output parsing, path/network policy and execution isolation. Forge’s model is not given direct filesystem/shell tools through the default OpenCode subprocess setup, but OS-level isolation of repository code is absent.

## 14.4 Major remaining security blocker

**No OS-enforced sandbox/container/VM for repository and test execution.** App-level code can constrain behavior but cannot fully contain a hostile npm lifecycle script, native executable, browser exploit or filesystem/network attack running as the user. Before production or untrusted repository execution, use a disposable restricted VM/container, non-root user, limited mounts, egress control, resource limits and secret-free environment; preferably implement/test a dedicated sandbox backend.

## 14.5 Cost and reliability

- OpenRouter prices/usage vary by model/vendor; Forge parsing usage is not a reliable universal cost meter.
- Context7 unauthenticated use may have lower limits; `CONTEXT7_API_KEY` is optional, not a promise of free/never-limited API.
- Agent-Reach backend setup and queries depend on external CLIs/platforms and may need accounts, tokens or cookies configured by the user. No auto-install/login or bypassing platform controls.
- No infinite loop claim: current workflow is bounded/sequential, but a robust durable task-state machine, explicit global cost budget and deterministic duplicate-failure/no-progress stopping have not been fully proven.

---

# PART 15 — Current project state

## 15.1 Latest verified identity

- **Product/package:** `forge-cli`
- **Current bundle version:** `0.1.5`
- **Runtime:** Node.js `>=22`
- **Required runtime dependencies:** none
- **Optional browser library:** Playwright/`playwright-core`; absent in the authoring environment at last browser check
- **Latest source archive:** `/mnt/data/forge-cli-mvp.zip`
- **Latest npm tarball:** `/mnt/data/forge-cli-0.1.5.tgz`
- **Git commit / repository remote:** UNKNOWN (ZIP has no `.git` directory/metadata)

## 15.2 Last confirmed successful actions

- This report session extracted the ZIP into `/tmp/forge-audit-snapshot`.
- `npm test` passed all 67 tests, 0 failures/skips.
- `npm run check` syntax-checked 21 JavaScript files.
- `node bin/forge.js --version` returned `0.1.5`.
- `node bin/forge.js --help` displayed the intended command set and safety defaults.
- Actual source archive listing and npm `package.json` version/engine metadata were inspected.

## 15.3 Existing functionality vs claims

**Verified in source/test execution:** CLI can import and run commands; current automated test suite passes; syntax checker passes; current package version is 0.1.5; key test cases for provider mocks, checkpoint validation, permission policy, research route policy, browser contracts and local server fixture pass.

**Implemented but not live-verified:** OpenRouter network request; OpenCode execution against a real model; Context7 request; Agent-Reach real backend searches; Playwright browser navigation/screenshots through the real Node browser engine.

**Not implemented:** OS-enforced sandbox, full-screen TUI, parallel subagent runtime, native direct OpenAI/Anthropic/Google adapters, automatic model fallback, semantic embeddings, MCP/plugin APIs, hosted agent/UI, PR creation, reliable cost pricing and unattended tasks.

## 15.4 Documentation conflict to preserve

Latest README and browser evidence report say 67 tests and 21 JS files. Root `DELIVERABLES.md` inside v0.1.5 bundle and `docs/HARNESS_RESEARCH_AND_ADOPTION.md` still include an older statement of 53 tests/18 JS files in at least one place. This is stale documentation rather than a failing test. Do not confuse it with the freshly rerun current count of 67.

## 15.5 Where this conversation stopped

The most recent development feature was Browser QA: automatic routing, optional Playwright adapter, local server start, test screenshots/reports, and regression tests. The current user did not ask to implement more product code; they supplied the master-history prompt asking for this report. The source snapshot passed the current test and syntax run, and the report is the requested handoff artifact.

---

# PART 16 — Outstanding tasks, blockers, risks and unresolved questions

| Task ID | Item | Status | Dependency / risk | Acceptance criteria | Priority / founder approval |
|---|---|---|---|---|---|
| TODO-001 | Verify Playwright on real runtime | BLOCKED by missing package/network in previous environment | Install optional Playwright package and browser; disposable project | Run `forge browser test` against a local demo; create screenshot and report; verify closure and origin/network policy in real Chromium | P0 engineering gate; no product-scope approval needed once install is consented |
| TODO-002 | Implement OS-enforced sandbox | NOT IMPLEMENTED | Requires OS-specific design/backend, container/VM or sandbox APIs, mounts/network/permissions | Demonstrate repository command cannot read out-of-workspace secrets or reach blocked network from a disposable test environment on supported OSs | P0; requires architecture review before broad rollout |
| TODO-003 | Live provider validation | NOT DONE | Provider login/API key and safe disposable repo | One OpenRouter live request and one OpenCode live request; confirm consent, redaction, usage, timeout, secret handling and no key in logs | P0; user-owned credentials must remain private, do not request them in chat |
| TODO-004 | Hosted CI run | CONFIGURED, UNVERIFIED | Push repository to GitHub / CI access | Linux, Windows, macOS matrix logs green; platform-specific deviations fixed | P0 before claiming cross-platform ready |
| TODO-005 | Reconcile stale docs test count | KNOWN DOC BUG | `DELIVERABLES.md` and harness report stale statements | All latest docs consistently say current snapshot is 67/67 and older counts labelled historical | P1; routine docs fix |
| TODO-006 | Adversarial prompt-injection evaluation | ROADMAP | Attack corpus, harness to isolate tests; AgentDojo reference | Measure attack success and false-positive rate; include malicious README, test logs, comments, indirect/encoded input; no automatic claims from heuristic | P1 security |
| TODO-007 | Extend loop state/no-progress detection | PARTIAL/ROADMAP | Durable state/run IDs, budgets, retry stops | Repeated patch/failure stops; budget tracked; resume from checkpoint; stop reasons in report | P1 reliability |
| TODO-008 | Browser application-specific assertions | PARTIAL | Real app pages/tests and user goal | Test login/forms/routes/buttons/loading/API and task-specific expected state; capture evidence and distinguish heuristic warning from failure | P1 usefulness |
| TODO-009 | Game-testing depth | PARTIAL | Game-specific test hooks and acceptance signals | Can assert objective/state changes, not just click Start/press movement keys; use screenshots and logs | P2; avoid generic false claims |
| TODO-010 | Multi-agent runtime | NOT IMPLEMENTED | Safe tool boundary, budget and durable state first | Optional scoped agents produce structured artifacts, no credentials, no direct authority to write/approve; benefit measured vs sequential baseline | P2 and only if evidence justifies |
| TODO-011 | Real Context7 verification | NOT DONE | Network/key optional, query disclosure | Live query returns expected docs with source links; no code/project context in request; inspect provider logs/output | P1 |
| TODO-012 | Real Agent-Reach backend verification | NOT DONE | Install/configure one chosen backend with user consent | Public read-only query works; selected route shown; auth route gated; output attributed/untrusted; no cookies/logins/writes by Forge | P1 for research capability |
| TODO-013 | Windows native CLI support | PARTIAL | PowerShell/npm global path/platform CI | Commands/docs work in clean Windows, `.cmd` and `.bat` bridge decision addressed | P1/P2 |
| TODO-014 | Artifact/release provenance | PARTIAL | Git remote/tag/publish workflow | Tagged commit matches ZIP/tarball; checksums and dependency/supply-chain record published | P2 |
| TODO-015 | Performance/quality benchmark | PROPOSED | Representative task set, live provider(s), repeatable measurement | Baseline task success, wall time, provider costs, patch sizes, regression rate and comparative controls; no unsupported superiority claim | P2 |
| TODO-016 | Cross-session durable project continuation | PARTIAL | Task journal/state format and user-controlled storage | Handoff file can resume project status/last test/next task reliably without leaking private state | P2 |
| TODO-017 | Review local screenshots before sharing | POLICY/UX | Browser report user interface | Clearly label images may contain private data and never upload by default | P1 |

---

# PART 17 — Recommended continuation plan

This plan preserves the user’s core goal and prioritizes executable evidence over paper architecture.

1. **Start from the exact v0.1.5 source bundle** and do not silently adopt a different branch/version. Recover the original Git repository/commit from the user’s local machine/OpenCode session if available, then compare it against the packaged source before modifying.
2. **Reconcile release docs** (`DELIVERABLES.md` and older harness report 53 vs latest 67) in a separate doc-only change; record the exact command and current snapshot date.
3. **Prove the browser adapter live:** on a machine where registry access is available, run `forge browser setup` after explicit consent, use a disposable local demo app, run `forge browser test http://127.0.0.1:<port>` and `forge browser test --start`, inspect screenshots/JSON reports, and verify Playwright closure, requests, WebSockets, DNS, process cleanup and no profile/cookie reuse. Do not claim live proof before logs exist.
4. **Implement an OS sandbox before untrusted repository code execution.** Choose a small backend (container/VM/platform-specific OS sandbox) based on target OS and no-VPS preference; include no-root, read-only mounts where possible, workspace-only writes, no host secrets, restricted egress, resource/time/output caps and process cleanup. Fail closed if no sandbox is available when running untrusted tasks.
5. **Run real-provider smoke tests using user-held credentials locally.** Never ask the user to paste credentials into conversation or write keys to repository config. Validate request destination, consent payload, outputs, timeout and log redaction.
6. **Run the hosted CI matrix** and fix platform-specific issues. Preserve full-SHA-pinned actions and read-only CI token policy.
7. **Add adversarial/evidence evals** for indirect prompt injection, path traversal, output spoofing, secrets and no-progress loops. Report both successes and misses/false positives.
8. **Make the core loop resumable and bounded** before adding parallel agents: run/task IDs, TODO state, attempt hashes, cost/time/output budgets, deterministic repeated-failure stopping, checkpointed resume and proof-based final status.
9. **Verify each external connector deliberately.** Start with a public web or GitHub route; show the exact backend/query/URL; do not auto-install tools or read browser cookies; audit only hashes for sensitive search queries; keep results out of coder context unless the user explicitly approves attaching them.
10. **Only then consider additional agent roles/platform UI.** Measure parallel subagents against the sequential baseline. Website/IDE/desktop features require a founder-approved scope and should not be inferred from a prompt to use the CLI browser.

---

# PART 18 — Exact handoff checkpoint

Copy this checkpoint to the master project conversation when continuing:

> We are continuing Forge CLI from the v0.1.5 source snapshot at `/mnt/data/forge-cli-mvp.zip` (npm tarball `/mnt/data/forge-cli-0.1.5.tgz`). This report verified the extracted snapshot: `npm test` = 67 pass / 0 fail / 0 skipped; `npm run check` = 21 JavaScript files syntax-checked; `node bin/forge.js --version` = 0.1.5; CLI help works. No Git commit SHA was recovered. The latest implemented area is optional Playwright Browser QA and a consent-gated allowlisted local-dev-server launcher. Unit/contract tests use a fake Playwright engine. The Playwright Node package was absent and registry access failed in the authoring environment, so Forge has NOT been shown to visit a real website through its own adapter. OpenRouter/OpenCode, Context7 and Agent-Reach have not all been live-tested. Hosted Windows/macOS CI and independent pentest are outstanding. There is no OS-enforced sandbox; this is still an experimental MVP. README/browser evidence says 67 tests, but DELIVERABLES.md and an older harness report still say 53 (documentation drift). Next: reconcile documentation, then verify real Playwright against a disposable local app, then implement/test OS-level isolation before untrusted code, live provider checks, hosted CI and adversarial prompt-injection evals. Keep founder authority and privacy boundaries: no auto-install/login/cookie import/social write operation; no external context send without explicit consent; external content stays untrusted; no full parallel subagents or hosted website UI until foundational reliability/security is proven.

**Where this conversation stopped:** After completing Browser QA integration/release v0.1.5, the user attached a master prompt asking for a comprehensive chronological history and handoff. This report is that handoff; no new product feature was implemented during this report task.

---

# PART 19 — Appendices: original prompts, commands, results and technical details

## Appendix A — Important prompts verbatim where visible

### A1 — OpenRouter request (from continuity summary; not raw UI transcript)

```text
Can you add api provider openrouter
```

### A2 — Preview request

```text
I want preview here can tell me plz with interactive ok
```

### A3 — CLI preview correction

```text
In cli how it looks like I want that ok pre view me that
```

### A4 — Image request correction

```text
I want image not this ok give me once ok
```

### A5 — Security, privacy and user-needs research request

```text
Once check code and security and privacy and agents and loop engineering and everything go into website and all platforms and what best top person saying howw the ai coding agent should be there and how watch videos and learn and fact check and implement ahd what ai coding agent users want in agents and what is iretated things in other list do deep dive in to them and do correct and truth ok with evidence and proofs do it @Thinking
```

### A6 — GitHub harness research request

```text
Go into GitHub and check best repos if you want you add them and keep inbuilt ok and harness you will adopt or improve or create your own tell me @Thinking do everything about this harness and understand and learn and make best futurestic with all secure safe privacy and the user data and details other will leave from our agent ok but other days from ihternetvtaken show to users ok make sure check all no. Prompt injection no bad like Ultron make it good and best ok like jarvis but this is coding agent
```

### A7 — Specific repository adoption request

```text
Some best githubs are there like rea and ponytail and context7 and graphify and agent reach for research in social media aplatforms also and other best you will take that and implement or adopt and or create your own what you will do as a creater of this and research in GitHub best repos usefull for us to ok @Thinking @
```

### A8 — Practitioner-style request

```text
Boris Cherny,Dax Raad,Andrej Karpathy you hired this people and your are this three people and act like think like work like research llthem and make best ai coding agentic agent ok for futuree and for now and best ok think what in feature ai will do and all what is practically posible now do it not ok paper ok @Thinking
```

### A9 — Browser testing request

```text
I want in this the user ask to go inside browser and test the website or apps aor games we should provide a browser playwrite or browser use or other best free and top best ok lightweight strong and powerful ok and the our agentic code auto use skills and cammonds and agents and sub agents when it required ok with proofs and evidences do it make it and your the founder and if you want to add agent reach and other things than only add if not you should not okni and the founder you are the ceo ok and co founder and workers and employees ok all you I am founder ok @Thinking
```

### A10 — Current report-generation request

The exact text is in `/mnt/data/Pasted text(7).txt` (515 lines). It is titled “MASTER PROMPT — COMPLETE PROJECT HISTORY EXTRACTION, FORENSIC AUDIT & HANDOFF” and requires the 20-part structure, evidence labeling, JSON sidecar and no code implementation. That entire 515-line instruction is not duplicated here to avoid burying the project history under the meta-instruction; it remains available as the original attachment.

## Appendix B — Source/research links present in project reports

These were referenced during repository research; the report does not claim every full repository was installed or exhaustively audited:

- OpenAI Codex CLI: https://github.com/openai/codex
- Deep Agents: https://github.com/langchain-ai/deepagents
- mini-SWE-agent: https://github.com/SWE-agent/mini-swe-agent
- SWE-agent: https://github.com/SWE-agent/SWE-agent
- Aider repository map: https://github.com/Aider-AI/aider/blob/main/aider/website/docs/repomap.md
- AgentDojo: https://github.com/ethz-spylab/agentdojo
- Continue: https://github.com/continuedev/continue
- Daytona: https://github.com/daytonaio/daytona
- Microsoft Agent Framework: https://github.com/microsoft/agent-framework
- Ponytail: https://github.com/DietrichGebert/ponytail
- Graphify: https://github.com/Graphify-Labs/graphify
- Graphify advisory recorded in research: https://github.com/Graphify-Labs/graphify/security/advisories/GHSA-pcc4-rvhr-2pr8
- Context7: https://github.com/upstash/context7
- Context7 API guide: https://github.com/upstash/context7/blob/master/docs/api-guide.mdx
- Agent-Reach: https://github.com/Panniantong/Agent-Reach
- REA: https://github.com/bookedsolidtech/rea
- Playwright browser contexts: https://playwright.dev/docs/browser-contexts
- Playwright BrowserContext API: https://playwright.dev/docs/api/class-browsercontext
- Microsoft Playwright MCP: https://github.com/microsoft/playwright-mcp
- Vercel agent-browser: https://github.com/vercel-labs/agent-browser
- OWASP LLM Top 10: https://owasp.org/www-project-top-10-for-large-language-model-applications/
- Node child processes: https://nodejs.org/api/child_process.html
- GitHub Actions secure use: https://docs.github.com/en/actions/reference/security/secure-use

## Appendix C — Evidence file excerpts / paths

- `evidence/FAKE_MODEL_E2E.log`: deterministic fake model/provider trace; not live model proof.
- `evidence/LOCAL_TESTS.md`: older local test scope and limitations.
- `evidence/BROWSER_QA_VERIFICATION_2026-10-20.md`: latest browser test scope and missing live Playwright dependency note.
- `docs/BROWSER_QA.md`: browser design, origin/network policy, commands and limitations.
- `docs/SECURITY.md` and `docs/SECURITY_AND_PRIVACY_CONTRACT.md`: security/privacy approach and caveats.
- `docs/RELEASE_AUDIT_2026-10-20.md`: release audit record.
- `docs/HARNESS_RESEARCH_AND_ADOPTION.md`: selected repository lessons and adoption decisions.
- `docs/ROADMAP.md`: limitations and proposed work.

## Appendix D — Important discrepancies to preserve in the merge

1. **Test count drift:** Current v0.1.5 tests freshly rerun at 67; several root/research documents still show 53 as an earlier snapshot. Do not merge these into one ambiguous number.
2. **“Browser support” vs “browser execution”:** Browser source and fake contract tests exist. Actual browser engine execution did not happen in the authoring environment because Playwright was not installed. These are different states.
3. **“Agentic” vs “multi-agent”:** sequential role orchestration exists; parallel subagents do not.
4. **“Local-only” vs “network-isolated”:** local-only config guards specific provider selection and known external operations; it is not a firewall or sandbox.
5. **“Research integration” vs “live sources”:** Context7 and Agent-Reach adapters exist and have tests, but live API/account/platform access is not verified.
6. **“Secure” vs “production hardened”:** security fixes and tests exist, but there is no OS-level sandbox or independent penetration-test evidence.
7. **“Image preview” vs “CLI capture”:** the generated montage is a design illustration, not a screenshot from a real Forge CLI session.
8. **“Cross-platform CI” vs “cross-platform passed”:** a CI matrix exists; hosted Windows/macOS jobs were not observed running in this context.

---

# PART 20 — Machine-readable handoff data

The companion file `/mnt/data/forge-project-history-handoff.json` contains valid JSON with the known source identity, coverage limits, requirements, features, decisions, test results, blockers, pending tasks, artifact references and exact checkpoint. Unknown information is represented explicitly rather than guessed.

The same machine-readable object is included below so the Markdown report can be copied as a self-contained handoff.

```json
{
  "report_title": "Forge CLI — Complete Accessible Conversation History, Forensic Audit & Handoff",
  "report_date": "2026-10-20",
  "timezone": "Asia/Kolkata",
  "coverage_status": "partial_history_current_release_snapshot_verified_locally",
  "source_identity": {
    "project": "Forge CLI",
    "latest_package": "forge-cli@0.1.5",
    "earliest_identifiable_prompt": "Can you add api provider openrouter",
    "latest_feature_prompt": "Browser QA request to test websites/apps/games and auto-select skills/commands/agents when needed",
    "latest_user_request": "MASTER PROMPT — COMPLETE PROJECT HISTORY EXTRACTION, FORENSIC AUDIT & HANDOFF",
    "missing_sources": [
      "Full raw transcripts of the first prior ChatGPT conversation",
      "Full raw transcript of the second prior ChatGPT conversation",
      "Full raw OpenCode CLI conversation and local coding trace",
      "Original Git remote, branch and commit SHA"
    ]
  },
  "artifact_paths": {
    "source_zip": "/mnt/data/forge-cli-mvp.zip",
    "npm_tarball": "/mnt/data/forge-cli-0.1.5.tgz",
    "browser_report": "/mnt/data/forge-browser-qa-report.md",
    "harness_research_report": "/mnt/data/forge-harness-research.md",
    "older_security_design_report": "/mnt/data/forge-research-and-design-audit.md",
    "test_log": "/mnt/data/forge-v0.1.5-tests.log",
    "syntax_check_log": "/mnt/data/forge-v0.1.5-check.log",
    "cli_preview_image": "/mnt/data/a_composite_montage_image_showing_a_terminal_cli_i.png",
    "history_report": "/mnt/data/forge-project-history-handoff.md",
    "json_handoff": "/mnt/data/forge-project-history-handoff.json",
    "history_request_attachment": "/mnt/data/Pasted text(7).txt"
  },
  "verified_current_checks": {
    "npm_test": {
      "passed": 67,
      "failed": 0,
      "skipped": 0,
      "duration_ms": 3000.37636,
      "status": "verified_through_execution",
      "environment": "/tmp/forge-audit-snapshot extracted from current ZIP"
    },
    "npm_run_check": {
      "syntax_checked_js_files": 21,
      "status": "verified_through_execution"
    },
    "cli_version": {
      "output": "0.1.5",
      "status": "verified_through_execution"
    },
    "cli_help": {
      "status": "verified_through_execution"
    },
    "package": {
      "name": "forge-cli",
      "version": "0.1.5",
      "node_engine": ">=22",
      "required_runtime_dependencies": 0,
      "status": "verified_from_artifact"
    }
  },
  "historic_test_counts": [
    {
      "count": 22,
      "phase": "baseline before OpenRouter",
      "status": "historically_reported"
    },
    {
      "count": 25,
      "phase": "OpenRouter mocked adapter",
      "status": "historically_reported"
    },
    {
      "count": 28,
      "phase": "checkpoint hardening",
      "status": "historically_reported"
    },
    {
      "count": 29,
      "phase": "subprocess environment hardening",
      "status": "historically_reported"
    },
    {
      "count": 35,
      "phase": "additional command/security regressions",
      "status": "historically_reported"
    },
    {
      "count": 37,
      "phase": "security and repo research phase",
      "status": "historically_reported"
    },
    {
      "count": 53,
      "phase": "graph/Context7/freeze/Agent-Reach snapshot",
      "status": "historically_reported_and_stale_in_some_docs"
    },
    {
      "count": 67,
      "phase": "browser QA v0.1.5 snapshot",
      "status": "rerun_and_verified_through_execution"
    }
  ],
  "requirements": [
    {
      "id": "REQ-001",
      "name": "Approval-first terminal coding harness",
      "status": "implemented"
    },
    {
      "id": "REQ-002",
      "name": "OpenCode and OpenRouter providers",
      "status": "implemented_but_live_unverified"
    },
    {
      "id": "REQ-003",
      "name": "Secret protection and restricted environments",
      "status": "partial_security_controls_present"
    },
    {
      "id": "REQ-004",
      "name": "Explicit consent before remote project context sharing",
      "status": "implemented_with_limitations"
    },
    {
      "id": "REQ-005",
      "name": "Public internet/research results shown as untrusted evidence without private project context by default",
      "status": "partial_live_unverified"
    },
    {
      "id": "REQ-006",
      "name": "Patch validation, approval, checkpoints and undo",
      "status": "implemented_unit_tested"
    },
    {
      "id": "REQ-007",
      "name": "Approved bounded verification commands",
      "status": "implemented_but_not_os_sandboxed"
    },
    {
      "id": "REQ-008",
      "name": "Prompt injection defenses",
      "status": "partial_heuristic_not_comprehensive"
    },
    {
      "id": "REQ-009",
      "name": "Automatic conditional skills/commands/roles",
      "status": "partial_sequential_roles_no_parallel_subagents"
    },
    {
      "id": "REQ-010",
      "name": "Free-first lightweight design",
      "status": "implemented_base_no_required_runtime_dependencies"
    },
    {
      "id": "REQ-011",
      "name": "Local repository index/search",
      "status": "implemented"
    },
    {
      "id": "REQ-012",
      "name": "Local approximate code graph",
      "status": "implemented_heuristic"
    },
    {
      "id": "REQ-013",
      "name": "Context7 documentation lookup",
      "status": "implemented_mock_tested_live_unverified"
    },
    {
      "id": "REQ-014",
      "name": "Consent-gated Agent-Reach-compatible search",
      "status": "implemented_mock_tested_live_unverified"
    },
    {
      "id": "REQ-015",
      "name": "Emergency freeze/unfreeze",
      "status": "implemented_for_guarded_paths"
    },
    {
      "id": "REQ-016",
      "name": "Browser website/app/game testing",
      "status": "adapter_implemented_real_browser_run_unverified"
    },
    {
      "id": "REQ-017",
      "name": "Consent-gated local development server launch",
      "status": "implemented_local_fixture_tested"
    },
    {
      "id": "REQ-018",
      "name": "Evidence/screenshots and truthful reports",
      "status": "partial_browser_reports_not_real_site_run_here"
    },
    {
      "id": "REQ-019",
      "name": "Cross-platform support",
      "status": "partial_ci_configured_not_hosted_verified"
    },
    {
      "id": "REQ-020",
      "name": "No daily browser profile/cookie reuse by default",
      "status": "implemented_by_design_real_browser_unverified"
    },
    {
      "id": "REQ-021",
      "name": "One lightweight browser engine",
      "status": "Playwright Node API selected; MCP and agent-browser deferred"
    },
    {
      "id": "REQ-023",
      "name": "Bounded retries/no progress stop",
      "status": "partial_robust_durable_loop_roadmap"
    },
    {
      "id": "REQ-024",
      "name": "Project continuity across sessions",
      "status": "partial_docs/checkpoints_no_full_durable_task_database"
    },
    {
      "id": "REQ-026",
      "name": "Evidence labels, avoid overclaiming",
      "status": "mostly_documented_but_doc_count_drift_exists"
    }
  ],
  "feature_statuses": {
    "sequential_coding_workflow": "implemented_live_model_unverified",
    "OpenCode_transport": "implemented_fake_exec_tested_live_unverified",
    "OpenRouter_transport": "implemented_mocked_request_live_unverified",
    "local_index_and_search": "implemented",
    "approximate_code_graph": "implemented_heuristic",
    "patch_validation_and_checkpoint_undo": "implemented_unit_tested",
    "Context7_docs": "implemented_mocked_live_unverified",
    "Agent-Reach_bridge": "implemented_mocked_live_backend_unverified",
    "freeze_unfreeze": "implemented_guarded_paths",
    "Playwright_browser_QA": "adapter_implemented_mocked_contract_tests_real_browser_not_run_here",
    "local_devserver": "implemented_local_HTTP_fixture_tested",
    "built_in_skills": "implemented",
    "parallel_subagents": "not_implemented",
    "OS_enforced_sandbox": "not_implemented_critical_blocker",
    "hosted_website_or_IDE_UI": "not_implemented",
    "unattended_execution": "not_implemented",
    "live_model_quality_benchmark": "not_implemented"
  },
  "decisions": [
    {
      "id": "DEC-001",
      "decision": "Keep Forge as an original thin Node CLI harness; adopt ideas rather than whole frameworks",
      "status": "current"
    },
    {
      "id": "DEC-002",
      "decision": "Support OpenCode and direct OpenRouter",
      "status": "implemented_live_unverified"
    },
    {
      "id": "DEC-007",
      "decision": "Adopt selected concepts from Ponytail, Graphify, Context7, REA and Agent-Reach",
      "status": "implemented_in_part"
    },
    {
      "id": "DEC-012",
      "decision": "Use optional Playwright Node API as only built-in browser engine initially",
      "status": "implemented_live_run_pending"
    },
    {
      "id": "DEC-013",
      "decision": "Do not reuse normal browser profile/cookies by default",
      "status": "current_policy"
    },
    {
      "id": "DEC-016",
      "decision": "Do not prematurely expand to hosted UI/all platforms; current product remains CLI",
      "status": "current"
    },
    {
      "id": "DEC-017",
      "decision": "Do not claim production readiness or sandboxing",
      "status": "current"
    }
  ],
  "security_findings": [
    {
      "id": "BUG-001",
      "finding": "OpenRouter endpoint credential redirection",
      "status": "fixed_and_mock_tested"
    },
    {
      "id": "BUG-002",
      "finding": "Forged checkpoint path traversal/deletion attack",
      "status": "fixed_and_regression_tested"
    },
    {
      "id": "BUG-003",
      "finding": "Broad inherited child environment leaked unrelated keys risk",
      "status": "restricted_environment_and_tests"
    },
    {
      "id": "BUG-004",
      "finding": "Dangerous command classification gap",
      "status": "matcher_improved_tested"
    },
    {
      "id": "BUG-005",
      "finding": "Git fsmonitor/helper execution via repo config",
      "status": "safe_status_probe_tested"
    },
    {
      "id": "BUG-006",
      "finding": "Terminal control spoofing from untrusted output",
      "status": "escaped_and_tested"
    },
    {
      "id": "BUG-009",
      "finding": "WebSocket upgrade bypass to HTTP route filters",
      "status": "routeWebSocket_gate_tested_with_fake_engine"
    },
    {
      "id": "BUG-010",
      "finding": "DNS rebinding/SSRF risk in browser targets",
      "status": "prevalidation_and_pinning_contract_tested_not_firewall"
    },
    {
      "id": "BUG-011",
      "finding": "Malicious npmrc shell/preload options during dev server startup",
      "status": "fixture_tested_override"
    },
    {
      "id": "BUG-017",
      "finding": "Stale docs report 53 instead of current 67 test count",
      "status": "unresolved_documentation_bug"
    }
  ],
  "pending_tasks": [
    {
      "id": "TODO-001",
      "task": "Run the Playwright adapter with real Playwright/Chromium against a disposable local demo and inspect report/screenshots",
      "priority": "P0",
      "status": "blocked_by_missing_dependency_in_authoring_env"
    },
    {
      "id": "TODO-002",
      "task": "Implement and test OS-enforced sandbox for repository/test/browser code",
      "priority": "P0",
      "status": "not_implemented"
    },
    {
      "id": "TODO-003",
      "task": "Perform safe live OpenRouter and OpenCode smoke tests locally with user-owned credentials",
      "priority": "P0",
      "status": "not_done"
    },
    {
      "id": "TODO-004",
      "task": "Run hosted Linux/Windows/macOS CI matrix",
      "priority": "P0",
      "status": "configured_not_hosted_verified"
    },
    {
      "id": "TODO-005",
      "task": "Reconcile docs test count drift from 53 to current 67 and label older snapshots",
      "priority": "P1",
      "status": "known_not_fixed_in_history_task"
    },
    {
      "id": "TODO-006",
      "task": "Add an adversarial prompt-injection evaluation suite and measure misses/false positives",
      "priority": "P1",
      "status": "roadmap"
    },
    {
      "id": "TODO-007",
      "task": "Implement durable bounded task state/no-progress/cost budget/recovery loop",
      "priority": "P1",
      "status": "partial_roadmap"
    },
    {
      "id": "TODO-008",
      "task": "Live test Context7 and selected read-only Agent-Reach backends with consent and attribution",
      "priority": "P1",
      "status": "not_done"
    },
    {
      "id": "TODO-009",
      "task": "Improve app/game-specific browser assertions and objective-aware gameplay verification",
      "priority": "P2",
      "status": "partial"
    },
    {
      "id": "TODO-010",
      "task": "Only after base safety, evaluate scoped parallel subagents versus sequential baseline",
      "priority": "P2",
      "status": "not_implemented"
    }
  ],
  "unresolved_questions": [
    "What are the original Git repository remote, branch and commit SHA?",
    "Can the user provide the full raw histories of the two prior ChatGPT conversations and the OpenCode CLI session for 100% source coverage?",
    "Which OS targets must be first-class for sandboxing (Windows is especially important in the user context)?",
    "Which actual Playwright runtime install option will be used and tested on a network-enabled machine?",
    "What repository/workload will serve as the real OpenRouter/OpenCode integration test fixture?",
    "What precise budget and retry caps should become user configurable after the durable loop is implemented?"
  ],
  "latest_checkpoint": {
    "version": "0.1.5",
    "source_zip": "/mnt/data/forge-cli-mvp.zip",
    "npm_tarball": "/mnt/data/forge-cli-0.1.5.tgz",
    "tests": "67 passed, 0 failed, 0 skipped (rerun from extracted source ZIP)",
    "syntax": "21 JavaScript files checked",
    "last_working_command": "node bin/forge.js --version",
    "last_output": "0.1.5",
    "latest_feature_area": "optional Playwright Browser QA and consent-gated local server start",
    "real_browser_adapter_run": "not performed; Playwright Node package missing and npm registry access unavailable in authoring environment",
    "production_sandbox": "absent",
    "where_conversation_stopped": "User requested a comprehensive history handoff; product implementation is paused for the report."
  },
  "evidence_references": [
    {
      "path": "README.md",
      "claims": "Version 0.1.5, 67 tests, feature scope and known limits"
    },
    {
      "path": "docs/BROWSER_QA.md",
      "claims": "Browser adapter/security policy and non-live verification boundary"
    },
    {
      "path": "evidence/BROWSER_QA_VERIFICATION_2026-10-20.md",
      "claims": "67 tests, 21 syntax files, live browser/provider/CI limitations"
    },
    {
      "path": "docs/SECURITY.md",
      "claims": "Security and safety model"
    },
    {
      "path": "docs/SECURITY_AND_PRIVACY_CONTRACT.md",
      "claims": "Privacy/remote data handling limits"
    },
    {
      "path": "docs/HARNESS_RESEARCH_AND_ADOPTION.md",
      "claims": "GitHub repository selection and architecture decisions; includes stale old test count in places"
    },
    {
      "path": "evidence/FAKE_MODEL_E2E.log",
      "claims": "Mock provider E2E, not live model proof"
    },
    {
      "path": "/mnt/data/forge-v0.1.5-tests.log",
      "claims": "Latest 67-test run log"
    },
    {
      "path": "/mnt/data/forge-v0.1.5-check.log",
      "claims": "21 JS syntax files check log"
    }
  ],
  "report_parts_completed": [
    1,
    2,
    3,
    4,
    5,
    6,
    7,
    8,
    9,
    10,
    11,
    12,
    13,
    14,
    15,
    16,
    17,
    18,
    19,
    20
  ],
  "appendices_completed": [
    "A: verbatim accessible prompts",
    "B: research links",
    "C: evidence paths",
    "D: discrepancies"
  ],
  "final_instruction": "Copy the Markdown report and JSON sidecar into the master project conversation; preserve evidence classifications and do not infer missing history."
}
```

## Final completeness statement

1. **Coverage:** This report covers all Forge-related information available in the current thread, the continuity summary and mounted v0.1.5 artifacts; it does not cover the complete raw history of both earlier ChatGPT conversations and the OpenCode CLI session because those transcripts were not fully supplied.
2. **Sections completed:** Parts 1–20 are present, along with appendices A–D and a valid JSON sidecar.
3. **Could not recover:** exact full chronology/raw wording for prior separate sessions, original Git remote/branch/commit, all model/tool invocations from OpenCode, unmounted screenshots/logs that were never attached, and live service results not run.
4. **Exact final known state:** source bundle/version `forge-cli@0.1.5`; 67 tests pass; syntax check covers 21 JavaScript files; `--version` prints 0.1.5; help output works; real Playwright adapter/provider/social/documentation connections remain live-unverified; OS sandbox absent.
5. **Where conversation ended:** user requested a complete history/forensic handoff after the browser QA v0.1.5 delivery. No additional product implementation occurred in this report task.
6. **What the new master conversation must do next:** reconcile the doc-count drift, prove Playwright against a real browser/app, implement and test OS sandboxing, validate OpenCode/OpenRouter/Context7/Agent-Reach against live systems using user-held credentials, run hosted platform CI and adversarial evals, then improve resumable bounded loop before adding true parallel subagents.

# COPY THIS REPORT INTO THE MASTER PROJECT CONVERSATION

Copy this entire Markdown report plus the companion JSON sidecar into the unified master project conversation as one source report. Preserve the evidence status labels and the unresolved gaps. Do not treat unknown or historically reported results as verified facts.
