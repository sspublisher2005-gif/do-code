# Forge CLI — TypeScript MVP implementation plan

**Purpose:** executable engineering plan aligned to the locked Forge decisions while preserving recovered v0.4.4 as a non-destructive reference baseline. This document is a plan, not a claim that the TypeScript implementation already exists.

## 1. Scope for the first working milestone

Milestone M1 is complete only when the following are implemented and tested together:

1. `forge --help`, `forge --version`, `forge init`, `forge doctor`, `forge config show`, `forge model test`, `forge files list/read/search`, and `forge audit --tail N`.
2. `forge.config.toml` parsing, schema validation, safe atomic writes, and strict rejection of unknown/unsafe fields where security-sensitive.
3. One typed provider adapter end-to-end with mock contract tests; all four provider families share one interface. Real network requests require explicit consent and are not used in unit tests.
4. Safe workspace file tools that reject traversal, symlink escapes, special files, oversized inputs, credential paths and disallowed write paths; writes are disabled by default, dry-run previews are available, and writes require approval plus a checkpoint.
5. Append-only local JSONL audit events, redaction before persistence, per-project location, stable schema version, request/decision/result linkage, and truthful unknown token/cost fields.
6. CI tests from a clean install and a packaged CLI smoke test pass. No arbitrary shell-command tool or autonomous code-edit loop ships in M1.

## 2. Repository structure

```text
forge/
├── package.json
├── package-lock.json
├── tsconfig.json
├── tsconfig.build.json
├── .gitignore
├── .npmrc
├── LICENSE
├── README.md
├── FORGE.md                         # concise project memory template; user-reviewed
├── forge.config.toml.example
├── docs/
│   ├── ARCHITECTURE.md
│   ├── THREAT_MODEL.md
│   ├── SECURITY_AND_PRIVACY.md
│   ├── SANDBOX_POLICY.md
│   ├── EVIDENCE_AND_COMPLETION.md
│   ├── PROVIDERS.md
│   ├── RECOVERY_AND_ROLLBACK.md
│   ├── TEST_STRATEGY.md
│   ├── RELEASE_PROCESS.md
│   └── BENCHMARK_PLAN.md
├── src/
│   ├── cli/
│   │   ├── main.ts
│   │   ├── command-router.ts
│   │   ├── output.ts
│   │   └── commands/
│   │       ├── init.ts
│   │       ├── doctor.ts
│   │       ├── config.ts
│   │       ├── model-test.ts
│   │       ├── files.ts
│   │       ├── audit.ts
│   │       ├── run.ts
│   │       ├── verify.ts
│   │       └── undo.ts
│   ├── config/
│   │   ├── schema.ts
│   │   ├── defaults.ts
│   │   ├── load.ts
│   │   └── save.ts
│   ├── core/
│   │   ├── types.ts                # canonical public contracts
│   │   ├── errors.ts
│   │   ├── ids.ts
│   │   ├── mission-state.ts        # legal state transitions
│   │   ├── orchestrator.ts         # sole state-machine owner
│   │   └── budgets.ts
│   ├── providers/
│   │   ├── provider.ts             # ModelProvider interface
│   │   ├── openai-compatible.ts
│   │   ├── anthropic.ts
│   │   ├── google.ts
│   │   ├── ollama.ts
│   │   ├── registry.ts
│   │   ├── normalize-usage.ts
│   │   └── retry.ts
│   ├── agents/
│   │   ├── prompts.ts
│   │   ├── orchestrator-agent.ts
│   │   ├── researcher.ts
│   │   ├── architect.ts
│   │   ├── coder.ts
│   │   ├── tester.ts
│   │   ├── reviewer.ts
│   │   ├── security.ts
│   │   └── devops.ts
│   ├── context/
│   │   ├── walk-repository.ts
│   │   ├── repo-map.ts
│   │   ├── symbol-index.ts
│   │   ├── dependency-graph.ts
│   │   ├── ignore-policy.ts
│   │   └── task-context-pack.ts
│   ├── tools/
│   │   ├── registry.ts             # schema + policy broker only
│   │   ├── safe-files.ts
│   │   ├── patch-preview.ts
│   │   ├── git-readonly.ts
│   │   └── verification-command.ts # not host-executable without sandbox approval
│   ├── safety/
│   │   ├── policy-engine.ts
│   │   ├── path-policy.ts
│   │   ├── secret-redaction.ts
│   │   ├── consent.ts
│   │   └── limits.ts
│   ├── sandbox/
│   │   ├── driver.ts
│   │   ├── resolver.ts
│   │   ├── limits.ts
│   │   ├── common/
│   │   │   ├── environment.ts
│   │   │   └── cleanup.ts
│   │   ├── linux/
│   │   │   ├── bubblewrap.ts
│   │   │   ├── landlock.ts
│   │   │   └── seccomp.ts
│   │   ├── macos/
│   │   │   └── seatbelt.ts
│   │   ├── windows/
│   │   │   └── unsupported.ts
│   │   └── container/
│   │       └── docker-podman.ts
│   ├── verification/
│   │   ├── runner.ts
│   │   ├── evidence-store.ts
│   │   ├── checks.ts
│   │   └── completion-gate.ts
│   ├── audit/
│   │   ├── jsonl.ts
│   │   ├── redaction.ts
│   │   ├── integrity.ts
│   │   └── usage-ledger.ts
│   ├── persistence/
│   │   ├── mission-store.ts
│   │   ├── atomic-json.ts
│   │   ├── lock.ts
│   │   ├── checkpoint.ts
│   │   └── recovery.ts
│   ├── privacy/
│   │   ├── project-identity.ts
│   │   ├── project-home.ts
│   │   └── import-context.ts
│   └── util/
│       ├── hash.ts
│       ├── fs-atomic.ts
│       ├── child-process.ts
│       └── time.ts
├── tests/
│   ├── unit/
│   │   ├── config.test.ts
│   │   ├── contracts.test.ts
│   │   ├── path-policy.test.ts
│   │   ├── safe-files.test.ts
│   │   ├── audit.test.ts
│   │   └── completion-gate.test.ts
│   ├── integration/
│   │   ├── cli-init.test.ts
│   │   ├── provider-contract.test.ts
│   │   ├── file-tools.test.ts
│   │   ├── audit-flow.test.ts
│   │   └── dry-run.test.ts
│   ├── security/
│   │   ├── traversal.test.ts
│   │   ├── symlink-swap.test.ts
│   │   ├── secret-redaction.test.ts
│   │   ├── network-policy.test.ts
│   │   ├── env-isolation.test.ts
│   │   └── sandbox-adversarial.test.ts
│   ├── e2e/
│   │   ├── cli.test.ts
│   │   └── browser/
│   │       └── playwright.config.ts
│   └── fixtures/
│       ├── clean-repo/
│       ├── symlink-escape/
│       └── vulnerable-demo-app/
├── scripts/
│   ├── check-release.mjs
│   ├── create-sbom.mjs
│   └── verify-artifacts.mjs
└── .github/workflows/ci.yml
```

**Layout rule:** `src/core/types.ts` owns canonical contract types. Provider output, model-generated tool arguments, repository files, `FORGE.md` and configuration are untrusted inputs until runtime validation/policy checks accept them. Agent modules never import unrestricted filesystem or process primitives directly; privileged I/O stays in `tools/`, `safety/`, `sandbox/`, and `persistence/` behind narrow interfaces.

## 3. `package.json` dependency plan

Keep the runtime surface narrow. Current registry pages consulted on 2026-10-21 report the versions below; a real repository must generate and commit `package-lock.json`, run audit and review licenses before accepting a release. Do not publish by copying this JSON without a resolved lockfile.

```json
{
  "name": "forge-cli",
  "version": "0.1.0",
  "description": "Evidence-first, project-isolated multi-agent AI coding harness",
  "type": "module",
  "bin": { "forge": "./dist/cli/main.js" },
  "engines": { "node": ">=22.12.0" },
  "files": ["dist", "README.md", "FORGE.md", "LICENSE", "docs"],
  "scripts": {
    "clean": "node scripts/clean.mjs",
    "typecheck": "tsc --noEmit -p tsconfig.json",
    "build": "npm run clean && tsc -p tsconfig.build.json",
    "test:unit": "vitest run tests/unit",
    "test:integration": "vitest run tests/integration",
    "test:security": "vitest run tests/security",
    "test": "npm run typecheck && npm run test:unit && npm run test:integration && npm run test:security",
    "test:e2e": "playwright test -c tests/e2e/browser/playwright.config.ts",
    "check:release": "npm run build && node scripts/check-release.mjs",
    "pack:check": "npm pack --dry-run"
  },
  "dependencies": {
    "@anthropic-ai/sdk": "^0.135.0",
    "@google/genai": "~2.30.0",
    "commander": "^15.0.0",
    "ignore": "^7.0.12",
    "openai": "^7.39.0",
    "smol-toml": "^1.9.1",
    "zod": "^4.6.5"
  },
  "devDependencies": {
    "@playwright/test": "^1.64.1",
    "@types/node": "^26.2.0",
    "typescript": "^6.0.3",
    "vitest": "^5.0.3"
  }
}
```

Dependency intent:

- `openai`: OpenAI and compatible chat-completions API; Ollama can be configured through an OpenAI-compatible local endpoint.
- `@anthropic-ai/sdk`, `@google/genai`: direct provider clients so request/usage/error semantics are explicit and tested.
- `smol-toml`: TOML parse/serialize; zero runtime dependencies and TypeScript declarations at the version observed during planning.
- `zod`: runtime validation at every untrusted boundary (config, messages, tool args, mission state, provider responses).
- `commander`: strict command parsing and consistent help/errors.
- `ignore`: `.gitignore`-compatible repository walk filtering.
- `vitest` for unit/integration/security tests; `@playwright/test` for browser E2E only. Browser binaries should be installed deliberately in CI, not fetched from an agent-requested script.

License/dependency caveat: before pinning release versions, use the exact lockfile, `npm audit`, license inventory, SBOM, provenance/signature policy and clean-room install. A clean audit alone is not a source-code security review.

## 4. TypeScript settings

`tsconfig.json` should use `target: ES2023`, `module: NodeNext`, `moduleResolution: NodeNext`, `strict: true`, `noUncheckedIndexedAccess: true`, `exactOptionalPropertyTypes: true`, `noImplicitOverride: true`, `useUnknownInCatchVariables: true`, `forceConsistentCasingInFileNames: true`, `noFallthroughCasesInSwitch: true`, and `skipLibCheck: false` where dependency support allows. Keep `noEmit: true` in the development config and use a separate build config to emit `src/` to `dist/`. Do not solve typing errors by turning off strict mode.

## 5. Canonical contracts (`src/core/types.ts`)

```ts
export type ISODateTime = string;
export type Id = string;

export type MissionStatus =
  | "draft"
  | "awaiting_approval"
  | "ready"
  | "running"
  | "verifying"
  | "needs_review"
  | "completed"
  | "failed"
  | "cancelled"
  | "interrupted";

export type StepStatus =
  | "pending"
  | "ready"
  | "running"
  | "awaiting_approval"
  | "passed"
  | "failed"
  | "blocked"
  | "skipped"
  | "interrupted";

export type AgentRole =
  | "orchestrator"
  | "researcher"
  | "architect"
  | "coder"
  | "tester"
  | "reviewer"
  | "security"
  | "devops";

export interface AcceptanceCriterion {
  id: Id;
  description: string;
  required: boolean;
  verificationKinds: Array<"test" | "typecheck" | "lint" | "browser" | "review" | "security" | "manual">;
}

export interface Mission {
  schemaVersion: 1;
  id: Id;
  projectId: Id;
  repoRoot: string;
  objective: string;
  status: MissionStatus;
  createdAt: ISODateTime;
  updatedAt: ISODateTime;
  steps: Step[];
  acceptanceCriteria: AcceptanceCriterion[];
  maxCostUsd?: number;
  maxDurationMs: number;
  dryRun: boolean;
  approvedCapabilities: Array<"model" | "read_workspace" | "write_workspace" | "sandbox_command" | "browser" | "network_research">;
  evidenceIds: Id[];
}

export type StepKind = "research" | "plan" | "implement" | "test" | "review" | "security" | "devops";

export interface Step {
  id: Id;
  missionId: Id;
  ordinal: number;
  kind: StepKind;
  assignedRole: AgentRole;
  status: StepStatus;
  dependsOn: Id[];
  attempt: number;
  inputEvidenceIds: Id[];
  outputEvidenceIds: Id[];
  toolCallIds: Id[];
  createdAt: ISODateTime;
  startedAt?: ISODateTime;
  finishedAt?: ISODateTime;
  failureCode?: string;
}

export interface TokenUsage {
  inputTokens?: number;
  outputTokens?: number;
  cachedInputTokens?: number;
  costUsd?: number;
  costKnown: boolean;
  source: "provider_reported" | "estimated" | "unknown";
}

export interface AgentMessage {
  id: Id;
  missionId: Id;
  stepId?: Id;
  role: AgentRole | "user" | "system" | "tool";
  senderId: string;
  recipientId?: string;
  content: string;
  toolCallIds: Id[];
  evidenceIds: Id[];
  createdAt: ISODateTime;
  provider?: string;
  model?: string;
  usage?: TokenUsage;
  redacted: boolean;
}

export type ToolRisk = "read_only" | "workspace_write" | "process" | "network" | "credentials" | "destructive";
export type ToolCallStatus = "requested" | "denied" | "awaiting_approval" | "approved" | "running" | "succeeded" | "failed" | "cancelled";

export interface ToolCall {
  id: Id;
  missionId: Id;
  stepId: Id;
  toolName: string;
  input: unknown;                 // must be parsed by the tool's runtime schema before execution
  risk: ToolRisk;
  requestedCapabilities: string[];
  status: ToolCallStatus;
  safetyDecisionId?: Id;
  createdAt: ISODateTime;
  startedAt?: ISODateTime;
  finishedAt?: ISODateTime;
  outputEvidenceIds: Id[];
  errorCode?: string;
}

export type SafetyOutcome = "allow" | "deny" | "needs_approval";
export interface SafetyDecision {
  id: Id;
  missionId: Id;
  toolCallId?: Id;
  outcome: SafetyOutcome;
  policyVersion: string;
  ruleIds: string[];
  resource: string;
  rationale: string;
  decidedAt: ISODateTime;
  expiresAt?: ISODateTime;
  operatorId?: string;
}

export type EvidenceKind = "test_log" | "typecheck_log" | "lint_log" | "patch" | "file_snapshot" | "browser_report" | "screenshot" | "review_report" | "security_report" | "manual_attestation" | "model_response" | "audit_event";
export interface EvidenceRef {
  id: Id;
  missionId: Id;
  stepId?: Id;
  kind: EvidenceKind;
  uri: string;                    // repo-relative or Forge-private artifact URI; never an arbitrary external fetch target
  sha256: string;
  createdAt: ISODateTime;
  producedBy: string;
  verified: boolean;
  mediaType?: string;
  byteLength?: number;
  metadata: Record<string, string | number | boolean | null>;
}

export type VerificationStatus = "passed" | "failed" | "incomplete" | "skipped";
export interface VerificationCheck {
  id: Id;
  name: string;
  status: VerificationStatus;
  required: boolean;
  exitCode?: number;
  durationMs?: number;
  evidenceIds: Id[];
  details?: string;
}
export interface VerificationResult {
  id: Id;
  missionId: Id;
  status: VerificationStatus;
  startedAt: ISODateTime;
  finishedAt: ISODateTime;
  checks: VerificationCheck[];
  unresolvedWarnings: string[];
  completionAllowed: boolean;
  policyVersion: string;
}
```

Implementation notes:

- Store times as UTC ISO-8601 strings; validate format at runtime. Generate IDs with `crypto.randomUUID()`.
- Schema version all persistent records. Use migrations or fail closed for unsupported versions.
- `input: unknown` is intentional: validate input with each tool's Zod schema before evaluating safety or executing it.
- `uri` never authorizes network fetch. External links require their own consent and egress policy.
- Completion is a deterministic function of verified checks/evidence and policy; an agent's text cannot set `completionAllowed=true`.
- A `completed` mission must have `VerificationResult.status === "passed"`, every required criterion mapped to passing evidence, review PASS, no unresolved blocking security warning, and required conditional Browser/Security checks passing. Otherwise use `needs_review`, `failed`, or `incomplete`.

## 6. Provider interface

Put the provider contract in `src/providers/provider.ts` and validate all response shapes:

```ts
import type { AgentRole, TokenUsage } from "../core/types.js";

export interface ModelRequest {
  model: string;
  role: AgentRole;
  system: string;
  messages: Array<{ role: "user" | "assistant"; content: string }>;
  responseSchema?: Record<string, unknown>;
  maxOutputTokens: number;
  timeoutMs: number;
  signal?: AbortSignal;
}

export interface ModelResponse {
  text: string;
  provider: "openai-compatible" | "anthropic" | "google" | "ollama";
  model: string;
  usage: TokenUsage;
  requestId?: string;
  durationMs: number;
}

export interface ModelProvider {
  readonly id: ModelResponse["provider"];
  generate(request: ModelRequest): Promise<ModelResponse>;
  healthCheck(signal?: AbortSignal): Promise<{ ok: boolean; detail: string }>;
}
```

- Use injected client/fetch factories in tests; no real requests in CI by default.
- OpenAI-compatible adapter validates base URL and blocks unexpected schemes/userinfo. The Ollama adapter permits only explicit local endpoints by default and never turns `local-only` into a claim of network isolation.
- Anthropic and Google adapters must map roles, structured output constraints, timeouts, cancellation, rate limits, retry-after and usage into common types.
- Retry only transient transport errors and 429/5xx with capped exponential backoff+jitter; do not retry authentication/config errors; check cancellation between attempts. All retry attempts share a maximum elapsed time and budget.
- `costKnown: false` with no `costUsd` is the honest value when the provider does not report price. Do not infer current prices without a dated pricing table.
- Never put API keys or credential-bearing endpoint URLs in logs, prompts, error messages, or saved config. Read credentials only from explicitly named environment variables or OS credential stores later.

## 7. Module implementation order

### Phase 0 — freeze reference and record baseline

1. Store the v0.4.4 ZIP/tarball/checksum as immutable reference artifacts.
2. Treat observed v0.4.4 behavior as characterization input, not automatic target behavior.
3. Write migration record explaining why target uses TS/TOML and native sandbox first.

### Phase 1 — TypeScript foundation

1. Add package scripts, strict tsconfig, Node support policy, license and lockfile workflow.
2. Add `core/types.ts` and Zod schemas for all persistent/runtime boundary objects.
3. Add `core/mission-state.ts` with a finite allowed-transition table; all other transitions throw.
4. Add `config/defaults.ts`, `config/schema.ts`, `config/load.ts` and `config/save.ts`; reject symlinked config and use atomic create/write.
5. Add CLI parser and deterministic machine-readable output mode; `forge init` must never call a provider and must not overwrite existing files.

### Phase 2 — first working milestone M1

1. `audit/jsonl.ts`: append one JSON object per line, schema version, monotonic event sequence, timestamp, mission/project IDs, action, decision/result IDs; redact secrets before serialization.
2. `safety/path-policy.ts`: canonicalize workspace root, reject absolute paths unless explicitly root-relative API is used, reject `..`, symlink components, devices/FIFOs/sockets, and protected secret patterns; recheck identity before write.
3. `tools/safe-files.ts`: bounded list/read/search, dry-run `writePreview`, and approved atomic write to a same-directory temp file followed by fsync/rename where supported. Create checkpoint + audit event before replacing an existing file. No arbitrary delete/rename in M1.
4. `providers/provider.ts` plus OpenAI-compatible adapter first; mock it with a local in-process HTTP server. Then adapt Anthropic, Google and Ollama behind the same contract.
5. `cli/model-test.ts`: explicit consent before external request; default demo/mock path must be clearly labeled; never imply a real provider was tested when only a mock ran.
6. `cli/audit.ts` and `cli/doctor.ts`: local-only diagnostics with no model calls, no telemetry, and no secret printing.
7. Build a clean-room package and run all M1 acceptance tests in section 10.

### Phase 3 — mission lifecycle and evidence

1. Atomic per-mission persistence with checksums, schema version, project-root identity and per-mission locks.
2. Resume is conservative: detect interrupted work, do not silently rerun a write step, require human review of current diff and explicit choice.
3. Persist `EvidenceRef` artifacts with SHA-256, size limits, private storage and provenance metadata.
4. Deterministic completion gate; test every missing/failed evidence condition.

### Phase 4 — repository context

1. No-follow repo walker, built-in exclusions + `.gitignore`, secret/binary/large-file filters and aggregate byte/file caps.
2. Repo map first; symbol extraction initially language-specific and tested, clearly labelled approximate until parser support exists.
3. Dependency graph from parsers where available; do not call regex-only import hints a complete graph.
4. Task context pack records included files/symbols, reasons, content hashes, token/character count and omitted-file reasons; secret files are never included.
5. Add retrieval fixture tests: relevant symbol recall, secret exclusion, stable ordering, byte-budget enforcement and determinism.

### Phase 5 — bounded multi-agent workflow

1. Orchestrator owns mission state and is the only component able to approve state transitions.
2. Researcher/Architect/Coder/Tester/Reviewer/Security/DevOps agents return validated structured messages. Separate role prompts are organization, not privilege separation.
3. Coder proposes a patch; it does not write to disk. Safety broker validates paths and patch preconditions; human approves write.
4. Tests require explicit approval and run only via selected sandbox driver. Failed tests cannot be overridden by Reviewer PASS.
5. Security agent is supplemental; deterministic rules block high-risk actions even if model review passes.

### Phase 6 — native OS sandbox and reliability

1. Implement `SandboxDriver` contract before enabling any command tool.
2. macOS: Seatbelt driver with a generated minimum-capability profile; probe platform support and fail closed if unavailable.
3. Linux/WSL2: Bubblewrap with user/mount/PID namespaces and no network, read-only source plus writable disposable workspace, limits and cleanup; Landlock/seccomp controls require capability probes and explicit tests, not just config declarations.
4. Docker/Podman remains opt-in for dependency installs/unknown scripts: digest pinned; never auto-pull; fixed unprivileged UID; read-only root; network disabled; dropped capabilities; memory/CPU/PID/time limits; sanitized workspace; cleanup; image signature/provenance/SBOM policy before production.
5. Windows: fail closed until a real supported sandbox implementation and tests exist; never label Windows support as complete because CLI works there.
6. External microVM/gVisor drivers only after first-party sandbox tests pass; never widen privileges by fallback.

### Phase 7 — release confidence

1. Add GitHub Actions full-SHA pins, locked dependency install, Linux/macOS/Windows unprivileged tests, and a dedicated real-sandbox runner.
2. Generate SPDX or CycloneDX SBOM; audit dependency licenses; check archive contents, package files, checksums and provenance.
3. Publish only from protected tag after clean-room install and package test from the generated `.tgz`.
4. Run a controlled benchmark against Claude Code/Codex only when access is available: fixed model/version, 30–50 held-out tasks initially, repeat seeds, equal budget, task success, test quality, human grade, cost, latency, security events and raw artifacts. No claims of superiority until evaluated.
5. Conduct onboarding usability tests and 20–30 customer interviews/tests after engineering reliability is adequate.

## 8. Security defaults and non-negotiable rules

- No telemetry and no background network activity by default.
- Provider request requires explicit context-sharing mode unless configured `local-only`; local-only configuration is not a network sandbox.
- No agent may directly invoke `fs`, `child_process`, `net`, `fetch`, browser drivers or arbitrary plugin code. Registered tools execute through central policy broker.
- No provider key inherited into shell/test/browser child processes. Use minimal allowlisted environment; scrub common credentials and avoid writing secrets to workspace copies.
- Deny network by default in sandbox. An allowlisted URL is not a valid reason to let untrusted code choose arbitrary egress.
- Bounds on file counts/bytes, context size, output tokens, duration, process count, memory/CPU and audit growth.
- On path uncertainty, policy error, missing sandbox capability, malformed provider/tool output, missing evidence or corrupted state: stop safely and surface a review-required status.
- Store event summaries by default; keep full model prompts/transcripts only if explicitly configured, encrypted where persisted and retention-limited.
- A hash chain detects some edits but is not a signature; protect signing key/state separately and explain tamper limits.

## 9. Test strategy

### Unit tests (fast, required on every commit)

- TOML parsing, defaults, schema constraints, unknown keys, path resolution and symlinked config refusal.
- Mission/Step state transition table and invalid-transition refusal.
- Provider response normalization, error mapping, retry classification, timeout/cancellation, malformed structured response, usage unknown/zero semantics.
- Tool input schemas; safe path normalization; traversal; Unicode/separator oddities; symlink and special-file rejection; maximum size limits.
- Audit JSONL parse/write, redaction before persistence, corrupt/truncated final line handling, event sequence; do not claim cryptographic authenticity without keyed signatures.
- Evidence SHA-256, artifact-size limits, and `VerificationResult` aggregation.
- Completion gate rejects absent tests, failed tests, missing criterion links, reviewer failure, unresolved blocking security warnings, failed browser checks and unknown required verification.

### Integration tests (temporary repos, no real model/API)

- `forge init` from a clean directory creates safe config, `FORGE.md`, private local state and audit root; second run is non-destructive.
- OpenAI-compatible HTTP fixture returns representative JSON, error, timeout, 429 and 500 responses; cancellation closes the request.
- A single mock-backed task constructs context, proposes a patch, requires approval, checkpoints, writes only in the test workspace and emits a verifiable audit chain.
- Dry-run produces a patch preview and does not modify workspace hashes or launch test commands.
- `forge undo` only restores files whose current hashes match the expected post-write hash; it must refuse to overwrite later user edits.
- Clean-room `npm pack`, install tarball into a temporary project, call CLI help/version/doctor, run packaged tests and verify no source-only imports are missing.

### Security/adversarial tests (required before enabling command autonomy)

- Symlink substitution and TOCTOU attempts between validation and write; hard links and path case/Unicode differences on applicable platforms.
- Reads/writes outside workspace, `.env`, SSH/cloud credentials, browser profiles, keychain/database files and nested symlink aliases.
- Prompt injection inside repository files and `FORGE.md` cannot alter safety policy or automatically grant tool permissions.
- Child process cannot access ambient model keys, user profile, host home or secret sentinel; audit and error messages redact credentials.
- Sandbox blocks network to localhost/LAN/public network as configured; outside-workspace read/write sentinel tests; CPU/memory/PID/time limits; SIGTERM/SIGKILL/process-tree cancel; kill/restart; cleanup after crash.
- Image digest mismatch, unsigned/untrusted images, stale SBOM, mutable tags and corrupted sandbox state fail closed.
- Concurrent mission resume, stale PID/lock, crash at each lifecycle phase, corrupted JSON/state, partial write and power-loss approximation.

### Browser/Playwright E2E

- Run a tiny deterministic local fixture app inside approved sandbox. Record trace, screenshot and evidence manifest.
- Assert page loaded, expected UI control works, no uncaught runtime/page errors, no unapproved third-party network origins, and seeded known UI failure is detected.
- Desktop and mobile viewport coverage. Browser result must be tied to the mission and exact local app/hash. Do not treat a `page.setContent` smoke fixture alone as a live-HTTP integration test.

### Cross-platform and release tests

- Linux, macOS, Windows clean installs; paths, terminal signals, process trees, permissions, packaging and CLI smoke.
- Linux/macOS sandbox-specific assertions run only where actual runtime capabilities are present; unsupported systems must show an explicit blocked state.
- Dependency audit, license list, SBOM, checksum, tarball path audit, package allowlist, clean-room install and hosted CI result retained as evidence.

## 10. Milestone gates

### M1 — CLI + config + model adapter + safe file tools + audit

Acceptance criteria:

- [ ] `npm ci` succeeds from committed lockfile on supported Node 22+.
- [ ] `npm run typecheck`, `npm test`, and `npm run build` pass.
- [ ] `forge --help`, `forge --version`, `forge init`, `forge doctor`, `forge config show`, `forge files list/read/search`, `forge model test`, `forge audit --tail 10` run.
- [ ] TOML defaults and invalid config cases are unit-tested; configuration never supplies an arbitrary executable or secret.
- [ ] Provider uses mock HTTP in automated test; live mode is explicit and labeled; no actual network request during `forge init` or unit tests.
- [ ] File reads are bounded; writes are preview-only until interactive approval and checkpoint are implemented. Path traversal/symlink tests pass.
- [ ] Audit log records request, policy decision, action result and evidence IDs; secrets are redacted before storage.
- [ ] Cost/token usage is `unknown` unless provider reports it; zero is not guessed.
- [ ] Dry-run does not change workspace files or execute commands.
- [ ] Clean-room packed install and CLI smoke pass.
- [ ] No claim of autonomous coding, sandbox safety, production readiness, cross-platform support or live provider validation is made at M1.

### M2 — mission/evidence/recovery

- [ ] Mission/step state is versioned and persisted atomically; invalid transitions fail closed.
- [ ] Crash/lock/concurrent resume tests pass.
- [ ] Evidence hashes and links are verified; missing evidence blocks completion.
- [ ] Undo checks file hash preconditions; conflict means refuse, not overwrite.

### M3 — context and bounded agents

- [ ] Repo map, symbol index, dependency graph and context pack are separately testable.
- [ ] Relevant-context benchmark shows why each included file was selected.
- [ ] Coder proposes patches only; file writes route through policy and explicit approval.
- [ ] Test/review/security evidence is separate and completion is deterministic.

### M4 — real sandbox

- [ ] OS-specific negative tests demonstrate blocked network, blocked secrets, blocked outside-workspace access, limits, cancellation and cleanup.
- [ ] Fail-closed behavior validated on every unsupported OS/runtime.
- [ ] Independent security reviewer has reviewed attack surface and residual risk.

### M5 — releasable candidate

- [ ] Linux/macOS/Windows CI evidence, clean-room package install, lockfile audit, SBOM/license report and checksum.
- [ ] At least one local model-backed and one approved remote OpenAI-compatible coding task complete with verified patch/tests and saved evidence.
- [ ] Browser E2E fixture passes under sandbox and failure injection is detected.
- [ ] All open critical findings fixed or explicitly risk-accepted with owner/date; product and user tests reported separately.

## 11. Required implementation order, short form

`strict TS contracts → config → audit/redaction → safe path policy → safe file tools → mockable provider contract → CLI M1 → mission persistence/locks → evidence store/completion gate → repo context packs → patch planner → interactive approvals/checkpoints → verification runner → agents → native sandbox → browser E2E → cross-platform CI → release/SBOM/license → live-provider task → benchmark/customer validation`.

The repository should stop at a known-good milestone whenever a gate fails. Do not build more autonomous agents as a workaround for missing sandbox/evidence foundations.

## 12. Package/version sources consulted during planning

Versions are observations on 2026-10-21 and can drift before implementation. Freeze resolved versions in `package-lock.json` after install/audit. Official/current registry references:

- OpenAI TypeScript SDK: https://github.com/openai/openai-node/blob/main/package.json
- Anthropic TypeScript SDK: https://www.npmjs.com/package/%40anthropic-ai/sdk
- Google Gen AI SDK: https://www.npmjs.com/package/%40google/genai
- Commander: https://www.npmjs.com/package/commander
- Zod: https://www.npmjs.com/package/zod
- smol-toml: https://www.npmjs.com/package/smol-toml
- ignore: https://www.npmjs.com/package/ignore
- TypeScript: https://www.npmjs.com/package/typescript
- Node types: https://www.npmjs.com/package/%40types/node
- Playwright Test: https://www.npmjs.com/package/%40playwright/test
