# Continue Forge CLI here

This pack brings forward the latest recovered Forge baseline and a strict TypeScript-first implementation plan. Start with `FORGE_CONTINUATION_CONTEXT.md`, then read `planning/TYPESCRIPT_MVP_IMPLEMENTATION_PLAN.md`.

## Authoritative order

1. The current user-approved decisions and requirements in `FORGE_CONTINUATION_CONTEXT.md` are the desired product direction.
2. `baseline/Forge_Unified_v0.4.4.zip` is the latest recovered release source archive; `baseline/forge-coding-harness-0.4.4.tgz` is its npm artifact. They are immutable reference artifacts, not proof that the TypeScript target already exists.
3. `baseline/extracted-source/Forge_Unified_v0.4.4/` is a browsable extraction of the same release archive.
4. `verification/RELEASE_VERIFICATION_2026-10-21_v0.4.4.md` records the original local verification and open blockers. `verification/independent-local-rerun/` contains checks rerun while preparing this handoff.
5. `history/` is old project lineage. If an older report conflicts with v0.4.4 or the current user decisions, label the conflict rather than merging incompatible claims.

## Independently rerun results in this ChatGPT recovery environment

- Node.js v22.16.0 / npm 10.9.2.
- Source test suite: 129 passed, 0 failed, 0 skipped.
- Syntax check: 32 JavaScript files passed.
- `npm ci --ignore-scripts`: succeeded; npm reported 0 vulnerabilities for the one-package dependency tree. This does not audit code or container images.
- `npm run check:release`: exited 0 and reported PASS; fresh package contains 121 files and 129 passing tests.
- CLI `--version`: 0.4.4; CLI `--help`: exit 0.
- SHA-256 of both original package artifacts matches the supplied manifest.

## Do not claim these are done

No TypeScript migration has been built by this recovery task. No live model-backed coding task was run. No real Docker/Podman isolation or escape test, native macOS/Linux sandbox validation, Windows sandbox, hosted CI result, image signature/provenance/SBOM enforcement, independent penetration test, external customer validation or controlled competitive benchmark was performed here. Consult the latest release verification and acceptance-gates docs.

## First next engineering action

Create a separate strict TypeScript repository from the plan; leave the recovered v0.4.4 JS artifact untouched. Begin with contracts/config/audit/path policy/safe file tools/provider interface and the M1 acceptance tests. Keep arbitrary shell execution and autonomous writes disabled until the corresponding sandbox and evidence gates pass.
