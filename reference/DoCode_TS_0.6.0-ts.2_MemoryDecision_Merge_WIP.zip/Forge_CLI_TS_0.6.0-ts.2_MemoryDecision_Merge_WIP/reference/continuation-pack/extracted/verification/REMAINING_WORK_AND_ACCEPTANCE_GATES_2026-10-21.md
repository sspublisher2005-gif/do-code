# Forge remaining work — acceptance gates

**Baseline:** Forge Unified v0.4.3 review build, including the opt-in sandbox path. This list separates local code work from evidence that requires an actual runtime, live provider, other operating systems, or people. The release should not be marked complete merely because code and docs exist.

## P0 — security and core trust

| Work | Current state | Acceptance evidence | Blocker type |
|---|---|---|---|
| Container execution isolation | v0.4.3 adds opt-in disposable sandbox command and `--sandbox-tests` routing. Ordinary host commands remain unchanged. No real runtime was present at implementation time. A separate real-Docker smoke job is configured in GitHub Actions but has not yet run. Docker remote/unverified context schemes now fail closed; a local Unix-socket proxy can still relay to another daemon and must be trusted by the operator. | Real Docker + Podman tests: network denial, host-secret sentinel, outside-file sentinel, resource limits, timeout/child cancellation, cleanup; independent attack review. | External runtime + security review |
| Trusted image provenance | Not implemented beyond no-auto-pull and operator-selected local images. | Enforced digest/signature policy, image scan/SBOM, update/rollback guidance. | Research + implementation |
| Crash-safe task lifecycle | v0.4.3 adds atomic per-session process locks, refuses concurrent CLI attempts, recovers stale same-host locks and marks old running attempts interrupted. Resume still re-runs task from the beginning and can leave partial edits. | Repeated process-kill tests at every phase; cross-process races; power-loss durability; stale PID reuse handling; explicit diff conflict detection and rollback instructions. | Implementation + repeated tests |
| Independent completion evidence | Command exit codes/audit events exist; acceptance coverage remains partly heuristic. | Versioned task contract; map each criterion to actual test/browser/manual evidence; fail closed on missing evidence. | Implementation + QA design |
| Live end-to-end provider run | Not recorded in prior evidence. | One simple task with real local provider and one approved remote OpenAI-compatible provider; patch, test results, redacted transcript/usage. | Provider access / user credentials |

## P1 — coding quality and product trust

| Work | Current state | Acceptance evidence | Blocker type |
|---|---|---|---|
| Provider adapter reliability | Prototype; token/cost formats incomplete across providers. | Contract tests for schemas, tool calls, timeout, cancellation, 429/5xx retry, malformed responses, token/cost reporting. | Implementation + provider accounts |
| Fair coding benchmark | Not run. | 30–50 held-out tasks to start; fixed model/version and budget; multiple seeds; success/cost/latency/safety; raw artifacts and human review. | Execution budget + competitor access |
| Cross-platform support | Current recorded verification is Linux/container only; v0.4.3 sandbox fails closed on Windows. | CI install/tests on Linux, macOS, Windows; path, process-tree cancellation, symlink, packaging and sandbox parity evidence. | External CI runners |
| Browser QA integration | Optional Playwright route exists but no live E2E proof in this release environment. | Real sample app, screenshot trace, console/network errors, UI acceptance steps and reproducible report; isolate runtime. | Browser dependency / runtime |
| Independent security review | Not performed. | Findings ranked by severity, regressions tests, fixes or accepted risk with owner/date. | External reviewer |

## P2 — onboarding, operations and customer validation

| Work | Current state | Acceptance evidence |
|---|---|---|
| First-run setup | CLI help and doctor exist; setup needs user usability validation. | Beginner test with clean machine/no provider, local provider, remote provider; measure time-to-first-verified-change. |
| Cost transparency | Cost command reports only provider-supplied figures and unknown when absent. | Provider-specific token price metadata with version date and explicit “unknown” states; strict budget refusal before exceeding known budgets. |
| User testing | No representative customer interviews/usability tests recorded. | 20–30 target users, scripted tasks, success and abandonment metrics, privacy-safe notes. |
| Release operations | No upstream push or npm publication. | User-owned repository, CI, changelog, license/third-party notice audit, signed artifacts, release instructions. |
| Security and privacy docs | Strong project-bound context and session docs; residual risks remain. | Reviewable data-flow diagram, event-retention/deletion semantics, threat model, backup/recovery and provider data disclosure. |

## P3 — defer until P0/P1 pass

- Full recursive Harness² Propose–Probe–Compose optimizer with pinned upstream integration and license review.
- Multi-step durable plans, true transcript/step resume, write-owning child agents and cross-task agent teams.
- ACP and remote MCP transports, richer MCP resources/prompts and OAuth; never permit an untrusted server to set Forge policy.
- IDE/GUI, extension marketplace, hosted/team features and remote execution.
- Broader memory/semantic search features; maintain strict project boundaries and explicit cross-project import.

## Release rule

Forge is not “100% complete” until the critical acceptance gates have evidence. Source implementation, unit tests, real runtime validation, external security review, user validation, and proven competitiveness are separate milestones. Do not turn blocked work into a completion percentage by counting documentation or planned features.
