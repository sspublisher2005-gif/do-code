# Recovery-local verification report — 2026-10-21

This report documents checks performed while recovering Forge artifacts from the ChatGPT file library. It is distinct from the original release report and is not an independent security audit.

| Check | Result | Limitation |
|---|---|---|
| Source ZIP entry-path inspection | PASS — 179 entries; no absolute or `..` path entries | Does not replace testing the program. |
| ZIP SHA-256 | PASS — `a8ee95139d6f7e703d4ef3d4b7c3f7a174906736c9c7774a229438b73209572d` | Matches provided manifest. |
| npm tarball SHA-256 | PASS — `b6697318ac7b3b4c6f0a662b0fe91a15ead0ea95a10b06d473ffa10e4fd51852` | Matches provided manifest. |
| `npm ci --ignore-scripts` | PASS — npm reported 0 vulnerabilities across a one-package/no-runtime-dependency package tree | This says little about application code and no image scan was run. |
| `npm test` | PASS — 129 passed; 0 failed; 0 skipped | Tests are those in the JavaScript v0.4.4 artifact. |
| `npm run check` | PASS — 32 JavaScript files syntax-checked | No TypeScript exists in the current artifact. |
| `npm run check:release` | PASS, exit 0 — packed tests 129/129; syntax check; CLI version/help | This is local package validation, not hosted CI. |
| CLI version/help | PASS — version 0.4.4; help exit 0 | Does not validate provider credentials or real model execution. |

## Still unverified

Real sandbox isolation and attack cases; live provider-backed coding; actual Node Playwright integration against HTTP-served apps; hosted GitHub CI; image scan/signature/provenance/SBOM; macOS and Windows runtime behavior; independent security review; real customer tests; fair competitor benchmark. Refer to the latest release verification report for the full limits.
