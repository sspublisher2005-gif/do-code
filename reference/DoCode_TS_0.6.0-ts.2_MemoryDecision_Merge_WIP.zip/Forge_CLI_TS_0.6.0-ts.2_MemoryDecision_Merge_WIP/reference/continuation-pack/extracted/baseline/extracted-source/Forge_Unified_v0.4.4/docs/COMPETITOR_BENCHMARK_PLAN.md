# Competitor Benchmark Plan — Evidence Before “Better”

Forge wants to be stronger than Claude Code, OpenAI Codex, OpenCode, Pi, Google Antigravity and related coding harnesses. This is the product ambition, **not a verified performance claim**.

## What to learn from public official descriptions

- **Claude Code:** Anthropic describes multiple customization mechanisms including `CLAUDE.md`, rules, skills, subagents, hooks, output styles and prompt configuration. Benchmark plan: compatibility, task context, hook-driven checks, skill selection and subagent value. Source: https://claude.com/resources/articles/steering-claude-code-skills-hooks-rules-subagents-and-more
- **Codex CLI:** OpenAI documents a local coding-agent CLI and approval/sandbox controls. Benchmark plan: patch correctness, command safety, test loop, and behavior under restricted permissions. Source: https://github.com/openai/codex and https://help.openai.com/en/articles/11096431-openai-codex-cli-getting-started
- **OpenCode:** current docs describe configurable primary agents and subagents plus tool permissions that can allow, deny or require approval. Benchmark plan: role routing, permissions, multi-step task completion and integration friction. Sources: https://docs.opencode.ai/docs/agents/ and https://docs.opencode.ai/docs/tools/
- **Pi:** project description emphasizes a minimal extensible harness, skills/extensions and several interaction modes while not including subagents and plan mode by default. Benchmark plan: startup and context overhead, extension ergonomics, model/provider freedom and completion on matched tasks. Source: https://github.com/franekp/pi
- **Google Antigravity:** official docs describe an agentic development workspace spanning editor, terminal and browser, with parallel agents and task artifacts. Benchmark plan: full workflow completion and evidence quality, especially UI/browser changes. Source: https://www.antigravity.google/docs/ide/overview/
- **Playwright (tooling comparator, not a coding-agent competitor):** traces can capture browser operations, screenshots, snapshots and network activity. Benchmark plan: trace reproducibility, useful debugging signals and correct failure reporting. Source: https://playwright.dev/docs/api/class-tracing

These sources describe product capabilities; they do not establish that any product wins on all coding tasks. Web pages and feature availability change, so record the retrieval date and tested release for every experiment.

## Evaluation design

1. **Task set:** at least 50 diverse tasks initially (bug fixes, feature work, test repair, refactor, repository exploration, security review, frontend/UI, API, browser journey, game interaction if supported), then grow to a held-out set. Include both public and private seeded tasks and known negative cases.
2. **Matched environment:** same base commit, language/runtime, task prompt, available context, target tests, tool permissions, time budget and model when possible. Clearly label unmatched provider/model setups instead of pooling them.
3. **Repetition:** multiple task variants or seeds; repeat failures and a sample of successes to estimate variance. Pre-register primary metrics before scoring.
4. **Primary metrics:** task completion under independently defined acceptance tests, correctness, regression count, severity-weighted security incidents, false-success rate, time-to-correct result, total model calls, observed provider cost when available, manual interventions, and reproducibility of evidence.
5. **Quality rubric:** blinded reviewers score diff scope, maintainability, test quality, readability and user-visible result. Automated pass rate is necessary but not sufficient.
6. **Browser work:** save the URL/environment, steps, expected/observed outcomes, screenshots/traces, console and network errors where available. Do not include secrets or private user data in the evidence pack.
7. **Reporting:** release exact task IDs/prompts where licensing permits, result JSON/CSV, evaluator version/hash, environment versions, cost sources, failure examples, missing data and confidence intervals. No cherry-picked demos.
8. **Safety rules:** run all agents in disposable workspaces; never place production credentials in the benchmark; require human authorization for paid provider use and external targets.

## Advancement rule

Forge may use “outperformed baseline X on benchmark Y under conditions Z” only after independent reruns substantiate the exact scoped claim. Do not say “better than Claude Code/Codex/OpenCode/Pi/Antigravity” as a general claim based on stars, feature lists or a small sample.
