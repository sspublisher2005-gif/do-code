# Forge product specification

## Product decision

Forge is an approval-first terminal coding harness. The MVP is narrow by design: plan a change, propose a patch, obtain a human decision, apply it with a checkpoint, run an approved verification command, review evidence, and report honestly. Forge will not compete by matching every UI, plugin, cloud, browser, or memory feature in existing platforms.

## Command contract

| Command | MVP behavior | Planned contract / constraints |
|---|---|---|
| `forge` | Simple readline loop | A full terminal UI only if it adds value without heavy dependency cost. |
| `forge "task"` | Shorthand for one-shot `run` | Must remain safe in interactive and non-interactive contexts. |
| `forge run "task"` | Planner → coder patch → tester → reviewer | Never auto-approve arbitrary commands or patches. |
| `forge run --dry-run "task"` | Propose and validate patch; no writes/tests | Useful for review-only changes. Model request still requires consent. |
| `forge init` | Creates config, `FORGE.md`, `.forge` | No provider request. Does not overwrite existing config/memory. |
| `forge doctor` | Node/Git/OpenCode/config checks, no inference | Future checks: provider model lookup, sandbox availability, git status. |
| `forge config [show|set K V]` | Reads/writes allowlisted JSON keys | Do not permit arbitrary shell/env interpolation or executable selection in project config. |
| `forge agents` | Lists role descriptions/status | Status should distinguish prompt roles from independently spawned agents. |
| `forge index` | Deterministic local map | Future: language-aware project graph and incremental cache. |
| `forge search TERMS` | Local keyword search | Future: language-aware symbols and optional semantic retrieval. |
| `forge undo` | Confirms and restores latest unused Forge checkpoint | Hash-check all affected files before restore; never overwrite unrelated user edits. |
| `forge audit [--tail N]` | Displays local JSONL metadata | Future: integrity chain/export/redaction policy. |
| `forge cost` | Totals usage OpenCode actually reports | Unknown remains unknown; no invented pricing. |
| `forge command COMMAND...` | Explicit manually approved one-line command | No shell expansions; risky command typed approval; future sandbox integration. |

## Runtime choice

Node.js 22+ ES modules with native filesystem, crypto, child-process, readline, and JSON support. The CLI has no third-party runtime package dependencies. Project-local config may select only the default `opencode` executable; a user-selected override is provided by the launching shell via `FORGE_OPENCODE_COMMAND`. Git is invoked as an external executable for Git status only; patch checkpoints are Forge-owned snapshots. A stronger implementation might use Rust, but the current advantage is iteration speed and no compile toolchain. We will benchmark rather than assume Node is always faster.

## Model strategy

- First adapter: OpenCode CLI. Model default `opencode/glm-5.3-flash`, dependent on provider access and current OpenCode naming.
- Text-only response channel: model returns constrained JSON; Forge validates it and controls actions.
- Model tools disabled in the OpenCode subprocess. Forge's own actions are local functions, gated separately.
- Cost/token accounting is best effort and driven by provider/OpenCode usage events.
- `local-only` is an endpoint-ID allowlist, not a hardened network boundary.
- Future adapter interface should normalize: `generate({ role, messages, jsonSchema, maxOutputTokens, timeoutMs, abortSignal }) → { text, usage?, provider, model, durationMs }` and should provide explicit timeout/retry/fallback semantics. No new direct model adapter until its credentials, data handling, retries and tests are isolated.

## Agent model

### Roles

- **Orchestrator:** only component that advances the task state machine and emits the delivery report.
- **Architect / Planner:** identifies minimal plan, assumptions, risk, target paths and test command candidates.
- **Researcher:** maps files/symbols/import hints and cites project evidence.
- **Coder:** returns unified diff; cannot write files itself.
- **Tester:** suggests likely verification commands; Forge allowlists and asks before execution.
- **Reviewer:** examines patch/test outcomes and reports findings/verification gaps.
- **Security:** deterministic checks for target paths, common secrets, shell risk, CI/CD patches and suspicious content. Future model-based review is supplementary.
- **DevOps:** future, opt-in CI/build/container/deploy assistance; absent from MVP.

The MVP uses prompts and separate model invocations for planner/coder/reviewer. Researcher/tester/security roles are mostly deterministic helpers, not separate parallel model instances. JSON role identity is not privilege isolation. Only the CLI runtime owns file/shell privileges.

## Retrieval and memory

- Walk repository without following symlinks; skip common generated directories, secret paths, binary/special files and oversized files; honor simple `.gitignore` patterns. Defaults cap indexed source text at 64 MiB total in addition to per-file and file-count limits.
- Extract common function/class/export names and import hints with regex, not complete AST parsers.
- Rank by task-token overlap, file path and simple package/readme hints.
- Limit indexed files, per-file bytes, target files, and prompt context; omit unrelated files.
- `FORGE.md` contains short human-reviewed project purpose, architecture, verified commands and constraints. It is treated as untrusted input, not policy.
- `.forge/audit.jsonl` captures event summaries; reads are capped to the newest 10 MiB. `.forge/checkpoints` stores base64 snapshots for changed files to support undo; each snapshot has an HMAC signature made with a user-local key outside the repo and is bound to the canonical workspace path.
- No semantic index, SQLite session database, long-running session compaction, or memory auto-write yet.

## Config schema (MVP)

```json
{
  "model": "opencode/glm-5.3-flash",
  "opencodeCommand": "opencode",
  "agent": "forge-model",
  "privacy": { "mode": "ask" },
  "limits": {
    "maxFiles": 3000,
    "maxFileBytes": 262144,
    "maxIndexBytes": 67108864,
    "maxContextChars": 24000,
    "maxTargetFiles": 8,
    "maxOutputBytes": 1200000,
    "modelTimeoutMs": 240000,
    "commandTimeoutMs": 120000
  },
  "review": { "enabled": true }
}
```

Only known keys can be modified by `forge config set`; unknown configuration fields currently survive JSON merge but are not acted on. Configuration is not intended as a secrets store.

## Plugin API (not implemented)

Future tool registration should declare `{ id, inputSchema, riskClass, permissions, execute, resultRedaction, timeoutMs }`. Every tool must execute through the policy engine; extensions must not have an unmediated route to filesystem/network/process. In-process untrusted plugins are not safe. First implementation should use declarative metadata and isolated child processes or MCP servers behind explicit approval, never arbitrary auto-loaded code.

## Verification contract

- Invalid JSON/patch/path aborts before writing.
- Patch requires explicit approval and checkpoint.
- Hash precondition rechecked before write.
- Test command must match the small allowlist and receive approval; timed out/declined/no test means verification incomplete.
- One optional repair loop only, with fresh review and approvals.
- Reviewer verdict cannot turn a failed test into a passing test.
- Delivery report distinguishes passed tests, reviewer finding, unknown cost, and gaps.

## Out of scope for MVP

Parallel subagents, direct provider SDKs, semantic embeddings, LSP/dynamic symbol graph, general MCP and plugin system, network browser, GitHub/GitLab PR creation, automatic commits, Docker management, remote execution, UI dashboard, vector database, cloud service, telemetry, update daemon, and background auto-run. Add these only if measured user outcomes justify the complexity.
