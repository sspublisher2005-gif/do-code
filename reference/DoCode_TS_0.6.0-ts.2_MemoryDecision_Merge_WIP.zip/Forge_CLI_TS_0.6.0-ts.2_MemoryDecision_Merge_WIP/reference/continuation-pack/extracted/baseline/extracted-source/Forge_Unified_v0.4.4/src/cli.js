import fs from 'node:fs';
import path from 'node:path';
import process from 'node:process';
import os from 'node:os';
import { randomUUID } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { VERSION, AGENTS, DEFAULT_CONFIG } from './constants.js';
import { browserStatus, isLoopbackBrowserHost, runBrowserAudit, safeUrlLabel, validateBrowserUrl } from './browser.js';
import { inspectLocalDevServer, startLocalDevServer } from './devserver.js';
import { buildExecutionPlan, extractHttpUrl, formatSkillContents, formatSkillList, isBrowserOnlyTask, isGameTask, loadSelectedSkills, renderAgentPlan, selectSkillsForTask } from './harness.js';
import { buildSpecialistPrompt, formatSpecialistFindings } from './specialists.js';
import { classifyTask, shouldUseDecisionSupport, validateDecisionMatrix, formatDecisionMatrix, decisionMatrixPrompt, isDecisionOnlyTask } from './decision-support.js';
import { normalizeClarifyingQuestions, ensureBlockingQuestionForAmbiguity, shouldConductInterview, buildClarifiedTask } from './interview.js';
import { collectClarificationAnswers, chooseDecisionOption } from './interview-ui.js';
import { installPortableLayer, previewPortableLayer, uninstallPortableLayer } from './layer.js';
import { loadConfig, saveConfig, setConfigValue, validateConfig, CONFIG_NAME } from './config.js';
import { buildRepoIndex, makeRepositorySummary, selectContextFiles } from './indexer.js';
import { buildLocalCodeGraph, renderGraphReport } from './codegraph.js';
import { buildReachSearchInvocation, discoverReachExecutables, isAccountResearchPlatform, validateResearchQuery } from './reach.js';
import { searchContext7, formatContext7Result } from './context7.js';
import { getFreezeState, assertProjectNotFrozen, freezeProject, unfreezeProject } from './policy.js';
import { forgeDir, writeAudit, readAudit, summarizeCost } from './audit.js';
import { invokeModel, extractJsonObject, validatePrivacyMode, getOpenCodeCommand } from './llm.js';
import { plannerPrompt, coderPrompt, reviewerPrompt, securityAuditorPrompt, securityWarningsForPatch } from './prompts.js';
import { scanPromptInjection, requiresElevatedPatchApproval } from './security.js';
import { preparePatch, applyPreparedPatch, formatPatchSummary } from './patch.js';
import { gitAvailable, gitStatus, createCheckpoint, restoreLatestCheckpoint, listCheckpoints } from './git.js';
import { buildCommandEnv, isCommonTestCommand, commandRisk, runProcess, testCommandCandidates, parseCommand } from './runner.js';
import { createTerminal, askYesNo, askExactApproval, canPrompt, requestModelConsent } from './terminal.js';
import { findRepoRoot, redactSecrets, safeTerminalText, resolveSafePath, safeReadText, sha256, truncate, ensureRealDirectory } from './utils.js';
import { assertProjectBinding, ensureProjectIdentity, importSelectedContext, listSharedContexts, loadProjectIdentity, loadSharedContextText, projectIdentityMatchesRoot, rebindProjectIdentity, removeSharedContext } from './project.js';
import { acquireSessionLock, beginSessionAttempt, createSession, deleteSession, finishSessionAttempt, listSessions, loadSession, setSessionPhase } from './sessions.js';
import { inspectSandbox, runSandboxedCommand } from './sandbox.js';

const HELP = `Forge ${VERSION} — project-isolated, adaptive engineering harness

Usage:
  forge                          Start the interactive terminal loop
  forge "task"                  Run a one-shot coding task
  forge run "task"              Run the planner → coder → tester → reviewer workflow
  forge run --dry-run "task"    Propose and validate a patch without applying it
  forge run --no-subagents "task" Disable parallel read-only specialist passes
  forge run --sandbox-tests "task" Run recognized verification commands in disposable containers (requires Docker/Podman)
  forge run --max-subagents 3 "task" Cap read-only specialist passes (0–3)
  forge init                     Initialize project configuration, memory, and local identity
  forge project status           Show the active project identity and binding
  forge project rebind           Rebind a moved/copied project after exact confirmation
  forge context list             List explicitly imported context from other projects
  forge context import --from DIR --file PATH   Import one reviewed file from a distinct initialized project
  forge context remove ID        Revoke one imported context item
  forge doctor                   Check Node, Git, selected provider, project configuration, and safety limitations
  forge sandbox status           Check local Docker/Podman and a pre-existing project-appropriate image
  forge sandbox run -- COMMAND   Run a command in a disposable, sanitized, network-disabled container copy
  forge sessions [list|show ID|delete ID]  Inspect or remove project-bound task sessions
  forge resume SESSION_ID        Restart an interrupted task against the current working files
  forge config [show|set K V]    Inspect or update forge.config.json
  forge config set provider openrouter  Select OpenRouter direct API
  forge agents                   Show available agent roles and their status
  forge skills [list|show NAME]  List/show task-routed skill guidance
  forge index                    Build a deterministic local repository map
  forge search WORDS             Search indexed file text (local only)
  forge undo                     Restore the latest unused Forge checkpoint
  forge audit [--tail N]         Show the local append-only event log
  forge cost                     Show usage/cost observed from OpenCode events
  forge graph                    Build a local approximate import graph
  forge browser status|test URL|setup  Run optional Playwright browser QA
  forge browser test --start     Start a recognized local dev server after consent, then test it
  forge layer preview [--tool both|claude|opencode]  Preview project-scoped agent/skill pack
  forge layer install [--tool both|claude|opencode] [--target DIR] [--force]  Install compatible layer files
  forge layer uninstall [--target DIR]  Remove only unchanged Forge-managed layer files
  forge docs QUESTION            Query Context7 library documentation with consent
  forge reach search --platform PLATFORM QUERY  External research search with consent
  forge freeze [reason]          Emergency stop for coding and external/write actions
  forge command COMMAND...       Run an explicit command after approval
  forge --version                Print the version
  forge --help                   Print this help

Safety defaults:
  - No provider call without explicit context-sharing consent (unless configured local-only).
  - Project-local memory stays inside the active project; cross-project context is never searched or loaded automatically.
  - Cross-project context is imported one explicitly selected file at a time, with provenance and revocation.
  - Small, clear fixes skip the clarification interview and decision matrix by default.
  - Blocking ambiguities trigger a bounded interview; ? or /explain opens separate help without changing the answer.
  - Decision matrices use strict schemas and local weighted ranking; they are not a claim of decision accuracy.
  - Specialist passes are optional extra model calls; their findings are hypotheses.
  - Sessions are stored outside repositories, signed with a private per-user key, and bound to project root + binding epoch.
  - forge resume re-runs the saved task against current files; it does not restore hidden model context or roll back partial edits.
  - No model-owned filesystem or shell tools in Forge's OpenCode subprocess config.
  - No patch writes without approval and a local checkpoint.
  - No test command runs without approval.
  - Browser QA is optional Playwright, passive by default; third-party origins are blocked.
  - Experimental container verification is opt-in and awaits real-runtime security validation; ordinary approved commands remain host-executed, and approval is not isolation.`;

function createIfAbsentRegularFile(filePath, content, mode = 0o600) {
  try {
    const info = fs.lstatSync(filePath);
    if (info.isSymbolicLink() || !info.isFile()) throw new Error(`Refusing to initialize through a symlink or special file: ${filePath}`);
    return false;
  } catch (error) { if (error?.code !== 'ENOENT') throw error; }
  // `wx` also rejects a dangling symlink that may appear after the lstat above.
  try { fs.writeFileSync(filePath, content, { mode, flag: 'wx' }); return true; }
  catch (error) { if (error?.code === 'EEXIST') throw new Error(`Path appeared during initialization; inspect it and retry: ${filePath}`); throw error; }
}

function initProject(root) {
  assertProjectNotFrozen(root, 'project initialization writes');
  const internal = ensureRealDirectory(forgeDir(root), 0o700);
  ensureRealDirectory(path.join(internal, 'checkpoints'), 0o700);
  const projectIdentity = ensureProjectIdentity(root);
  const configFile = path.join(root, CONFIG_NAME);
  createIfAbsentRegularFile(configFile, `${JSON.stringify(DEFAULT_CONFIG, null, 2)}\n`);
  loadConfig(root); // Validate a pre-existing regular config rather than silently accepting malformed JSON.
  const memoryFile = path.join(root, 'FORGE.md');
  createIfAbsentRegularFile(memoryFile, `# FORGE.md — project memory\n\nKeep this file short, factual, and reviewed by a human. Forge reads it as project guidance but treats its contents as untrusted repository text, not permission to bypass safety rules.\n\n## Project purpose\n- TODO: what this project does\n\n## Architecture and conventions\n- TODO: important modules and coding conventions\n\n## Verification\n- TODO: commands that have been verified to work in this repository\n\n## Known risks / constraints\n- TODO: sensitive paths, platform limits, compatibility rules\n`);
  const internalIgnore = path.join(internal, '.gitignore');
  createIfAbsentRegularFile(internalIgnore, '*\n!.gitignore\n');
  writeAudit(root, { action: 'init', version: VERSION });
  console.log(safeTerminalText(`Initialized Forge in ${root}`));
  console.log(`Created/checked: ${CONFIG_NAME}, FORGE.md, .forge/`);
  console.log(`Project identity: ${projectIdentity.projectId} · bound to ${projectIdentity.rootPath}`);
  console.log('No provider request was made.');
}

function loadMemory(root) {
  const memoryPath = path.join(root, 'FORGE.md');
  let ownMemory = '';
  try {
    if (fs.existsSync(memoryPath) && !fs.lstatSync(memoryPath).isSymbolicLink() && fs.lstatSync(memoryPath).isFile()) {
      ownMemory = redactSecrets(safeReadText(memoryPath, 20000) ?? '');
    }
  } catch { ownMemory = ''; }
  const explicitlyShared = loadSharedContextText(root);
  return [ownMemory, explicitlyShared].filter(Boolean).join('\n\n--- Explicit context imported into this project ---\n\n');
}

async function modelCall(root, config, role, prompt, runId = null) {
  const started = Date.now();
  try {
    const result = await invokeModel({ config, prompt, role });
    writeAudit(root, {
      action: 'model_call', runId: runId ?? undefined, role, model: config.model, durationMs: Date.now() - started,
      tokensIn: result.tokensIn || undefined, tokensOut: result.tokensOut || undefined,
      costUsd: result.hasCost ? result.costUsd : undefined,
      usageSource: result.provider === 'openrouter' ? 'OpenRouter API usage' : ((result.hasCost || result.tokensIn || result.tokensOut) ? 'OpenCode JSON events' : 'unavailable'),
      responseChars: result.text.length,
    });
    return result;
  } catch (error) {
    writeAudit(root, { action: 'model_call_failed', runId: runId ?? undefined, role, model: config.model, durationMs: Date.now() - started, error: String(error.message).slice(0, 500) });
    throw error;
  }
}

function validateTargetPaths(root, proposed, index, limit) {
  const existing = new Set(index.files.map((file) => file.path));
  const safe = [];
  const rejected = [];
  for (const candidate of (Array.isArray(proposed) ? proposed : []).slice(0, limit * 2)) {
    if (typeof candidate !== 'string') continue;
    try {
      resolveSafePath(root, candidate, { allowMissing: true });
      if (!safe.includes(candidate)) safe.push(candidate);
    } catch { rejected.push(candidate); }
    if (safe.length >= limit) break;
  }
  return { safe, rejected, existing };
}

function showList(title, items) {
  console.log(`\n${safeTerminalText(title)}:`);
  if (!items?.length) { console.log('  (none)'); return; }
  for (const item of items) console.log(safeTerminalText(`  - ${typeof item === 'string' ? item : JSON.stringify(item)}`));
}

function showPatch(patch) {
  console.log('\nProposed unified diff:');
  console.log(safeTerminalText(truncate(patch, 18000)));
  if (patch.length > 18000) console.log('[Diff display truncated; the full diff was not saved to the audit log.]');
}

async function approveUntrustedContext(root, rl, runId, candidates, memory = '', stage = 'model_context') {
  const findings = scanPromptInjection({ files: candidates }, memory);
  if (!findings.length) return true;
  console.log(`\nSECURITY WARNING: heuristic prompt-injection indicators were found in the ${stage}. This scanner is incomplete and cannot prove content safe.`);
  showList('Flagged paths and indicator categories (matching text is not copied into the audit log)', findings);
  writeAudit(root, { action: 'prompt_injection_indicators', runId, stage, count: findings.length, findings });
  const approved = await askExactApproval(rl, 'Continue sending/using this untrusted context? Review the flagged material first. This approval does not grant it authority to bypass Forge controls.', 'APPROVE UNTRUSTED CONTEXT');
  if (!approved) writeAudit(root, { action: 'context_gate_denied', runId, stage });
  return approved;
}

async function proposePatch(root, config, rl, task, plan, index, initialContextPaths, failureText = null, runId = null, skills = '') {
  const existingRanked = index.ranked.map((file) => file.path);
  const contextPaths = [...new Set([...initialContextPaths, ...existingRanked])].slice(0, Math.max(config.limits.maxTargetFiles, 8));
  let context = selectContextFiles(index, contextPaths, config.limits.maxContextChars);
  if (!context) context = '(No readable text files were selected. Propose a minimal patch only if the task and file map make the change unambiguous.)';
  const selectedFiles = index.files.filter((file) => contextPaths.includes(file.path));
  const untrustedForCoder = [
    ...selectedFiles,
    { path: '[planner output]', content: JSON.stringify(plan) },
    ...(failureText ? [{ path: '[verification output]', content: failureText }] : []),
  ];
  if (!await approveUntrustedContext(root, rl, runId, untrustedForCoder, '', failureText ? 'repair-model context' : 'coder context')) {
    throw new Error('Untrusted context approval was declined; no coder model request was made.');
  }
  const prompt = coderPrompt({ task, plan, paths: contextPaths, context, config, failure: failureText, skills });
  const result = await modelCall(root, config, failureText ? 'coder-repair' : 'coder', prompt, runId);
  const payload = extractJsonObject(result.text);
  if (typeof payload.patch !== 'string' || payload.patch.trim().length === 0) throw new Error('Coder response did not include a non-empty unified diff in its "patch" field.');
  if (payload.patch.length > 250000) throw new Error('Proposed patch exceeds 250 KB and was rejected.');
  return { payload, result };
}

async function runApprovedTest(root, rl, config, commandText, runId = null, sandboxTests = false) {
  if (!isCommonTestCommand(commandText)) {
    return { command: commandText, skipped: true, success: false, reason: 'Not a recognized verification command; Forge will not execute arbitrary model-suggested commands.' };
  }
  let tokens;
  try { tokens = parseCommand(commandText); } catch (error) {
    return { command: commandText, skipped: true, success: false, reason: error.message };
  }
  if (commandRisk(commandText)) return { command: commandText, skipped: true, success: false, reason: 'Command was classified as high-risk.' };
  console.log(safeTerminalText(`\nVerification command: ${tokens.join(' ')}`));
  if (sandboxTests) {
    const status = inspectSandbox({ cwd: root });
    if (!status.available) {
      const reason = `Sandbox unavailable; verification was not executed and no host fallback occurred. ${status.reason}`;
      console.log(reason);
      writeAudit(root, { action: 'sandbox_test_skipped', runId: runId ?? undefined, command: commandText, reason: 'sandbox_unavailable' });
      return { command: commandText, skipped: true, success: false, reason };
    }
    console.log(`Sandbox: ${status.runtime} / ${status.image}; network disabled; writes by the test are discarded.`);
  } else {
    console.log('This executes code defined by the repository on the host. Approval is not OS-level isolation. Use `forge run --sandbox-tests` where a trusted local container image is available.');
  }
  const approved = await askYesNo(rl, sandboxTests ? 'Run this verification command in the disposable sandbox copy?' : 'Run this verification command on the host?');
  if (!approved) {
    writeAudit(root, { action: sandboxTests ? 'sandbox_test_skipped' : 'test_skipped', runId: runId ?? undefined, command: commandText, reason: 'user_denied' });
    return { command: commandText, skipped: true, success: false, reason: 'User declined execution.' };
  }
  const started = Date.now();
  let result;
  if (sandboxTests) {
    try {
      result = await runSandboxedCommand(commandText, { cwd: root, timeoutMs: config.limits.commandTimeoutMs, maxOutputBytes: config.limits.maxOutputBytes });
    } catch (error) {
      const reason = `Sandbox verification was not completed: ${redactSecrets(error?.message ?? String(error))}`;
      writeAudit(root, { action: 'sandbox_test_skipped', runId: runId ?? undefined, command: commandText, reasonHash: sha256(reason) });
      console.log(reason);
      return { command: commandText, skipped: true, success: false, reason };
    }
  } else {
    result = await runProcess(commandText, { cwd: root, timeoutMs: config.limits.commandTimeoutMs, maxOutputBytes: config.limits.maxOutputBytes });
  }
  writeAudit(root, {
    action: sandboxTests ? 'sandbox_test_run' : 'test_run', runId: runId ?? undefined, command: commandText,
    exitCode: result.code, success: result.success, timedOut: result.timedOut, overflow: result.overflow,
    durationMs: Date.now() - started, runtime: result.sandbox?.runtime, image: result.sandbox?.image,
  });
  console.log(`Exit code: ${result.code}${result.timedOut ? ' (timeout)' : ''}${result.overflow ? ' (output limit)' : ''}`);
  const safeStdout = safeTerminalText(redactSecrets(result.stdout));
  const safeStderr = safeTerminalText(redactSecrets(result.stderr));
  if (safeStdout.trim()) console.log(`\nstdout:\n${truncate(safeStdout, 7000)}`);
  if (safeStderr.trim()) console.log(`\nstderr:\n${truncate(safeStderr, 5000)}`);
  return { command: commandText, ...result, stdout: truncate(safeStdout, 8000), stderr: truncate(safeStderr, 6000), durationMs: Date.now() - started };
}

async function performRunInternal(root, task, options, rl) {
  assertProjectNotFrozen(root, 'coding runs');
  const activeIdentity = ensureProjectIdentity(root);
  const runId = options.runId || randomUUID();
  console.log(`Active project: ${safeTerminalText(activeIdentity.name)} · ${activeIdentity.projectId}`);
  const executionPlan = buildExecutionPlan(task, { dryRun: Boolean(options.dryRun), maxSubagents: options.maxSubagents ?? 2, noSubagents: Boolean(options.noSubagents) });
  executionPlan.skills = selectSkillsForTask(root, task);
  if (executionPlan.browserOnly) {
    console.log(renderAgentPlan(executionPlan, loadSelectedSkills(root, executionPlan.skills)));
    writeAudit(root, { action: 'task_started', runId, taskHash: sha256(task), browserOnly: true, dryRun: Boolean(options.dryRun) });
    setSessionPhase({ root, identity: activeIdentity, sessionId: options.sessionId, runId, phase: 'browser_qa' });
    try {
      const browserOutcome = await runBrowserTaskFromUserGoal(root, task, rl, executionPlan);
      writeAudit(root, { action: 'task_finished', runId, taskHash: sha256(task), testsPassed: browserOutcome.status === 'PASS', reviewVerdict: browserOutcome.status === 'PASS' ? 'PASS' : 'UNVERIFIED', browserStatus: browserOutcome.status, securityWarningCount: 0, browserOnly: true });
      return browserOutcome;
    } catch (error) {
      writeAudit(root, { action: 'browser_task_failed', runId, taskHash: sha256(task), error: redactSecrets(error?.message ?? String(error)).slice(0, 300), browserOnly: true });
      throw error;
    }
  }
  const config = loadConfig(root);
  const selectedSkills = loadSelectedSkills(root, executionPlan.skills);
  const skillText = formatSkillContents(selectedSkills);
  console.log(renderAgentPlan(executionPlan, selectedSkills));
  if (options.model) config.model = options.model;
  validateConfig(config);
  validatePrivacyMode(config);
  setSessionPhase({ root, identity: activeIdentity, sessionId: options.sessionId, runId, phase: 'awaiting_model_context_consent' });
  const consent = await requestModelConsent(rl, config);
  if (!consent) {
    writeAudit(root, { action: 'run_cancelled', runId, taskHash: sha256(task), reason: 'model_context_consent_denied' });
    console.log('Cancelled. No model request was made and no project files were changed.');
    return;
  }

  let index = buildRepoIndex(root, config, task);
  const memory = loadMemory(root);
  if (selectedSkills.some((skill) => skill.source !== 'built-in')) {
    const externalSkillCandidates = selectedSkills.filter((skill) => skill.source !== 'built-in').map((skill) => ({ path: `[skill ${skill.id}]`, content: skill.content }));
    if (!await approveUntrustedContext(root, rl, runId, externalSkillCandidates, '', 'selected project/user skills')) {
      writeAudit(root, { action: 'run_cancelled', runId, reason: 'untrusted_skill_context_not_approved' });
      console.log('Cancelled. No model request was made and no project files were changed.');
      return;
    }
  }
  const capabilityPlan = `${executionPlan.roles.join(' -> ')}; selected skills: ${selectedSkills.map((skill) => skill.id).join(', ') || 'none'}`;
  const plannerMap = makeRepositorySummary(index, Math.max(6000, config.limits.maxContextChars * 0.7));
  if (!await approveUntrustedContext(root, rl, runId, [{ path: '[repository map]', content: plannerMap }], memory, 'planner context')) {
    writeAudit(root, { action: 'run_cancelled', runId, reason: 'untrusted_context_gate_not_approved' });
    console.log('Cancelled. No model request was made and no project files were changed.');
    return;
  }
  const status = gitStatus(root);
  if (status.isRepo && status.output.trim()) {
    console.log('\nWarning: the working tree already has changes. Forge will preserve file content as it exists at the time of its own checkpoint, but overlapping work may prevent automatic undo.');
    if (!await askYesNo(rl, 'Continue with this non-clean Git working tree?')) {
      writeAudit(root, { action: 'run_cancelled', runId, taskHash: sha256(task), reason: 'user_declined_non_clean_working_tree' });
      console.log('Cancelled before planning; no model request was made.');
      return;
    }
  }
  writeAudit(root, { action: 'task_started', runId, taskHash: sha256(task), indexedFiles: index.totalFiles, skippedFiles: index.excluded, dryRun: Boolean(options.dryRun) });
  setSessionPhase({ root, identity: activeIdentity, sessionId: options.sessionId, runId, phase: 'planning_and_context_analysis' });
  console.log(`\nForge indexed ${index.totalFiles} text files (${index.excluded} skipped).`);

  let specialistFindings = '';
  if (executionPlan.subagents?.length) {
    const specialistPaths = index.ranked.slice(0, 8).map((file) => file.path);
    const specialistContext = selectContextFiles(index, specialistPaths, Math.min(10000, Math.floor(config.limits.maxContextChars * 0.55)));
    if (specialistContext && !await approveUntrustedContext(root, rl, runId, [{ path: '[read-only specialist excerpts]', content: specialistContext }], memory, 'read-only specialist context')) {
      writeAudit(root, { action: 'run_cancelled', runId, reason: 'specialist_context_not_approved' });
      console.log('Cancelled. Specialist context was not sent to the model; no project files were changed.');
      return;
    }
    console.log(`\nLaunching ${executionPlan.subagents.length} bounded read-only specialist pass(es) in parallel. These are extra model calls; their findings are unverified hypotheses.`);
    writeAudit(root, { action: 'specialists_started', runId, specialistIds: executionPlan.subagents.map((item) => item.id), contextPaths: specialistPaths });
    const specialistResults = await Promise.all(executionPlan.subagents.map(async (specialist) => {
      const started = Date.now();
      try {
        const output = await modelCall(root, config, `subagent:${specialist.id}`, buildSpecialistPrompt({
          specialist, task, repositorySummary: plannerMap, excerpts: specialistContext,
        }), runId);
        const parsed = extractJsonObject(output.text);
        const result = {
          specialist: specialist.id, status: 'complete',
          summary: typeof parsed.summary === 'string' ? parsed.summary : 'No summary supplied.',
          findings: Array.isArray(parsed.findings) ? parsed.findings.slice(0, 6) : [],
          relevantFiles: Array.isArray(parsed.relevantFiles) ? parsed.relevantFiles.slice(0, 8) : [],
          verificationIdeas: Array.isArray(parsed.verificationIdeas) ? parsed.verificationIdeas.slice(0, 6) : [],
          unknowns: Array.isArray(parsed.unknowns) ? parsed.unknowns.slice(0, 5) : [],
        };
        writeAudit(root, { action: 'specialist_complete', runId, specialistId: specialist.id, durationMs: Date.now() - started, findingCount: result.findings.length, outputHash: sha256(JSON.stringify(result)) });
        return result;
      } catch (error) {
        writeAudit(root, { action: 'specialist_failed', runId, specialistId: specialist.id, durationMs: Date.now() - started, error: redactSecrets(error?.message ?? String(error)).slice(0, 350) });
        return { specialist: specialist.id, status: 'unavailable', summary: 'This specialist pass failed; continue without it.', findings: [], relevantFiles: [], verificationIdeas: [], unknowns: ['Model request or JSON parsing failed.'] };
      }
    }));
    specialistFindings = formatSpecialistFindings(specialistResults, 10000);
    showList('Specialist pass results (not ground truth)', specialistResults.map((result) => `${result.specialist} [${result.status}]: ${result.summary}`));
  }

  let taskForExecution = task;
  const loadPlan = async (currentTask, role = 'planner') => {
    const result = await modelCall(root, config, role, plannerPrompt({ task: currentTask, index, config, memory, skills: skillText, capabilityPlan, specialistFindings }), runId);
    const parsed = extractJsonObject(result.text);
    parsed.summary = typeof parsed.summary === 'string' ? parsed.summary : 'No plan summary supplied.';
    parsed.steps = Array.isArray(parsed.steps) ? parsed.steps.slice(0, 12).map(String) : [];
    parsed.assumptions = Array.isArray(parsed.assumptions) ? parsed.assumptions.slice(0, 8).map(String) : [];
    parsed.risks = Array.isArray(parsed.risks) ? parsed.risks.slice(0, 8).map(String) : [];
    parsed.testCommands = Array.isArray(parsed.testCommands) ? parsed.testCommands.slice(0, 6).map(String) : [];
    return parsed;
  };
  let plan = await loadPlan(taskForExecution);
  let clarificationQuestions = ensureBlockingQuestionForAmbiguity(taskForExecution, normalizeClarifyingQuestions(plan.clarifyingQuestions));
  if (shouldConductInterview(taskForExecution, clarificationQuestions)) {
    console.log('\nForge found a material ambiguity. It will clarify before proposing code; small, clear fixes skip this interview.');
    const interview = await collectClarificationAnswers({
      rl, config, runId, task: taskForExecution, questions: clarificationQuestions, canPrompt,
      modelCall: (modelConfig, role, prompt, parentRunId) => modelCall(root, modelConfig, role, prompt, parentRunId),
      askYesNo,
      writeAudit: (event) => writeAudit(root, event),
      sha256,
      safeTerminalText,
      redactSecrets,
      truncate,
    });
    if (interview.status !== 'complete') {
      const reason = interview.status === 'non_interactive' ? 'A blocking clarification requires an interactive terminal; no patch was proposed.' : 'The clarification interview was cancelled; no patch was proposed.';
      writeAudit(root, { action: 'task_blocked_for_clarification', runId, taskHash: sha256(task), reason: interview.status });
      console.log(reason);
      return;
    }
    taskForExecution = buildClarifiedTask(task, interview.answers);
    index = buildRepoIndex(root, config, taskForExecution);
    writeAudit(root, { action: 'planner_restarted_after_interview', runId, taskHash: sha256(task), clarificationCount: interview.answers.length, clarifiedTaskHash: sha256(taskForExecution) });
    plan = await loadPlan(taskForExecution, 'planner-after-clarification');
    clarificationQuestions = normalizeClarifyingQuestions(plan.clarifyingQuestions);
    if (clarificationQuestions.some((question) => question.blocking)) {
      writeAudit(root, { action: 'task_blocked_after_clarification', runId, taskHash: sha256(task), remainingQuestionCount: clarificationQuestions.filter((question) => question.blocking).length });
      console.log('Forge still sees a blocking ambiguity after one clarification round. No patch was proposed; refine the request and rerun rather than letting the agent guess.');
      showList('Remaining clarification questions', clarificationQuestions.filter((question) => question.blocking).map((question) => question.question));
      return;
    }
  }

  const decisionSupportRequested = shouldUseDecisionSupport(taskForExecution, plan);
  let decisionMatrix = null;
  if (decisionSupportRequested) {
    const decisionResult = await modelCall(root, config, 'decision-analyst', decisionMatrixPrompt({
      task: taskForExecution,
      plan,
      repositorySummary: makeRepositorySummary(index, Math.max(5000, config.limits.maxContextChars * 0.55)),
    }), runId);
    let decisionPayload;
    try { decisionPayload = extractJsonObject(decisionResult.text); } catch { decisionPayload = null; }
    const validatedDecision = validateDecisionMatrix(decisionPayload);
    if (!validatedDecision.ok) {
      writeAudit(root, { action: 'decision_matrix_rejected', runId, taskHash: sha256(task), errorCount: validatedDecision.errors.length });
      console.log('Forge refused to show a ranking because the model output did not satisfy the typed decision schema:');
      showList('Schema errors', validatedDecision.errors);
      if (classifyTask(taskForExecution).explicitDecision) {
        console.log('The requested comparison was not completed. No coding patch was proposed. Rerun or rephrase the comparison request.');
        return;
      }
      console.log('This was an optional internal comparison, so Forge will continue using its standard workflow without a ranking.');
    } else {
      decisionMatrix = validatedDecision.matrix;
      plan.decisionMatrix = decisionMatrix;
      console.log(`\n${formatDecisionMatrix(decisionMatrix)}`);
      writeAudit(root, {
        action: 'decision_matrix_completed', runId, taskHash: sha256(task), schemaVersion: decisionMatrix.schemaVersion,
        criteriaCount: decisionMatrix.criteria.length, optionCount: decisionMatrix.rankedOptions.length,
        computedRecommendationId: decisionMatrix.computedRecommendationId,
        modelRecommendationId: decisionMatrix.modelRecommendationId,
        recommendationDisagreesWithScore: decisionMatrix.recommendationDisagreesWithScore,
        confidence: decisionMatrix.confidence,
      });
      if (isDecisionOnlyTask(taskForExecution)) {
        console.log('Decision-only request complete. Forge did not modify repository files or run commands.');
        return;
      }
      if (decisionMatrix.requiresUserChoice) {
        if (!canPrompt()) {
          writeAudit(root, { action: 'task_blocked_for_decision', runId, taskHash: sha256(task), reason: 'non_interactive_user_choice_required' });
          console.log('This implementation choice needs your preference. Rerun in an interactive terminal; no patch was proposed.');
          return;
        }
        const decision = await chooseDecisionOption({
          rl, config, runId, matrix: decisionMatrix,
          modelCall: (modelConfig, role, prompt, parentRunId) => modelCall(root, modelConfig, role, prompt, parentRunId),
          askYesNo,
          writeAudit: (event) => writeAudit(root, event),
          sha256, safeTerminalText, redactSecrets, truncate,
        });
        if (decision.status !== 'selected') {
          console.log('Decision cancelled. No code patch was proposed.');
          return;
        }
        taskForExecution += `\n\nUser-selected implementation approach: ${decision.selected.label} (option id: ${decision.selected.id}). Follow this choice unless repository evidence proves it is infeasible; report any conflict before changing scope.`;
        plan.selectedDecision = { id: decision.selected.id, label: decision.selected.label, source: 'user' };
      } else if (decisionMatrix.rankedOptions.length) {
        const top = decisionMatrix.rankedOptions[0];
        plan.selectedDecision = { id: top.id, label: top.label, source: 'unconfirmed-recommendation' };
        taskForExecution += `\n\nForge decision-support recommendation (not a user-confirmed requirement): ${top.label} (option ${top.id}). Use as a guide only; do not treat the score as a fact.`;
      }
    }
  }

  if (isDecisionOnlyTask(taskForExecution)) {
    console.log('This request is decision-oriented, but no valid typed matrix was available. Forge did not modify repository files.');
    return;
  }

  const targets = validateTargetPaths(root, plan.targetFiles, index, config.limits.maxTargetFiles);
  if (targets.rejected.length) console.log(safeTerminalText(`\nIgnored unsafe planner paths: ${targets.rejected.join(', ')}`));
  let initialTargets = targets.safe;
  if (!initialTargets.length) initialTargets = index.ranked.slice(0, config.limits.maxTargetFiles).map((file) => file.path);
  initialTargets = initialTargets.slice(0, config.limits.maxTargetFiles);
  showList('Plan', [plan.summary, ...plan.steps]);
  showList('Target paths', initialTargets);
  showList('Assumptions', plan.assumptions);
  showList('Plan risks', plan.risks);
  if (!initialTargets.length && index.totalFiles === 0) console.log('No text files were found. The coder may still propose a new text file, but review the result carefully.');

  const first = await proposePatch(root, config, rl, taskForExecution, plan, index, initialTargets, null, runId, skillText);
  const coder = first.payload;
  const patch = coder.patch;
  const changes = preparePatch(root, patch);
  const changeSummary = formatPatchSummary(changes);
  const appliedPatchHistory = [patch];
  const appliedChangeSummaries = [changeSummary];
  const completedChanges = [...changes];
  const allSecurityWarnings = securityWarningsForPatch(changes);
  let latestCheckpoint = null;
  showList('Coder summary', [coder.summary ?? '(not supplied)']);
  showList('Change summary', changeSummary.split('\n'));
  if (allSecurityWarnings.length) showList('Security flags for human review', allSecurityWarnings);
  showPatch(patch);
  writeAudit(root, { action: 'patch_proposed', runId, taskHash: sha256(task), paths: changes.map((change) => change.path), patchHash: sha256(patch), securityWarningCount: allSecurityWarnings.length, runId });

  if (options.dryRun) {
    console.log('\nDry run complete. No patch was written and no test command was executed.');
    writeAudit(root, { action: 'dry_run_complete', paths: changes.map((change) => change.path) });
    return;
  }

  if (changes.some((change) => /^\.github\/workflows\//i.test(change.path) || /^\.gitlab-ci\.yml$/i.test(change.path) || /^\.circleci\//i.test(change.path))) {
    if (!await askExactApproval(rl, 'This patch modifies CI/CD configuration, which may execute code in automated environments. Review the diff carefully.', 'APPROVE')) {
      writeAudit(root, { action: 'patch_denied', runId, reason: 'CI/CD explicit approval missing' });
      console.log('Patch rejected. No workspace files were changed.');
      return;
    }
  }
  if (requiresElevatedPatchApproval(allSecurityWarnings) && !await askExactApproval(rl, 'CRITICAL SECURITY FLAG: this change may combine credential/environment access with network output. Review every changed line and its destination.', 'APPROVE SECURITY RISKS')) {
    writeAudit(root, { action: 'patch_denied', runId, reason: 'elevated_security_approval_missing' });
    console.log('Patch rejected. No workspace files were changed.');
    return;
  }
  setSessionPhase({ root, identity: activeIdentity, sessionId: options.sessionId, runId, phase: 'awaiting_patch_approval' });
  if (!await askYesNo(rl, 'Apply this exact patch? Forge will validate the paths again and save a checkpoint first.')) {
    writeAudit(root, { action: 'patch_denied', runId, reason: 'user_denied', patchHash: sha256(patch) });
    console.log('Patch rejected. No workspace files were changed.');
    return;
  }

  const checkpoint = createCheckpoint(root, changes);
  latestCheckpoint = checkpoint;
  const applied = applyPreparedPatch(root, changes);
  writeAudit(root, { action: 'patch_applied', runId, checkpointId: checkpoint.id, changes: applied });
  console.log(`\nApplied patch. Checkpoint: ${checkpoint.id}`);

  setSessionPhase({ root, identity: activeIdentity, sessionId: options.sessionId, runId, phase: 'verification' });
  let testCommands = Array.isArray(coder.tests) ? coder.tests : [];
  if (!testCommands.length && Array.isArray(plan.testCommands)) testCommands = plan.testCommands;
  if (!testCommands.length) testCommands = testCommandCandidates(buildRepoIndex(root, config, task));
  testCommands = [...new Set(testCommands.filter((command) => typeof command === 'string'))].slice(0, 3);
  let testResults = [];
  for (const command of testCommands) testResults.push(await runApprovedTest(root, rl, config, command, runId, Boolean(options.sandboxTests)));
  if (!testResults.length) {
    testResults = [{ skipped: true, success: false, reason: 'No test command could be inferred. Verification remains incomplete.' }];
    writeAudit(root, { action: 'test_skipped', runId, reason: 'no_test_command' });
  }

  // One optional correction cycle; it remains gated by a second patch approval and checkpoint.
  const failedTests = testResults.filter((result) => result.success === false && !result.skipped);
  if (failedTests.length) {
    const failureText = failedTests.map((result) => `COMMAND: ${result.command}\nEXIT: ${result.code}\nSTDOUT:\n${result.stdout}\nSTDERR:\n${result.stderr}`).join('\n\n');
    console.log('\nVerification failed. Forge can ask the model for one corrective patch; it will not apply anything automatically.');
    if (await askYesNo(rl, 'Attempt one test-failure correction? This sends failure output and relevant source excerpts to the configured model.')) {
      const refreshed = buildRepoIndex(root, config, task);
      const targetPaths = [...new Set([...changes.map((change) => change.path), ...initialTargets])].slice(0, config.limits.maxTargetFiles);
      try {
        const repair = await proposePatch(root, config, rl, taskForExecution, plan, refreshed, targetPaths, failureText, runId, skillText);
        const repairChanges = preparePatch(root, repair.payload.patch);
        const repairSummary = formatPatchSummary(repairChanges);
        const repairSecurityWarnings = securityWarningsForPatch(repairChanges);
        showList('Corrective patch summary', [repair.payload.summary ?? '(not supplied)', ...repairSummary.split('\n')]);
        if (repairSecurityWarnings.length) showList('Corrective patch security flags', repairSecurityWarnings);
        showPatch(repair.payload.patch);
        const changesCiCd = repairChanges.some((change) => /^\.github\/workflows\//i.test(change.path) || /^\.gitlab-ci\.yml$/i.test(change.path) || /^\.circleci\//i.test(change.path));
        let explicitGatePassed = !changesCiCd || await askExactApproval(rl, 'The corrective patch modifies CI/CD configuration, which may execute code in automated environments. Review it carefully.', 'APPROVE');
        if (explicitGatePassed && requiresElevatedPatchApproval(repairSecurityWarnings)) {
          explicitGatePassed = await askExactApproval(rl, 'CRITICAL SECURITY FLAG on the corrective patch: this change may combine credential/environment access with network output.', 'APPROVE SECURITY RISKS');
        }
        if (!explicitGatePassed) {
          writeAudit(root, { action: 'patch_denied', runId, reason: 'corrective explicit security approval missing' });
          console.log('Corrective patch rejected because the required explicit approval was not provided.');
        } else if (await askYesNo(rl, 'Apply this exact corrective patch?')) {
          const repairCheckpoint = createCheckpoint(root, repairChanges);
          applyPreparedPatch(root, repairChanges);
          latestCheckpoint = repairCheckpoint;
          completedChanges.push(...repairChanges);
          allSecurityWarnings.push(...repairSecurityWarnings);
          appliedPatchHistory.push(repair.payload.patch);
          appliedChangeSummaries.push(repairSummary);
          writeAudit(root, { action: 'patch_applied', runId, checkpointId: repairCheckpoint.id, paths: repairChanges.map((change) => change.path), corrective: true, patchHash: sha256(repair.payload.patch), securityWarningCount: repairSecurityWarnings.length });
          const retryCommands = Array.isArray(repair.payload.tests) && repair.payload.tests.length ? repair.payload.tests.filter((command) => typeof command === 'string') : testCommands;
          testResults = [];
          for (const command of [...new Set(retryCommands)].slice(0, 3)) testResults.push(await runApprovedTest(root, rl, config, command, runId, Boolean(options.sandboxTests)));
        } else writeAudit(root, { action: 'patch_denied', runId, reason: 'corrective_patch_denied' });
      } catch (error) {
        console.log(safeTerminalText(`Corrective patch was rejected: ${error.message}`));
        writeAudit(root, { action: 'repair_rejected', runId, error: String(error.message).slice(0, 500) });
      }
    }
  }

  setSessionPhase({ root, identity: activeIdentity, sessionId: options.sessionId, runId, phase: 'review_and_delivery_report' });
  let review = null;
  if (config.review.enabled) {
    try {
      const reviewResult = await modelCall(root, config, 'reviewer', reviewerPrompt({ task, plan, changeSummary: appliedChangeSummaries.join('\n'), patch: appliedPatchHistory.join('\n\n--- Corrective patch applied after verification failure ---\n\n'), tests: testResults, securityWarnings: allSecurityWarnings, config }), runId);
      review = extractJsonObject(reviewResult.text);
      writeAudit(root, { action: 'review_complete', runId, verdict: String(review.verdict ?? 'UNKNOWN').toUpperCase(), findingCount: Array.isArray(review.findings) ? review.findings.length : null });
      showList('Reviewer verdict', [String(review.verdict ?? 'UNKNOWN').toUpperCase()]);
      showList('Reviewer findings', Array.isArray(review.findings) ? review.findings.map((item) => `${item.severity ?? 'unknown'}: ${item.file ?? ''} ${item.detail ?? ''}`) : []);
      showList('Verification gaps', Array.isArray(review.verificationGaps) ? review.verificationGaps : []);
    } catch (error) {
      console.log(safeTerminalText(`Reviewer unavailable: ${error.message}`));
      review = { verdict: 'UNVERIFIED', findings: [], verificationGaps: ['Independent model review did not complete.'] };
    }
  }

  let securityReview = null;
  const shouldRunSecurityAgent = executionPlan.securityAgent || allSecurityWarnings.some((warning) => warning.severity === 'critical' || warning.severity === 'high');
  if (shouldRunSecurityAgent && config.review.enabled) {
    console.log('\nActivating conditional Security Auditor subagent because the task or deterministic diff flags indicate elevated risk. This is a separate model review, not a substitute for tests or sandboxing.');
    try {
      const securityResult = await modelCall(root, config, 'security-auditor', securityAuditorPrompt({
        task, changeSummary: appliedChangeSummaries.join('\n'),
        patch: appliedPatchHistory.join('\n\n--- Corrective patch ---\n\n'),
        tests: testResults, securityWarnings: allSecurityWarnings,
      }), runId);
      securityReview = extractJsonObject(securityResult.text);
      writeAudit(root, { action: 'security_subagent_complete', runId, verdict: String(securityReview.verdict ?? 'UNKNOWN').toUpperCase(), findingCount: Array.isArray(securityReview.findings) ? securityReview.findings.length : null });
      showList('Security Auditor verdict', [String(securityReview.verdict ?? 'UNKNOWN').toUpperCase()]);
      showList('Security Auditor findings', Array.isArray(securityReview.findings) ? securityReview.findings.map((item) => `${item.severity ?? 'unknown'}: ${item.file ?? ''} ${item.evidence ?? item.detail ?? ''} — ${item.recommendation ?? ''}`) : []);
      showList('Security Auditor verification gaps', Array.isArray(securityReview.verificationGaps) ? securityReview.verificationGaps : []);
    } catch (error) {
      console.log(safeTerminalText(`Security Auditor unavailable: ${error.message}`));
      securityReview = { verdict: 'UNVERIFIED', findings: [], verificationGaps: ['Conditional security review did not complete.'] };
      writeAudit(root, { action: 'security_subagent_failed', runId, error: redactSecrets(error.message).slice(0, 250) });
    }
  }

  let browserResult = null;
  if (executionPlan.browser && !options.dryRun) {
    const browserUrl = extractHttpUrl(task) || process.env.FORGE_BROWSER_URL || '';
    const browserArgs = ['test'];
    if (browserUrl) browserArgs.push(browserUrl);
    // When no URL is known, the Browser QA router can start a narrowly allow-listed
    // local framework script after a separate approval, then stop it in a finally block.
    try {
      browserResult = await runBrowserCommand(root, browserArgs, rl, { task, autoRouted: true });
    } catch (error) {
      browserResult = error?.browserResult || { status: 'NOT_VERIFIED', reason: redactSecrets(error.message).slice(0, 500) };
      console.log(safeTerminalText(`Browser QA was selected but is not fully verified: ${browserResult.reason || error.message}`));
      writeAudit(root, { action: 'browser_qa_not_verified', runId, targetOrigin: browserResult.targetOrigin, status: browserResult.status, reasonHash: sha256(error.message) });
    }
  }

  const allTestsPassed = testResults.length > 0 && testResults.every((result) => result.success === true) && (!executionPlan.browser || options.dryRun || browserResult?.status === 'PASS');
  console.log('\n=== Forge delivery report ===');
  console.log(safeTerminalText(`Changed paths: ${[...new Set(completedChanges.map((change) => change.path))].join(', ') || '(none)'}`));
  console.log(`Tests: ${allTestsPassed ? 'all executed checks passed' : 'not fully verified — inspect the results above'}`);
  console.log(safeTerminalText(`Review: ${String(review?.verdict ?? 'not run').toUpperCase()}`));
  console.log(`Security flags: ${allSecurityWarnings.length}`);
  if (securityReview) console.log(`Conditional Security Auditor: ${String(securityReview.verdict ?? 'UNVERIFIED').toUpperCase()}`);
  if (browserResult) console.log(`Browser QA: ${browserResult.status}${browserResult.reportPath ? ` · report ${safeTerminalText(path.relative(root, browserResult.reportPath))}` : ` · ${safeTerminalText(browserResult.reason || 'see output above')}`}`);
  console.log(`Rollback: forge undo (latest checkpoint ${latestCheckpoint?.id ?? checkpoint.id}; repeat undo to roll back earlier patches from this task)`);
  const cost = summarizeCost(readAudit(root).filter((event) => event.runId === runId));
  console.log(`This task's observed usage: ${cost.tokensIn || cost.tokensOut ? `${cost.tokensIn} input / ${cost.tokensOut} output tokens reported` : 'token usage unavailable from model events'}; ${cost.knownCostCalls ? `$${cost.costUsd.toFixed(6)} USD reported across ${cost.knownCostCalls} calls` : 'cost unavailable from model events'}`);
  writeAudit(root, { action: 'task_finished', runId, taskHash: sha256(task), testsPassed: allTestsPassed, reviewVerdict: review?.verdict ?? 'UNVERIFIED', securitySubagentVerdict: securityReview?.verdict ?? undefined, browserStatus: browserResult?.status, securityWarningCount: allSecurityWarnings.length });
}


export function classifySessionOutcome(root, runId) {
  const events = readAudit(root).filter((event) => event.runId === runId);
  const decisionOnly = [...events].reverse().find((event) => event.action === 'decision_matrix_completed');
  if (decisionOnly && !events.some((event) => ['patch_applied', 'patch_proposed'].includes(event.action)) && !events.some((event) => event.action === 'task_finished')) {
    return { status: 'completed', phase: 'decision_matrix_validated', outcome: { decisionMatrixValidated: true, criteriaCount: decisionOnly.criteriaCount, optionCount: decisionOnly.optionCount, evidence: 'Typed decision schema validated and ranking computed locally; model scores are not ground truth.' } };
  }
  const finished = [...events].reverse().find((event) => event.action === 'task_finished');
  if (finished) {
    const reviewVerdict = String(finished.reviewVerdict || 'UNVERIFIED').toUpperCase();
    const securitySubagentVerdict = finished.securitySubagentVerdict == null
      ? null : String(finished.securitySubagentVerdict).toUpperCase();
    const browserStatus = finished.browserStatus == null ? null : String(finished.browserStatus).toUpperCase();
    const securityWarningCount = Number.isInteger(finished.securityWarningCount) ? finished.securityWarningCount : 0;
    // Completion is evidence-gated. A reviewer PASS cannot override failed tests,
    // browser QA failure, or unresolved deterministic security flags.
    const verified = finished.testsPassed === true
      && reviewVerdict === 'PASS'
      && securityWarningCount === 0
      && (!securitySubagentVerdict || securitySubagentVerdict === 'PASS')
      && (!browserStatus || browserStatus === 'PASS');
    return {
      status: verified ? 'completed' : 'needs_review',
      phase: verified ? 'verified' : 'finished_with_unverified_or_failing_checks',
      outcome: {
        testsPassed: finished.testsPassed === true,
        reviewVerdict,
        securitySubagentVerdict,
        browserStatus,
        securityWarningCount: Number.isInteger(finished.securityWarningCount) ? finished.securityWarningCount : null,
        evidence: 'Forge audit events for this run; completion requires passing executed checks and review, no unresolved security flags, and passing browser QA when present. See `forge audit` for details.',
      },
    };
  }
  if (events.some((event) => typeof event.action === 'string' && event.action.startsWith('task_blocked'))) {
    return { status: 'blocked', phase: 'blocked_for_input_or_safety', outcome: { evidence: 'Task was blocked before a verified completion; inspect `forge audit`.' } };
  }
  if (events.some((event) => event.action === 'run_cancelled' || event.action === 'patch_denied')) {
    return { status: 'cancelled', phase: 'cancelled_or_denied', outcome: { evidence: 'The user cancelled or declined an action; no completion is implied.' } };
  }
  if (events.some((event) => event.action === 'dry_run_complete')) {
    return { status: 'needs_review', phase: 'dry_run_proposal_only', outcome: { dryRun: true, evidence: 'A proposal was generated; it was not applied.' } };
  }
  if (events.some((event) => event.action === 'patch_applied' || event.action === 'patch_proposed')) {
    return { status: 'needs_review', phase: 'patch_activity_without_verified_finish', outcome: { evidence: 'Patch activity exists, but no verified completion event was recorded.' } };
  }
  return { status: 'needs_review', phase: 'no_verified_completion_event', outcome: { evidence: 'No final task-completion record was found. Inspect `forge audit`; do not infer success.' } };
}

async function performRun(root, task, options, rl) {
  const identity = ensureProjectIdentity(root);
  const runId = randomUUID();
  let session;
  let sessionLock;
  try {
    if (options.sessionId) {
      // Lock before mutating the session or making a provider request; concurrent resumes fail closed.
      sessionLock = acquireSessionLock({ root, identity, sessionId: options.sessionId });
      session = beginSessionAttempt({ root, identity, sessionId: options.sessionId, runId });
    } else {
      session = createSession({ root, identity, task, options, runId, acquireLock: true });
      sessionLock = session.sessionLock;
    }
    const resumed = Boolean(options.sessionId);
    writeAudit(root, {
      action: resumed ? 'session_resumed' : 'session_started',
      sessionId: session.sessionId,
      runId,
      taskHash: session.taskHash,
      attempt: session.attempts.length,
      restartSemantics: resumed ? 're-run-against-current-files; prior model conversation is not restored' : undefined,
    });
    try {
      await performRunInternal(root, task, { ...options, runId, sessionId: session.sessionId }, rl);
      const outcome = classifySessionOutcome(root, runId);
      finishSessionAttempt({
        root, identity, sessionId: session.sessionId, runId,
        status: outcome.status, phase: outcome.phase, outcome: outcome.outcome,
      });
      writeAudit(root, { action: 'session_attempt_finished', sessionId: session.sessionId, runId, status: outcome.status, phase: outcome.phase });
      console.log(`\nForge session: ${session.sessionId} · ${outcome.status}`);
      console.log(`Inspect with: forge sessions show ${session.sessionId}`);
    } catch (error) {
      try {
        finishSessionAttempt({
          root, identity, sessionId: session.sessionId, runId,
          status: 'failed', phase: 'exception',
          outcome: { error: redactSecrets(error?.message ?? String(error)).slice(0, 500), evidence: 'The CLI threw an error; completion was not established.' },
        });
        writeAudit(root, { action: 'session_attempt_failed', sessionId: session.sessionId, runId, error: redactSecrets(error?.message ?? String(error)).slice(0, 300) });
      } catch { /* Preserve the original failure; session integrity errors must not mask it. */ }
      throw error;
    }
  } finally {
    if (sessionLock && !sessionLock.release()) {
      console.error(`Warning: Forge could not verify and release its session lock for ${session?.sessionId || options.sessionId || '(new session)'}. Inspect the matching .lock file in the private Forge session directory before trying again.`);
      try { writeAudit(root, { action: 'session_lock_release_warning', sessionId: session?.sessionId || options.sessionId, runId }); } catch { /* Preserve the task outcome. */ }
    }
  }
}

function renderSessionList(root, identity) {
  const result = listSessions({ root, identity, limit: 50 });
  if (!result.sessions.length) console.log('No valid Forge sessions for this project yet. Start one with `forge run "Describe the task"`.');
  else {
    console.log(`Forge sessions for ${safeTerminalText(identity.name)} · ${identity.projectId}`);
    for (const session of result.sessions) {
      const task = session.task.replace(/\s+/g, ' ').slice(0, 96);
      console.log(`${session.sessionId}  ${session.status.padEnd(12)} ${session.updatedAt}  ${safeTerminalText(task)}${session.task.length > 96 ? '…' : ''}`);
    }
    if (result.sessions.length === 50) console.log('Showing the 50 most recently updated sessions.');
  }
  if (result.invalidCount) console.log(`Security note: ignored ${result.invalidCount} session record(s) that failed integrity or project-binding checks.`);
}

function renderSessionDetails(root, identity, sessionId) {
  const session = loadSession({ root, identity, sessionId });
  console.log(`Session: ${session.sessionId}`);
  console.log(`Status: ${session.status} · phase: ${session.phase}`);
  console.log(`Project: ${session.projectRoot} · ${session.projectId} · binding epoch ${session.bindingEpoch}`);
  console.log(`Created: ${session.createdAt}`);
  console.log(`Updated: ${session.updatedAt}`);
  console.log(`Task: ${safeTerminalText(session.task)}`);
  console.log(`Attempts: ${session.attempts.length}`);
  for (const attempt of session.attempts) {
    console.log(`  - ${attempt.runId}  ${attempt.status}  ${attempt.startedAt}${attempt.finishedAt ? ` → ${attempt.finishedAt}` : ''}  phase=${attempt.phase || 'unknown'}${attempt.resumed ? '  (restart)' : ''}`);
    const usage = summarizeCost(readAudit(root).filter((event) => event.runId === attempt.runId));
    const tokenText = usage.knownTokenCalls
      ? `reported tokens ${usage.tokensIn} input / ${usage.tokensOut} output (${usage.knownTokenCalls}/${usage.calls} model calls returned usage)`
      : 'token usage unavailable from provider events';
    const costText = usage.knownCostCalls
      ? `$${usage.costUsd.toFixed(6)} USD reported (${usage.knownCostCalls}/${usage.calls} model calls returned cost)`
      : 'cost unavailable from provider events';
    console.log(`      Usage: ${tokenText}; ${costText}`);
  }
  if (session.lastOutcome) console.log(`Last outcome: ${safeTerminalText(JSON.stringify(session.lastOutcome))}`);
  if (session.status !== 'completed' && session.status !== 'cancelled') {
    console.log(`Restart command: forge resume ${session.sessionId}`);
    console.log('A restart re-executes the saved task against current files; it does not restore prior model messages or undo existing edits.');
  }
}

async function runResumeCommand(root, args, rl) {
  if (args.length !== 1 || args[0].startsWith('-')) throw new Error('Usage: forge resume SESSION_ID. List sessions with `forge sessions list`.');
  const identity = ensureProjectIdentity(root);
  const session = loadSession({ root, identity, sessionId: args[0] });
  if (session.status === 'completed') throw new Error('This session completed with verified checks. Start a new `forge run` for new work.');
  if (session.status === 'cancelled') throw new Error('This session was explicitly cancelled. Start a new `forge run` if you want to try again.');
  console.log(`Forge will restart this task in project ${safeTerminalText(identity.name)}.`);
  console.log(`Previous outcome: ${session.status} · ${session.phase}`);
  console.log('Important: this is a fresh attempt using the current working tree. Forge does not restore model conversation state or automatically undo partial edits. Review `git diff` and `forge audit` first.');
  if (!canPrompt()) throw new Error('Resuming requires an interactive terminal and exact confirmation. No model request was made.');
  const confirmed = await askExactApproval(rl,
    'The saved task will be run again from the beginning against the current filesystem. Existing partial edits remain and may affect the result. Confirm only after reviewing them.',
    'RESTART SAVED TASK');
  if (!confirmed) { console.log('Resume cancelled; no model request was made.'); return; }
  await performRun(root, session.task, { ...session.options, sessionId: session.sessionId }, rl);
}

function doctor(root) {
  const config = loadConfig(root);
  const nodeOk = Number(process.versions.node.split('.')[0]) >= 22;
  console.log(`Forge ${VERSION}`);
  console.log(`Node.js: ${process.version} ${nodeOk ? '(OK)' : '(requires >=22)'}`);
  console.log(`Git: ${gitAvailable() ? 'available' : 'not found'}`);
  console.log(safeTerminalText(`Project root: ${root}`));
  console.log(`Config: ${fs.existsSync(path.join(root, CONFIG_NAME)) ? 'found' : 'defaults (run forge init to persist)'}`);
  console.log(`Provider: ${config.provider}`);
  console.log(`Model: ${config.model}`);
  if (config.provider === 'openrouter') console.log(`OpenRouter API key: ${process.env.OPENROUTER_API_KEY ? 'present in environment' : 'missing (set OPENROUTER_API_KEY)'}`);
  console.log(`Privacy mode: ${config.privacy.mode}`);
  console.log(`Context7 API key: ${process.env.CONTEXT7_API_KEY ? 'present in environment' : 'not set (forge docs may have lower rate limits)'}`);
  const halt = getFreezeState(root);
  console.log(`Emergency stop: ${halt.frozen ? `ACTIVE (${safeTerminalText(halt.reason || 'HALT marker requires inspection')})` : 'inactive'}`);
  try { validatePrivacyMode(config); console.log('Model/privacy compatibility: OK'); }
  catch (error) { console.log(safeTerminalText(`Model/privacy compatibility: ERROR — ${error.message}`)); }
  // A short non-model CLI probe. It never sends a provider request.
  if (config.provider === 'openrouter') { console.log('OpenCode: not required for the selected provider'); console.log('OpenRouter connectivity: not tested (doctor never sends a model request)'); const sandbox = inspectSandbox({ cwd: root }); console.log(`Container sandbox: ${sandbox.available ? `ready (${sandbox.runtime}, ${sandbox.image})` : 'not ready; run `forge sandbox status` for details'}`); console.log('Only `forge sandbox run` uses the disposable container path. Ordinary approval-gated commands remain host-executed.'); return; }
  try {
    const opencodeCommand = getOpenCodeCommand(config);
    const probe = spawnSync(opencodeCommand, ['--version'], { cwd: os.tmpdir(), env: buildCommandEnv(), encoding: 'utf8', timeout: 3000, windowsHide: true });
    console.log(safeTerminalText(`OpenCode: ${probe.status === 0 ? (probe.stdout || probe.stderr).trim() : 'not available or failed (no model request made)'}`));
  } catch (error) { console.log(safeTerminalText(`OpenCode: not available (${redactSecrets(error.message)})`)); }
  const sandbox = inspectSandbox({ cwd: root });
  console.log(`Container sandbox: ${sandbox.available ? `ready (${sandbox.runtime}, ${sandbox.image})` : 'not ready; run `forge sandbox status` for details'}`);
  console.log('Only `forge sandbox run` uses the disposable container path. Ordinary approval-gated commands remain host-executed.');
}


function writeForgeReport(root, filename, content) {
  const directory = ensureRealDirectory(forgeDir(root), 0o700);
  const target = path.join(directory, filename);
  try {
    const info = fs.lstatSync(target);
    if (info.isSymbolicLink() || !info.isFile()) throw new Error(`Refusing to overwrite a symlink or non-file: ${target}`);
  } catch (error) { if (error?.code !== 'ENOENT') throw error; }
  const temp = `${target}.tmp-${randomUUID()}`;
  try {
    fs.writeFileSync(temp, content, { mode: 0o600, flag: 'wx' });
    fs.renameSync(temp, target);
  } catch (error) {
    try { fs.rmSync(temp, { force: true }); } catch {}
    throw error;
  }
  return target;
}

function buildGraphReport(root) {
  assertProjectNotFrozen(root, 'code graph report writes');
  const config = loadConfig(root);
  const index = buildRepoIndex(root, config);
  const graph = buildLocalCodeGraph(index);
  const jsonPath = writeForgeReport(root, 'code-graph.json', `${JSON.stringify(graph, null, 2)}\n`);
  const reportPath = writeForgeReport(root, 'CODE_GRAPH.md', renderGraphReport(graph));
  console.log('Forge local code graph');
  console.log(`Files indexed: ${graph.stats.sourceFiles}`);
  console.log(`Nodes: ${graph.stats.nodes}`);
  console.log(`Import edges: ${graph.stats.edges} (${graph.stats.internalEdges} resolved internally)`);
  console.log(`Graph: ${safeTerminalText(path.relative(root, jsonPath))}`);
  console.log(`Report: ${safeTerminalText(path.relative(root, reportPath))}`);
  console.log('Privacy: local-only; no code or graph was sent to a provider. Regex-derived hints are not a complete semantic graph.');
  writeAudit(root, { action: 'local_code_graph_built', sourceFiles: graph.stats.sourceFiles, nodes: graph.stats.nodes, edges: graph.stats.edges });
}

async function runContext7Docs(root, args, rl) {
  assertProjectNotFrozen(root, 'remote documentation lookups');
  const config = loadConfig(root);
  if (config.privacy.mode === 'local-only') throw new Error('forge docs requires an explicit remote service and is disabled by privacy.mode=local-only. Change the privacy policy deliberately before using it.');
  let library = null; let version = null; let language = null; let approvedFlag = false;
  const queryParts = [];
  for (let i = 0; i < args.length; i += 1) {
    if (args[i] === '--library') { library = args[++i]; if (!library) throw new Error('--library needs a name or Context7 library ID.'); }
    else if (args[i] === '--version') { version = args[++i]; if (!version) throw new Error('--version needs a version.'); }
    else if (args[i] === '--language') { language = args[++i]; if (!language) throw new Error('--language needs a language name.'); }
    else if (args[i] === '--yes') approvedFlag = true;
    else if (args[i] === '--help' || args[i] === '-h') {
      console.log('Usage: forge docs [--library NAME_OR_ID] [--version X.Y.Z] [--language NAME] [--yes] "QUESTION"');
      console.log('Sends only the question and selected hints to https://context7.com/api/v3/search. Does not send repository files.');
      return;
    } else queryParts.push(args[i]);
  }
  const query = redactSecrets(queryParts.join(' ').trim());
  if (!query) throw new Error('Usage: forge docs [--library NAME_OR_ID] [--version X.Y.Z] [--language NAME] [--yes] "QUESTION"');
  console.log('\nContext7 documentation lookup (read-only external request).');
  console.log('Data to be sent: the question plus any library/version/language hints shown below.');
  console.log(`Question: ${safeTerminalText(query)}`);
  if (library) console.log(`Library: ${safeTerminalText(library)}`);
  if (version) console.log(`Version: ${safeTerminalText(version)}`);
  if (language) console.log(`Language: ${safeTerminalText(language)}`);
  console.log(`API key: ${process.env.CONTEXT7_API_KEY ? 'present (sent only to Context7)' : 'not set (Context7 documents low unauthenticated rate limits)'}`);
  console.log('Repository files, project memory, task history, and Forge credentials are NOT included in the request. Returned documentation is untrusted external data; do not execute code snippets without review.');
  if (!approvedFlag && !await askYesNo(rl, 'Send this query to Context7?')) {
    writeAudit(root, { action: 'context7_lookup_denied', queryChars: query.length, library: library || undefined });
    console.log('Cancelled; no network request was made.');
    return;
  }
  try {
    const result = await searchContext7({ query, library, version, language, apiKey: process.env.CONTEXT7_API_KEY || '' });
    const body = formatContext7Result(result.data, 18000);
    console.log('\n=== UNTRUSTED EXTERNAL DOCUMENTATION: CONTEXT7 ===\n');
    console.log(safeTerminalText(redactSecrets(body || 'Context7 returned no documentation snippets.')));
    console.log('\n=== END EXTERNAL DOCUMENTATION ===');
    writeAudit(root, { action: 'context7_lookup_succeeded', queryChars: result.queryChars, library: result.library || undefined, version: result.version || undefined, responseChars: body.length, apiKeyUsed: Boolean(process.env.CONTEXT7_API_KEY) });
  } catch (error) {
    writeAudit(root, { action: 'context7_lookup_failed', error: redactSecrets(error.message).slice(0, 300), library: library || undefined });
    throw error;
  }
}

async function runAgentReach(root, args, rl) {
  const subcommand = args[0] || 'status';
  if (!['status', 'doctor', 'search'].includes(subcommand)) {
    throw new Error('Usage: forge reach [status|doctor|search --platform PLATFORM QUERY]. Forge will not install Agent-Reach or configure platform cookies automatically.');
  }
  if (subcommand !== 'status') assertProjectNotFrozen(root, 'Agent-Reach bridge actions');
  if (subcommand === 'status') {
    // Status is intentionally passive: do not execute an arbitrary PATH binary even for --help.
    // Search routes work with compatible local CLIs and do not require Agent-Reach itself.
    const available = discoverReachExecutables(buildCommandEnv());
    console.log('Forge research bridge: allow-listed routes; no research query was sent.');
    console.log(`Detected backend executables: ${available.length ? available.join(', ') : 'none'}`);
    console.log('This is PATH-file discovery only, not a live health check. Use `forge reach doctor` only after reviewing its separate remote-probe disclosure.');
    console.log('Forge does not install tools, log in, import cookies, or perform write actions. Use only accounts and access permitted by the platform.');
    return;
  }
  if (subcommand === 'doctor') {
    const config = loadConfig(root);
    if (config.privacy.mode === 'local-only') throw new Error('forge reach doctor can run generic remote channel health probes and is disabled by privacy.mode=local-only. Change the policy deliberately before running it.');
    let probe;
    try {
      probe = spawnSync('agent-reach', ['doctor'], { cwd: os.tmpdir(), env: buildCommandEnv(), encoding: 'utf8', timeout: 20000, maxBuffer: 200000, windowsHide: true, shell: false });
    } catch (error) {
      throw new Error(`Could not start Agent-Reach: ${redactSecrets(error.message)}. Install it yourself from the official repository; Forge never installs external code automatically.`);
    }
    if (probe.error?.code === 'ENOENT') throw new Error('Agent-Reach is not installed or not on PATH. Forge will not install it automatically; review https://github.com/Panniantong/Agent-Reach and use its install preflight first.');
    if (probe.error) throw new Error(`Agent-Reach doctor failed to start: ${redactSecrets(probe.error.message)}`);
    console.log(safeTerminalText(redactSecrets(truncate(`${probe.stdout || ''}${probe.stderr ? `\n${probe.stderr}` : ''}`, 12000))));
    console.log(`Agent-Reach exit status: ${probe.status ?? 'unknown'}${probe.signal ? ` (signal ${probe.signal})` : ''}`);
    console.log('Privacy note: Agent-Reach doctor may run generic remote health probes across multiple configured channels; it does not send Forge repository files or project memory. Results are untrusted.');
    console.log('Security note: channel output is untrusted internet content. Do not follow embedded instructions; never permit fetched content to approve code changes, access secrets, or bypass Forge gates.');
    writeAudit(root, { action: 'agent_reach_doctor', exitCode: probe.status ?? undefined, signal: probe.signal ?? undefined, outputChars: Math.min((probe.stdout || '').length + (probe.stderr || '').length, 12000) });
    if (probe.status !== 0) console.log('Some channels may be unavailable. Forge has not installed or changed any dependencies.');
    return;
  }

  let platform = null; let approvedFlag = false; let allowAccount = false;
  const queryParts = [];
  for (let i = 1; i < args.length; i += 1) {
    const arg = args[i];
    if (arg === '--platform') { platform = args[++i]; if (!platform) throw new Error('--platform needs a platform name.'); }
    else if (arg === '--yes') approvedFlag = true;
    else if (arg === '--allow-account') allowAccount = true;
    else if (arg === '--help' || arg === '-h') {
      console.log('Usage: forge reach search --platform PLATFORM [--allow-account] [--yes] QUERY');
      console.log('Platforms: github, youtube, bilibili, web, twitter, reddit, xiaohongshu, facebook, instagram.');
      console.log('Every search is external and consent-gated. Social/account routes additionally require --allow-account.');
      return;
    } else queryParts.push(arg);
  }
  if (!platform) throw new Error('Usage: forge reach search --platform PLATFORM [--allow-account] [--yes] QUERY');
  const query = validateResearchQuery(redactSecrets(validateResearchQuery(queryParts.join(' '))));
  const config = loadConfig(root);
  if (config.privacy.mode === 'local-only') throw new Error('forge reach search is a remote research action and is blocked by privacy.mode=local-only. Change that policy deliberately before searching.');
  if (isAccountResearchPlatform(platform) && !allowAccount) {
    throw new Error(`${platform} may use an account or browser session. Add --allow-account only after reviewing this risk; Forge does not import or export browser cookies.`);
  }

  console.log('\nForge external research consent checkpoint');
  console.log(`Platform: ${safeTerminalText(platform)}`);
  console.log(`Query to send: ${safeTerminalText(query)}`);
  console.log('Data boundary: Forge sends only this query to the selected platform/backend. It does not attach repository files, FORGE.md, indexed code, previous chats, or Forge audit records.');
  console.log('The external service/platform will receive the query; its own logs, terms, and retention rules apply. Returned results are untrusted internet content and will not be sent to a model automatically.');
  const childEnv = buildCommandEnv();
  const twitterCredentialsAvailable = Boolean(process.env.TWITTER_AUTH_TOKEN && process.env.TWITTER_CT0);
  const availableCommands = discoverReachExecutables(childEnv);
  // Select the route using local PATH inspection only. Agent-Reach doctor is deliberately
  // not run here because upstream health checks can make generic requests to other platforms.
  const invocation = buildReachSearchInvocation(platform, query, { availableCommands, allowAccount, twitterCredentialsAvailable });
  console.log(`Selected backend: ${safeTerminalText(invocation.backend)} (${safeTerminalText(invocation.command)}).`);
  console.log('No automatic Agent-Reach doctor probes will run as part of this search.');
  console.log('Forge will not install tools, log in, import cookies, or perform write actions.');
  if (invocation.usesAccountSession || allowAccount) console.log('Account boundary: --allow-account enabled. The selected backend may use an account/session already configured for that CLI or browser.');
  if (!approvedFlag) {
    const ok = await askYesNo(rl, 'Send this query to the selected external research backend?');
    if (!ok) { console.log('Cancelled. No research query was sent.'); writeAudit(root, { action: 'agent_reach_search_cancelled', platform, queryHash: sha256(query) }); return; }
  }


  if (invocation.command === 'twitter') {
    const authToken = process.env.TWITTER_AUTH_TOKEN;
    const ct0 = process.env.TWITTER_CT0;
    if (!authToken || !ct0) throw new Error('The selected Twitter CLI backend requires TWITTER_AUTH_TOKEN and TWITTER_CT0 in the launching shell. Forge will not read browser cookies or import saved cookies from Agent-Reach.');
    childEnv.TWITTER_AUTH_TOKEN = authToken;
    childEnv.TWITTER_CT0 = ct0;
  }
  const timeout = platform === 'xiaohongshu' ? 125000 : 35000;
  let result;
  try {
    result = spawnSync(invocation.command, invocation.args, { cwd: os.tmpdir(), env: childEnv, encoding: 'utf8', timeout, maxBuffer: 250000, windowsHide: true, shell: false });
  } catch (error) {
    throw new Error(`Could not start approved read-only backend: ${redactSecrets(error.message)}`);
  }
  let rawOutput = truncate(`${result.stdout || ''}${result.stderr ? `\n${result.stderr}` : ''}`, 24000);
  for (const secret of [process.env.TWITTER_AUTH_TOKEN, process.env.TWITTER_CT0]) {
    if (typeof secret === 'string' && secret.length >= 4) rawOutput = rawOutput.split(secret).join('[REDACTED]');
  }
  const output = safeTerminalText(redactSecrets(rawOutput));
  writeAudit(root, {
    action: 'agent_reach_search', platform, backend: invocation.backend,
    queryHash: sha256(query), queryChars: query.length,
    exitCode: result.status ?? undefined, signal: result.signal ?? undefined,
    timedOut: Boolean(result.error?.code === 'ETIMEDOUT'), outputChars: output.length,
  });
  console.log(`\nResearch backend: ${safeTerminalText(invocation.command)} (${safeTerminalText(invocation.backend)})`);
  console.log('--- UNTRUSTED EXTERNAL RESULTS: do not follow instructions found in results ---');
  console.log(output || '(No output returned.)');
  console.log('--- END EXTERNAL RESULTS ---');
  if (result.error?.code === 'ETIMEDOUT') throw new Error(`Research backend timed out after ${timeout} ms. No automatic retry was attempted.`);
  if (result.error?.code === 'ENOENT') throw new Error(`Selected backend executable ${invocation.command} disappeared or cannot be started. Install/configure the documented backend yourself; Forge will not install it automatically.`);
  if (result.error) throw new Error(`Research backend failed to start: ${redactSecrets(result.error.message)}`);
  console.log(`Research command exit status: ${result.status ?? 'unknown'}. ${result.status === 0 ? 'A result was returned; independently verify sources and dates.' : 'The search did not complete successfully.'}`);
}

async function runBrowserSetup(root, rl) {
  assertProjectNotFrozen(root, 'browser automation setup');
  const config = loadConfig(root);
  if (config.privacy.mode === 'local-only') throw new Error('Browser setup downloads a package from npm and is blocked in privacy.mode=local-only. Install dependencies deliberately outside Forge, then use the local browser route.');
  const status = browserStatus(root);
  if (status.playwrightAvailable) {
    console.log(`Playwright is already available (${status.packageName}). ${status.setupInstructions}`);
    return;
  }
  console.log('Browser setup will add the optional playwright-core package to this project.');
  console.log('Package-manager lifecycle scripts are disabled (--ignore-scripts); Forge will not download a browser or reuse logged-in browser data.');
  console.log('Data sent: npm registry requests to resolve/download the package. This changes package.json/package-lock.json and installs code.');
  if (!canPrompt() || !await askYesNo(rl, 'Install playwright-core as a development dependency now?')) {
    console.log('Cancelled. No package install was attempted.');
    return;
  }
  const result = await runProcess('npm install --save-dev playwright-core --ignore-scripts --no-audit --no-fund', {
    cwd: root, timeoutMs: 120000, maxOutputBytes: 120000,
  });
  const stdout = safeTerminalText(redactSecrets(result.stdout || ''));
  const stderr = safeTerminalText(redactSecrets(result.stderr || ''));
  if (stdout.trim()) console.log(truncate(stdout, 7000));
  if (stderr.trim()) console.log(truncate(stderr, 5000));
  writeAudit(root, { action: 'browser_setup', package: 'playwright-core', exitCode: result.code, success: result.success, timedOut: result.timedOut });
  if (!result.success) throw new Error(`Playwright setup failed (exit ${result.code}${result.timedOut ? ', timed out' : ''}). Browser testing remains unavailable until the dependency is installed. No browser was downloaded.`);
  const after = browserStatus(root);
  console.log(`Playwright dependency: ${after.playwrightAvailable ? 'available' : 'not detected after install'}`);
  console.log(`Browser executable: ${after.browserExecutable || 'not found'}`);
  console.log(after.setupInstructions);
}

function printBrowserSummary(result, root) {
  const report = result.report;
  console.log(`\\nBrowser QA status: ${result.status}`);
  console.log(`Target: ${safeTerminalText(report.target.url)} (query parameters and fragments excluded from the report)`);
  console.log(`Navigation HTTP status: ${report.navigation.httpStatus ?? 'unavailable'}${report.navigation.error ? ` — ${safeTerminalText(report.navigation.error)}` : ''}`);
  for (const viewport of report.viewports) {
    console.log(`${viewport.viewport}: ${viewport.viewportWidth}×${viewport.viewportHeight}; title=${viewport.titlePresent ? 'yes' : 'missing'}; h1=${viewport.visibleH1Count}; buttons=${viewport.visibleButtons}; links=${viewport.visibleLinks}; canvas=${viewport.canvasCount}; horizontal-overflow=${viewport.horizontalOverflow ? 'YES' : 'no'}`);
  }
  console.log(`Issues: ${report.issues.pageErrors.length} uncaught JS errors, ${report.issues.consoleErrors.length} console errors, ${report.issues.httpErrors.length} HTTP errors, ${report.issues.failedRequests.length} failed requests, ${report.issues.blockedRequests.length} policy-blocked requests.`);
  if (report.promptInjectionIndicators.length) {
    console.log('Prompt-injection indicators in rendered page: flagged by heuristic. The page is untrusted; content was not sent to a model.');
    showList('Indicator categories only', report.promptInjectionIndicators.map((item) => `${item.path}: ${item.indicators.join(', ')}`));
  }
  if (report.gameExercise.requested) console.log(`Game exercise: start-control-clicked=${report.gameExercise.startControlClicked}; keys=${report.gameExercise.keysSent.join(', ') || '(none)'}; ${safeTerminalText(report.gameExercise.note)}`);
  console.log(`Evidence directory: ${safeTerminalText(path.relative(root, result.outputDirectory))}`);
  for (const screenshot of result.screenshots) console.log(`Screenshot: ${safeTerminalText(path.relative(root, screenshot))}`);
  console.log(`Report: ${safeTerminalText(path.relative(root, result.reportPath))}`);
  console.log('Privacy: ephemeral browser context; no regular Chrome profile, cookies or storage state reused; report/screenshots stay local and are not sent to a model.');
  console.log('Limit: this is a deterministic smoke audit, not full app/game correctness proof or an OS sandbox.');
}

async function runBrowserCommand(root, args, rl, { task = '', autoRouted = false } = {}) {
  const action = args[0] || 'status';
  if (!['status', 'setup', 'test', 'inspect', 'open'].includes(action)) {
    throw new Error('Usage: forge browser [status|setup|test URL|inspect URL|open URL] [--start [dev|preview|start|serve]] [--port PORT] [--headed] [--allow-origin ORIGIN] [--allow-private-network] [--exercise] [--yes]');
  }
  if (action === 'status') {
    const status = browserStatus(root);
    console.log('Forge Browser QA — optional Playwright adapter');
    console.log(`Playwright: ${status.playwrightAvailable ? `available (${status.packageName})` : 'not installed'}`);
    console.log(`System browser: ${status.browserExecutable || 'not detected'}`);
    console.log(`Status: ${status.setupInstructions}`);
    console.log('Default policy: fresh isolated context, no user browser profile/cookies/storage state, target origin only, third-party origins blocked, no form submission or automatic clicking, private reports.');
    console.log('This status check does not launch a browser or make a network request.');
    return { status: 'STATUS' };
  }
  if (action === 'setup') return runBrowserSetup(root, rl);
  assertProjectNotFrozen(root, 'browser automation');
  const config = loadConfig(root);
  let headed = action === 'open' || action === 'inspect';
  let exercise = false;
  let allowPrivateNetwork = false;
  let approvedFlag = false;
  let timeoutMs = 20000;
  let startRequested = false;
  let startScriptName = '';
  let port = 0;
  const allowOrigins = [];
  const words = [];
  for (let i = 1; i < args.length; i += 1) {
    const arg = args[i];
    if (arg === '--headed') headed = true;
    else if (arg === '--headless') headed = false;
    else if (arg === '--exercise') exercise = true;
    else if (arg === '--allow-private-network') allowPrivateNetwork = true;
    else if (arg === '--yes') approvedFlag = true;
    else if (arg === '--allow-origin') { const value = args[++i]; if (!value) throw new Error('--allow-origin requires an origin URL.'); allowOrigins.push(value); }
    else if (arg === '--timeout') { const value = args[++i]; timeoutMs = Number(value); if (!value || !Number.isFinite(timeoutMs)) throw new Error('--timeout needs milliseconds between 1000 and 60000.'); }
    else if (arg === '--start') { startRequested = true; if (['dev', 'preview', 'start', 'serve'].includes(args[i + 1])) startScriptName = args[++i]; }
    else if (arg === '--port') { const value = args[++i]; port = Number(value); if (!value || !Number.isInteger(port) || port < 1024 || port > 65535) throw new Error('--port must be an integer between 1024 and 65535.'); }
    else if (arg === '--help' || arg === '-h') {
      console.log('Usage: forge browser test [URL] [--start [dev|preview|start|serve]] [--port 5173] [--headed] [--allow-origin https://api.example.com] [--allow-private-network] [--exercise] [--timeout 20000] [--yes]');
      console.log('Without URL, Forge can offer a reviewed, recognized local framework script. Server startup is consent-gated and the server process tree is stopped afterward.');
      console.log('Use `forge browser setup` to install optional playwright-core after explicit consent. --exercise only sends a recognized game-start click and basic movement keys.');
      return;
    } else if (arg.startsWith('-')) throw new Error(`Unsupported browser option: ${arg}`);
    else words.push(arg);
  }
  let urlText = words[0] || extractHttpUrl(task) || process.env.FORGE_BROWSER_URL || '';
  let startInspection = null;
  if (!urlText && (startRequested || autoRouted)) {
    if (config.privacy.mode === 'local-only') {
      if (startRequested) throw new Error('Automatic dev-server startup runs repository code and is blocked in privacy.mode=local-only. Start the server manually, then test its loopback URL.');
    } else {
      startInspection = inspectLocalDevServer(root, startScriptName);
      if (startInspection.available) {
        port = port || startInspection.defaultPort;
        urlText = `http://127.0.0.1:${port}/`;
        console.log(`Forge detected a recognized ${startInspection.framework} script: npm run ${safeTerminalText(startInspection.scriptName)}.`);
      } else if (startRequested) {
        throw new Error(`${startInspection.reason} Forge did not execute a script. Run the site yourself and pass its local URL.`);
      } else {
        console.log(`Forge could not safely infer a local dev-server command: ${startInspection.reason}`);
      }
    }
  }
  if (!urlText && canPrompt()) urlText = (await rl.question('Which running website/app URL should Forge test? (example http://127.0.0.1:5173): ')).trim();
  if (!urlText) throw new Error('Forge routed this task to Browser QA, but no URL was supplied and no safe framework script could be selected. Pass `forge browser test URL`, set FORGE_BROWSER_URL, or add a standard supported framework script. Forge will not guess an external target.');
  const target = validateBrowserUrl(urlText);
  if (autoRouted && isGameTask(task) && /\b(?:play|gameplay|movement|controls|exercise)\b/i.test(task) && isLoopbackBrowserHost(target.hostname)) exercise = true;
  if (config.privacy.mode === 'local-only' && !isLoopbackBrowserHost(target.hostname)) {
    throw new Error('privacy.mode=local-only permits Browser QA only for loopback development URLs (localhost/127.0.0.1/::1). External browsing is blocked.');
  }
  const browserEngineStatus = browserStatus(root);
  if (!browserEngineStatus.playwrightAvailable) {
    console.log(`Playwright unavailable: ${browserEngineStatus.setupInstructions}`);
    throw new Error('No browser audit was run because the optional Playwright dependency is not installed.');
  }
  console.log('Forge Browser QA consent checkpoint');
  console.log(`Target: ${safeTerminalText(safeUrlLabel(target.href))}`);
  console.log(`Allowed origins: ${[target.origin, ...allowOrigins].map((origin) => safeTerminalText(origin)).join(', ')}`);
  console.log(`Mode: ${headed ? 'headed (visible browser)' : 'headless'}${exercise ? '; game exercise enabled' : '; passive audit'}`);
  console.log('Data: the target website receives a normal HTTP visit. Its JavaScript runs in an isolated browser context. Only target origin and explicit --allow-origin origins are allowed; private/LAN addresses are blocked unless explicitly approved. Third-party resources are blocked by default.');
  console.log('Privacy: Forge does not reuse your ordinary browser, login cookies, storage state or profile. Browser DOM contents, screenshots, logs and cookies are not sent to the coding model. Private screenshots/report are saved under .forge/browser-runs/.');
  console.log('Safety: no forms are submitted; no generic controls are clicked. With --exercise, only a recognized game-start button and basic movement keys are attempted. Browser execution is not an OS sandbox.');
  if (startInspection) {
    console.log(`Local app startup: npm run ${safeTerminalText(startInspection.scriptName)} (${safeTerminalText(startInspection.framework)}), bound via host/port flags to 127.0.0.1:${port}.`);
    console.log('The repository script is untrusted code and is not OS-sandboxed. Known shell chains and pre/post lifecycle hooks are rejected; the process will be stopped after the audit.');
  }
  if (allowPrivateNetwork) console.log('WARNING: --allow-private-network permits access to private/LAN destinations; use it only for a target you control.');
  if (allowOrigins.length) console.log('Additional origins are allowed by your explicit flags; review them before continuing.');
  if (!approvedFlag && !await askYesNo(rl, 'Start the isolated browser test with these network and privacy settings?')) {
    writeAudit(root, { action: 'browser_test_cancelled', targetOrigin: target.origin, targetHash: sha256(target.href), autoRouted });
    console.log('Cancelled. No browser was launched and no target request was sent.');
    return { status: 'CANCELLED' };
  }
  let localServer = null;
  let result;
  try {
    if (startInspection) {
      localServer = await startLocalDevServer(root, startInspection, { port: port || startInspection.defaultPort });
      writeAudit(root, { action: 'browser_dev_server_started', framework: localServer.framework, scriptName: localServer.scriptName, port: localServer.port, pid: localServer.pid });
      console.log(`Local dev server ready at ${localServer.url}; Forge will stop it after the browser test.`);
    }
    result = await runBrowserAudit({ root, rawUrl: target.href, allowOrigins, allowPrivateNetwork, headed, exercise, timeoutMs });
  } catch (error) {
    writeAudit(root, { action: 'browser_test_failed', targetOrigin: target.origin, targetHash: sha256(target.href), autoRouted, reasonHash: sha256(error?.message || 'unknown'), devServerAttempted: Boolean(startInspection) });
    throw error;
  } finally {
    if (localServer) {
      await localServer.stop();
      writeAudit(root, { action: 'browser_dev_server_stopped', framework: localServer.framework, scriptName: localServer.scriptName, port: localServer.port, pid: localServer.pid });
      console.log('Forge stopped the local dev-server process tree.');
    }
  }
  writeAudit(root, {
    action: 'browser_test_completed', targetOrigin: target.origin, targetHash: sha256(target.href), autoRouted,
    status: result.status, report: path.relative(root, result.reportPath), reportHash: result.digest,
    javascriptErrors: result.report.issues.pageErrors.length, consoleErrors: result.report.issues.consoleErrors.length,
    httpErrors: result.report.issues.httpErrors.length, failedRequests: result.report.issues.failedRequests.length,
    blockedRequests: result.report.issues.blockedRequests.length, screenshotCount: result.screenshots.length,
  });
  printBrowserSummary(result, root);
  if (result.status === 'FAIL') {
    const error = new Error(`Browser smoke test FAILED; evidence is saved at ${path.relative(root, result.reportPath)}. Review the issues before claiming completion.`);
    error.browserResult = { status: result.status, reportPath: result.reportPath, targetOrigin: target.origin };
    throw error;
  }
  return { ...result, targetOrigin: target.origin };
}

async function runBrowserTaskFromUserGoal(root, task, rl, executionPlan) {
  const args = ['test'];
  const url = extractHttpUrl(task) || process.env.FORGE_BROWSER_URL;
  if (url) args.push(url);
  else args.push('--start');
  if (executionPlan.game && /\b(?:play|gameplay|movement|controls|exercise)\b/i.test(task) && url && isLoopbackBrowserHost(validateBrowserUrl(url).hostname)) args.push('--exercise');
  return runBrowserCommand(root, args, rl, { task, autoRouted: true });
}

function showSkills(root, args) {
  const subcommand = args[0] || 'list';
  const skills = formatSkillList(root);
  if (subcommand === 'list' || subcommand === '--list') {
    console.log('Forge skills (auto-selected by task intent; guidance never grants permissions):');
    for (const skill of skills) console.log(`${skill.id.padEnd(26)} ${skill.source.padEnd(8)} ${safeTerminalText(skill.description)}`);
    console.log('Project/user skills are treated as untrusted data and may trigger an acknowledgment gate before being sent to a model.');
    return;
  }
  if (subcommand === 'show') {
    const wanted = args[1];
    if (!wanted) throw new Error('Usage: forge skills show NAME');
    const skill = skills.find((entry) => entry.id === wanted);
    if (!skill) throw new Error(`Unknown skill: ${wanted}. Use forge skills list.`);
    const loaded = loadSelectedSkills(root, [wanted]).find((entry) => entry.id === wanted);
    if (!loaded) throw new Error(`Skill ${wanted} is unavailable or exceeds the configured limit.`);
    console.log(`Skill: ${safeTerminalText(loaded.name)} (${loaded.id}; ${loaded.source})`);
    console.log(safeTerminalText(loaded.content));
    return;
  }
  throw new Error('Usage: forge skills [list|show NAME]');
}

function runSearch(root, query, config) {
  const index = buildRepoIndex(root, config, query);
  const terms = query.toLowerCase().split(/\s+/).filter(Boolean);
  const matches = [];
  for (const file of index.files) {
    const lines = file.content.split(/\r?\n/);
    for (let i = 0; i < lines.length; i += 1) {
      if (terms.some((term) => lines[i].toLowerCase().includes(term))) matches.push(`${file.path}:${i + 1}: ${truncate(lines[i].trim(), 240)}`);
      if (matches.length >= 80) break;
    }
    if (matches.length >= 80) break;
  }
  console.log(safeTerminalText(matches.length ? matches.join('\n') : 'No matches.'));
}

function showAudit(root, tail) {
  const events = readAudit(root);
  const selected = events.slice(-tail);
  if (!selected.length) { console.log('No audit records yet.'); return; }
  for (const event of selected) {
    const { timestamp, action, ...rest } = event;
    console.log(safeTerminalText(`${timestamp} ${action} ${Object.keys(rest).length ? JSON.stringify(rest) : ''}`));
  }
}

async function runSandboxCommand(root, args, rl) {
  const action = args[0] || 'status';
  if (action === 'status') {
    if (args.length > 1) throw new Error('Usage: forge sandbox status');
    const status = inspectSandbox({ cwd: root });
    console.log(`Sandbox support: ${status.supported ? 'available on this platform' : 'not available'}`);
    if (status.runtime) console.log(`Runtime: ${status.runtime}`);
    if (status.image) console.log(`Image: ${status.image}`);
    if (status.imageId) console.log(`Immutable local image ID: ${status.imageId}`);
    console.log(`Ready: ${status.available ? 'YES' : 'NO'}`);
    if (status.candidates) {
      for (const item of status.candidates) console.log(`  ${item.runtime}: ${item.installed ? 'installed' : 'not found'}; engine=${item.engineReady ? 'ready' : 'unavailable'}; image=${item.imageAvailable ? 'present' : 'missing'}`);
    }
    console.log(status.reason);
    console.log('Sandbox limitations: container/kernel vulnerabilities remain possible; network is disabled; common secret files and symlinks are omitted; container writes are discarded with the staging copy.');
    return;
  }
  if (action !== 'run') throw new Error('Usage: forge sandbox status | forge sandbox run -- COMMAND [ARG ...]');
  let commandParts = args.slice(1);
  if (commandParts[0] === '--') commandParts = commandParts.slice(1);
  if (!commandParts.length) throw new Error('Usage: forge sandbox run -- COMMAND [ARG ...]');
  const commandText = commandParts.join(' ');
  const tokens = parseCommand(commandText);
  const status = inspectSandbox({ cwd: root });
  if (!status.available) throw new Error(`Sandbox is unavailable, so the command was not executed. ${status.reason} Install/start Docker or Podman and pre-load the appropriate image; Forge will not pull images automatically.`);
  console.log(`Sandbox command: ${safeTerminalText(tokens.join(' '))}`);
  console.log(`Runtime/image: ${status.runtime} / ${status.image}`);
  console.log(`Immutable local image ID: ${status.imageId}`);
  console.log('Boundary: disposable sanitized workspace copy; network disabled; read-only container root; workspace changes discarded; API credentials are not passed into the container. This reduces risk but is not a perfect VM or protection from container/kernel vulnerabilities.');
  if (!await askExactApproval(rl, 'Run this command inside the sandboxed disposable copy? It will not modify the original project, but repository code will execute inside the container.', 'RUN SANDBOXED COMMAND')) {
    console.log('Sandbox command cancelled.');
    return;
  }
  const config = loadConfig(root);
  const started = Date.now();
  const result = await runSandboxedCommand(commandText, {
    cwd: root,
    timeoutMs: config.limits.commandTimeoutMs,
    maxOutputBytes: config.limits.maxOutputBytes,
  });
  const safeStdout = safeTerminalText(redactSecrets(result.stdout));
  const safeStderr = safeTerminalText(redactSecrets(result.stderr));
  if (safeStdout.trim()) console.log(`\nstdout:\n${truncate(safeStdout, 8000)}`);
  if (safeStderr.trim()) console.error(`\nstderr:\n${truncate(safeStderr, 6000)}`);
  console.log(`Exit code: ${result.code}${result.timedOut ? ' (timeout)' : ''}${result.overflow ? ' (output limit)' : ''}`);
  console.log(`Workspace copied: ${result.sandbox.files} files, ${Math.round(result.sandbox.bytes / 1024)} KiB; skipped ${result.sandbox.skippedSecrets} secret-like entries and ${result.sandbox.skippedSymlinks} symlinks.`);
  console.log(`Container image ID: ${result.sandbox.imageId}`);
  writeAudit(root, {
    action: 'sandbox_command', command: commandText, runtime: result.sandbox.runtime, image: result.sandbox.image,
    exitCode: result.code, success: result.success, timedOut: result.timedOut, overflow: result.overflow,
    durationMs: Date.now() - started, imageId: result.sandbox.imageId, stagedFiles: result.sandbox.files, stagedBytes: result.sandbox.bytes,
    skippedSecrets: result.sandbox.skippedSecrets, skippedSymlinks: result.sandbox.skippedSymlinks,
  });
  if (result.success) console.log('Verified: sandbox command exited 0. This verifies only that command, not the whole coding task.');
  else console.log('Not verified: command failed, timed out, exceeded output limits, or was interrupted.');
}

async function runCommandManually(root, rl, commandText) {
  assertProjectNotFrozen(root, 'manual commands');
  const tokens = parseCommand(commandText);
  console.log(safeTerminalText(`\nRequested command: ${tokens.join(' ')}`));
  console.log('Forge does not use a shell to expand commands. Arguments are passed directly to the executable.');
  console.log('Child-process environment is restricted by default; provider credentials and runtime-injection variables are excluded. Repository scripts are still unsandboxed and may access files/network available to your OS account.');
  if (process.env.FORGE_COMMAND_ENV_ALLOWLIST?.trim()) console.log('Warning: FORGE_COMMAND_ENV_ALLOWLIST explicitly exposes selected ordinary environment variables to this command.');
  if (commandRisk(commandText)) {
    if (!await askExactApproval(rl, 'HIGH-RISK command: it may delete/modify data, use the network, install packages, or change remote Git state.', 'RUN COMMAND')) {
      console.log('Command cancelled.'); return;
    }
  } else if (!await askYesNo(rl, 'Run this exact command?')) {
    console.log('Command cancelled.'); return;
  }
  const config = loadConfig(root);
  const result = await runProcess(commandText, { cwd: root, timeoutMs: config.limits.commandTimeoutMs, maxOutputBytes: config.limits.maxOutputBytes });
  console.log(safeTerminalText(redactSecrets(result.stdout)));
  if (result.stderr) console.error(safeTerminalText(redactSecrets(result.stderr)));
  console.log(`Exit code: ${result.code}`);
  writeAudit(root, { action: 'manual_command', command: commandText, exitCode: result.code, success: result.success, timedOut: result.timedOut });
}

async function runLayerCommand(root, args, rl) {
  const subcommand = args[0] || 'preview';
  let tool = 'both';
  let target = root;
  let force = false;
  for (let i = 1; i < args.length; i += 1) {
    if (args[i] === '--tool') {
      tool = args[i + 1];
      i += 1;
      if (!['both', 'claude', 'opencode'].includes(tool)) throw new Error('--tool must be both, claude, or opencode.');
    } else if (args[i] === '--target') {
      const rawTarget = args[i + 1];
      i += 1;
      if (!rawTarget || rawTarget.startsWith('--')) throw new Error('--target needs a directory path.');
      target = path.resolve(root, rawTarget);
    } else if (args[i] === '--force') force = true;
    else throw new Error(`Unknown layer option: ${args[i]}`);
  }
  if (subcommand === 'preview') {
    const entries = previewPortableLayer({ tool });
    console.log(`Forge portable layer preview (${tool}): ${entries.length} files; target=${target}`);
    for (const entry of entries) console.log(`  ${entry.destination} (${entry.bytes} bytes)`);
    console.log('Preview only; no project files were written.');
    return;
  }
  if (subcommand === 'install') {
    assertProjectNotFrozen(target, 'portable-layer installation');
    const summary = installPortableLayer({ target, tool, force });
    console.log(`Forge layer install completed in ${summary.target}`);
    console.log(`Created: ${summary.created.length}; updated: ${summary.updated.length}; unchanged: ${summary.unchanged.length}; preserved existing files: ${summary.preserved.length}`);
    if (summary.preserved.length) console.log(`Preserved files (inspect/merge manually): ${summary.preserved.join(', ')}`);
    if (summary.warning) console.log(`Warning: ${summary.warning}`);
    console.log(`Manifest: ${summary.manifest}. Installer writes only within the target project; global configuration is untouched.`);
    writeAudit(target, { action: 'portable_layer_installed', tool, created: summary.created.length, updated: summary.updated.length, preserved: summary.preserved.length });
    return;
  }
  if (subcommand === 'uninstall') {
    assertProjectNotFrozen(target, 'portable-layer uninstall');
    const expected = 'UNINSTALL FORGE LAYER';
    if (!await askExactApproval(rl, 'This removes only unchanged files tracked as Forge-managed. Files edited since installation and all user-owned files will be preserved.', expected)) {
      console.log('Uninstall cancelled.');
      return;
    }
    const summary = uninstallPortableLayer({ target });
    console.log(`Removed ${summary.removed.length} unchanged managed files from ${summary.target}.`);
    if (summary.preserved.length) console.log(`Preserved modified or unsafe files: ${summary.preserved.join(', ')}`);
    writeAudit(target, { action: 'portable_layer_uninstalled', removed: summary.removed.length, preserved: summary.preserved.length });
    return;
  }
  throw new Error('Usage: forge layer preview|install|uninstall [--tool both|claude|opencode] [--target DIR] [--force]');
}

async function commandDispatch(args, rl) {
  const root = findRepoRoot();
  const [command, ...rest] = args;
  if (command === '--version' || command === '-v') { console.log(VERSION); return; }
  if (command === '--help' || command === '-h' || command === 'help') { console.log(HELP); return; }
  // Project status/rebind are the only operational commands allowed while a copied/moved
  // project identity points elsewhere. All other operations fail closed at this boundary.
  if (!(command === 'project' && ['status', 'rebind'].includes(rest[0]))) assertProjectBinding(root);
  if (!command || command === '--interactive') return interactiveLoop(root, rl);
  if (command === 'init') return initProject(root);
  if (command === 'sandbox') return runSandboxCommand(root, rest, rl);
  if (command === 'project') {
    const action = rest[0] || 'status';
    if (action === 'status') {
      const identity = loadProjectIdentity(root);
      console.log(`Active filesystem root: ${safeTerminalText(root)}`);
      if (!identity) { console.log('Project identity: NOT INITIALIZED'); console.log('Run `forge init` to create a local identity before using shared context.'); return; }
      console.log(`Project: ${safeTerminalText(identity.name || path.basename(root))}`);
      console.log(`Project ID: ${identity.projectId}`);
      console.log(`Identity root: ${safeTerminalText(identity.rootPath)}`);
      console.log(`Binding: ${projectIdentityMatchesRoot(identity, root) ? 'VALID' : 'MISMATCH — writes and model runs are blocked'}`);
      console.log(`Binding epoch: ${Number(identity.bindingEpoch) || 1}`);
      const matches = projectIdentityMatchesRoot(identity, root);
      console.log(`Explicitly shared context items: ${matches ? listSharedContexts(root).length : 'not read while binding mismatches'}`);
      if (!matches) console.log('After verifying the intended project, run `forge project rebind` from this directory.');
      return;
    }
    if (action === 'rebind') {
      const identity = loadProjectIdentity(root);
      if (!identity) throw new Error('No project identity exists. Run `forge init` first.');
      if (projectIdentityMatchesRoot(identity, root)) { console.log('Project identity is already bound to this root; no change made.'); return; }
      const confirmed = await askExactApproval(rl,
        `This changes only the filesystem-root binding for project ID ${identity.projectId}. Use only if this is the intended moved/copied project. Other project data is not imported.`,
        'REBIND FORGE PROJECT');
      if (!confirmed) { console.log('Project rebind cancelled; no change made.'); return; }
      const result = rebindProjectIdentity(root);
      console.log(`Project identity rebound: ${result.identity.projectId} · ${result.identity.rootPath}`);
      console.log('Rebinding does not merge another project, conversation, memory, or credential.');
      return;
    }
    throw new Error('Usage: forge project status|rebind');
  }
  if (command === 'context') {
    const action = rest[0] || 'list';
    if (action === 'list') {
      const items = listSharedContexts(root);
      if (!items.length) { console.log('No explicitly imported cross-project context is active.'); return; }
      for (const item of items) {
        console.log(`${item.contextId} · from ${safeTerminalText(item.sourceProjectName)} (${item.sourceProjectId})`);
        console.log(`  file: ${safeTerminalText(item.sourceRelativePath)} · ${item.chars} chars · ${item.createdAt}${item.redactionApplied ? ' · secret-pattern redaction applied' : ''}`);
      }
      console.log('Only listed, integrity-checked imports are added to project memory. Remove an item to revoke it.');
      return;
    }
    if (action === 'import') {
      let sourceRoot = '';
      let sourceFile = '';
      for (let i = 1; i < rest.length; i += 1) {
        if (rest[i] === '--from') { sourceRoot = rest[++i] || ''; if (!sourceRoot) throw new Error('--from needs a source project directory.'); }
        else if (rest[i] === '--file') { sourceFile = rest[++i] || ''; if (!sourceFile) throw new Error('--file needs one project-relative file path.'); }
        else throw new Error(`Unknown context import option: ${rest[i]}`);
      }
      if (!sourceRoot || !sourceFile) throw new Error('Usage: forge context import --from SOURCE_PROJECT_DIR --file PROJECT_RELATIVE_PATH');
      const sourceAbsolute = path.resolve(root, sourceRoot);
      const targetIdentity = ensureProjectIdentity(root);
      console.log(`Target project: ${targetIdentity.name} (${targetIdentity.projectId})`);
      console.log(`Selected source project path: ${safeTerminalText(sourceAbsolute)}`);
      console.log(`Selected source file: ${safeTerminalText(sourceFile)}`);
      if (!await askExactApproval(rl,
        'Forge will copy only this one text file into the target project’s private .forge/shared-context store. The imported text may influence future model context, is treated as untrusted data, and can be removed with `forge context remove`. Sensitive paths, symlinks, .git and .forge are blocked.',
        'IMPORT SELECTED CONTEXT')) { console.log('Context import cancelled; no data was copied.'); return; }
      const result = importSelectedContext({ targetRoot: root, sourceRoot: sourceAbsolute, sourceRelativePath: sourceFile });
      console.log(`Imported context ID: ${result.contextId}`);
      console.log(`Source: ${result.sourceProjectName} (${result.sourceProjectId}) · ${result.sourceRelativePath} · ${result.chars} chars`);
      if (result.redactionApplied) console.log('Warning: common secret patterns were redacted. Review the imported file before sending context to a remote model.');
      console.log('No other source-project files, chats, credentials, or memories were imported.');
      return;
    }
    if (action === 'remove') {
      const contextId = rest[1];
      if (!contextId || rest.length !== 2) throw new Error('Usage: forge context remove CONTEXT_ID');
      const accepted = await askYesNo(rl, `Revoke imported context ${contextId}? It will no longer be loaded into model context.`);
      if (!accepted) { console.log('Context removal cancelled.'); return; }
      const result = removeSharedContext(root, contextId);
      console.log(`Removed imported context ${result.contextId} from the active project.`);
      return;
    }
    throw new Error('Usage: forge context list|import --from DIR --file PATH|remove ID');
  }
  if (command === 'sessions' || command === 'session') {
    const identity = ensureProjectIdentity(root);
    const action = rest[0] || 'list';
    if (action === 'list' || action === '--list') {
      if (rest.length > 1) throw new Error('Usage: forge sessions [list|show SESSION_ID]');
      return renderSessionList(root, identity);
    }
    if (action === 'show') {
      if (rest.length !== 2) throw new Error('Usage: forge sessions show SESSION_ID');
      return renderSessionDetails(root, identity, rest[1]);
    }
    if (action === 'delete') {
      if (rest.length !== 2) throw new Error('Usage: forge sessions delete SESSION_ID');
      const session = loadSession({ root, identity, sessionId: rest[1] });
      console.log(`Session: ${session.sessionId} · ${session.status}`);
      console.log('Deletion permanently removes the saved task and local session record. It does not undo project-file changes, erase audit events, or securely erase forensic copies from the disk.');
      if (!canPrompt()) throw new Error('Deleting a session requires an interactive terminal and exact confirmation. No data was deleted.');
      const confirmed = await askExactApproval(rl,
        'This deletes the selected session record from the active project only. No other project sessions are searched or modified.',
        `DELETE SESSION ${session.sessionId}`);
      if (!confirmed) { console.log('Session deletion cancelled; no data was deleted.'); return; }
      const removed = deleteSession({ root, identity, sessionId: session.sessionId });
      writeAudit(root, { action: 'session_deleted', sessionId: removed.sessionId, taskHash: removed.taskHash });
      console.log(`Deleted session ${removed.sessionId} from the active project. Project files and the audit trail were not changed.`);
      return;
    }
    throw new Error('Usage: forge sessions [list|show SESSION_ID|delete SESSION_ID]');
  }
  if (command === 'resume') return runResumeCommand(root, rest, rl);
  if (command === 'doctor') return doctor(root);
  if (command === 'freeze') {
    const result = freezeProject(root, rest.join(' ') || 'Manual emergency stop');
    console.log(result.created ? 'FORGE HALT activated. New coding runs, remote docs, research bridge calls, manual commands, and undo actions are blocked.' : `FORGE HALT is already active: ${safeTerminalText(result.state.reason || 'inspect .forge/HALT')}`);
    console.log('Read-only inspection (help, doctor, index, search, config show, agents, audit, cost) remains available. Writes and remote/command actions stay blocked.');
    return;
  }
  if (command === 'unfreeze') {
    const state = getFreezeState(root);
    if (!state.frozen) { console.log('Forge is not frozen.'); return; }
    console.log(`Emergency stop reason: ${safeTerminalText(state.reason || 'unreadable HALT marker')}`);
    if (!canPrompt()) throw new Error('Unfreeze requires an interactive terminal and exact typed confirmation. The HALT marker remains active.');
    const confirmed = await askExactApproval(rl, 'Only unfreeze after reviewing the incident and confirming it is safe to resume.', 'UNFREEZE FORGE');
    if (!confirmed) { console.log('Cancelled; Forge remains frozen.'); return; }
    unfreezeProject(root);
    console.log('Forge HALT removed. Run forge doctor and review the audit log before continuing.');
    return;
  }
  if (command === 'config') {
    const config = loadConfig(root);
    if (!rest.length || rest[0] === 'show') { console.log(safeTerminalText(JSON.stringify(config, null, 2))); return; }
    if (rest[0] !== 'set' || rest.length < 3) throw new Error('Usage: forge config set KEY VALUE');
    assertProjectNotFrozen(root, 'configuration writes');
    setConfigValue(config, rest[1], rest.slice(2).join(' '));
    saveConfig(root, config);
    writeAudit(root, { action: 'config_updated', key: rest[1] });
    console.log(`Updated ${rest[1]} in ${CONFIG_NAME}`);
    return;
  }
  if (command === 'agents') {
    for (const agent of AGENTS) console.log(`${agent.name.padEnd(19)} ${agent.status.padEnd(12)} ${agent.purpose}\n${' '.repeat(21)}tools: ${agent.tools.join(', ') || '(none)'}`);
    return;
  }
  if (command === 'index') {
    const config = loadConfig(root);
    const index = buildRepoIndex(root, config);
    console.log(safeTerminalText(makeRepositorySummary(index, 26000)));
    console.log(`\nIndexed ${index.totalFiles} files (${(index.indexedBytes / 1048576).toFixed(2)} MiB text); skipped ${index.excluded}. No provider request was made.`);
    writeAudit(root, { action: 'repo_indexed', files: index.totalFiles, skipped: index.excluded });
    return;
  }
  if (command === 'graph') return buildGraphReport(root);
  if (command === 'browser') return runBrowserCommand(root, rest, rl);
  if (command === 'layer') return runLayerCommand(root, rest, rl);
  if (command === 'skills') return showSkills(root, rest);
  if (command === 'docs') return runContext7Docs(root, rest, rl);
  if (command === 'reach') return runAgentReach(root, rest, rl);
  if (command === 'search') {
    if (!rest.length) throw new Error('Usage: forge search WORDS');
    return runSearch(root, rest.join(' '), loadConfig(root));
  }
  if (command === 'audit') {
    const tailIndex = rest.indexOf('--tail');
    const tail = tailIndex >= 0 ? Math.max(1, Math.min(500, Number(rest[tailIndex + 1]) || 30)) : 30;
    return showAudit(root, tail);
  }
  if (command === 'cost') {
    const cost = summarizeCost(readAudit(root));
    console.log(`Model calls: ${cost.calls}`);
    console.log(`Calls reporting token counts: ${cost.knownTokenCalls}`);
    console.log(`Input tokens: ${cost.knownTokenCalls ? cost.tokensIn : 'unknown'}`);
    console.log(`Output tokens: ${cost.knownTokenCalls ? cost.tokensOut : 'unknown'}`);
    console.log(`Calls reporting USD cost: ${cost.knownCostCalls}`);
    console.log(`Reported USD total: ${cost.knownCostCalls ? `$${cost.costUsd.toFixed(6)}` : 'unknown (OpenCode may omit usage/cost events)'}`);
    return;
  }
  if (command === 'undo') {
    assertProjectNotFrozen(root, 'undo/restore actions');
    const checkpoints = path.join(root, '.forge', 'checkpoints');
    if (!fs.existsSync(checkpoints)) throw new Error('No Forge checkpoints.');
    const available = listCheckpoints(root).filter((item) => !item.undone);
    if (!available.length) throw new Error('No unused Forge checkpoint found.');
    const snapshot = available[0];
    showList(`Latest checkpoint ${snapshot.id}`, snapshot.files.map((file) => `${file.existed ? 'restore' : 'remove newly created'} ${file.path}`));
    if (!await askYesNo(rl, 'Restore these files to the exact pre-patch state?')) return console.log('Undo cancelled.');
    const restored = restoreLatestCheckpoint(root);
    console.log(`Restored checkpoint ${restored.id}.`);
    return;
  }
  if (command === 'command') {
    if (!rest.length) throw new Error('Usage: forge command PROGRAM [ARG ...]');
    return runCommandManually(root, rl, rest.join(' '));
  }
  if (command === 'run') {
    let dryRun = false;
    let model;
    let noSubagents = false;
    let maxSubagents = 2;
    let sandboxTests = false;
    const taskParts = [];
    for (let i = 0; i < rest.length; i += 1) {
      if (rest[i] === '--dry-run') dryRun = true;
      else if (rest[i] === '--sandbox-tests') sandboxTests = true;
      else if (rest[i] === '--no-subagents') noSubagents = true;
      else if (rest[i] === '--max-subagents') {
        const raw = rest[i + 1];
        if (raw === undefined || !/^\d+$/.test(raw) || Number(raw) > 3) throw new Error('--max-subagents must be an integer from 0 to 3.');
        maxSubagents = Number(raw);
        i += 1;
      }
      else if (rest[i] === '--model') {
        model = rest[i + 1];
        i += 1;
        if (!model) throw new Error('--model needs a model id.');
      } else taskParts.push(rest[i]);
    }
    const task = taskParts.join(' ').trim();
    if (!task) throw new Error('Usage: forge run [--dry-run] [--sandbox-tests] [--no-subagents] [--max-subagents 0..3] "Describe the task"');
    return performRun(root, task, { dryRun, model, noSubagents, maxSubagents, sandboxTests }, rl);
  }
  // Bare `forge "task"` is shorthand for `forge run "task"`.
  return performRun(root, [command, ...rest].join(' '), {}, rl);
}

async function interactiveLoop(root, rl) {
  console.log(safeTerminalText(`Forge ${VERSION} · ${root}`));
  console.log('Enter a task, or use /help, /index, /doctor, /undo, /quit. Use `forge sessions list` to inspect saved task state. Browser QA tasks auto-route to Playwright when configured.');
  while (true) {
    let value;
    try { value = await rl.question('forge> '); } catch { return; }
    const task = value.trim();
    if (!task) continue;
    if (['/quit', '/exit', '/q'].includes(task)) return;
    try {
      if (task === '/help') { console.log(HELP); continue; }
      if (task.startsWith('/freeze')) { await commandDispatch(['freeze', ...task.slice('/freeze'.length).trim().split(/\s+/).filter(Boolean)], rl); continue; }
      if (task === '/unfreeze') { await commandDispatch(['unfreeze'], rl); continue; }
      if (task === '/index') { await commandDispatch(['index'], rl); continue; }
      if (task === '/doctor') { doctor(root); continue; }
      if (task === '/undo') { await commandDispatch(['undo'], rl); continue; }
      await performRun(root, task, {}, rl);
    } catch (error) {
      console.error(safeTerminalText(`Task failed: ${redactSecrets(error?.message ?? String(error))}`));
      console.error('Forge is still running. Correct the configuration/problem or enter another task; no success is implied.');
    }
  }
}

export async function main(args = process.argv.slice(2)) {
  const rl = createTerminal();
  try { await commandDispatch(args, rl); }
  finally { rl.close(); }
}
