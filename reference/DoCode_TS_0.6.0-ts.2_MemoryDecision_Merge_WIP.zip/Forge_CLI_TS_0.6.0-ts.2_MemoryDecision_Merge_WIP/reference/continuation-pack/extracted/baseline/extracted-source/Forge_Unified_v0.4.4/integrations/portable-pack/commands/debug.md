# Root-cause debugging

Reproduce the symptom or identify why reproduction is blocked. Trace the smallest failing path, list hypotheses, rank them by evidence, and test one hypothesis at a time. Prefer a minimal regression test before a fix. Do not mask failures, change unrelated files, repeat the same failed attempt, or state root cause as fact until evidence distinguishes it from alternatives.
