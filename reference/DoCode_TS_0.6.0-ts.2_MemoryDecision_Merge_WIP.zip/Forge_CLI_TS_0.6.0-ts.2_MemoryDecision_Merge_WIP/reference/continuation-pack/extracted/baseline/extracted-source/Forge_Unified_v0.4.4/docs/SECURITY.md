# Forge security and privacy model

## Threat model

Forge is designed to reduce accidental harm from model-produced patches and commands, and to make side effects visible. It is not yet a hardened security boundary against a malicious local process, hostile OS user, compromised Node runtime, malicious package scripts, prompt injection that persuades a user, or an upstream/provider compromise.

### Assets

- Repository source, project secrets, uncommitted user changes.
- Provider credentials stored by OpenCode or explicitly allowlisted for its subprocess.
- Local checkpoints and audit log.
- Git credentials and remote repository state.

### Adversaries / failure classes

- Prompt injection in README, issue text, source comments, test output, or `FORGE.md`.
- Model proposes path traversal, a symlink target, a secret-file edit, a destructive command, or unsafe CI workflow change.
- User accidentally approves a dangerous test or manual command.
- Local race condition modifies a target between validation and write.
- Provider/model returns malformed, adversarial, or false structured data.
- A test/build script executes unsafe project code.

## Controls implemented in the MVP

| Risk | Control | Residual risk |
|---|---|---|
| Remote code disclosure | Explicit consent before project context leaves the machine; non-TTY remote requests fail closed | Consent is broad, not path-by-path; a user can approve a private repo by mistake. Provider-side retention is not controlled by Forge. |
| Model executes arbitrary tools | OpenCode subprocess in empty temp dir; tool permissions denied in temp config and inline config; `--pure`; project config cannot select an arbitrary executable | This design has not been tested against a live OpenCode version. A future OpenCode schema change could weaken the policy. It is not an OS sandbox; Windows launch compatibility is unverified. |
| Secret file accidentally included | Excludes common secret paths and redacts common token formats at context, audit, CLI-error, and command-output boundaries | Pattern-based detection misses unknown formats, binary encodings, unusual files, and secret values in ordinary source files. |
| Path traversal | Reject absolute, `..`, `.`, empty segments; block `.git`, `.forge`, and common secret paths | Does not fully defend against concurrent privileged filesystem races. |
| Symlink redirection | Checks existing path segments with `lstat`; rejects symlinks before reading/writing | TOCTOU remains possible if another process races Forge. Run in an isolated workspace for hostile inputs. |
| Patch overwrites new user edits | File content hashes rechecked after approval and before apply | Cross-process race after the check is still possible. Multi-file write rollback is best-effort. |
| Patch deletion/rename | Rejected by patch parser | User must handle file deletion/renames manually for now. |
| Unsafe tests/commands | No shell expansion; command allowlist for model-suggested tests; command length, time and output bounds; user approval | Allowed commands execute repository scripts and can access the current account's files/network. Not sandboxed. |
| CI/CD changes | Extra typed `APPROVE` checkpoint before general patch approval | The diff can be misunderstood; typed approval is a checkpoint, not a safety proof. |
| Dangerous manual shell action | Heuristic high-risk detector and `RUN COMMAND` typed confirmation | Detector is incomplete; explicit commands still rely on user judgment. |
| Rollback destroys user edits or trusts forged metadata | Undo requires a valid HMAC signed by a user-local key and bound to the canonical workspace path; validates ID/schema/path/hash/mode and checks each post-patch hash before restoring | Key loss or workspace relocation can invalidate checkpoints; local user compromise and TOCTOU races remain possible; multi-file I/O failure can require manual recovery. |
| Provider usage/cost confusion | Reports tokens/cost only when events report them; otherwise labels unknown | Usage may be unavailable or model/provider accounting may differ. |
| Audit-log memory abuse | `readAudit` is limited to the last 10 MiB when the log grows larger | Older records may not appear in local reads; disk growth is not rotated automatically yet. |
| Telemetry | Forge has no telemetry feature enabled or implemented | OpenCode/provider may log requests under their own terms. |

## Consent and data flow

For remote inference, Forge tells the user that the task, repository map, selected source excerpts, and potentially test output are sent to the configured model through OpenCode or OpenRouter. The user must approve. Test failure output is sent only after a separate prompt when asking for a repair. No provider request is made by `forge init`, `forge doctor`, `forge index`, `forge search`, `forge config show`, or local audit inspection.

`privacy.mode = local-only` accepts local model ID prefixes (`ollama/`, `lmstudio/`, `llama.cpp/`, `local/`). This is only a configuration guard. It does not inspect endpoints, detect remote relay, block networking at OS level, or prove that OpenCode provider settings map to localhost. Validate the local provider configuration separately.

## OpenCode subprocess design

The adapter writes a temporary configuration that disables the model's tools and sharing. It sets `OPENCODE_CONFIG` and `OPENCODE_CONFIG_CONTENT`, chooses the text-only `forge-model` agent, uses `--pure`, and runs with the temp directory as current project. Source is sent as prompt text, not exposed as readable filesystem through a tool interface. Since this environment lacks OpenCode, a real-version compatibility test is still a release blocker for a claim of verified isolation.

The child receives a minimal environment by default: executable search path, home/config directories, temp paths, locale, and proxy/certificate settings. Arbitrary cloud credentials and provider API keys are not inherited automatically. If an OpenCode provider requires a key from the shell, the operator must explicitly name it in `FORGE_OPENCODE_ENV_ALLOWLIST` (for example, `OPENAI_API_KEY`). `OPENROUTER_API_KEY`, `FORGE_*`, `OPENCODE_*`, and common runtime-injection variables cannot be passed through this allowlist. Existing OpenCode credentials stored in its normal user configuration remain available through the home directory. Forge cannot guarantee that a provider never logs submitted prompts. The safe operational rule is to use non-sensitive code unless the configured provider has been approved for that data.

## Operational guidance

- Test in a disposable clone or temporary branch.
- Never commit `.forge/` (checkpoints may contain pre-edit content). A project-local `.forge/.gitignore` is created by `forge init`.
- Do not run Forge on a production server or sensitive repo until live provider isolation, Windows approvals, and command allowlisting are audited.
- Use a disposable container/VM for untrusted repos and builds. Forge currently does not enforce one.
- Review the exact diff and every command prompt. A model review is not an independent security audit.
- Checkpoint undo is a convenience mechanism, not a replacement for Git backups. Checkpoints are HMAC-signed with `~/.forge-cli/checkpoint-key` (or the platform home equivalent); it is user state, not repository state. `FORGE_HOME` can point at an alternate user-state directory. Do not commit or share the signing key. Moving a workspace path or losing the key can make old checkpoint files unverifiable. Checkpoints from pre-HMAC versions are unsigned and are intentionally rejected; use Git/backups rather than automatically trusting old metadata.


## Current defense-in-depth controls (experimental; not a security certification)

- Forge's OpenCode model role has no workspace/file/shell/web tools enabled; OpenCode is run from a temporary directory with `--pure` and a deny-all tool policy. This is a configuration boundary inside the provider process, **not** an OS sandbox.
- Repository source, `FORGE.md`, planner output, model output, test output, and third-party content are treated as untrusted data in every role prompt. The repository scanner reports only paths and indicator categories. It is heuristic: obfuscation, multilingual payloads, novel wording, and cross-file intent can evade it. The hard security boundary remains the deterministic tool/patch/approval paths.
- A scan finding requires the exact phrase `APPROVE UNTRUSTED CONTEXT` before the context is sent to the model. The approval allows the operator to proceed; it does not make repository instructions trusted or grant additional tools.
- Patch review heuristically flags environment-variable access, network I/O, credential files, subprocess use, dynamic evaluation, TLS verification changes and CI/deployment edits. A probable secret-to-network pattern requires `APPROVE SECURITY RISKS` in addition to the normal patch approval. Static patterns are not taint analysis and are not complete.
- Test and manual-command child processes inherit a small OS/runtime environment instead of all of `process.env`. Ordinary custom variables may be exposed with `FORGE_COMMAND_ENV_ALLOWLIST=NAME1,NAME2`; do not allowlist secrets. Common provider credentials and runtime-injection variables remain blocked. This protects inherited environment variables; it does not stop a script from reading accessible files or contacting the network.
- High-risk command patterns require `RUN COMMAND`. Parsing rejects shell operators/substitutions and uses `spawn(..., shell:false)` in the normal path. This is not a substitute for OS sandboxing: a permitted test script can perform destructive actions with the current user's privileges.
- Context leaves the device only after the configured provider consent checkpoint (except `local-only`, whose prefix check is **not** a network firewall). For remote providers, data transfer includes task text, repository map, selected excerpts, diffs and potentially verification output. Users must check the provider's terms and never submit code they cannot share.
- Forge does not send its own product telemetry. Local audit logs/checkpoints are still user data: checkpoints contain pre-change file contents; audit/error records may contain bounded diagnostics after pattern-based redaction. Keep `.forge/` private and do not upload it unreviewed.

## Data-flow policy for future internet/research connectors

Internet results should be clearly separated from private workspace data. Each displayed web claim should retain its source URL, retrieval timestamp, and the basis of the statement. Label observed source text, vendor claims, inference, and unknowns separately. Treat page text, repository files, issue comments, package metadata, MCP descriptions, and generated docs as untrusted data—never as instructions to change permissions, expose secrets, install dependencies, or bypass approvals. Sending repository excerpts to a search/provider service must require a separate, explicit disclosure decision; browsing public documentation must not silently upload private source files. Forge implements a limited, explicit-query Agent-Reach search bridge for allow-listed sources, but not general browser navigation. Account/browser routes require `--allow-account`; results are displayed as untrusted data and not automatically fed into a model. The search path and `forge reach status` inspect local executable files without launching a backend or automatically invoking Agent-Reach doctor, because upstream doctor checks may contact unrelated remote platforms. Running `forge reach doctor` manually may make generic channel health probes. No live source queries have been verified in the local regression suite. Explicit `forge reach doctor` may contact external platforms and is blocked by `privacy.mode=local-only`.

## Known residual risks

No heuristic prompt-injection detector can guarantee detection. The current runner is not OS/container sandboxed, command environment restrictions do not block filesystem/network access, model API results were not live-verified in this workspace, and Windows/macOS CI has not run from this container. Do not use this experimental build on untrusted repositories with privileged credentials. Use a disposable VM/container configured with restricted mounts, non-root user, denied network by default and resource limits.


## Additional process and Git hardening (2026-10-20)

- Child processes used for test/manual commands receive a restricted environment; provider/cloud tokens and runtime-injection variables are excluded even if the optional environment allowlist is used. Timeouts and output-limit events terminate a process group/tree where the platform supports it, then escalate after a short grace period.
- `forge doctor` probes OpenCode from the system temporary directory with a restricted environment; it does not pass provider keys to the version command.
- Automatic Git metadata checks pass `core.fsmonitor=false`, `core.untrackedCache=false`, `--no-optional-locks`, and `GIT_CONFIG_NOSYSTEM=1`. This specifically prevents a repository-local `core.fsmonitor` command from running during Forge's automatic status check. Git and local filesystem operations remain subject to hostile concurrent-process/TOCTOU limits.
- CI now pins `actions/checkout` v7.0.1 and `actions/setup-node` v7.1.0 by full commit SHA. Their releases were checked on 2026-10-20; the hosted workflow has not yet run from this workspace.

- Untrusted model, repository, search, audit, and subprocess text is escaped before display so ANSI/VT control bytes are visible text rather than terminal commands. Control characters are rejected in patch paths. This protects the local CLI display; it is not a prompt-injection detector.
