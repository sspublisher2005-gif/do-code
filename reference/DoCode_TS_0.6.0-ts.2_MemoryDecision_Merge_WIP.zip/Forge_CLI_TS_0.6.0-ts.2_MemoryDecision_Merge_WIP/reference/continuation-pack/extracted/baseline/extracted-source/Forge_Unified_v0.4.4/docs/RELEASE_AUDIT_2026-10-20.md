# Forge CLI — Harness, Security, and Privacy Release Audit

**Review date:** 2026-10-20  
**Review type:** source-level engineering/security review plus selective upstream repository/documentation review. This is not a third-party penetration test, formal security audit, or complete line-by-line analysis of each upstream project.

## Decision

Keep Forge's own small, zero-runtime-dependency JavaScript harness. Borrow design patterns—not large code dumps—from more mature coding agents. The controller, permission checks, patch validator, and approval paths must remain ordinary deterministic code; the LLM is a fallible proposal generator, not the authority. Do not optimize for the number of agents. Optimize for correct completion, safe failures, resumability, and verifiable evidence.

## Upstream projects and what to adopt

| Repository | Observed strength | Decision for Forge |
|---|---|---|
| [OpenAI Codex CLI](https://github.com/openai/codex) | Separate sandbox/permission policy, process lifecycle and output limits; the sandbox guides distinguish trusted orchestration from code execution. | Adopt permission-boundary, cancellation, output-limit, and harness-versus-executor principles. Do not copy isolated Rust components without their platform-specific machinery. |
| [LangChain Deep Agents](https://github.com/langchain-ai/deepagents) | Middleware composition, checkpoint/persistence, context management, scoped subagents, skills and evaluation/tracing. | Adopt modular interfaces and persisted task state concepts; avoid the full framework dependency while the MVP is zero-dependency and still defining its security boundary. |
| [SWE-agent / mini-SWE-agent](https://github.com/SWE-agent/mini-swe-agent) | A small, inspectable model/environment loop; current SWE-agent README directs new users to mini-SWE-agent. | Adopt the simple loop, one limited repair, explicit stop conditions and testable adapters. Do not add broad shell access just to imitate a shell-first harness. |
| [Aider repo map](https://github.com/Aider-AI/aider/blob/main/aider/website/docs/repomap.md) | Compact file/symbol map for repository navigation. | Continue Forge's bounded local index and improve it with relevance tests before embeddings/vector DB. |
| [AgentDojo](https://github.com/ethz-spylab/agentdojo) | Evaluates direct/indirect prompt injection and defense strategies in tool-using agents. | Use as a future adversarial-evaluation reference. Keep the runtime free of benchmark dependencies; a detector is not a defense. Upstream states its package API is still evolving. |
| [Invariant Labs MCP-Scan](https://github.com/invariantlabs-ai/mcp-scan) | Makes third-party tool/MCP metadata a trust boundary worth inspecting. | No MCP by default. Add only after per-tool permissions, consent, isolation and adversarial tests. Review data-transfer choices before using scanning services. |
| [Continue](https://github.com/continuedev/continue) | Project rules and developer-facing IDE/CLI workflows. | Learn from the interface concepts, not as a base: its README describes the repository as read-only/final release. |
| [Daytona](https://github.com/daytonaio/daytona) | Sandboxes as isolated files/process/network/resource environments. | Use as an architectural case study, not as a required paid service; hosted compute transfers code outside the device. Its repository currently states core development moved to a private codebase in June 2026. |
| [Microsoft Agent Framework](https://github.com/microsoft/agent-framework) | Composable tool loop, state, context management, todo/plan-execute, approval hooks and telemetry integrations. | Adopt replaceable subsystem boundaries; add observability only after defining a privacy-safe event schema and opt-in policy. |

No source code was copied from those repositories. This is a selective comparison of public repositories/docs and does not constitute a license review of all upstream dependencies.

## Changes now implemented in Forge

- **OpenRouter:** direct HTTPS adapter with official endpoint allowlisting, redirect rejection, required environment key, request timeout and bounded response parsing. Mocked tests exist; no live API call was made.
- **Checkpoint safety:** checkpoints are signed with a user-local HMAC key and bound to a canonical workspace. Strict metadata/path checks reject forged, unsigned or traversal attempts rather than trusting repository-provided checkpoint metadata.
- **Subprocess privacy:** provider and repository/test subprocesses receive restricted environments. Provider credentials require explicit allowlisting where appropriate; cloud/API keys and runtime-injection variables remain blocked from the repository command allowlist.
- **Git hooks/config:** automatic Git status runs with repository fsmonitor and untracked-cache helpers disabled and a credential-free environment; a regression test verifies a local fsmonitor helper does not run.
- **Command control:** risk classification covers high-risk executable/subcommand patterns. Commands require approval according to policy; passing a command through the approval UI does not make it safe.
- **Prompt-injection handling:** repository/memory/model/test output is labeled untrusted, heuristic indicators are surfaced by category/path without copying hostile instructions into the audit event, and flagged model-bound context asks for explicit acknowledgment. High-risk patch patterns require a separate stronger approval. Detection is heuristic and can miss attacks.
- **Patches and undo:** strict path/hunk validation, file hash recheck before apply, checkpointing, and forged checkpoint regression tests.
- **Resource/terminal safety:** provider and subprocess output/timeout bounds, process-tree termination on timeout, escaped terminal control characters in untrusted output, and rejection of control bytes in patch paths.
- **Audit/privacy:** common token patterns are redacted from local JSONL events, and the CLI does not send Forge-owned analytics/telemetry.
- **Harness integrations:** `forge graph` implements a local approximate graph inspired by Graphify; `forge docs` provides a consent-gated Context7 docs lookup; REA-inspired HALT control is built in; Ponytail-inspired minimal-change/verification principles are used in prompts; and `forge reach search` provides a narrow allow-listed Agent-Reach-compatible route. `forge reach status` is passive PATH inspection; it does not launch arbitrary diagnostics. Research results are user-facing only and are not passed into the coding-model context automatically.
- **CI:** added Ubuntu/Windows/macOS matrix. Actions are pinned to verified full commit SHAs for `actions/checkout@v7.0.1` and `actions/setup-node@v7.1.0`, with read-only workflow permissions, checkout credential persistence disabled and package-manager caching disabled. These hosted jobs have not run from this environment.

## Security model and residual risk

The harness is **not yet safe to treat as sandboxed**. Restricted environment variables are useful but do not stop a user-approved build/test script from reading accessible files, accessing the network, or modifying permitted workspace files. Forge has no OS-level sandbox backend today. Do not run untrusted repositories with privileged credentials on the host; use a disposable VM/container, non-root user, restricted mounts, default-deny network and CPU/memory/process limits.

Prompt injection cannot be made impossible by a system prompt or regex detector. Defenses currently implemented are layered: treat text as untrusted, restrict model tools, check paths/commands/endpoints in code, constrain output and time, separate consent from authorization, and require human approval for consequential changes. A malicious model can still lie about its analysis; deterministic test results and exit codes take precedence.

**Privacy truth:** Forge-owned telemetry is disabled, but choosing OpenRouter or another remote model sends the exact context included in that request to the selected provider after the consent flow. Pattern-based secret redaction is not complete DLP. A “nothing leaves this device” promise is only defensible with a genuinely local model endpoint plus network controls enforced outside the model/harness. Forge has a limited Agent-Reach search bridge but no browser-navigation session of its own. Returned query output is labeled untrusted and shown to the user, not automatically sent to the coding model. Future model-connected research must preserve URL/timestamp/source labels, per-platform permissions, and the rule that only the user’s explicit search query is sent by default—never private repository files, `FORGE.md`, secrets, or chat history appended silently.

## Loop engineering recommendation

Use a bounded, stateful sequence:

`DISCOVER → PLAN → PROPOSE → STATIC CHECKS → APPROVE → APPLY → VERIFY → (ONE REPAIR) → REVIEW → REPORT`

Persist the run ID, task state, patch hash, command/test results, remaining time/token budget and stop reason. Stop on completion, denial, repeated identical patch/failure, exhausted retry/cost/time budget, or provider/tool failure. Never turn an exhausted budget into a success claim. Add parallel specialist agents only after they show a measurable improvement over the same tasks, models and costs; keep subagents read-only/scoped and leave authorization/apply decisions to the controller.

## Current local verification

- `npm test`: **53 passed, 0 failed, 0 skipped**.
- `npm run check`: **18 JavaScript files syntax-checked in the refreshed v0.1.2 build**.
- CLI `--version` and `--help`: passed.
- `forge doctor`: Node.js and Git present; OpenCode binary unavailable; no model request made; correctly warns OS-level sandbox is absent.
- OpenRouter request/response tests are mocked; no live provider request.
- Linux/POSIX process-group timeout test passed locally; Windows/macOS hosted CI is configured but has not run.
- Fake-command contract tests exercise the Agent-Reach-compatible GitHub search route and passively verify `forge reach status`; a separate regression verifies local-only mode blocks doctor before launch and prove search does not invoke `agent-reach doctor` or make an Internet request in the test fixture. No live social-source query, benchmark superiority claim, formal third-party audit, or complete prompt-injection resistance claim is made.

## Evidence references

- [OpenAI Codex CLI repository](https://github.com/openai/codex)
- [OpenAI sandbox agents guide](https://developers.openai.com/api/docs/guides/agents/sandboxes)
- [OpenAI sandbox security guidance](https://developers.openai.com/api/docs/guides/agents-api/environments/security)
- [Deep Agents repository](https://github.com/langchain-ai/deepagents)
- [mini-SWE-agent repository](https://github.com/SWE-agent/mini-swe-agent)
- [Aider repository map docs](https://github.com/Aider-AI/aider/blob/main/aider/website/docs/repomap.md)
- [AgentDojo repository](https://github.com/ethz-spylab/agentdojo)
- [OWASP LLM Top 10](https://genai.owasp.org/llm-top-10/)
- [GitHub checkout v7.0.1 release](https://github.com/actions/checkout/releases/tag/v7.0.1)
- [GitHub setup-node v7.1.0 release](https://github.com/actions/setup-node/releases/tag/v7.1.0)
- [GitHub Actions Node 20 removal notice (2026-09-23)](https://github.blog/changelog/2026-09-23-node-20-is-no-longer-available-in-github-actions/)
