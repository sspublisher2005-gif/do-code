const BASE = 'https://context7.com/api/v3/search';
const MAX_RESPONSE_BYTES = 500_000;

async function readBoundedText(response, maxBytes = MAX_RESPONSE_BYTES) {
  if (!response.body?.getReader) {
    const text = await response.text();
    if (Buffer.byteLength(text, 'utf8') > maxBytes) throw new Error('Context7 response exceeded the configured size limit.');
    return text;
  }
  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let output = ''; let total = 0;
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      total += value.byteLength;
      if (total > maxBytes) { await reader.cancel(); throw new Error('Context7 response exceeded the configured size limit.'); }
      output += decoder.decode(value, { stream: true });
    }
    return output + decoder.decode();
  } finally { reader.releaseLock?.(); }
}

function validateText(value, label, max) {
  if (typeof value !== 'string' || !value.trim() || value.length > max || /[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]/.test(value)) {
    throw new Error(`${label} must be non-empty, <= ${max} characters, and contain no control characters.`);
  }
  return value.trim();
}

/** One explicit, read-only Context7 public documentation search; never sends repository context. */
export async function searchContext7({ query, library = null, version = null, language = null, apiKey = '', fetchImpl = globalThis.fetch, timeoutMs = 15000 }) {
  const question = validateText(query, 'Question', 2000);
  const url = new URL(BASE);
  url.searchParams.set('query', question);
  url.searchParams.set('type', 'json');
  if (library) url.searchParams.append('library', validateText(library, 'Library', 120));
  if (version) {
    const safeVersion = validateText(version, 'Version', 48);
    if (!/^v?\d+(?:[._]\d+){0,2}(?:[-+][A-Za-z0-9.-]+)?$/.test(safeVersion)) throw new Error('Version must look like a package version (for example 5.4.0).');
    url.searchParams.set('version', safeVersion);
  }
  if (language) url.searchParams.set('language', validateText(language, 'Language', 40));
  if (url.origin !== 'https://context7.com' || url.pathname !== '/api/v3/search') throw new Error('Context7 endpoint validation failed.');
  const headers = { Accept: 'application/json, text/plain' };
  if (apiKey) {
    if (typeof apiKey !== 'string' || apiKey.length > 500 || /[\r\n]/.test(apiKey)) throw new Error('CONTEXT7_API_KEY has an invalid format.');
    headers.Authorization = `Bearer ${apiKey}`;
  }
  const response = await fetchImpl(url, { method: 'GET', headers, redirect: 'error', signal: AbortSignal.timeout(timeoutMs) });
  const text = await readBoundedText(response);
  if (!response.ok) {
    const error = `Context7 request failed (${response.status} ${response.statusText || 'HTTP error'}).`;
    if (response.status === 401 || response.status === 403) throw new Error(`${error} Check CONTEXT7_API_KEY and the provider's current access requirements.`);
    if (response.status === 429) throw new Error(`${error} Rate limited. Retry later or review your Context7 plan.`);
    throw new Error(error);
  }
  let data;
  try { data = JSON.parse(text); } catch { data = { text }; }
  return { data, queryChars: question.length, library: library ? String(library).slice(0, 120) : null, version: version || null, endpoint: BASE };
}

export function formatContext7Result(data, maxChars = 18000) {
  if (typeof data === 'string') return data.slice(0, maxChars);
  if (typeof data?.text === 'string') return data.text.slice(0, maxChars);
  const lines = [];
  if (data?.results && Array.isArray(data.results)) {
    for (const result of data.results.slice(0, 12)) {
      const title = String(result.title || result.name || result.library || 'Documentation result');
      const library = result.library || result.libraryId || result.id || '';
      lines.push(`## ${title}${library ? ` (${library})` : ''}`);
      if (result.url) lines.push(`Source: ${String(result.url).slice(0, 1000)}`);
      if (result.content || result.snippet || result.description) lines.push(String(result.content || result.snippet || result.description));
      for (const snippet of (Array.isArray(result.codeSnippets) ? result.codeSnippets : []).slice(0, 4)) {
        if (snippet.codeTitle) lines.push(`### ${String(snippet.codeTitle)}`);
        for (const code of (Array.isArray(snippet.codeList) ? snippet.codeList : []).slice(0, 3)) {
          if (code.code) lines.push(`\n\`\`\`${String(code.language || '')}\n${String(code.code).slice(0, 4000)}\n\`\`\``);
        }
      }
      lines.push('');
    }
  }
  for (const snippet of (Array.isArray(data?.codeSnippets) ? data.codeSnippets : []).slice(0, 12)) {
    lines.push(`## ${String(snippet.codeTitle || 'Code example')}`);
    if (snippet.source) lines.push(`Source: ${String(snippet.source).slice(0, 1000)}`);
    for (const code of (Array.isArray(snippet.codeList) ? snippet.codeList : []).slice(0, 4)) {
      if (code.code) lines.push(`\n\`\`\`${String(code.language || '')}\n${String(code.code).slice(0, 4000)}\n\`\`\``);
    }
    lines.push('');
  }
  for (const info of (Array.isArray(data?.infoSnippets) ? data.infoSnippets : []).slice(0, 12)) {
    lines.push(`## ${String(info.title || 'Documentation note')}`);
    if (info.source) lines.push(`Source: ${String(info.source).slice(0, 1000)}`);
    if (info.content) lines.push(String(info.content));
    lines.push('');
  }
  if (!lines.length) lines.push(JSON.stringify(data, null, 2));
  return lines.join('\n').slice(0, maxChars);
}
