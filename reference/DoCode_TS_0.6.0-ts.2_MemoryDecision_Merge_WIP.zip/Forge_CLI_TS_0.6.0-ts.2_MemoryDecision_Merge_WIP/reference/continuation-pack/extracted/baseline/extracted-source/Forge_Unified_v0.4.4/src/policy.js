import fs from 'node:fs';
import path from 'node:path';
import { forgeDir, writeAudit } from './audit.js';
import { ensureRealDirectory, safeTerminalText } from './utils.js';

const HALT_NAME = 'HALT';

export function getFreezeState(root) {
  const file = path.join(forgeDir(root), HALT_NAME);
  let info;
  try { info = fs.lstatSync(file); }
  catch (error) { if (error?.code === 'ENOENT') return { frozen: false, file }; throw error; }
  if (info.isSymbolicLink() || !info.isFile() || info.size > 4096) {
    return { frozen: true, invalid: true, reason: 'HALT marker is a symlink, special file, or oversized. Inspect it manually; Forge fails closed.', file };
  }
  try {
    const data = JSON.parse(fs.readFileSync(file, 'utf8'));
    return { frozen: true, reason: typeof data.reason === 'string' ? data.reason.slice(0, 500) : 'Emergency stop is active.', timestamp: data.timestamp, file };
  } catch {
    return { frozen: true, invalid: true, reason: 'HALT marker is unreadable. Inspect it manually; Forge fails closed.', file };
  }
}

export function assertProjectNotFrozen(root, action = 'this action') {
  const state = getFreezeState(root);
  if (state.frozen) throw new Error(`FORGE HALT is active; ${action} is blocked. ${state.reason || 'Inspect .forge/HALT.'} Use forge unfreeze from an interactive terminal after reviewing the incident.`);
}

export function freezeProject(root, reason = 'Manual emergency stop') {
  const directory = ensureRealDirectory(forgeDir(root), 0o700);
  const file = path.join(directory, HALT_NAME);
  try {
    const existing = fs.lstatSync(file);
    if (existing.isSymbolicLink() || !existing.isFile()) throw new Error('Refusing to overwrite a symlink or special HALT marker. Inspect it manually.');
    return { created: false, state: getFreezeState(root) };
  } catch (error) { if (error?.code !== 'ENOENT') throw error; }
  const record = { timestamp: new Date().toISOString(), reason: safeTerminalText(String(reason || 'Manual emergency stop').replace(/[\x00-\x1f\x7f]/g, ' ').trim()).slice(0, 500) || 'Manual emergency stop' };
  try { fs.writeFileSync(file, `${JSON.stringify(record, null, 2)}\n`, { mode: 0o600, flag: 'wx' }); }
  catch (error) { if (error?.code === 'EEXIST') throw new Error('HALT marker appeared concurrently; Forge is frozen or needs manual inspection.'); throw error; }
  writeAudit(root, { action: 'forge_frozen', reason: record.reason });
  return { created: true, state: getFreezeState(root) };
}

export function unfreezeProject(root) {
  const state = getFreezeState(root);
  if (!state.frozen) return { removed: false };
  const info = fs.lstatSync(state.file);
  if (info.isSymbolicLink() || !info.isFile()) throw new Error('Refusing to remove a symlink or special HALT marker. Inspect it manually.');
  fs.unlinkSync(state.file);
  writeAudit(root, { action: 'forge_unfrozen', previousReason: state.reason || 'unreadable HALT marker' });
  return { removed: true };
}
