# Forge project isolation contract (v0.4.1)

## Product rule

Forge treats a project as an explicit security and context boundary. A user owning two repositories, projects, or conversations does not authorize Forge to combine them. Same-project context is the default. Cross-project context is absent unless the user imports a specifically selected file into the active project.

This contract applies to project memory and imported files managed by Forge. It does not give Forge access to ChatGPT conversations, browser history, files in other apps, or operating-system credentials. Those are separate products/security boundaries and are not silently joined.

## Implemented in this build

- **Stable local project ID:** `forge init` records a UUID in `.forge/project.json`, alongside its canonical filesystem root, display name, creation time, and binding epoch. The ID is local metadata; it is not a remote identity service.
- **Location binding:** normal Forge commands fail closed when the stored identity points at a different root. `forge project status` remains available to explain the mismatch. `forge project rebind` requires interactive exact-phrase confirmation and changes only the root binding, not project content or context.
- **Visible active project:** the interactive prompt and coding-run startup display the project root/ID so accidental workspace switching is easier to notice.
- **No automatic cross-project search:** Forge does not crawl sibling repositories or user-wide folders for memories or conversations.
- **Scoped import:** `forge context import --from SOURCE_DIR --file RELATIVE_PATH` imports one user-selected text file from a distinct, initialized Forge project. Imports are written to the target project's ignored `.forge/shared-context/` directory, not mixed into source files.
- **Provenance and integrity:** each item records source/target project IDs, relative source file path, source content hash, imported-content hash, creation time, and whether common secret patterns were redacted. The complete record is authenticated with HMAC-SHA-256 using a private per-user key outside both participating project roots; imports and reads fail closed if configured `FORGE_HOME` would place the key inside the source/target root. Records are also bound to the target project’s `bindingEpoch` (`$FORGE_HOME/context-signing-key`, or `~/.forge-cli/context-signing-key`). A plain SHA-256 content hash is not treated as proof of consent. Unsigned, foreign-key, tampered, or unverifiable records are ignored.
- **Bounded storage and context:** one import is at most 50 KiB; at most 20 items and 20,000 characters are admitted to prompt context. Secret paths, `.git`, `.forge`, symlinks, special files, binary files, and oversized files are rejected.
- **Revocation:** `forge context list` shows active imports without printing their contents; `forge context remove ID` removes one import from active context. The event is audited locally.
- **Untrusted source content:** imported text is labelled as untrusted data in the model context. It cannot grant permissions or override Forge policy.

## Usage

Initialize both projects locally:

```bash
cd /path/to/project-a
node /path/to/Forge_Unified/bin/forge.js init

cd /path/to/project-b
node /path/to/Forge_Unified/bin/forge.js init
node /path/to/Forge_Unified/bin/forge.js project status
```

From project B, import only a file you have reviewed from project A:

```bash
node /path/to/Forge_Unified/bin/forge.js context import --from /path/to/project-a --file docs/approved-architecture.md
node /path/to/Forge_Unified/bin/forge.js context list
node /path/to/Forge_Unified/bin/forge.js context remove <CONTEXT_ID>
```

The import command is interactive and requires typing `IMPORT SELECTED CONTEXT`. Do not import broad dumps of chat history, environment files, private keys, or entire unrelated projects. Re-read `forge project status` after changing directories.

## Data flow

1. Resolve the current working project root.
2. Validate `.forge/project.json` when it exists. A moved/copied project is blocked until its location is explicitly rebound.
3. Read only that project's `FORGE.md` and HMAC-authenticated, integrity-checked files under that project's `.forge/shared-context/`. Reads never create a missing signing key, and invalid key files cause imported context to fail closed. Each signed record also matches the current `bindingEpoch`; rebinding increments the epoch, so copied/rebound projects do not replay their old signed context. Re-import any still-needed file with explicit consent.
4. Show normal model-context disclosure and untrusted-context approval before repository memory/context is sent to a provider.
5. Keep imports isolated inside the target project and auditable; removal stops Forge from loading that imported item in future context builds.

## Threat model and limits

This is an **application-level context-isolation control**, not an OS sandbox or a defense against a malicious process running as the same OS user. It does not block all possible filesystem races or defend against a privileged attacker who can rewrite both data and code. The record MAC prevents an untrusted repository from manufacturing a self-consistent “already imported” record just by recomputing SHA-256 hashes. The per-user key is stored outside the repository with restrictive permissions. This still does not defend against a same-user attacker who can read the key, modify the running Forge installation, or act with the same OS privileges. The source hash is provenance metadata and cannot prove what a source file contained at all previous times. Imported records from v0.4.0 have no MAC and are intentionally ignored after upgrading; re-import the specifically approved source file through the interactive flow. If the local signing key is lost or invalid, old imported records fail closed and must be recreated from their source.

Common token redaction is heuristic and cannot guarantee that all credentials or personal data are removed. Review imported material before allowing it into a remote-model context. `.forge` is configured as local ignored state, but operators should verify their own Git ignore rules and filesystem backup policy.

The project root is bound to its canonical path. Moving a project requires explicit rebind; rebind retains its project ID but increments the binding epoch. Existing cross-project imports from the old epoch are therefore ignored after rebind and must be re-imported explicitly if still needed. If a directory is a separate logical project, initialize a fresh copy without copying `.forge/` rather than rebinding it as the same project.

## Not implemented by this contract

- Full conversation/session persistence and a safe `forge resume` state machine.
- Workspace identity/signature against hostile same-user processes or attackers who can read the per-user signing key.
- OS/container sandboxing, network egress controls, secret mounts/withholding, and hard resource limits.
- Browser/IDE session isolation beyond existing browser tool policy.
- Automatic memory extraction or merging; these should remain opt-in and reviewable.

These remain explicit engineering work, not implied capabilities.
