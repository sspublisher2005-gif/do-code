---
name: Performance Investigation
description: Diagnose measurable latency, CPU, memory, bundle size, or throughput problems without premature optimization.
---

## Method
1. Define the measured symptom, workload, environment, and acceptable target.
2. Establish a baseline before changing implementation.
3. Use the project's profiler/benchmark or a reproducible focused measurement; do not infer speed from code appearance.
4. Identify the bottleneck and explain the mechanism.
5. Prefer the smallest targeted change and preserve correctness/security.
6. Rerun the same measurement and tests; report before/after values, variability, and limits.

Do not claim a speedup without comparable measurements. Avoid adding dependencies or caches without invalidation, memory, and failure behavior considered.
