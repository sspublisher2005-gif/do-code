import test from 'node:test';
import assert from 'node:assert/strict';
import { classifyTask, shouldUseDecisionSupport, validateDecisionMatrix, formatDecisionMatrix, isDecisionOnlyTask } from '../src/decision-support.js';
import { normalizeClarifyingQuestions, ensureBlockingQuestionForAmbiguity, shouldConductInterview, buildClarifiedTask } from '../src/interview.js';
import { collectClarificationAnswers } from '../src/interview-ui.js';

const validMatrix = {
  question: 'Which persistence strategy best fits this repository?',
  criteria: [
    { id: 'safety', label: 'Data safety', weight: 0.7, scoringGuide: 'Higher means easier to make safe' },
    { id: 'complexity', label: 'Operational simplicity', weight: 0.3, scoringGuide: 'Higher means simpler' },
  ],
  options: [
    { id: 'sql', label: 'SQL database', scores: { safety: 5, complexity: 3 }, pros: ['Transactions'], cons: ['Requires setup'], risks: ['Migration needed'], evidence: [{ sourceType: 'repository', reference: 'src/db.js', note: 'Current persistence integration' }], confidence: 'medium' },
    { id: 'file', label: 'Local file store', scores: { safety: 2, complexity: 5 }, pros: ['Simple'], cons: ['Concurrency limits'], risks: ['Corruption without careful writes'], evidence: [{ sourceType: 'inference', reference: '', note: 'Assumes low write concurrency' }], confidence: 'low' },
  ],
  recommendationId: 'file', // deliberately inconsistent with weighted scores
  requiresUserChoice: false,
  confidence: 'medium',
  assumptions: ['One instance writes at a time'],
  unknowns: ['Expected data volume'],
};

test('task triage skips decision analysis for small fixes and triggers it for explicit comparisons', () => {
  assert.equal(classifyTask('Fix the typo in README.md').kind, 'small');
  assert.equal(shouldUseDecisionSupport('Fix the typo in README.md', { decisionSupport: { needed: true } }), false);
  assert.equal(shouldUseDecisionSupport('Compare SQLite and Postgres for this app', {}), true);
  assert.equal(shouldUseDecisionSupport('Refactor the payment architecture across services', { decisionSupport: { needed: true } }), true);
  assert.equal(shouldUseDecisionSupport('Build the feature and update tests', { decisionSupport: { needed: false } }), false);
});

test('decision schema is strict and ranking is calculated locally from validated numeric scores', () => {
  const result = validateDecisionMatrix(validMatrix);
  assert.equal(result.ok, true);
  assert.equal(result.matrix.rankedOptions[0].id, 'sql');
  assert.equal(result.matrix.computedRecommendationId, 'sql');
  assert.equal(result.matrix.modelRecommendationId, 'file');
  assert.equal(result.matrix.recommendationDisagreesWithScore, true);
  assert.equal(result.matrix.requiresUserChoice, true, 'ranking disagreement must require the user even if the model forgot the flag');
  assert.match(formatDecisionMatrix(result.matrix), /WARNING: model recommended file/);
  assert.match(formatDecisionMatrix(result.matrix), /Scores are weighted model assessments/);
});

test('decision schema rejects duplicate IDs, missing scores and out-of-range values', () => {
  const duplicate = structuredClone(validMatrix);
  duplicate.options[1].id = 'sql';
  const duplicateResult = validateDecisionMatrix(duplicate);
  assert.equal(duplicateResult.ok, false);
  assert.ok(duplicateResult.errors.some((error) => /Duplicate option id/.test(error)));

  const missing = structuredClone(validMatrix);
  delete missing.options[0].scores.safety;
  assert.equal(validateDecisionMatrix(missing).ok, false);

  const invalidRange = structuredClone(validMatrix);
  invalidRange.options[0].scores.safety = 6;
  assert.equal(validateDecisionMatrix(invalidRange).ok, false);

  const extraScore = structuredClone(validMatrix);
  extraScore.options[0].scores.hidden = 4;
  assert.equal(validateDecisionMatrix(extraScore).ok, false);

  const unsupported = structuredClone(validMatrix);
  unsupported.requiresUserChoice = false;
  unsupported.confidence = 'medium';
  unsupported.options.forEach((option) => { option.evidence = []; option.confidence = 'high'; });
  const unsupportedResult = validateDecisionMatrix(unsupported);
  assert.equal(unsupportedResult.ok, true);
  assert.equal(unsupportedResult.matrix.rankedOptions[0].confidence, 'low');
  assert.equal(unsupportedResult.matrix.requiresUserChoice, true, 'missing evidence references must not silently authorize a recommendation');
});

test('decision-only requests are identified without confusing coding tasks', () => {
  assert.equal(isDecisionOnlyTask('Compare SQLite and Postgres for this repository.'), true);
  assert.equal(isDecisionOnlyTask('Compare SQLite and Postgres, then implement the selected approach.'), false);
});

test('unclear shorthand receives one deterministic blocking question instead of letting the planner guess', () => {
  const questions = ensureBlockingQuestionForAmbiguity('fix it', []);
  assert.equal(questions.length, 1);
  assert.equal(questions[0].blocking, true);
  assert.match(questions[0].question, /What exact behavior/);
  assert.equal(ensureBlockingQuestionForAmbiguity('Fix the typo in README.md', []).length, 0);
});

test('clarification normalization is bounded, validates content and small fixes skip interviews', () => {
  const raw = Array.from({ length: 8 }, (_, index) => ({
    id: `q${index + 1}`, question: `Which useful option should be selected ${index + 1}?`, blocking: true,
    options: ['A', 'B'], safeDefault: index === 0 ? 'A' : '',
  }));
  const normalized = normalizeClarifyingQuestions(raw);
  assert.equal(normalized.length, 5);
  assert.equal(shouldConductInterview('Fix the typo in README.md', normalized), false);
  assert.equal(shouldConductInterview('Refactor the authentication architecture across services', normalized), true);
  const clarified = buildClarifiedTask('Refactor auth', [{ question: 'Which provider?', answer: 'Keep the current provider' }]);
  assert.match(clarified, /Keep the current provider/);
});

test('question-help side-channel does not mutate the main interview answer', async () => {
  const inputs = ['? Explain this term in simple language', '/back', 'Keep the current provider'];
  const audit = [];
  const modelCalls = [];
  const result = await collectClarificationAnswers({
    rl: { question: async () => inputs.shift() },
    config: { model: 'test-model' }, runId: 'run-test', task: 'Refactor auth',
    questions: [{ id: 'q1', question: 'Which identity provider should be retained?', whyItMatters: 'Changing this alters login behavior.', blocking: true, options: ['Keep current', 'Migrate'], safeDefault: '' }],
    canPrompt: () => true,
    modelCall: async (_config, role, prompt) => { modelCalls.push({ role, prompt }); return { text: 'An identity provider is the service that handles sign-in.' }; },
    askYesNo: async () => true,
    writeAudit: (event) => audit.push(event),
    sha256: (value) => `hash:${value.length}`,
    safeTerminalText: (value) => String(value),
    redactSecrets: (value) => String(value),
    truncate: (value, size) => String(value).slice(0, size),
  });
  assert.equal(result.status, 'complete');
  assert.equal(result.answers.length, 1);
  assert.equal(result.answers[0].answer, 'Keep the current provider');
  assert.equal(modelCalls.length, 1);
  assert.equal(modelCalls[0].role, 'interview-explainer');
  assert.doesNotMatch(modelCalls[0].prompt, /Refactor auth/);
  assert.doesNotMatch(modelCalls[0].prompt, /Refactor auth|src\/[^ ]+|secret-value/i);
  assert.equal(audit.some((event) => event.action === 'interview_side_question' && event.mainAnswerChanged === false), true);
});

test('skipping a blocking interview without a safe default stops rather than guessing', async () => {
  const inputs = ['/skip'];
  const result = await collectClarificationAnswers({
    rl: { question: async () => inputs.shift() }, config: { model: 'test-model' }, runId: 'run-test', task: 'Refactor auth',
    questions: [{ id: 'q1', question: 'Which identity provider should be retained?', blocking: true, safeDefault: '' }],
    canPrompt: () => true, modelCall: async () => { throw new Error('must not call model'); }, askYesNo: async () => true,
    writeAudit: () => {}, sha256: (value) => `hash:${value.length}`, safeTerminalText: String, redactSecrets: String, truncate: (value) => value,
  });
  assert.equal(result.status, 'cancelled');
});
