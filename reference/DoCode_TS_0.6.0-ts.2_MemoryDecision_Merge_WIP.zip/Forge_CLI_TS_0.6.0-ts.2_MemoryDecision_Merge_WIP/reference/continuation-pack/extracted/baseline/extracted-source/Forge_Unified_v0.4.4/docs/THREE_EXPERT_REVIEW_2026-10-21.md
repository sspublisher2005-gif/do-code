# Forge founder review through three specialist lenses

**Date:** 2026-10-21  
**Method:** structured internal review informed by public product documentation, public issue reports, the current Forge source and its test suite. These are *simulated specialist perspectives*, not claims that three external experts or customers were interviewed.

## v0.4.4 implementation delta (fresh local review)

- Built-in Node/Python/Go/Rust/Alpine container image references are now digest-pinned. This establishes reference immutability, not publisher authenticity or vulnerability status; image pull/SBOM/signature scanning remains open.
- Container commands now request fixed UID/GID `65532:65532`, make only the disposable copied workspace user-writable after copying, and use no-follow regular-file descriptors/metadata checks during host-side staging. A further directory-level TOCTOU remains possible under a concurrent same-host writer; this is not a kernel security boundary.
- Expanded excluded cloud/CLI credential directories; added a SIGKILL session recovery regression test.
- Fresh local proof: 129/129 tests pass, 32 JS modules pass syntax checks, and the release verifier re-packs/extracts the package and passes all 129 tests plus CLI version/help checks. `npm audit` reports zero known vulnerabilities on the zero-dependency tree.
- A separate Python Playwright 1.57 + system Chromium 144 fixture passed desktop/mobile UI assertions and detected a seeded calculation bug. This does not run Forge's Node Playwright adapter.
- **Still not verified:** Docker/Podman runtime or escape behavior; image provenance/vulnerabilities; Forge-native browser integration; live provider-backed task; hosted CI; external security/customer review; matched competitor benchmark.

## 1. Security / platform engineering perspective

### Verdict
Forge should not grant greater autonomy until isolation and evidence boundaries are testable. Approval is valuable but is not a sandbox. A repository test script can read any file available to the host account unless the operating system enforces a boundary.

### Findings
- The prior Forge version ran approved repository commands on the host and warned that execution was not sandboxed.
- v0.4.4 hardens the opt-in container runner to stage a sanitized, bounded copy and run under unprivileged UID/GID `65532:65532`; filters common secret files and symlinks; does not pass provider credentials; disables networking and automatic image pulls; uses a read-only rootfs and capped tmpfs; and fails closed when a runtime/image is missing.
- The new feature is intentionally not the default execution path. It cannot be described as closing the production isolation gate before actual Docker/Podman validation.
- Built-in image references are digest-pinned in v0.4.4, while image signature/provenance and vulnerability validation are still open; custom image overrides must be digest-pinned but remain operator-trusted. Filename filtering cannot guarantee that all secrets are omitted. Container/host kernel vulnerabilities remain possible.

### Required next actions
1. Run the new real-engine Linux smoke probe in `scripts/real-sandbox-check.mjs`, then add canary secret and outside-workspace tests, attempted network request, fork bomb/process-limit test, tmpfs fill test, timeout with grandchildren, forced daemon stop and cleanup. The CI job is configured but has not run yet.
2. Independent review of Docker/Podman flags and local-daemon enforcement.
3. Digest-pinned trusted images, SBOM, scanning and explicit provenance policy. A real-engine probe is now scripted in `scripts/real-sandbox-check.mjs` and wired into CI, but it has not yet run.
4. Route automated verification through the sandbox only after its integration tests and rollback behavior are proven.

## 2. Coding-agent reliability / QA perspective

### Verdict
Passing unit tests proves deterministic code paths, not task-level coding ability. Forge needs a crisp completion contract and real provider-backed tasks whose source changes and verification outcomes can be independently inspected.

### Findings
- Current provider paths and agent loop have fake-provider tests but no verified live model-backed coding run in the release evidence.
- Session restart replays the saved task against the current tree; it does not restore exact step state or automatically roll back partial edits. v0.4.3 added active-process locks and stale-attempt marking; v0.4.4 adds one SIGKILL crash-recovery regression, but simultaneous subprocess races and crash-at-each-phase still need tests.
- Heuristic test-command detection is not an independent evaluator of every acceptance criterion.
- `forge sandbox run` currently executes a single command in a disposable copy. Because outputs are discarded, it is a verification primitive, not yet the repair-loop runtime.

### Required next actions
1. Crash injection at every run phase, subprocess contention, stale-session state recovery, and lock cleanup under forced termination.
2. Provider adapter conformance tests with recorded/redacted request/response fixtures, timeout/cancel, 429/5xx retry, token usage and cost accounting.
3. Build 30–50 representative held-out tasks and run fixed model/version/config with repeated seeds; retain patches, exit codes, reviewer rubrics, task cost and latency.
4. Do not use a single popular benchmark as the sole quality measure. OpenAI published a February 23, 2026 analysis recommending against SWE-bench Verified for frontier evaluation because audited test cases can reject functionally correct solutions and training contamination is a concern.
5. Separate `PASS`, `PARTIAL`, `UNVERIFIED`, and `FAIL` as deterministic states grounded in evidence, not the model's prose.

## 3. Founder / customer experience perspective

### Verdict
A broader feature list is unlikely to create a moat. Forge needs one promise users can experience in minutes: “make a change, show the exact evidence, and never pretend it passed.”

### Customer pain hypotheses
- Beginner/student: unclear setup, model/provider billing uncertainty, intimidating security prompts, and no plain-English explanation of what will happen.
- Solo founder/vibe coder: wasted time on broken builds and confident-but-wrong completion claims.
- Professional engineer: context loss, unreviewable diffs, noisy agent chatter, flaky verification, and hard-to-reproduce failures.
- Team/security owner: project boundary violations, secret exposure, policy inconsistency, weak audit evidence, and unmanaged provider spend.

These are hypotheses synthesized from product docs and public issue reports; they are not statistically representative interview findings.

### Product moves
1. Default to a small task loop: inspect → plan → proposed diff → approval → verification → result evidence.
2. One explicit current-project indicator; never silently mix other projects, chats, files, credentials or memory. Cross-project context remains opt-in and scoped.
3. Plain-language controls for network access, shell execution, provider context, costs and the active sandbox.
4. Evidence report always lists changed files, commands actually run, exit codes, test summary, known untested criteria, duration/cost when known, and rollback/checkpoint path.
5. Launch with a narrow target: solo developers and small teams who want controlled agent changes with proof. Expand only after activation, task success and week-4 retention show value.

## CEO / co-founder prioritization decision

### P0 — before broader autonomy
- Real Docker/Podman validation and independent sandbox review.
- Route accepted test commands through the sandbox in a way that preserves only intended outputs and never makes original host paths writable to the container.
- Crash-safe, concurrent-safe session lifecycle.
- One real provider-backed end-to-end code task with full redacted evidence.

### P1 — before claiming competitiveness
- Provider conformance and truthful token/cost tracking.
- Browser E2E in an isolated runtime with console/network/screenshot evidence.
- Cross-platform CI on Linux, Windows and macOS.
- Fair held-out benchmark against accessible current versions of Codex CLI, Claude Code, OpenCode and at least one additional open source agent.

### P2 — before broad launch
- Onboarding and troubleshooting for no-provider, local-provider, and remote-provider setups.
- Explicit opt-in telemetry-free diagnostics, understandable error messages, privacy/security docs and license/notice review.
- External usability sessions with at least 20–30 target users, then monitor first-task success, time-to-first-verified-change, crash rate and 7-/28-day retention.

### P3 — only after core quality improves
- Full recursive Harness² optimization loop, long-lived writing subagents, broader MCP/ACP protocols, extension marketplace, IDE GUI and cloud/team features.

No claim is made that Forge is superior to incumbent coding agents. No income, popularity, or product-market fit is guaranteed.

## Sources
- Codex sandbox and approval concepts: https://github.com/openai/codex/blob/main/docs/sandbox.md and https://help.openai.com/en/articles/11096431
- Gemini CLI sandbox: https://github.com/google-gemini/gemini-cli/blob/main/docs/cli/sandbox.md
- Gemini CLI checkpointing: https://github.com/google-gemini/gemini-cli/blob/main/docs/cli/checkpointing.md
- OpenCode permissions: https://opencode.ai/docs/agents/ and https://docs.opencode.ai/docs/tools/
- OpenHands Docker runtime rationale: https://github.com/OpenHands/docs/blob/main/openhands/usage/architecture/runtime.mdx
- Public session-context issue examples: https://github.com/anthropics/claude-code/issues/22882 and https://github.com/anomalyco/opencode/issues/29181
- OpenAI on SWE-bench Verified: https://openai.com/index/why-we-no-longer-evaluate-swe-bench-verified/ (published February 23, 2026)
