# Security Release Gate

Forge 0.4.4 remains an engineering prototype. Passing unit tests is not evidence that it can safely execute hostile code.

## Required before untrusted repositories or production autonomy

- [x] Partial implementation: v0.4.4 adds fixed unprivileged container UID/GID, digest-pinned built-in image references, secret-path filtering, no-follow file staging, and an opt-in disposable container command with sanitized read-only input and capped tmpfs workspace. The corresponding tests use a fake runtime; actual engine behavior is not verified.
- [ ] Production gate remains open: real-runtime testing; automatic verification/repair routing; write-back design; independent escape review; Windows backend.
- [ ] Host secrets absent from the execution environment; deny credential-file reads and test attempted exfiltration.
- [ ] Network egress denied by default, with narrowly configured allowlists where needed.
- [ ] CPU, memory, process-count, disk and wall-clock budgets enforced outside the model.
- [ ] Reliable process-tree cancellation, timeouts, cleanup and rollback.
- [ ] Adversarial tests for symlinks, traversal, TOCTOU races, shell escaping, archive expansion and child processes.
- [ ] Prompt-injection red-team tests across repository files, command output, web pages, MCP tools and browser DOM content.
- [ ] Secrets never placed in model context unless an explicit, documented task requires it; redaction tests must include every supported provider/error shape.
- [ ] Independent security reviewer examines tool routing, permissions, provider adapters, MCP subprocesses, browser context, audit integrity and error handling.
- [ ] CI across Linux, Windows and macOS after all current failures and platform differences are resolved.

## Current limits

Project identity/root binding and explicit cross-project file import were implemented in v0.4.0; v0.4.1 adds per-user HMAC authentication and target binding-epoch checks, so repository-controlled records cannot forge an approved import and previously signed records are not replayed automatically after rebind. They reduce accidental context mixing but are application-level controls only; they do not replace an OS sandbox or defend against a hostile same-user process. v0.4.2 adds HMAC-authenticated, encrypted task sessions stored outside repositories and bound to project root + binding epoch; this still does not provide exact crash-safe transcript/step resume. v0.4.4 hardens the opt-in sandbox path with an unprivileged UID/GID, digest-pinned default image references, wider credential-path exclusion, and file-level no-follow staging; ordinary approved commands and the existing automatic repair loop remain host-executed, and the new path has not yet been tested against a real container engine. A single SIGKILL session-recovery regression test now passes, but comprehensive crash-phase and concurrent-hostile-writer stress remain open. v0.4.3 also rejects Docker endpoints that are remote or not positively identified as local. See [Project Isolation](PROJECT_ISOLATION.md).

Application-level permission gates do not provide kernel-enforced isolation. The project does not promise sandbox escape prevention or complete secret isolation. The opt-in container path disables container networking when run successfully, but ordinary host command paths do not have a Forge-enforced network-egress boundary; the new runner has not yet had real-runtime penetration testing. Optional MCP servers and browser automation may execute programs and interact with untrusted content; use only trusted integrations inside a disposable environment until the gate above is met.

## Current v0.4.4 evidence

- [x] Local automated suite: 129 passed, 0 failed, 0 skipped.
- [x] Syntax check: 32 JavaScript modules.
- [x] Fresh package verification: 121 packaged entries; 129 tests, syntax validation, version and help checks passed.
- [x] Completion gate regression tests require passing tests/review, no security warnings, and a passing conditional security/browser result where present.
- [x] npm audit: 0 known vulnerabilities reported for a package with no declared dependencies (does not scan source code or container images).
- [ ] Real Docker/Podman isolation test and hostile workspace escape review.
- [ ] Image signature/provenance, SBOM and vulnerability scan.
- [ ] Live model provider, Forge Node Playwright adapter, hosted cross-platform CI and external security review.

## Approval and data rules

- Provider calls require context-sharing consent, except where the configured local-only mode applies.
- Do not commit API keys, `.env` values, private keys, cookies, user data, task transcripts containing secrets, or private screenshots.
- Installing the portable layer only writes inside the selected project and maintains a manifest; inspect preview output first.
- No global CLI settings, model settings or installation preferences are changed by the portable-layer installer.
- Freeze/cancel must stop further permitted writes/external operations as soon as feasible; verify cleanup evidence rather than assuming cancellation killed every child process.
