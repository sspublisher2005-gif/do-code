import fs from 'node:fs';
import path from 'node:path';
import { isSensitivePath, redactSecrets, safeReadText } from './utils.js';

const IGNORED_DIRS = new Set([
  '.git', '.forge', 'node_modules', 'vendor', 'dist', 'build', 'coverage', '.next', '.nuxt', '.turbo',
  '.venv', 'venv', '__pycache__', '.cache', 'target', 'out', '.idea', '.vscode', '.gradle', 'Pods',
]);
const IGNORED_FILES = new Set(['package-lock.json', 'pnpm-lock.yaml', 'yarn.lock', 'bun.lockb', 'bun.lock', 'Cargo.lock', 'poetry.lock', 'uv.lock']);
const SYMBOL_RULES = [
  /^\s*(?:export\s+)?(?:async\s+)?function\s+([\w$]+)/,
  /^\s*(?:export\s+)?class\s+([\w$]+)/,
  /^\s*(?:export\s+)?interface\s+([\w$]+)/,
  /^\s*(?:export\s+)?type\s+([\w$]+)/,
  /^\s*(?:export\s+)?(?:const|let|var)\s+([\w$]+)\s*=/,
  /^\s*def\s+([\w$]+)/,
  /^\s*class\s+([\w$]+)/,
  /^\s*func\s+([\w$]+)/,
  /^\s*fn\s+([\w$]+)/,
];

function loadIgnorePatterns(root) {
  const file = path.join(root, '.gitignore');
  if (!fs.existsSync(file)) return [];
  const info = fs.lstatSync(file);
  if (info.isSymbolicLink() || !info.isFile()) return [];
  return fs.readFileSync(file, 'utf8').split(/\r?\n/)
    .map((line) => line.trim()).filter((line) => line && !line.startsWith('#'))
    .map((line) => ({ raw: line.replace(/^!/, ''), negated: line.startsWith('!'), dir: line.endsWith('/') }));
}

function ignoredByGitignore(relative, patterns) {
  const segments = relative.split('/');
  let ignored = false;
  for (const rule of patterns) {
    const pattern = rule.raw.replaceAll('\\', '/');
    if (pattern.startsWith('/')) {
      const exact = pattern.slice(1).replace(/\/$/, '');
      if (relative === exact || relative.startsWith(`${exact}/`)) ignored = !rule.negated;
    } else if (pattern.includes('*')) {
      const regex = new RegExp(`(^|/)${pattern.replace(/[.+^${}()|[\]\\]/g, '\\$&').replaceAll('**', '§§').replaceAll('*', '[^/]*').replaceAll('§§', '.*')}${rule.dir ? '(/.*)?' : ''}$`);
      if (regex.test(relative)) ignored = !rule.negated;
    } else if (segments.includes(pattern.replace(/\/$/, '')) || relative === pattern) ignored = !rule.negated;
  }
  return ignored;
}

function extractSymbols(text) {
  const found = [];
  const lines = text.split(/\r?\n/);
  for (let i = 0; i < lines.length; i += 1) {
    for (const rule of SYMBOL_RULES) {
      const match = lines[i].match(rule);
      if (match) {
        found.push({ name: match[1], line: i + 1 });
        break;
      }
    }
    if (found.length >= 120) break;
  }
  return found;
}

export function buildRepoIndex(root, config, task = '') {
  const patterns = loadIgnorePatterns(root);
  const files = [];
  const symbols = [];
  let excluded = 0;
  let indexedBytes = 0;
  let queueIndex = 0;
  const queue = [''];

  while (queueIndex < queue.length && files.length < config.limits.maxFiles) {
    const relativeDir = queue[queueIndex++];
    const absoluteDir = path.join(root, relativeDir);
    let entries;
    try { entries = fs.readdirSync(absoluteDir, { withFileTypes: true }).sort((a, b) => a.name.localeCompare(b.name)); }
    catch { continue; }
    for (const entry of entries) {
      const relative = relativeDir ? `${relativeDir}/${entry.name}` : entry.name;
      if (IGNORED_DIRS.has(entry.name) || entry.name.startsWith('.forge-tmp')) { excluded += 1; continue; }
      if (isSensitivePath(relative) || ignoredByGitignore(relative, patterns)) { excluded += 1; continue; }
      const abs = path.join(root, ...relative.split('/'));
      let stat;
      try { stat = fs.lstatSync(abs); } catch { continue; }
      if (stat.isSymbolicLink()) { excluded += 1; continue; }
      if (entry.isDirectory()) {
        if (!relative.startsWith('.git/')) queue.push(relative);
        continue;
      }
      if (!entry.isFile() || IGNORED_FILES.has(entry.name) || stat.size > config.limits.maxFileBytes || indexedBytes + stat.size > config.limits.maxIndexBytes) { excluded += 1; continue; }
      const content = safeReadText(abs, config.limits.maxFileBytes);
      if (content === null) { excluded += 1; continue; }
      const contentBytes = Buffer.byteLength(content, 'utf8');
      if (indexedBytes + contentBytes > config.limits.maxIndexBytes) { excluded += 1; continue; }
      indexedBytes += contentBytes;
      const redactedContent = redactSecrets(content);
      const entryInfo = {
        path: relative,
        bytes: stat.size,
        lines: content.split(/\r?\n/).length,
        symbols: extractSymbols(redactedContent),
        imports: extractImports(redactedContent),
        content: redactedContent,
      };
      files.push(entryInfo);
      for (const symbol of entryInfo.symbols) symbols.push({ path: relative, ...symbol });
      if (files.length >= config.limits.maxFiles) break;
    }
  }
  files.sort((a, b) => a.path.localeCompare(b.path));
  const ranked = rankFiles(files, task);
  const tree = files.map((file) => `${file.path} (${file.lines} lines, ${file.bytes} bytes)`).join('\n');
  const dependencyGraph = files.filter((file) => file.imports.length).map((file) => ({ path: file.path, imports: file.imports }));
  return { root, files, symbols, dependencyGraph, tree, ranked, excluded, totalFiles: files.length, indexedBytes };
}

function extractImports(text) {
  const imports = [];
  const patterns = [
    /\bimport\s+(?:[^'";]+?\s+from\s+)?['"]([^'"]+)['"]/g,
    /\brequire\s*\(\s*['"]([^'"]+)['"]\s*\)/g,
    /^\s*from\s+([\w.]+)\s+import\s+/gm,
    /^\s*import\s+([\w.]+)/gm,
  ];
  for (const regex of patterns) {
    let match;
    while ((match = regex.exec(text)) !== null && imports.length < 100) imports.push(match[1]);
  }
  return [...new Set(imports)];
}

export function rankFiles(files, task = '') {
  const terms = String(task).toLowerCase().match(/[a-z0-9_./-]{3,}/g) ?? [];
  const uniqueTerms = [...new Set(terms)];
  return files.map((file) => {
    const content = file.content.toLowerCase();
    const p = file.path.toLowerCase();
    let score = 0;
    for (const term of uniqueTerms) {
      if (p.includes(term)) score += 8;
      const occurrences = content.split(term).length - 1;
      score += Math.min(occurrences, 12) * 0.6;
    }
    if (/(^|\/)(readme|package|pyproject|go\.mod|cargo\.toml|makefile)(\.|$)/i.test(file.path)) score += 1;
    return { ...file, score };
  }).sort((a, b) => b.score - a.score || a.path.localeCompare(b.path));
}

export function makeRepositorySummary(index, maxChars = 16000) {
  const sections = [
    `Repository root: [local project root]\nText files indexed: ${index.totalFiles}; skipped paths/files: ${index.excluded}`,
    `\nTask-relevant files:\n${index.ranked.slice(0, 80).map((file) => `${file.path} (${file.lines} lines, ${file.bytes} bytes; relevance ${file.score.toFixed(1)})`).join('\n')}`,
    `\nFile map (truncated):\n${index.tree.slice(0, Math.max(1500, Math.floor(maxChars * 0.28)))}`,
    `\nTop symbols:\n${index.symbols.slice(0, 160).map((item) => `${item.path}:${item.line} ${item.name}`).join('\n')}`,
    `\nImport/dependency hints:\n${index.dependencyGraph.slice(0, 70).map((item) => `${item.path} -> ${item.imports.slice(0, 8).join(', ')}`).join('\n')}`,
  ];
  let output = '';
  for (const section of sections) {
    const remaining = maxChars - output.length;
    if (remaining <= 0) break;
    output += `${section.slice(0, remaining)}\n`;
  }
  return output.slice(0, maxChars);
}

export function selectContextFiles(index, paths, maxChars) {
  const byPath = new Map(index.files.map((file) => [file.path, file]));
  const selected = [];
  let used = 0;
  for (const relative of paths) {
    const file = byPath.get(relative);
    if (!file) continue;
    const chunk = `\n--- FILE: ${file.path} ---\n${file.content.slice(0, 6000)}\n`;
    if (used + chunk.length > maxChars) continue;
    selected.push(chunk);
    used += chunk.length;
  }
  return selected.join('\n');
}
