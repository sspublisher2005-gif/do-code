import json, os, pathlib, shutil, subprocess, tempfile
base = pathlib.Path(tempfile.mkdtemp(prefix='forge-permission-probe-', dir='/mnt/data'))
os.chmod(base, 0o755)
input_dir = base/'input'; workspace = base/'workspace'
input_dir.mkdir(); os.chmod(input_dir, 0o755)
workspace.mkdir(); os.chown(workspace, 65532, 65532); os.chmod(workspace, 0o1777)
(input_dir/'private-mode-source.txt').write_text('original source')
os.chmod(input_dir/'private-mode-source.txt', 0o444)
(input_dir/'source-dir').mkdir(); os.chmod(input_dir/'source-dir', 0o555)
(input_dir/'source-dir'/'readonly.js').write_text('export const value = 1;')
os.chmod(input_dir/'source-dir'/'readonly.js', 0o444)
script = 'cp -R "$1"/. "$2"/ && chmod -R u+rwX "$2" && printf modified >> "$2/private-mode-source.txt" && printf "export const changed = true;\\n" >> "$2/source-dir/readonly.js" && test -w "$2/private-mode-source.txt" && test -w "$2/source-dir/readonly.js"'
def drop_privileges():
    os.setgid(65532); os.setuid(65532)
result = subprocess.run(['/bin/sh','-c', script, 'probe', str(input_dir), str(workspace)], preexec_fn=drop_privileges, text=True, capture_output=True)
report = {
  'exit_code': result.returncode,
  'stderr': result.stderr,
  'original_source_unchanged': (input_dir/'private-mode-source.txt').read_text() == 'original source',
  'copied_file_writable': (workspace/'private-mode-source.txt').exists() and os.access(workspace/'private-mode-source.txt', os.W_OK),
  'copied_nested_file_writable': (workspace/'source-dir'/'readonly.js').exists() and os.access(workspace/'source-dir'/'readonly.js', os.W_OK),
  'copied_file_content_modified': (workspace/'private-mode-source.txt').read_text().endswith('modified'),
  'method': 'host POSIX permissions test under UID/GID 65532; not a container test'
}
print(json.dumps(report, indent=2))
shutil.rmtree(base)
assert result.returncode == 0 and report['original_source_unchanged'] and report['copied_file_content_modified'] and report['copied_nested_file_writable']
