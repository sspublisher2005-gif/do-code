import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
const npmCli = process.env.npm_execpath;
if (!npmCli || !fs.existsSync(npmCli)) {
  throw new Error('Release verification must be invoked through `npm run check:release` so npm_execpath is available.');
}
const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'forge-release-check-'));
const packed = path.join(temp, 'packed');
const extracted = path.join(temp, 'extracted');
fs.mkdirSync(packed, { recursive: true });
fs.mkdirSync(extracted, { recursive: true });
const evidence = {};

function run(label, executable, args, cwd, options = {}) {
  const result = spawnSync(executable, args, {
    cwd, encoding: 'utf8', windowsHide: true, timeout: options.timeout ?? 120000,
    maxBuffer: 16 * 1024 * 1024, env: { ...process.env, NO_COLOR: '1', FORCE_COLOR: '0' },
  });
  if (result.error || result.status !== 0) {
    const details = `${result.error?.message || ''}\n${result.stdout || ''}\n${result.stderr || ''}`.trim();
    throw new Error(`${label} failed (exit ${result.status ?? 'unknown'}):\n${details.slice(-12000)}`);
  }
  return result.stdout || '';
}

function npm(args, cwd) { return run(`npm ${args.join(' ')}`, process.execPath, [npmCli, ...args], cwd); }

try {
  const packText = npm(['pack', '--json', '--pack-destination', packed], root);
  let packInfo;
  try { packInfo = JSON.parse(packText)[0]; }
  catch { throw new Error(`npm pack did not return valid JSON: ${packText.slice(0, 2000)}`); }
  const archive = path.join(packed, packInfo.filename);
  if (!fs.existsSync(archive) || fs.statSync(archive).size < 1000) throw new Error('npm pack did not produce a plausible tarball.');
  const listing = run('list packed files', 'tar', ['-tzf', archive], packed);
  const entries = listing.split(/\r?\n/).filter(Boolean);
  for (const required of ['package/package.json', 'package/bin/forge.js', 'package/src/cli.js', 'package/src/sandbox.js', 'package/tests/sandbox.test.js', 'package/scripts/check.mjs']) {
    if (!entries.includes(required)) throw new Error(`Release tarball is missing required source/test entry: ${required}`);
  }
  if (entries.some((entry) => entry.startsWith('/') || entry.split('/').includes('..'))) throw new Error('Release tarball contains an unsafe absolute or traversal path.');
  run('extract npm package', 'tar', ['-xzf', archive, '-C', extracted], packed);
  const packageRoot = path.join(extracted, 'package');
  const extractedPkg = JSON.parse(fs.readFileSync(path.join(packageRoot, 'package.json'), 'utf8'));
  if (extractedPkg.name !== pkg.name || extractedPkg.version !== pkg.version) throw new Error('Packed package identity does not match source package.json.');
  const tests = npm(['test'], packageRoot);
  const pass = Number(tests.match(/^# pass (\d+)$/m)?.[1] ?? -1);
  const fail = Number(tests.match(/^# fail (\d+)$/m)?.[1] ?? -1);
  if (pass < 1 || fail !== 0) throw new Error(`Packed test results were not green (pass=${pass}, fail=${fail}).`);
  const check = npm(['run', 'check'], packageRoot);
  if (!/Syntax OK:/m.test(check)) throw new Error('Packed syntax check did not report success.');
  const version = run('CLI version smoke test', process.execPath, ['bin/forge.js', '--version'], packageRoot).trim();
  if (version !== pkg.version) throw new Error(`CLI reports ${version}, expected package version ${pkg.version}.`);
  const help = run('CLI help smoke test', process.execPath, ['bin/forge.js', '--help'], packageRoot);
  if (!help.includes(`Forge ${pkg.version}`) || !help.includes('sandbox')) throw new Error('Packed CLI help is missing version or sandbox commands.');
  evidence.version = pkg.version;
  evidence.filename = packInfo.filename;
  evidence.tgzBytes = fs.statSync(archive).size;
  evidence.packedFiles = entries.length;
  evidence.packedTestsPassed = pass;
  evidence.packedTestsFailed = fail;
  evidence.syntaxCheck = check.trim().split(/\r?\n/).at(-1);
  evidence.cliVersion = version;
  evidence.cliHelp = 'PASS';
  console.log(JSON.stringify({ result: 'PASS', ...evidence }, null, 2));
} finally {
  fs.rmSync(temp, { recursive: true, force: true, maxRetries: 3, retryDelay: 100 });
}
