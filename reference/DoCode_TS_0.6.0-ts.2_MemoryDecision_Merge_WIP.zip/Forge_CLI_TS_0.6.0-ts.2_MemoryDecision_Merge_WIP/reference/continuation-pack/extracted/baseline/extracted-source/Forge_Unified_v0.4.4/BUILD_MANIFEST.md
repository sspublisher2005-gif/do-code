# Build Manifest — Forge Unified 0.4.4 review build

Built locally on 2026-10-21. No npm publication, Git push, or deployment was performed. This bundle contains the executable source and tests; this release is still a review build, not production-certified software.

## Included executable source

- `bin/forge.js` — CLI entry point.
- `src/` — coding harness, provider paths, repository indexing, patch/checkpoint/policy controls, optional browser QA, audit, skill routing, bounded read-only specialists, project identity, explicit cross-project context import, encrypted project-bound sessions, session locks/crash marking, and opt-in disposable container verification.
- `tests/` — 129 unit/integration tests as verified in this release run, including sandbox policy/staging and a child-process SIGKILL session-recovery test.
- `scripts/check.mjs` — syntax validation.
- `scripts/verify-release.mjs` — creates and validates a fresh npm tarball, validates archive paths and required files, runs tests/syntax checks from extracted package, and checks CLI version/help.
- `scripts/real-sandbox-check.mjs` — opt-in integration probe for a real Docker engine.
- `.github/workflows/ci.yml` — configured Node 22 matrix for Ubuntu, Windows and macOS plus a real-Docker job; hosted results have not yet been observed.
- `skills/`, `integrations/`, `examples/`, `docs/` — reusable workflows, portable packs, examples and project/security documentation.
- `package-lock.json` — lockfile (zero external dependencies currently declared).
- `.npmignore` — excludes local logs/screenshots/evidence from the publishable npm tarball; the full-source ZIP still contains them.

## v0.4.4 changes in this build

- Sandbox command containers run as fixed numeric UID/GID `65532:65532`, even if Forge itself runs as root.
- The sanitized read-only input copy receives permissions that allow the unprivileged container user to read ordinary source files. This does not expose original host write access to the container.
- Built-in Node, Python, Go, Rust and generic Alpine image references are digest-pinned. Digests are immutability identifiers, not an assertion of publisher provenance or image safety.
- More cloud/CLI credential paths and directories are excluded from the sandbox staging copy.
- SIGKILL session crash/recovery regression test was added; custom sandbox image overrides now require explicit digest-pinned references and mutable tags fail closed.
- Dependency audit and fresh package self-verification are wired into CI.

## Fresh local verification

- `npm ci --ignore-scripts`: passed.
- `npm audit --audit-level=high`: reported 0 known vulnerabilities for the current zero-dependency package. This is not a source-code or image audit.
- `npm test`: 129 passed, 0 failed, 0 skipped.
- `npm run check`: 32 JavaScript modules passed syntax checks.
- `npm run check:release`: PASS; 121 packed entries, 129 package tests passed, 0 failed, 32 JavaScript files syntax-checked, CLI version/help passed. The exact fresh-tarball byte count is retained in `evidence/forge-v0.4.4-check-release.log`.
- A separate browser fixture was exercised using Python Playwright 1.57 with system Chromium 144. Form calculation, accessibility labels, mobile-fit assertion and no-console/page-error assertions passed; a seeded incorrect calculation was detected. Desktop/mobile screenshots and log are in `evidence/`. This is not proof of the Forge Node Playwright adapter.
- Full suite and release verification logs are in `evidence/`.

## Open release gates

No Docker, Podman, bwrap or firejail executable was available in the authoring environment. The fake-runtime suite passes, but the real-Docker integration workflow has not been executed and real container isolation is unverified. Image pulls/SBOM/vulnerability/signature checks could not be run. The actual Node Playwright adapter was not run against a website because its Node package was absent and dependency installation could not be relied on; the separate Python/Chromium fixture does not close this gap. No live model-backed coding task, hosted Linux/macOS/Windows run, independent security review, external customer study or matched competitor benchmark has been performed. Therefore Forge is not claimed complete or production-ready.
