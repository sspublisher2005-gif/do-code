# Start here — Forge Coding Harness 0.4.4

Requirements: Node.js 22+. Forge is an experimental coding-agent CLI, not a proven replacement for Codex CLI, Claude Code, OpenCode, or other incumbents.

```bash
npm test
npm run check
node bin/forge.js --help
node bin/forge.js doctor
node bin/forge.js sandbox status
```

v0.4.3 introduced the opt-in disposable container runner; v0.4.4 adds a fixed unprivileged container identity and digest-pinned built-in Node, Python, Go, Rust, and Alpine image references. It requires local Docker or Podman and a suitable image that is already present. Forge will not pull images automatically. On supported POSIX systems:

```bash
# Example only: load an approved image under your own image policy first.
docker pull node:22-bookworm-slim@sha256:c3de60bf2f9dd0ac6370e6117950ff62d6e339527e7472301c9c78a017978392
node bin/forge.js sandbox run -- npm test
```

Sandbox runs use a disposable sanitized copy and discard its changes. `forge run --sandbox-tests` explicitly opts recognized verification commands into that path; default tests and ordinary `forge command` remain host-executed after approval. Windows sandbox execution is currently unavailable and fails closed.

Read [Sandbox Execution](docs/SANDBOX_EXECUTION.md), [Remaining Work and Acceptance Gates](docs/REMAINING_WORK_AND_ACCEPTANCE_GATES_2026-10-21.md), and [Three-Expert Review](docs/THREE_EXPERT_REVIEW_2026-10-21.md) before using Forge with untrusted repositories.
