---
name: Accessibility Review
description: Check web interfaces for semantic structure, keyboard operation, focus behavior, contrast, labels, motion, and screen-reader support.
---

## Checklist
- Prefer native semantic HTML and correctly named controls.
- Verify every interaction by keyboard, visible focus, predictable tab order, and focus restoration after dialogs/routes.
- Provide labels/instructions and programmatic error associations; do not rely on placeholder text alone.
- Check contrast, zoom/reflow, target size, reduced-motion preferences, headings, landmarks, and meaningful alt text.
- Use automated tools as signals, not as proof of accessibility conformance.
- Test critical journeys with browser evidence and, when possible, assistive technology.
- Report the standard and coverage actually tested; never claim WCAG compliance from a quick scan alone.
