# Forge CLI — Security, Engineering, and Product-Design Audit

> **Current-state note (2026-10-20):** This document preserves the earlier snapshot and its historical test counts. The current harness/research audit supersedes those counts: see [`HARNESS_RESEARCH_AND_ADOPTION.md`](HARNESS_RESEARCH_AND_ADOPTION.md), [`SECURITY_AND_PRIVACY_CONTRACT.md`](SECURITY_AND_PRIVACY_CONTRACT.md), and [`../evidence/REPO_AUDIT_2026-10-20.md`](../evidence/REPO_AUDIT_2026-10-20.md). The current local run is 53/53 tests with 18 JavaScript files syntax-checked; live providers, live Context7, live Agent-Reach source searches, OS sandboxing, and hosted cross-platform CI remain unverified.

**Research and local-test date:** 2026-10-20 (Asia/Kolkata)  
**Status:** source-level audit with fixes and local regression tests; **not** a certification, third-party penetration test, or production-readiness sign-off.

## Executive verdict

Forge is a useful early prototype for a small, approval-first coding-agent runtime. Its strongest choices are that the model proposes structured output rather than directly using the filesystem, patch application is deterministic, context-sharing consent is explicit, tests require approval, and the final report can distinguish missing verification from success. Those are sensible building blocks, not proof of safety or high coding quality.

The core architecture should remain **plan → implement a bounded patch → validate → get approval → checkpoint → run approved verification → review evidence → report**. The priority is not to bolt on a large swarm of agents. First make each stage observable, resumable, testable, cross-platform, and difficult to trick into unauthorized side effects.

### Evidence-based conclusion

- **Strongly supported design guidance:** make verification a first-class loop, keep privileges narrow, isolate workspaces/processes, preserve task state explicitly, and stop repeated non-progress. Sources include the [Anthropic coding workflow guide](https://support.claude.com/en/articles/14554000-claude-code-power-user-tips), [OpenAI Codex CLI approval-mode documentation](https://help.openai.com/en/articles/11096431), [OpenCode permissions documentation](https://docs.opencode.ai/docs/permissions/), and [OWASP's 2025 prompt-injection guidance](https://genai.owasp.org/llmrisk/llm01-prompt-injection/).
- **Qualitative user pain signals:** public issue reports describe excessive “continue” interruptions, repeated work after context compaction, session-to-session memory loss, and usage consumed by loops. These are individual reports—not a representative user survey and not proof that every version of the relevant product has the problem.
- **What Forge has actually demonstrated here:** after this audit's changes, 29 local automated tests pass and 13 JavaScript files pass syntax checks. A fake-provider integration test exercises a workflow with synthetic responses. These do **not** prove real provider compatibility, cross-platform support, model quality, sandbox strength, or production security.

## What changed in the code during this audit

| Area | Change | Regression evidence | Residual limitation |
|---|---|---|---|
| OpenRouter credential safety | Only the official HTTPS `openrouter.ai/api/v1` origin/path is accepted; redirects are rejected. | Config tests reject hostile hosts, lookalike subdomains, and userinfo; request test checks `redirect: 'error'`. | A real API request was not made; the allowlist does not protect a compromised provider or OS. |
| Response resource bounds | OpenRouter response reading is capped; OpenCode stdout is capped and the child is stopped on overflow. | Tests cover OpenCode oversized stdout and mocked OpenRouter responses. | Provider internals, memory high-water marks, and every streaming/error case have not been measured. |
| OpenCode executable/environment | Project-local config cannot select an arbitrary binary; custom path is an operator-set `FORGE_OPENCODE_COMMAND` environment override. The child gets only an environment allowlist by default; cloud credentials and Node/runtime injection variables are not inherited by default. Provider keys can be explicitly allowlisted by the operator, but `OPENROUTER_API_KEY`, `FORGE_*`, and `OPENCODE_*` cannot be allowlisted. | Fake executable transport test and direct environment-builder regression test. | Default OpenCode launcher behavior on Windows remains unverified; provider-specific auth from shell requires explicit opt-in. |
| Checkpoint integrity | Checkpoints are authenticated with a user-local HMAC key and bound to the canonical workspace path. Embedded IDs, schemas, file paths, hashes, modes, and signature are validated before a checkpoint can be restored. | Added a forged-checkpoint test that attempts to delete an existing file and proves it is rejected. | Checkpoints depend on the same local user key and workspace path; moving the repository or losing the key means old checkpoints may not validate. Checkpoints from pre-HMAC versions are intentionally rejected as unsigned; use Git/backups rather than migrating untrusted metadata. The key must not be copied into the repo. |
| Audit-log resource use | Reads are bounded to the last 10 MiB to avoid unbounded allocation from an oversized repository-local log. | Syntax/test suite passes; large-log performance was not benchmarked separately. | The log can still grow on disk; reads beyond the retained window are intentionally unavailable. |
| Output redaction | Redaction is applied to common command output and top-level CLI errors before showing them to the user; secret path exclusions expanded. | Pattern and secret-path tests. | Redaction is heuristic. A novel/short/encoded secret can still escape detection. |
| Workflow resilience | Interactive mode catches task failures and remains usable instead of losing the prompt loop; repair patch warnings/history are included in final review/report. | Existing CLI/workflow tests plus syntax check. | The current correction pass is deliberately bounded; this is not a resumable autonomous loop. |
| Usage reporting | Task usage is associated with a run ID, and unknown provider cost remains unknown. | Existing audit/usage tests. | OpenCode usage/cost event semantics can vary by release/provider; reconcile with an actual account invoice before using as a billing record. |

## Current implementation, accurately described

### Agent architecture

The named roles—Orchestrator, Researcher, Architect/Planner, Coder, Tester, Reviewer, Security, and DevOps—are **not eight independently running agents**. The MVP performs a sequential workflow with model calls labelled by role and deterministic local controls around them. It does not have parallel subagent execution, isolated agent worktrees, a scheduler, shared durable event bus, independent context stores, or merge/conflict handling for concurrent writes.

Current flow:

1. Validate config and privacy mode; request consent before sending remote context.
2. Build a bounded repository map and select relevant source excerpts.
3. Ask the planner for a structured plan and target files.
4. Ask the coder for a unified diff; validate file paths and exact patch context.
5. Show the diff and risk warnings; require human approval before write; save checkpoint.
6. Suggest an allowlisted verification command; require approval before execution.
7. If an approved test fails, request explicit permission before sending failure output for one repair pass; independently validate and approve the correction.
8. Review the changes and evidence, summarize security flags, rollback and observed usage.

**Loop policy:** one bounded repair pass is safer than an unconstrained self-driving loop in a runtime that has no OS sandbox. Next iteration should add configurable caps and no-progress detection—not simply increase loop count.

### Privacy/data flow

- `forge init`, `doctor`, `index`, `search`, config display, and local audit inspection do not require a model inference request.
- In remote `privacy.mode=ask`, the task, repository map, selected source excerpts, and potentially test output are sent after consent. OpenRouter/OpenCode may apply their own retention and logging policies; Forge cannot promise provider-side zero retention.
- The direct OpenRouter key is read from `OPENROUTER_API_KEY`, not written to project config or the audit log. The API origin is pinned.
- `privacy.mode=local-only` is a model-ID guard. It is **not** a firewall and does not prove a proxy/provider endpoint is local. Use OS egress controls if “no network” is a hard requirement.
- Checkpoints contain pre-edit file contents and may contain sensitive information even when obvious credential files are excluded. `.forge/` should stay out of Git and be access-controlled.
- Secret exclusions and token-pattern redaction reduce accidental disclosure but are not a data-loss-prevention system.

## Product/platform readiness matrix

| Surface | Status as of this audit | What must happen before a credible release claim |
|---|---|---|
| Linux terminal | Local unit/integration tests pass in this Linux container. | Run matched tests against an installed real OpenCode release and at least one real model; test hostile repositories in an external sandbox. |
| macOS terminal | Not tested here. | Run test matrix on macOS, verify permissions, spawn behavior, file modes, and checkpoint restore. |
| Windows terminal | Not tested on a Windows host. Some command execution is explicitly adapted for Windows, but real OpenCode launch and interactive approvals are unverified. | CI on Windows; verify `.cmd`/`.exe` provider-launch behavior and prompt escaping; verify PowerShell consent UI, path/case edge cases, and undo. Use OpenRouter transport until OpenCode launch is validated if a user needs a Windows path that works today. |
| IDE extension (VS Code/JetBrains) | Not implemented. | Build a thin UI client around a stable local protocol; never let IDE callbacks bypass the same permission engine. |
| Browser/web app | Not implemented. No hosted task service, auth, workspace upload protocol, tenant isolation, or web interface exists. | Separate control plane from isolated execution workers; authenticate users, isolate workspaces and secrets, set retention/deletion controls, and prevent one tenant's repository or logs reaching another. |
| Desktop GUI | Not implemented. | Only build after CLI safety, resume, workspace, and cancellation behavior stabilize. |
| Mobile/remote handoff | Not implemented. | Requires a secure remote session service, identity/session controls, reconnect/resume, and clear approvals on the mobile client; don't expose local shell access directly to a public endpoint. |
| CI/headless mode | Basic CLI commands exist; the complete unattended workflow is not validated. | Add explicit non-interactive policy flags, bounded budget/timeout, machine-readable result schema, and fail-closed behavior when approval is unavailable. |
| GitHub/GitLab review and PRs | Not implemented. | Least-privilege app permissions, short-lived tokens, branch/worktree isolation, diff-only scopes, required checks, audit trail, and explicit publish/merge approval. |
| MCP/plugins/tools | Not implemented. | Tool manifest with schema, origin, required permissions, data-flow labels, timeouts, side-effect class and deny-by-default registration. |

## What good coding agents should optimize for

These are design requirements supported by official engineering/security guidance and observed public reports, not a claim that all users want the same thing.

### Correctness and proof, before confident prose

- Treat a passed acceptance test or reproducible check as stronger evidence than the model's self-assessment.
- Show exact changed files and diff, tests executed, failed/skipped checks, what was not tested, and the basis for any claim of completion.
- Add regression tests for bug fixes. For UI tasks, launch a browser and inspect the actual page; for APIs, exercise contracts; for mobile, use simulator/device tests; for infra, validate a plan and policy before deployment.
- A reviewer model is another fallible model, not an independent source of truth. Make objective checks deterministic and keep the human decision visible.

### Safe autonomy, without approval spam

- Use a least-privilege sandbox that constrains filesystem and network access. A prompt saying “don't do unsafe things” is not a sandbox.
- Define action classes: read-only; write inside approved workspace; execute approved test; network access; package install; credentials; Git push/PR/merge; deployment. Different classes need different policies.
- Pre-approve narrow, transparent low-risk operations where justified; always gate high-consequence operations (credential access, network egress, remote pushes, destructive filesystem changes, deploy/merge) and show the exact target.
- Stop after a repeated patch/test hash, identical failure with no changed hypothesis, exhausted budget, or expired deadline. Offer a resumable diagnosis rather than asking “continue?” after every tiny step.
- Don't solve permission fatigue by silently escalating authority. Prefer sandboxed execution plus auditable narrow rules.

### Context, memory, and continuity

- Persist concise task state: goal, acceptance criteria, completed phases, repository/worktree identity, changed paths and hashes, command/results, unresolved questions, last proven checkpoint, and remaining steps.
- Treat memory files and repository instructions as user/project content, not a new source of system authority. Record corrections as *suggested edits* to human-reviewable project rules, not hidden permanent policy.
- After context compaction or restart, re-anchor on the active goal and repository state. Check for progress before repeating discovery. Preserve failed attempts as structured evidence so the agent does not blindly rerun them.
- Summarize what has changed since the last checkpoint instead of repeatedly dumping entire conversation history.

### Cost, control, and UX

- Expose model, provider, task run ID, elapsed time, number of model calls, reported tokens/cost, and **unknown** usage when provider data is missing.
- Bound model calls, per-call output, total time and repair rounds; provide cancellation and a clear no-progress reason.
- Offer useful modes: Explain/Plan (read-only), Propose (dry-run), Apply with approval, and Sandbox Auto (only where OS isolation is verified). Don't blur their side-effect boundaries.
- Keep CLI output usable in scripts and accessible to beginners; add a full TUI or web UI only when it makes the workflow clearer, not as decoration.
- Show the smallest actionable ask: one patch, one command, one decision, and the risk/rollback implications.

## Research findings: official guidance

1. **Verification:** Anthropic's team-authored [Claude Code power-user guide](https://support.claude.com/en/articles/14554000-claude-code-power-user-tips) explicitly calls verification its most impactful practice and recommends domain-specific verification (tests, simulators, browser testing). It also describes worktrees, planning, memory, hooks, custom agents and permission scopes. This is vendor guidance from its own engineers, not an independent comparative study.
2. **Approval modes and sandboxes:** OpenAI's [Codex CLI guide](https://help.openai.com/en/articles/11096431) distinguishes a suggest/approval path from more autonomous operation in a sandboxed environment. Forge should provide similarly understandable modes only when its relevant containment mechanism is actually enforced. Current Forge has approval gates but not an OS sandbox.
3. **Least privilege:** OpenCode's [permissions guide](https://docs.opencode.ai/docs/permissions/) documents `allow`, `ask`, and `deny`, and its [tools guide](https://docs.opencode.ai/docs/tools/) says tools are enabled by default unless permissions are used to control them. Forge's generated OpenCode config uses deny-by-default permissions, but this configuration still requires a live-version contract test.
4. **Prompt injection:** [OWASP LLM01:2025](https://genai.owasp.org/llmrisk/llm01-prompt-injection/) describes prompt injection as a persistent risk and recommends least privilege, human approval for high-risk actions, clear separation of untrusted content, and adversarial testing. Repository instructions can be malicious; they must never override deterministic permission checks.
5. **Isolation:** Anthropic's [Claude Code sandboxing article](https://www.anthropic.com/engineering/claude-code-sandboxing) describes filesystem and network isolation and reports an 84% reduction in permission prompts in Anthropic's internal usage. That 84% is vendor-reported internal evidence, not an independently reproduced Forge result. The valuable engineering lesson is to use enforceable boundaries to reduce repetitive prompts.
6. **Role separation:** Aider's [architect/editor modes](https://github.com/Aider-AI/aider/blob/main/aider/website/docs/usage/modes.md) show a documented way to separate high-level architecture from editing. The documentation itself notes that a two-request architecture can add latency/cost. Forge's current planner/coder/reviewer roles are sequential prompts, not isolated agents.
7. **Benchmark quality:** OpenAI's [February 23, 2026 SWE-bench Verified reassessment](https://openai.com/index/why-we-no-longer-evaluate-swe-bench-verified/) reports possible data contamination and says at least 59.4% of a 27.6% audited subset had materially flawed tests/problem descriptions. Forge must not use SWE-bench Verified alone as a superiority claim. Use pinned tasks, exact versions, repeated runs, independent review and publish failures as well as successes.
8. **Control plane vs execution plane:** OpenAI's [sandbox-agent guide](https://developers.openai.com/api/docs/guides/agents/sandboxes) explicitly separates the harness (loop, model calls, policy, approvals, tracing, recovery and run state) from the compute sandbox (filesystem, commands, packages and network). This supports a future Forge design in which the trusted coordinator remains outside an isolated workspace; Forge's current subprocess temp directory is not that sandbox.
9. **One harness, multiple surfaces:** OpenAI's [Codex-as-a-platform article](https://developers.openai.com/blog/codex-as-a-platform) describes bringing the underlying harness into different workflows rather than forcing everyone into one UI. Product implication for Forge: stabilize a local protocol, run state, policy engine and machine-readable results first; then make terminal/IDE/web clients share those controls rather than re-implementing separate safety logic.
10. **Avoid instruction bloat:** OpenAI's [September 2026 guidance on skills and prompts](https://developers.openai.com/blog/rethinking-skills-and-prompts-for-gpt-6-astra) recommends revisiting accumulated instructions and keeping skills/prompts focused as models evolve. Combined with user reports of context overhead, Forge should retrieve narrow project guidance progressively, deduplicate it, and measure prompt size rather than blindly concatenating more rules.

## Public user-feedback signals: what bothers users

These examples were opened/read as individual public GitHub issue reports. They are qualitative signals only; reports may be incomplete, duplicates, unresolved, or version-specific.

| Report | User-reported problem | Design response for Forge |
|---|---|---|
| [Claude Code #59977](https://github.com/anthropics/claude-code/issues/59977), opened May 17, 2026 | Reporter says the agent stopped after each fix awaiting “continue,” about ten times in one session. | Continue through safe deterministic steps inside a bounded budget; ask at meaningful authority boundaries rather than every loop step. |
| [Claude Code #72745](https://github.com/anthropics/claude-code/issues/72745), opened July 1, 2026 | Reporter describes repeated failed approaches and missing continuity across sessions. | Durable run ledger with attempts, results, changed state and next step. |
| [Codex #29354](https://github.com/openai/codex/issues/29354), opened June 21, 2026 | Reporter describes repeated pre-write inspection/context-compaction loops without implementation. | Persist execution frontier and detect “same inputs/same plan/no state change” before repeating. |
| [Codex #47707](https://github.com/openai/codex/issues/47707), opened September 24, 2026 | Reporter describes repeated or semantically equivalent outputs after compaction, one observation around 288 repeated turns. | Hard max-iteration/time/token budgets, response/patch fingerprints, repeated-failure circuit breaker and visible stop reason. |
| [Codex #55281](https://github.com/openai/codex/issues/55281), opened October 19, 2026 | Reporter alleges a repetitive agent loop consumed usage quota rapidly. | Per-run call/usage ledger, budget cutoff and an operator-visible no-progress warning. |
| [Codex #47418](https://github.com/openai/codex/issues/47418), opened September 23, 2026 | Windows user reports inability to create the agent sandbox after an update. | Windows CI and fail-closed diagnostic when required isolation cannot be provisioned. |

Additional community signals from Reddit (also anecdotal, self-selected posts):

- In [r/LocalLLaMA](https://www.reddit.com/r/LocalLLaMA/comments/1vavh2h/software_engineers_do_you_honestly_get_anything/), a July 2026 post with 344 upvotes describes repeated outputs, instruction/methodology drift, superficial tests, and agents adding technical debt. This is a high-engagement complaint, but not proof of population-wide prevalence.
- In [r/LocalLLaMA](https://www.reddit.com/r/LocalLLaMA/comments/1rr5fo5/why_ai_coding_agents_waste_half_their_context/), a March 2026 post reports 15–20 tool calls spent locating code before implementation. The actionable design question is whether repository navigation can be more targeted and whether context use is observable; the claimed degradation after many calls is the poster's experience, not an independently verified universal model effect.
- In [r/LocalLLaMA](https://www.reddit.com/r/LocalLLaMA/comments/1u6mmuu/local_coding_agents_are_good_now_but_only_if_you/), a June 2026 post describes agents being useful for small tasks but requiring a person to inspect diffs and rerun tests when they make unrelated changes. In [r/codex](https://www.reddit.com/r/codex/comments/1x9cmqv/am_i_using_codex_wrong_fast_progress_initially/), an October 18, 2026 post describes strong early progress followed by a costly final stretch. These reinforce a need to measure verified acceptance-criteria progress—not token consumption, code volume, or “task completed” messaging.
- In [r/LocalLLaMA](https://www.reddit.com/r/LocalLLaMA/comments/1rwiaw8/best_private_and_local_only_coding_agent/), a March 2026 thread asks for stable local-model support, sensible permissions, automatic context selection, and no telemetry. It expresses a real segment's priorities, not all users' priorities.

**Important interpretation:** public issues and Reddit discussions are not prevalence data and are affected by self-selection. We can say runaway loops, context loss, instruction drift, excessive navigation, unverified completion claims, and cost/quality plateaus are reported failure modes; we cannot say these are objectively the “most hated things” across all coding-agent users without a representative survey.

## Video review: what was and was not reviewed

I retrieved the official YouTube listing/description metadata and companion documentation. The YouTube player itself did not expose playable frames/audio in the research interface. I inspected a transcript-indexed page for OpenAI's Codex walkthrough and third-party synopsis/chapter notes for Anthropic's talk, then cross-checked the takeaways against current official documentation. For Codex, the available indexed transcript emphasizes multiple usage surfaces and especially `AGENTS.md` for repeatable project context, environment setup, prompting patterns, MCP and headless/SDK workflows. For Claude Code, the available secondary summaries emphasize planning before editing, exploring the repo with targeted tools, persistent project instructions, permissions, verification, early interruption when the plan is wrong, and parallel sessions only for independent work. These are secondary/indexed sources, not official full transcripts; this report does **not** claim to have literally watched either video end-to-end or quote either speaker verbatim.

- [Anthropic — “Claude Code best practices | Code w/ Claude”](https://www.youtube.com/watch?v=gv0WHhKelSE), published July 31, 2025; the description says it was presented at Code w/ Claude on May 22, 2025. The available listing confirms topic/speakers, while specific implementation recommendations above are grounded mainly in the current official power-user documentation linked earlier—not invented video quotes.
- [OpenAI — “Getting started with Codex”](https://www.youtube.com/watch?v=px7XlbYgk7I), published January 12, 2026. The listing provides chapters for CLI/IDE installation, project setup, `AGENTS.md`, prompting, IDE/CLI workflows, MCP and headless/SDK workflows. The platform description—not a transcript—was the available evidence for the chapter list.

For a follow-up evidence pass with full video extraction, obtain official transcripts where available and cite timestamped transcript passages. Do not treat view counts or marketing demos as quality benchmarks.

## Loop-engineering recommendation

Do not implement a never-ending “Ralph loop” in the current runtime. Implement a state machine with explicit, durable phases:

`DISCOVER → PLAN → PATCH → STATIC CHECKS → APPROVAL → APPLY → VERIFY → (REPAIR, bounded) → REVIEW → REPORT`

Required loop guardrails:

- Store `runId`, phase, goal hash, repository/worktree identity, current diff hash, verification command/result hash, attempt number, last error signature, cost/time counters, and unresolved issues.
- Default `maxRepairRounds` to 1 initially (current behavior). Make increases opt-in and capped, e.g. at most 2 further repairs after test fixtures prove no regressions.
- Stop if the same patch hash repeats, same test failure signature repeats without a changed patch, no file/test state changes after a phase, budget/time cap is reached, or approval is refused.
- Only automatically repeat **read-only or sandboxed verification** actions that have passed risk review. Require human approval for writes until actual OS isolation is available.
- On stop, save progress, show the evidence that blocked completion and make resume explicit. Never tell the user a task “succeeded” because the model says it did.

## Prioritized implementation plan

### P0 — release-blocking correctness and safety

1. Run CI on Linux, Windows and macOS. Add real OpenCode compatibility testing on the exact supported version; if Windows `.cmd` launch remains unsupported, display that clearly and prefer the direct OpenRouter path there.
2. Run a real OpenRouter smoke test only in an opt-in environment with a disposable public fixture and cost limit. Keep mocked tests for deterministic CI; never put secrets in logs.
3. Run untrusted build/test commands inside an OS/container sandbox with explicit filesystem/network policy before advertising unattended autonomy. Forge itself currently has no such sandbox.
4. Adversarial test prompt injection, forged checkpoints, symlink/race attempts, credential-bearing outputs, patch edge cases, approval refusal, timeout/cancellation, and interrupted multi-file writes.
5. Document the HMAC checkpoint key and backup/recovery behavior. Never sync/share the key into the code repository.

### P1 — loop quality and continuity

1. Persist task state between processes with a versioned schema and resume command.
2. Add no-progress detection (patch/diff hashes, repeated failure fingerprints, state-change verification), maximum model calls and budget/time cutoffs.
3. Make tests and diagnostics domain-specific: browser test for web UI; typecheck/lint/test per detected project; avoid treating a reviewer response as a passing test.
4. Build a held-out benchmark suite with bug-fix, feature, regression, monorepo, secret, prompt-injection and context-stress cases. Publish exact environment, costs and failures.
5. Expand credential/path tests and harden symlink/TOCTOU and partial-write recovery with OS-specific isolation primitives where feasible.

### P2 — useful agent teams

1. Add specialist roles only when an experiment proves value (e.g. independent security review); report additional model calls and costs.
2. Add read-only subagents first; use independent Git worktrees or a true isolated workspace for any writing agent.
3. Merge only reviewable, non-overlapping patches; no concurrent writers on the same workspace without a conflict protocol.

### P3 — more platforms and ecosystem

1. Define a stable local daemon/protocol first, then build a VS Code/JetBrains client and a small web UI.
2. For a web-hosted product, create isolated execution workers, tenant-scoped storage, short-lived credentials, access/retention/deletion controls, quotas and audit export before exposing it publicly.
3. Add MCP and GitHub/GitLab integrations only after tool-level permissions, network controls and supply-chain review work end-to-end.
4. Desktop/mobile/remote-control flows must preserve approval semantics, show current workspace and branch, allow cancellation, and resume from durable state.

## Local validation record

Environment: Node.js `v22.16.0`, npm `10.9.2`, Linux container. Runtime package dependencies: zero. Current result after this audit:

```text
npm test       29 passed, 0 failed, 0 skipped
npm run check  Syntax OK: 13 JavaScript files checked
```

The suite includes a fake OpenCode executable and mocked OpenRouter fetch response. `opencode` was not installed in this container; no live provider API request was made. macOS and Windows test runs have not been performed here. The existing synthetic end-to-end trace uses fake model output and synthetic usage/cost values. This validation is repeatable but is not a formal security audit.

## References

- [OpenAI Codex CLI getting started](https://help.openai.com/en/articles/11096431)
- [OpenAI “Why we no longer evaluate SWE-bench Verified” (2026-02-23)](https://openai.com/index/why-we-no-longer-evaluate-swe-bench-verified/)
- [Anthropic Claude Code power-user tips](https://support.claude.com/en/articles/14554000-claude-code-power-user-tips)
- [Anthropic Claude Code sandboxing (2025-10-20)](https://www.anthropic.com/engineering/claude-code-sandboxing)
- [OpenCode permissions](https://docs.opencode.ai/docs/permissions/)
- [OpenCode tools](https://docs.opencode.ai/docs/tools/)
- [OpenAI sandbox-agent architecture (control plane vs execution plane)](https://developers.openai.com/api/docs/guides/agents/sandboxes)
- [OpenAI Codex as a platform (2026-08-19)](https://developers.openai.com/blog/codex-as-a-platform)
- [OpenAI on revisiting skills and prompts (2026-09-11)](https://developers.openai.com/blog/rethinking-skills-and-prompts-for-gpt-6-astra)
- [OWASP LLM01:2025 Prompt Injection](https://genai.owasp.org/llmrisk/llm01-prompt-injection/)
- [Aider architect/editor modes](https://github.com/Aider-AI/aider/blob/main/aider/website/docs/usage/modes.md)
- [Anthropic official video listing](https://www.youtube.com/watch?v=gv0WHhKelSE); [third-party synopsis and timestamp outline](https://podwise.ai/episodes/4846070) and [independent viewer's summary](https://abhaybagda.com/writing/watched-claude-best-practices-video/) (secondary sources, cross-checked with official docs)
- [OpenAI official video listing](https://www.youtube.com/watch?v=px7XlbYgk7I); [available transcript-indexed synopsis for Codex](https://glasp.co/youtube/px7XlbYgk7I) (third party, not official)
- Reddit discussion samples (anecdotal, not representative): [r/LocalLLaMA—agent quality/technical debt](https://www.reddit.com/r/LocalLLaMA/comments/1vavh2h/software_engineers_do_you_honestly_get_anything/), [context/tool-call overhead](https://www.reddit.com/r/LocalLLaMA/comments/1rr5fo5/why_ai_coding_agents_waste_half_their_context/), [babysitting loop](https://www.reddit.com/r/LocalLLaMA/comments/1u6mmuu/local_coding_agents_are_good_now_but_only_if_you/), [early progress then plateau](https://www.reddit.com/r/codex/comments/1x9cmqv/am_i_using_codex_wrong_fast_progress_initially/), [privacy/local-agent priorities](https://www.reddit.com/r/LocalLLaMA/comments/1rwiaw8/best_private_and_local_only_coding_agent/).
- Public issue examples: [Claude #59977](https://github.com/anthropics/claude-code/issues/59977), [Claude #72745](https://github.com/anthropics/claude-code/issues/72745), [Codex #29354](https://github.com/openai/codex/issues/29354), [Codex #47707](https://github.com/openai/codex/issues/47707), [Codex #55281](https://github.com/openai/codex/issues/55281), [Codex #47418](https://github.com/openai/codex/issues/47418).
