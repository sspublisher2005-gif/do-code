# Forge roadmap and release gate

## Milestones

| Milestone | Scope | Acceptance gate | Current status |
|---|---|---|---|
| M1 — Core CLI + OpenCode adapter | CLI/config, JSON-only model adapter, basic planner/coder/reviewer, consent | Unit tests; adapter tested against supported OpenCode release; malformed outputs fail closed | **Partially complete** — local core tests pass; live OpenCode/GLM adapter not tested here. |
| M2 — Repo context engine | Bounded local map, symbols/import hints, ranking, `FORGE.md` | Relevance benchmark on small/medium/monorepo fixtures; no secret fixtures included | **Basic implementation complete** — heuristic, not AST/LSP/semantic. |
| M3 — Safe patch, shell, git and tests | Unified diff apply, approval, snapshots, undo, approved test loop | Malformed patch/path/symlink/race tests; test command approval test; rollback integration | **Basic implementation complete** — no OS sandbox; Git status only. |
| M4 — Multi-agent orchestration | Structured role handoffs and selective subagents | Demonstrate improvement vs sequential workflow on held-out tasks, capped cost and concurrency | **Basic sequential role workflow only** — no parallel child-agent runtime. |
| M5 — Security/privacy | Data consent, tool-denied OpenCode config, secret/path checks, audit | Live-provider and adversarial tests; Windows test; threat model review | **Partially complete** — local tests only, isolation not yet verified against live OpenCode. |
| M6 — MCP and extensions | Declared tool schemas, permissions, isolated extension execution | Threat review and abuse tests for every extension boundary | **Not implemented**. |
| M7 — Benchmarks and optimization | Baselines, task benchmark, overhead, context and cost metrics | Replicable report, no unsupported superiority claim | **Plan defined; preliminary no-model latency sanity baseline recorded; full suite pending**. |

## Priority order

1. **Execution isolation is the release blocker:** create a local, OS-specific sandbox backend with workspace-only writes, explicit network policy, minimal privileges, resource limits, and no ambient secrets. Until this exists, only run untrusted repos inside an external disposable VM/container.
2. Run the OpenCode adapter against a pinned, supported CLI build and verify the exact effective tool/plugin deny policy; test OpenRouter with an opt-in low-risk live smoke test.
3. Run the current GitHub Actions matrix on Windows, Linux, and macOS. Add cancellation/process-tree and filesystem race tests on each OS.
4. Add a deterministic adversarial suite inspired by AgentDojo: malicious README/comments/test output, fake role markers, split/encoded injection, indirect credential exfiltration attempts, and false-positive tracking. A detector warning is not evidence of blocking.
5. Make the task loop an explicit persisted state machine with hashes, stop reasons, retry/token/time budgets, repeated-patch detection, and crash-safe resume.
6. Build held-out quality/retrieval/cost benchmarks before adding parallel specialist agents; compare against the same tasks/models and publish exact test conditions.
7. Improve repo map incrementally with deterministic symbol/import maps and package boundaries before embeddings or a vector DB.
8. Add optional Internet research only through a provenance-aware source adapter: user query alone by default, visible citations and timestamps, no source-authorized actions, and no private project context sent to search automatically.
9. MCP/plugins last, after every tool has a declarative scope, user-facing data-sharing disclosure, prompt-injection evaluation, and an isolated execution boundary.

## Audit follow-up

See [`RESEARCH_AND_DESIGN_AUDIT.md`](RESEARCH_AND_DESIGN_AUDIT.md) for current official-source research, documented user-feedback examples, evidence limits, the cross-platform readiness matrix, and the prioritized security/loop-engineering plan. A Linux/Windows/macOS GitHub Actions matrix is configured in `.github/workflows/ci.yml`; it is not yet evidence of hosted-platform success because this workspace cannot run those hosted jobs. Actions are pinned to the verified current full commit SHAs for checkout v7.0.1 and setup-node v7.1.0 (reviewed 2026-10-20).

## Known limitations

- The installed OpenCode binary is absent in the build container; a real GLM 5.3 Flash completion, JSON event format, `--pure`, `OPENCODE_CONFIG_CONTENT`, and tool-denial behavior have not been tested together.
- No model quality or benchmark score is claimed. Token/cost event parsing is best effort and could differ between OpenCode versions/providers.
- Multi-agent mode is currently sequential role prompting/helper logic. No agent scheduler, parallel execution, independent context database, shared message queue, or conflict resolution.
- No true interactive TUI; terminal interaction is a simple prompt loop.
- Local index uses bounded regular expressions and file/path lexical ranking. Import hints are not a real dependency graph; monorepo scopes are not resolved.
- No AST-level parser, language server, semantic index, embeddings, database, or incremental cache.
- Patch parser supports update/create only; not delete/rename, binary changes, complex copy metadata, or mode changes. It does not implement all edge cases of Git's patch parser.
- Shell commands are not sandboxed. A user-approved test/build may execute arbitrary repo scripts and access user/network resources.
- `forge undo` supports only the latest unused Forge checkpoint; it is not a general file-history tool and refuses when hashes differ.
- Secret detection/redaction is pattern based. Don't treat it as a data-loss-prevention product.
- GitHub/GitLab integration, PR creation, provider routing/fallback, direct OpenAI/Anthropic/Google API adapters, MCP and custom tools are not implemented.
- Cold-cache startup time, resident memory, install size on users' machines, provider costs, coding quality and competitor performance have not been benchmarked. Warm-loop local no-model latency sanity checks are recorded in `docs/BENCHMARKS.md`.
- Public-code research is source-backed only for selected files; all target tools have not been installed and black-box tested. See research evidence scope.
