# Architecture comparison: where Forge fits

## Summary

Forge's intended differentiator is not having the longest list of tools or the largest agent team. It is a small, inspectable action control plane that accepts model proposals but owns workspace writes, test execution approval and rollback state. The current MVP only partially realizes this; it is not yet a stronger all-around agent than existing tools.

| System | Architecture pattern evidenced here | Strong lesson | Tradeoff / unknown | Forge response |
|---|---|---|---|---|
| Claude Code | Commercial terminal agent with documented authentication/configuration and subagents | Mature terminal workflow and higher-level delegation can be valuable | Runtime source and black-box behavior unavailable in this pass | Study public surfaces; no clone; keep internal behavior claims unknown until tested. |
| OpenCode | Configurable open-source CLI/model/tool layer, JSON events and per-agent tool permissions documented | Model provider, tools and agent role are separable; config can constrain capabilities | Exact current run-loop source and Forge adapter compatibility not yet verified | Use it only as text adapter with temporary project, no-tools config and `--pure`; live test is a blocker. |
| Codex CLI | Native Rust CLI/TUI/application loop; usage/thread information appears in source | Explicit app runtime, thread/session IDs and usage reporting | Need inspect full sandbox path and subagent coordination | Use local audit/checkpoint contracts; compare behavior only after pinned test runs. |
| Hermes | Multi-module model loop with retries, fallback, tool dispatch, context compression and SQLite-backed persistence documented/source inspected | Recovery and context lifecycle deserve explicit state machines | More dependencies and provider/tool/plugin surface; cost/concurrency require limits | Add task state and recovery incrementally; don't begin with full agent swarm. |
| Pi | Minimal terminal harness with provider/extension APIs, sessions and lossy compaction | Small core + optional extensions is a good complexity baseline | Extensions can run with system permissions; native multi-agent not established here | Keep core lean, don't auto-load arbitrary tools, separate historical transcript from compact active context later. |
| Antigravity CLI | Vendor-described keyboard-first terminal interface sharing engine with desktop | Efficient terminal interaction and resumable session UX are worth evaluating | Backend, policy and resource behavior unknown | Learn only from public docs/controlled behavior; no assumptions about internals. |
| Harness2 | Meta-harness component tuning: prompts, guardrails, memory, subagents, skills, scripts, plugins | Systematic component ablation and benchmarks are useful methods | Not a directly equivalent coding CLI; own benchmark claims not reproduced | Adopt benchmark discipline, not an eight-layer config surface in MVP. |
| Aider | Central coder loop with message handling and edit application; architect/editor chat modes | Split planning from edit translation when task complexity warrants it | Edit formats and Git/test workflow require full tests | Use one planner for complex changes; direct minimal path for small changes. |
| Mini-SWE-Agent | Compact model-query/action/environment loop | Tiny loop is auditable and cost can be first-class | Safety depends on the selected environment; no guarantee from simple loop alone | Minimal role pipeline, but stricter explicit approval and checkpoints. |
| Gemini CLI | Streaming model client with retry helper/function-call sequencing; documented permission/checkpoint features | Preserve tool-call/result ordering and checkpoint before mutations | Google-focused provider path; current runtime wasn't executed | Keep adapter protocol strict; local checkpoint and approval are explicit. |
| OpenHands | SDK, tool and workspace packages; optional agent server and Docker/remote workspaces | Execution environment is an architectural concern, not a prompt field | More packages/deployment complexity | Later integrate a real workspace sandbox; no server in initial zero-budget CLI. |
| OpenClaw | Gateway and configurable per-agent tool sandbox; docs say sandbox off by default in cited default | Sandbox activation/which process is isolated must be explicit | Broad gateway/integration surface raises policy audit scope | Never state “sandboxed” without runtime proof; no gateway service in Forge. |
| Goose | Agent + interface + extension architecture with MCP/ACP integration docs | Extension protocols can reduce tool implementation duplication | Extension process/auth/policy surface needs governance | Defer MCP/ACP until core policy and schema are stable. |
| Cline | SDK/CLI/IDE surfaces, tool policies and workflow hooks | Per-tool enable/approval rules are the right abstraction | SDK docs' unlisted tools default to enabled/auto-approved; must configure explicitly | Deny unknown tools by default, require explicit manifest and policy. |

## Seven subsystem decision record

### 1. Agent loop

Start with a sequential state machine: consent → map → plan → propose patch → validate → approve → checkpoint → apply → approve/run tests → optional repair → review → report. Each step should have a timeout, structured result, audit event, and single exit path. Add retries only around provider/network failures that are safe to retry; never automatically retry writes or destructive shell commands.

### 2. LLM integration

Adapter normalizes prompt, model ID, timeout, structured output, token/cost fields and errors. OpenCode is first transport only. A single `ModelAdapter` interface should later support direct compatible endpoints, Google and Anthropic without making the core loop provider-specific. Credentials must never be copied into prompts or logs.

### 3. Tools/actions

Keep a small hard-coded set in MVP: repository index/read excerpts, diff parse/apply, allowlisted command execution, local Git status, audit/checkpoint. A future registry must expose schemas and risk metadata. Model-provided function calls remain proposals until Forge dispatches through the permission layer.

### 4. Memory/context

Bound context via lexical map, relevant-file ranking and source excerpts. `FORGE.md` is human-reviewed project guidance. Long-running sessions later need a versioned task-state file with current plan, evidence, decisions, touched paths, verification and unresolved questions. Do not conflate permanent memory with a lossy context summary.

### 5. Safety/permissions

Default deny unknown tools. Approval for network, package install, file delete, secret access, CI/CD edits, Git remote/force operations and unknown scripts. A prompt check is not sandboxing; use OS-level isolation for untrusted code. Keep audit events and avoid storing full source/prompt bodies.

### 6. Orchestration

Use the fewest roles needed. Research/review can be concurrent only after isolated context and output schemas exist; two workers must not write the same tree at once. Cap concurrency and cost and ensure the orchestrator cannot approve its own dangerous action.

### 7. Extensibility

Do not expose dynamic plugin loading in MVP. Plan explicit manifests, schema validation, permission class, timeout, redaction contract, child-process/MCP isolation and audit attribution. Plugin signing and sandboxing require their own threat model.

## Original design decisions

- Forge's core is dependency-free JavaScript, not a thin wrapper around another harness's prompt loop.
- The default OpenCode process lives in a temp working directory, has external plugins disabled, and is intended to be text-only.
- Only the Forge patch applier writes workspace files.
- Apply and undo require hash preconditions.
- Tests are explicit executable code, therefore approved and reported as unverified when omitted/declined.
- No autonomous network use, package installation, remote Git operation or PR action in the initial agent loop.
- No cloud backend, telemetry, vector database or mandatory paid infrastructure.
