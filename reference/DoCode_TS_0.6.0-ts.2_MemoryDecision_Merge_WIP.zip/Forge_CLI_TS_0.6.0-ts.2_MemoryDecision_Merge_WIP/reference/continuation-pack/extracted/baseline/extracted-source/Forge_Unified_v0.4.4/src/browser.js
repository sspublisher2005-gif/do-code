import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import net from 'node:net';
import dns from 'node:dns/promises';
import { createRequire } from 'node:module';
import { randomUUID } from 'node:crypto';
import { safeTerminalText, redactSecrets, truncate, ensureRealDirectory, sha256 } from './utils.js';
import { scanPromptInjection } from './security.js';

const MAX_ISSUES = 40;
const MAX_ERROR_CHARS = 700;
const DEFAULT_TIMEOUT_MS = 20000;
const MAX_TIMEOUT_MS = 60000;
const SAFE_BROWSER_ARGS = [
  '--disable-extensions', '--disable-background-networking', '--disable-sync',
  '--disable-default-apps', '--no-first-run', '--metrics-recording-only',
];

function parsePackageJson(root) {
  try {
    const file = path.join(root, 'package.json');
    const info = fs.lstatSync(file);
    if (info.isSymbolicLink() || !info.isFile() || info.size > 1024 * 1024) return {};
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch { return {}; }
}

function dependencyDeclared(root, name) {
  const pkg = parsePackageJson(root);
  return ['dependencies', 'devDependencies', 'optionalDependencies', 'peerDependencies'].some((group) => Object.hasOwn(pkg[group] || {}, name));
}

function globalNodeModuleRoots() {
  const roots = [];
  if (process.env.FORGE_GLOBAL_NODE_MODULES) roots.push(path.resolve(process.env.FORGE_GLOBAL_NODE_MODULES));
  if (process.env.NODE_PATH) roots.push(...process.env.NODE_PATH.split(path.delimiter).filter(Boolean).map((item) => path.resolve(item)));
  roots.push(path.resolve(path.dirname(process.execPath), '..', 'lib', 'node_modules'));
  roots.push(path.resolve(path.dirname(process.execPath), '..', 'node_modules'));
  if (process.platform === 'win32' && process.env.APPDATA) roots.push(path.join(process.env.APPDATA, 'npm', 'node_modules'));
  roots.push(path.join(os.homedir(), '.npm-global', 'lib', 'node_modules'));
  return [...new Set(roots)];
}

export function resolvePlaywright(root, { requireImpl = createRequire } = {}) {
  const reasons = [];
  const candidates = [];
  const declared = ['playwright', 'playwright-core'].filter((name) => dependencyDeclared(root, name));
  for (const name of declared) {
    try {
      const requireFromProject = requireImpl(path.join(root, 'package.json'));
      const entry = requireFromProject.resolve(name);
      candidates.push({ name, entry, require: requireFromProject });
    } catch (error) { reasons.push(`${name} declared but unavailable: ${String(error.message).slice(0, 120)}`); }
  }
  // Global module lookup is an explicit operator-installed tool path, not a project-configured executable.
  for (const moduleRoot of globalNodeModuleRoots()) {
    for (const name of ['playwright', 'playwright-core']) {
      try {
        const requireFromGlobal = requireImpl(path.join(moduleRoot, '__forge_resolver__.cjs'));
        const entry = requireFromGlobal.resolve(name);
        candidates.push({ name, entry, require: requireFromGlobal });
      } catch { /* Not installed in this global root. */ }
    }
  }
  // A deliberate operator override can point to a reviewed automation module.
  if (process.env.FORGE_PLAYWRIGHT_MODULE) {
    const absolute = path.resolve(process.env.FORGE_PLAYWRIGHT_MODULE);
    try {
      if (fs.lstatSync(absolute).isFile() && !fs.lstatSync(absolute).isSymbolicLink()) {
        const request = requireImpl(path.join(path.dirname(absolute), '__forge_resolver__.cjs'));
        candidates.unshift({ name: 'operator module', entry: absolute, require: request });
      }
    } catch (error) { reasons.push(`FORGE_PLAYWRIGHT_MODULE invalid: ${String(error.message).slice(0, 120)}`); }
  }
  for (const candidate of candidates) {
    try {
      const impl = candidate.require(candidate.entry);
      const chromium = impl?.chromium ?? impl?.default?.chromium;
      if (chromium && typeof chromium.launch === 'function') return { available: true, packageName: candidate.name, path: candidate.entry, chromium, reasons };
      reasons.push(`${candidate.name} does not export a Chromium launcher`);
    } catch (error) { reasons.push(`${candidate.name} could not load: ${String(error.message).slice(0, 140)}`); }
  }
  return { available: false, packageName: null, path: null, chromium: null, reasons };
}

function canExecute(filePath) {
  try {
    const info = fs.statSync(filePath);
    return info.isFile() && (process.platform === 'win32' || (info.mode & 0o111) !== 0);
  } catch { return false; }
}

function findOnPath(command, env = process.env) {
  const pathValue = env.PATH || env.Path || env.path || '';
  const extensions = process.platform === 'win32' ? (env.PATHEXT || '.EXE;.CMD;.BAT').split(';') : [''];
  for (const directory of pathValue.split(path.delimiter).filter(Boolean)) {
    for (const extension of extensions) {
      const candidate = path.join(directory, `${command}${extension}`);
      if (canExecute(candidate)) return candidate;
    }
  }
  return null;
}

export function findBrowserExecutable({ env = process.env, root = process.cwd() } = {}) {
  const override = env.FORGE_BROWSER_EXECUTABLE;
  if (override) {
    const absolute = path.resolve(override);
    if (!canExecute(absolute)) throw new Error('FORGE_BROWSER_EXECUTABLE must point to an executable browser file.');
    return absolute;
  }
  const commands = process.platform === 'win32'
    ? ['chrome', 'msedge', 'chromium', 'chromium-browser']
    : process.platform === 'darwin'
      ? ['google-chrome', 'chromium', 'chromium-browser', 'msedge']
      : ['chromium', 'chromium-browser', 'google-chrome', 'google-chrome-stable', 'msedge'];
  for (const command of commands) {
    const found = findOnPath(command, env);
    if (found) return found;
  }
  const known = process.platform === 'win32'
    ? [path.join(env.PROGRAMFILES || 'C:\\Program Files', 'Google', 'Chrome', 'Application', 'chrome.exe'), path.join(env['PROGRAMFILES(X86)'] || 'C:\\Program Files (x86)', 'Microsoft', 'Edge', 'Application', 'msedge.exe')]
    : process.platform === 'darwin'
      ? ['/Applications/Google Chrome.app/Contents/MacOS/Google Chrome', '/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge', '/Applications/Chromium.app/Contents/MacOS/Chromium']
      : ['/usr/bin/chromium', '/usr/bin/chromium-browser', '/usr/bin/google-chrome', '/usr/bin/microsoft-edge'];
  for (const candidate of known) if (canExecute(candidate)) return candidate;
  return null;
}

export function validateBrowserUrl(raw) {
  if (typeof raw !== 'string' || raw.length > 4096 || /[\u0000-\u001f\u007f]/.test(raw)) throw new Error('Browser URL must not contain control characters and must be a valid HTTP(S) URL of at most 4096 characters.');
  let url;
  try { url = new URL(raw); } catch { throw new Error('Use a complete URL such as http://127.0.0.1:5173 or https://example.com.'); }
  if (!['http:', 'https:'].includes(url.protocol)) throw new Error('Browser URL must use HTTP or HTTPS. file:, data:, javascript: and browser-internal URLs are blocked.');
  if (url.username || url.password) throw new Error('URLs containing embedded credentials are blocked.');
  if (!url.hostname) throw new Error('Browser URL must have a hostname.');
  return url;
}

export function safeUrlLabel(raw) {
  try {
    const url = new URL(raw);
    const pathLabel = url.pathname.split('/').map((part) => {
      if (/^(?:token|access_token|auth|session|secret|key|credential)$/i.test(part)) return '[redacted]';
      if (part.length > 36 || /^[A-Za-z0-9_-]{24,}$/.test(part)) return '[id]';
      return part;
    }).join('/');
    return `${url.origin}${pathLabel}`.slice(0, 500);
  } catch { return '[invalid URL]'; }
}

function ipv4ToInt(address) {
  const nums = address.split('.').map(Number);
  if (nums.length !== 4 || nums.some((n) => !Number.isInteger(n) || n < 0 || n > 255)) return null;
  return (((nums[0] * 256 + nums[1]) * 256 + nums[2]) * 256 + nums[3]) >>> 0;
}
function inV4Range(ip, base, maskBits) {
  const value = ipv4ToInt(ip); const netValue = ipv4ToInt(base);
  if (value === null || netValue === null) return false;
  const mask = maskBits === 0 ? 0 : (0xffffffff << (32 - maskBits)) >>> 0;
  return (value & mask) === (netValue & mask);
}
function isPrivateIpv4(ip) {
  return [
    ['0.0.0.0', 8], ['10.0.0.0', 8], ['100.64.0.0', 10], ['127.0.0.0', 8],
    ['169.254.0.0', 16], ['172.16.0.0', 12], ['192.0.0.0', 24], ['192.0.2.0', 24],
    ['192.88.99.0', 24], ['192.168.0.0', 16], ['198.18.0.0', 15], ['198.51.100.0', 24],
    ['203.0.113.0', 24], ['224.0.0.0', 4], ['240.0.0.0', 4],
  ].some(([base, bits]) => inV4Range(ip, base, bits));
}
function isPrivateAddress(address) {
  const family = net.isIP(address);
  if (family === 4) return isPrivateIpv4(address);
  if (family !== 6) return true;
  const lower = address.toLowerCase();
  if (lower === '::1' || lower === '::' || lower.startsWith('fc') || lower.startsWith('fd') || lower.startsWith('fe8') || lower.startsWith('fe9') || lower.startsWith('fea') || lower.startsWith('feb')) return true;
  const mapped = lower.match(/^::ffff:(\d+\.\d+\.\d+\.\d+)$/);
  if (mapped) return isPrivateIpv4(mapped[1]);
  // Public unicast IPv6 lives in 2000::/3. Exclude the documentation prefix.
  const first = Number.parseInt(lower.split(':')[0] || '0', 16);
  if (first < 0x2000 || first > 0x3fff || lower.startsWith('2001:db8:')) return true;
  return false;
}
export function isLoopbackBrowserHost(hostname) {
  const host = String(hostname || '').toLowerCase().replace(/^\[|\]$/g, '');
  return host === 'localhost' || host.endsWith('.localhost') || host === '::1' || inV4Range(host, '127.0.0.0', 8);
}
function isLiteralPrivate(hostname) {
  const host = String(hostname || '').replace(/^\[|\]$/g, '');
  return net.isIP(host) !== 0 && isPrivateAddress(host);
}

async function createHostGuard(targetUrl, { allowPrivateNetwork = false, dnsLookup = dns.lookup, allowedOrigins = [] } = {}) {
  const dnsCache = new Map();
  const pinnedAddresses = new Map();
  const targetIsLoopback = isLoopbackBrowserHost(targetUrl.hostname);
  const targetIsPrivate = isLiteralPrivate(targetUrl.hostname) && !targetIsLoopback;
  if (targetIsPrivate && !allowPrivateNetwork) throw new Error('Private/LAN browser targets require --allow-private-network. Loopback development URLs such as http://127.0.0.1:5173 are allowed by default.');

  // Pin public DNS names to addresses verified before Chromium starts. Otherwise a hostname
  // can change DNS between the policy check and Chromium's own lookup (DNS-rebinding SSRF).
  // The opt-in private-network mode explicitly accepts this risk and therefore skips pinning.
  async function resolveAndPin(hostname) {
    const host = String(hostname || '').replace(/^\[|\]$/g, '').toLowerCase();
    if (allowPrivateNetwork || isLoopbackBrowserHost(host) || net.isIP(host)) return;
    if (dnsCache.has(host)) return dnsCache.get(host);
    const pending = Promise.resolve().then(() => dnsLookup(host, { all: true, verbatim: true })).then((items) => {
      const rows = Array.isArray(items) ? items : [items];
      if (!rows.length || rows.some((item) => !item?.address || isPrivateAddress(item.address))) {
        throw new Error(`Browser target hostname ${host} did not resolve exclusively to public addresses. Access was blocked.`);
      }
      // Chrome supports hostname-to-IP host-resolver rules. Prefer IPv4 for broad compatibility.
      const selected = rows.find((item) => net.isIP(item.address) === 4) || rows[0];
      if (!selected || !net.isIP(selected.address)) throw new Error(`Browser target hostname ${host} has no usable public address.`);
      pinnedAddresses.set(host, selected.address.includes(':') ? `[${selected.address}]` : selected.address);
      return rows;
    }).catch((error) => { throw error; });
    dnsCache.set(host, pending);
    return pending;
  }

  if (!allowPrivateNetwork) {
    await resolveAndPin(targetUrl.hostname);
    for (const origin of allowedOrigins) await resolveAndPin(new URL(origin).hostname);
  }

  async function hostAllowed(hostname) {
    const host = String(hostname || '').replace(/^\[|\]$/g, '').toLowerCase();
    if (isLoopbackBrowserHost(host)) return targetIsLoopback || allowPrivateNetwork;
    if (net.isIP(host)) return !isPrivateAddress(host) || allowPrivateNetwork;
    if (allowPrivateNetwork) return true;
    try {
      const rows = await (dnsCache.get(host) || resolveAndPin(host));
      return rows.length > 0 && rows.every((item) => !isPrivateAddress(item.address));
    } catch { return false; }
  }

  const resolverRules = !allowPrivateNetwork && pinnedAddresses.size
    ? [...pinnedAddresses].map(([host, address]) => `MAP ${host} ${address}`).join(',')
    : '';
  return { hostAllowed, targetIsLoopback, resolverRules };
}

function ensurePrivateDirectory(directory) {
  const absolute = path.resolve(directory);
  const parent = path.dirname(absolute);
  if (parent !== absolute && !fs.existsSync(parent)) ensurePrivateDirectory(parent);
  ensureRealDirectory(absolute, 0o700);
  return absolute;
}
function writePrivateFile(file, contents) {
  try {
    const existing = fs.lstatSync(file);
    if (existing.isSymbolicLink() || !existing.isFile()) throw new Error(`Refusing to overwrite a symlink or special report file: ${file}`);
  } catch (error) { if (error?.code !== 'ENOENT') throw error; }
  fs.writeFileSync(file, contents, { mode: 0o600, flag: 'wx' });
}

function clipIssue(value) {
  return safeTerminalText(redactSecrets(String(value ?? ''))).slice(0, MAX_ERROR_CHARS);
}

async function inspectPage(page, viewportName) {
  return page.evaluate((name) => {
    const visible = (element) => {
      const rect = element.getBoundingClientRect();
      const style = getComputedStyle(element);
      return rect.width > 0 && rect.height > 0 && style.display !== 'none' && style.visibility !== 'hidden';
    };
    const accessibleName = (element) => {
      const aria = element.getAttribute('aria-label') || element.getAttribute('aria-labelledby');
      const title = element.getAttribute('title');
      const text = element.innerText || element.value || element.alt || '';
      return Boolean(String(aria || title || text).trim());
    };
    const images = [...document.images].filter(visible);
    const buttons = [...document.querySelectorAll('button,[role="button"]')].filter(visible);
    const links = [...document.querySelectorAll('a[href]')].filter(visible);
    const inputs = [...document.querySelectorAll('input:not([type="hidden"]),textarea,select')].filter(visible);
    const headings = [...document.querySelectorAll('h1,h2,h3,h4,h5,h6')].filter(visible);
    let webgl = false;
    for (const canvas of [...document.querySelectorAll('canvas')].slice(0, 5)) {
      try { if (canvas.getContext('webgl2') || canvas.getContext('webgl') || canvas.getContext('experimental-webgl')) webgl = true; } catch {}
    }
    const controlsWithoutNames = [...buttons, ...links].filter((el) => !accessibleName(el)).length;
    const inputsWithoutLabels = inputs.filter((el) => !(el.labels && el.labels.length) && !accessibleName(el)).length;
    return {
      viewport: name,
      viewportWidth: window.innerWidth,
      viewportHeight: window.innerHeight,
      documentWidth: document.documentElement?.scrollWidth ?? 0,
      horizontalOverflow: Boolean(document.documentElement && document.documentElement.scrollWidth > document.documentElement.clientWidth + 1),
      titlePresent: Boolean(document.title.trim()),
      languagePresent: Boolean(document.documentElement?.lang),
      visibleH1Count: [...document.querySelectorAll('h1')].filter(visible).length,
      visibleHeadingCount: headings.length,
      visibleImageCount: images.length,
      imagesMissingAlt: images.filter((image) => !image.hasAttribute('alt') || (image.getAttribute('alt') === '' && image.getAttribute('role') !== 'presentation')).length,
      visibleButtons: buttons.length,
      visibleLinks: links.length,
      controlsWithoutAccessibleName: controlsWithoutNames,
      visibleInputs: inputs.length,
      inputsWithoutLabels,
      forms: [...document.forms].filter(visible).length,
      canvasCount: document.querySelectorAll('canvas').length,
      webglCanvasDetected: webgl,
      bodyVisible: Boolean(document.body && document.body.getBoundingClientRect().height > 0),
      documentReadyState: document.readyState,
    };
  }, viewportName);
}

function sanitizeIssueUrl(raw) {
  return safeUrlLabel(raw);
}

function issueUnique(array, item) {
  const key = JSON.stringify(item);
  if (array.length < MAX_ISSUES && !array.some((existing) => JSON.stringify(existing) === key)) array.push(item);
}

export async function runBrowserAudit({ root, rawUrl, allowOrigins = [], allowPrivateNetwork = false, headed = false, exercise = false, timeoutMs = DEFAULT_TIMEOUT_MS, engine = null, env = process.env, dnsLookup = dns.lookup }) {
  const targetUrl = validateBrowserUrl(rawUrl);
  if (!Number.isInteger(timeoutMs) || timeoutMs < 1000 || timeoutMs > MAX_TIMEOUT_MS) throw new Error(`Browser timeout must be between 1000 and ${MAX_TIMEOUT_MS} ms.`);
  const targetOrigin = targetUrl.origin;
  const allowed = new Set([targetOrigin]);
  for (const rawOrigin of allowOrigins) {
    const item = validateBrowserUrl(rawOrigin);
    if (item.pathname !== '/' || item.search || item.hash) throw new Error(`Allowed origins must be origins only, for example https://api.example.com: ${rawOrigin}`);
    allowed.add(item.origin);
  }
  if (exercise && !isLoopbackBrowserHost(targetUrl.hostname) && !allowPrivateNetwork) throw new Error('Interactive game exercise is restricted to loopback targets by default. Use a local test server; Forge will not send game-control inputs to public sites automatically.');
  const hostGuard = await createHostGuard(targetUrl, { allowPrivateNetwork, dnsLookup, allowedOrigins: [...allowed] });
  const discovered = engine || resolvePlaywright(root, { env });
  if (!discovered?.available || !discovered.chromium) {
    throw new Error(`Playwright is not installed or cannot be loaded. Forge keeps it optional to stay lightweight. Run "forge browser setup" to install playwright-core into this project, then set FORGE_BROWSER_EXECUTABLE to your existing Chrome/Chromium/Edge binary if needed. Or install "playwright" and run "npx playwright install chromium" for a managed browser. ${discovered?.reasons?.slice(0, 2).join('; ') || ''}`.trim());
  }

  const runId = `${new Date().toISOString().replace(/[:.]/g, '-')}-${randomUUID().slice(0, 8)}`;
  ensureRealDirectory(path.join(root, '.forge'), 0o700);
  const outputDirectory = ensurePrivateDirectory(path.join(root, '.forge', 'browser-runs', runId));
  const issue = {
    consoleErrors: [], pageErrors: [], httpErrors: [], failedRequests: [], blockedRequests: [],
  };
  const pageStats = [];
  const screenshots = [];
  let browser = null;
  let context = null;
  let navigationStatus = null;
  let navigationError = null;
  let pageInjectionIndicators = [];
  let attemptedExercise = { requested: Boolean(exercise), startControlClicked: false, keysSent: [], note: exercise ? 'No recognized safe start control found; key sequence only runs after explicit exercise mode.' : 'passive audit; no controls clicked and no forms submitted' };
  const deniedUnique = new Set();

  const launchArgs = [...SAFE_BROWSER_ARGS];
  if (hostGuard.resolverRules) launchArgs.push(`--host-resolver-rules=${hostGuard.resolverRules}`);
  const launchOptions = { headless: !headed, timeout: timeoutMs, chromiumSandbox: true, args: launchArgs };
  if (env.FORGE_BROWSER_EXECUTABLE) {
    const executable = path.resolve(env.FORGE_BROWSER_EXECUTABLE);
    if (!canExecute(executable)) throw new Error('FORGE_BROWSER_EXECUTABLE does not identify an executable file.');
    launchOptions.executablePath = executable;
  } else if (discovered.packageName === 'playwright-core') {
    const executable = findBrowserExecutable({ env, root });
    if (!executable) throw new Error('playwright-core is installed but no Chrome/Chromium/Edge executable was found. Set FORGE_BROWSER_EXECUTABLE to an existing browser binary.');
    launchOptions.executablePath = executable;
  }

  try {
    browser = await discovered.chromium.launch(launchOptions);
    context = await browser.newContext({
      viewport: { width: 1365, height: 850 },
      acceptDownloads: false,
      javaScriptEnabled: true,
      serviceWorkers: 'block',
      permissions: [],
      ignoreHTTPSErrors: false,
    });
    // HTTP routing alone does not cover WebSocket upgrades. Require Playwright 1.48+
    // and put a matching origin/destination policy in front of any socket before
    // creating a page. Fail closed rather than silently dropping this boundary.
    if (typeof context.routeWebSocket !== 'function') {
      throw new Error('This Playwright version cannot enforce WebSocket routing. Install Playwright v1.48 or later; Forge will not run browser QA with an incomplete network policy.');
    }
    await context.routeWebSocket('**/*', async (socketRoute) => {
      let socketUrl;
      let httpOrigin;
      try {
        socketUrl = new URL(socketRoute.url());
        if (!['ws:', 'wss:'].includes(socketUrl.protocol)) throw new Error('invalid scheme');
        socketUrl.protocol = socketUrl.protocol === 'wss:' ? 'https:' : 'http:';
        httpOrigin = socketUrl.origin;
      } catch {
        issueUnique(issue.blockedRequests, { url: '[invalid WebSocket URL]', reason: 'invalid_websocket_url' });
        try { await socketRoute.close({ code: 1008, reason: 'blocked by Forge origin policy' }); } catch {}
        return;
      }
      const label = sanitizeIssueUrl(socketRoute.url());
      if (!allowed.has(httpOrigin)) {
        deniedUnique.add(httpOrigin);
        issueUnique(issue.blockedRequests, { url: label, reason: 'websocket_origin_not_allowlisted' });
        try { await socketRoute.close({ code: 1008, reason: 'blocked by Forge origin policy' }); } catch {}
        return;
      }
      const privateHostAllowed = allowPrivateNetwork || (httpOrigin === targetOrigin && hostGuard.targetIsLoopback && socketUrl.hostname.toLowerCase() === targetUrl.hostname.toLowerCase());
      const hostAllowed = privateHostAllowed || await hostGuard.hostAllowed(socketUrl.hostname);
      if (!hostAllowed) {
        issueUnique(issue.blockedRequests, { url: label, reason: 'websocket_private_or_unresolvable_destination' });
        try { await socketRoute.close({ code: 1008, reason: 'blocked by Forge network policy' }); } catch {}
        return;
      }
      try { socketRoute.connectToServer(); } catch (error) {
        issueUnique(issue.failedRequests, { url: label, reason: 'websocket_connect_failed' });
        try { await socketRoute.close({ code: 1011, reason: 'connection failed' }); } catch {}
      }
    });
    await context.route('**/*', async (route) => {
      const request = route.request();
      let requestUrl;
      try { requestUrl = new URL(request.url()); } catch { issueUnique(issue.blockedRequests, { url: '[invalid URL]', reason: 'invalid_url' }); await route.abort('blockedbyclient'); return; }
      if (!['http:', 'https:'].includes(requestUrl.protocol)) {
        issueUnique(issue.blockedRequests, { url: sanitizeIssueUrl(request.url()), reason: 'non_http_scheme' });
        await route.abort('blockedbyclient');
        return;
      }
      if (!allowed.has(requestUrl.origin)) {
        const label = sanitizeIssueUrl(request.url());
        deniedUnique.add(requestUrl.origin);
        issueUnique(issue.blockedRequests, { url: label, reason: 'origin_not_allowlisted' });
        await route.abort('blockedbyclient');
        return;
      }
      const privateHostAllowed = allowPrivateNetwork || (requestUrl.origin === targetOrigin && hostGuard.targetIsLoopback && requestUrl.hostname.toLowerCase() === targetUrl.hostname.toLowerCase());
      const hostAllowed = privateHostAllowed || await hostGuard.hostAllowed(requestUrl.hostname, requestUrl.origin);
      if (!hostAllowed) {
        issueUnique(issue.blockedRequests, { url: sanitizeIssueUrl(request.url()), reason: 'private_or_unresolvable_destination' });
        await route.abort('blockedbyclient');
        return;
      }
      try { await route.continue(); } catch { /* Browser may have closed during a request. */ }
    });
    const page = await context.newPage();
    page.setDefaultTimeout(Math.min(timeoutMs, 10000));
    page.on('console', (message) => {
      if (message.type() !== 'error') return;
      issueUnique(issue.consoleErrors, { type: 'console_error', message: clipIssue(message.text()) });
    });
    page.on('pageerror', (error) => issueUnique(issue.pageErrors, { message: clipIssue(error?.message || error) }));
    page.on('requestfailed', (request) => {
      const url = sanitizeIssueUrl(request.url());
      if (deniedUnique.has(safeUrlOrigin(request.url()))) return;
      const failure = request.failure()?.errorText || 'request_failed';
      issueUnique(issue.failedRequests, { url, reason: clipIssue(failure) });
    });
    page.on('response', (response) => {
      if (response.status() >= 400) issueUnique(issue.httpErrors, { status: response.status(), url: sanitizeIssueUrl(response.url()) });
    });
    page.on('dialog', async (dialog) => { try { await dialog.dismiss(); } catch {} });
    page.on('popup', async (popup) => { try { await popup.close(); } catch {} });

    try {
      const response = await page.goto(targetUrl.href, { waitUntil: 'domcontentloaded', timeout: timeoutMs });
      navigationStatus = response?.status() ?? null;
      await page.waitForTimeout(350);
      await page.screenshot({ path: path.join(outputDirectory, 'desktop.png'), animations: 'disabled', timeout: timeoutMs });
      screenshots.push(path.join(outputDirectory, 'desktop.png'));
      pageStats.push(await inspectPage(page, 'desktop-1365x850'));
      // Read at most 30k characters / 1,500 text nodes in the browser process.
      // Avoid materializing an unbounded document.innerText result from hostile pages.
      const visibleText = await page.evaluate(() => {
        const root = document.body;
        if (!root) return '';
        const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
        let text = '';
        let nodes = 0;
        while (text.length < 30000 && nodes < 1500 && walker.nextNode()) {
          const value = String(walker.currentNode?.nodeValue || '').replace(/\s+/g, ' ').trim();
          if (value) text += `${text ? ' ' : ''}${value.slice(0, Math.max(0, 30000 - text.length))}`;
          nodes += 1;
        }
        return text;
      }).catch(() => '');
      pageInjectionIndicators = scanPromptInjection({ files: [{ path: '[rendered browser page]', content: String(visibleText).slice(0, 30000) }] });
      await page.setViewportSize({ width: 390, height: 844 });
      await page.waitForTimeout(150);
      await page.screenshot({ path: path.join(outputDirectory, 'mobile.png'), animations: 'disabled', timeout: timeoutMs });
      screenshots.push(path.join(outputDirectory, 'mobile.png'));
      pageStats.push(await inspectPage(page, 'mobile-390x844'));

      if (exercise) {
        const buttons = page.getByRole('button');
        const count = Math.min(await buttons.count(), 80);
        const startTexts = /^(play|play now|start game|new game|begin game|resume game|start playing)$/i;
        for (let i = 0; i < count; i += 1) {
          const button = buttons.nth(i);
          const text = String(await button.innerText().catch(() => '')).trim();
          const aria = String(await button.getAttribute('aria-label').catch(() => '')).trim();
          if (!startTexts.test(text || aria)) continue;
          if (!await button.isVisible().catch(() => false) || !await button.isEnabled().catch(() => false)) continue;
          try { await button.click({ timeout: 1500 }); attemptedExercise.startControlClicked = true; attemptedExercise.note = `Clicked visible game start control: ${text || aria}`; break; } catch {}
        }
        // Only predictable keyboard events; never send form input or text, and only after explicit --exercise.
        for (const key of ['ArrowUp', 'ArrowRight', 'ArrowDown', 'ArrowLeft', 'w', 'd', 's', 'a']) {
          try { await page.keyboard.press(key); attemptedExercise.keysSent.push(key); await page.waitForTimeout(80); } catch {}
        }
        await page.screenshot({ path: path.join(outputDirectory, 'after-exercise.png'), animations: 'disabled', timeout: timeoutMs });
        screenshots.push(path.join(outputDirectory, 'after-exercise.png'));
        pageStats.push(await inspectPage(page, 'after-game-exercise'));
      }
    } catch (error) {
      navigationError = clipIssue(error?.message || error);
      // Capture a best-effort failure screenshot without converting a failed navigation into success.
      try {
        await page.screenshot({ path: path.join(outputDirectory, 'failure.png'), animations: 'disabled', timeout: 3000 });
        screenshots.push(path.join(outputDirectory, 'failure.png'));
      } catch {}
    }
  } finally {
    try { await context?.close(); } catch {}
    try { await browser?.close(); } catch {}
  }

  const statuses = issue.httpErrors.filter((item) => item.status >= 500).length;
  const failed = Boolean(navigationError || (navigationStatus !== null && navigationStatus >= 400) || issue.pageErrors.length || statuses > 0);
  const warnings = Boolean(issue.consoleErrors.length || issue.httpErrors.length || issue.failedRequests.length || issue.blockedRequests.length || pageStats.some((stats) => !stats.titlePresent || !stats.bodyVisible || stats.visibleH1Count === 0 || !stats.languagePresent || stats.horizontalOverflow || stats.imagesMissingAlt || stats.controlsWithoutAccessibleName || stats.inputsWithoutLabels));
  const resultStatus = failed ? 'FAIL' : warnings ? 'WARN' : 'PASS';
  const report = {
    schemaVersion: 1,
    runId,
    createdAt: new Date().toISOString(),
    status: resultStatus,
    engine: { name: discovered.packageName, playwrightModulePath: '[not persisted]' },
    target: { url: safeUrlLabel(targetUrl.href), origin: targetOrigin },
    networkPolicy: {
      allowedOrigins: [...allowed],
      thirdPartyOriginsBlockedByDefault: true,
      webSocketOriginFiltering: true,
      networkBoundaryNote: 'HTTP(S) and WebSocket requests are origin-filtered by Playwright interception. This is not an OS firewall; WebRTC/UDP and other browser network surfaces may bypass request routing. Use external egress controls for hostile targets.',
      allowPrivateNetwork,
      blockedOriginCount: deniedUnique.size,
      blockedRequestCount: issue.blockedRequests.length,
    },
    navigation: { httpStatus: navigationStatus, error: navigationError },
    viewports: pageStats,
    issues: issue,
    promptInjectionIndicators: pageInjectionIndicators.map((finding) => ({ path: finding.path, indicators: finding.indicators })),
    gameExercise: attemptedExercise,
    screenshots: screenshots.map((file) => path.basename(file)),
    privacy: {
      browserProfile: 'ephemeral; no existing profile or storage state used',
      cookiesOrFormValuesSaved: false,
      pageContentsSentToModel: false,
      dataPersisted: 'private local screenshots and metadata report only',
      osSandbox: 'not provided by Forge; browser runs with browser sandbox requested where supported',
    },
    disclaimer: 'Heuristic browser smoke audit, not full end-to-end coverage or proof of absence of defects. Page content is untrusted data. Review screenshots and findings.',
  };
  const reportPath = path.join(outputDirectory, 'report.json');
  writePrivateFile(reportPath, `${JSON.stringify(report, null, 2)}\n`);
  return { report, reportPath, outputDirectory, screenshots, status: resultStatus, digest: sha256(JSON.stringify(report)) };
}

function safeUrlOrigin(raw) {
  try { return new URL(raw).origin; } catch { return '[invalid origin]'; }
}

export function browserStatus(root) {
  const engine = resolvePlaywright(root);
  let executable = findBrowserExecutable({ root });
  if (!executable && engine.available && engine.packageName === 'playwright') {
    try {
      const bundled = engine.chromium.executablePath();
      if (canExecute(bundled)) executable = bundled;
    } catch { /* Managed browser may not have been downloaded yet. */ }
  }
  return {
    playwrightAvailable: engine.available,
    packageName: engine.packageName,
    browserExecutable: executable,
    reasons: engine.reasons,
    setupInstructions: engine.available
      ? (executable ? 'Playwright and a system or managed browser appear available.' : 'Set FORGE_BROWSER_EXECUTABLE to an existing Chrome/Chromium/Edge binary, or install the Playwright-managed Chromium with the full playwright package.')
      : 'Run forge browser setup to install optional playwright-core. It does not download a browser. Use an existing Chrome/Chromium/Edge browser or install playwright and its managed Chromium.',
  };
}

export function sanitizeBrowserConsoleValue(value) {
  return truncate(safeTerminalText(redactSecrets(String(value ?? ''))), MAX_ERROR_CHARS);
}
