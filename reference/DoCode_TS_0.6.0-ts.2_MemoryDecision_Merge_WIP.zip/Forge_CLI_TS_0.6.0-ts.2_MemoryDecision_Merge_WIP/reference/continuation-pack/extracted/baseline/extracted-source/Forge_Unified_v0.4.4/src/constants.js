export const VERSION = '0.4.4';

export const DEFAULT_CONFIG = Object.freeze({
  provider: 'opencode',
  model: 'opencode/glm-5.3-flash',
  openrouter: { baseUrl: 'https://openrouter.ai/api/v1', maxTokens: 4096 },
  opencodeCommand: 'opencode',
  agent: 'forge-model',
  privacy: { mode: 'ask' },
  limits: {
    maxFiles: 3000,
    maxFileBytes: 262144,
    maxIndexBytes: 67108864,
    maxContextChars: 24000,
    maxTargetFiles: 8,
    maxOutputBytes: 1200000,
    modelTimeoutMs: 240000,
    commandTimeoutMs: 120000,
  },
  review: { enabled: true },
});

export const AGENTS = Object.freeze([
  { name: 'Orchestrator', status: 'implemented', purpose: 'Owns task flow, approvals, checkpoints, and final report.', tools: ['index', 'delegate', 'audit'] },
  { name: 'Researcher', status: 'implemented', purpose: 'Builds the local code graph and can explicitly retrieve versioned documentation or route consent-gated external research.', tools: ['index', 'graph', 'docs', 'reach search'] },
  { name: 'Architect / Planner', status: 'implemented', purpose: 'Produces a structured plan and target-file set.', tools: ['read', 'index'] },
  { name: 'Coder', status: 'implemented', purpose: 'Proposes a unified diff; cannot apply it.', tools: ['read', 'propose_patch'] },
  { name: 'Tester', status: 'implemented', purpose: "Selects and runs approved tests, and reports actual exit codes.", tools: ['propose_test_command', 'run_approved_test'] },
  { name: 'Reviewer', status: 'implemented', purpose: 'Reviews the proposed diff and verification evidence.', tools: ['read_diff', 'read_test_results'] },
  { name: 'Read-only Specialists', status: 'conditional', purpose: 'For complex tasks, runs up to three parallel read-only model passes for repository exploration, testing, architecture, browser QA planning, or security review. No write/command tools; outputs remain hypotheses.', tools: ['repository_map', 'bounded_source_excerpts'] },
  { name: 'Security Auditor', status: 'conditional', purpose: 'Runs deterministically detected risk checks and a separate model review only for security-sensitive tasks or elevated-risk patches.', tools: ['inspect_paths', 'inspect_diff', 'security_audit'] },
  { name: 'Browser QA', status: 'conditional', purpose: 'Auto-routes browser testing tasks to isolated Playwright when configured; audits JS errors, responses, layout and accessible labels.', tools: ['browser_test', 'screenshot', 'local_report'] },
  { name: 'DevOps', status: 'planned', purpose: 'Explicitly requested CI/CD and deployment workflows.', tools: [] },
]);
