/**
 * Bounded, read-only research routes inspired by Agent-Reach's documented backends.
 * Never accept executable names or arguments from model output or remote metadata.
 */
import fs from 'node:fs';
import path from 'node:path';

const PLATFORM_CHANNEL = Object.freeze({
  github: 'github', youtube: 'youtube', bilibili: 'bilibili', web: 'exa_search',
  twitter: 'twitter', reddit: 'reddit', xiaohongshu: 'xiaohongshu',
  facebook: 'facebook', instagram: 'instagram',
});

const ACCOUNT_PLATFORMS = new Set(['github', 'twitter', 'reddit', 'xiaohongshu', 'facebook', 'instagram']);

const ROUTES = Object.freeze({
  github: [
    { backend: 'gh CLI', command: 'gh', account: true, args: (q) => ['search', 'repos', q, '--sort', 'stars', '--limit', '10'] },
  ],
  youtube: [
    { backend: 'yt-dlp', command: 'yt-dlp', account: false, args: (q) => ['--ignore-config', '--no-warnings', '--skip-download', '--flat-playlist', '--dump-single-json', `ytsearch5:${q}`] },
  ],
  bilibili: [
    { backend: 'bili-cli', command: 'bili', account: false, args: (q) => ['search', q, '--type', 'video', '-n', '5'] },
    { backend: 'OpenCLI', command: 'opencli', account: true, args: (q) => ['bilibili', 'search', q, '-f', 'yaml'] },
  ],
  web: [
    { backend: 'Exa via mcporter', command: 'mcporter', account: false, args: (q) => ['call', 'exa.web_search_exa', `query=${q}`, 'numResults=5'] },
  ],
  twitter: [
    { backend: 'twitter-cli', command: 'twitter', account: true, requiresTwitterCredentials: true, args: (q) => ['search', q, '-n', '10'] },
    { backend: 'OpenCLI', command: 'opencli', account: true, args: (q) => ['twitter', 'search', q, '-f', 'yaml'] },
  ],
  reddit: [
    { backend: 'OpenCLI', command: 'opencli', account: true, args: (q) => ['reddit', 'search', q, '-f', 'yaml'] },
    { backend: 'rdt-cli', command: 'rdt', account: true, args: (q) => ['search', q, '--limit', '10'] },
  ],
  xiaohongshu: [
    { backend: 'OpenCLI', command: 'opencli', account: true, args: (q) => ['xiaohongshu', 'search', q, '-f', 'yaml'] },
    { backend: 'xiaohongshu-mcp via mcporter', command: 'mcporter', account: true, args: (q) => ['call', 'xiaohongshu.search_feeds', `keyword=${q}`, '--timeout', '120000'] },
  ],
  facebook: [
    { backend: 'OpenCLI', command: 'opencli', account: true, args: (q) => ['facebook', 'search', q, '-f', 'yaml'] },
  ],
  instagram: [
    // This is user/profile search, not a claim of global post-keyword search.
    { backend: 'OpenCLI', command: 'opencli', account: true, args: (q) => ['instagram', 'search', q, '-f', 'yaml'] },
  ],
});

export function validateResearchQuery(query) {
  if (typeof query !== 'string') throw new Error('Research query must be text.');
  const normalized = query.trim();
  if (!normalized || normalized.length > 1000 || /[\x00-\x1f\x7f]/.test(normalized)) {
    throw new Error('Research query must be 1–1000 characters and contain no control characters.');
  }
  if (normalized.startsWith('-')) throw new Error('Research queries cannot start with a dash; this avoids confusing a query with a CLI option.');
  return normalized;
}

export function isAccountResearchPlatform(platform) {
  return ACCOUNT_PLATFORMS.has(platform);
}

function findEnv(sourceEnv, key) {
  const actual = Object.keys(sourceEnv || {}).find((name) => name.toLowerCase() === key.toLowerCase());
  return actual ? sourceEnv[actual] : undefined;
}

/**
 * Finds installed executable files without launching them. Windows .cmd/.bat shims are
 * intentionally not accepted because running them requires a shell, which is outside this bridge.
 */
export function discoverReachExecutables(sourceEnv = process.env, platform = process.platform) {
  const pathValue = String(findEnv(sourceEnv, 'PATH') || '');
  const dirs = pathValue.split(path.delimiter).filter(Boolean);
  const commands = [...new Set(Object.values(ROUTES).flat().map((route) => route.command))];
  const found = new Set();
  for (const command of commands) {
    const candidates = platform === 'win32' ? [`${command}.exe`] : [command];
    for (const dir of dirs) {
      let matched = false;
      for (const candidate of candidates) {
        const file = path.join(dir, candidate);
        try {
          const info = fs.statSync(file);
          if (!info.isFile()) continue;
          if (platform !== 'win32') fs.accessSync(file, fs.constants.X_OK);
          found.add(command); matched = true; break;
        } catch { /* Try the next PATH entry. */ }
      }
      if (matched) break;
    }
  }
  return [...found];
}

/** Return a fixed, shell-free invocation; executable and arguments never come from the model. */
export function buildReachSearchInvocation(platform, query, {
  availableCommands = [], allowAccount = false, twitterCredentialsAvailable = false,
} = {}) {
  if (!Object.hasOwn(PLATFORM_CHANNEL, platform)) {
    throw new Error(`Unsupported platform "${platform}". Supported: ${Object.keys(PLATFORM_CHANNEL).join(', ')}.`);
  }
  const cleanQuery = validateResearchQuery(query);
  if (isAccountResearchPlatform(platform) && !allowAccount) {
    throw new Error(`${platform} may use an account or existing browser session. Re-run with --allow-account only after reviewing that access boundary.`);
  }
  const available = new Set(availableCommands);
  const configuredRoutes = ROUTES[platform];
  const executableRoutes = configuredRoutes.filter((route) => available.has(route.command));
  const credentialReadyRoutes = executableRoutes.filter((route) => !route.requiresTwitterCredentials || twitterCredentialsAvailable);
  const permittedRoutes = credentialReadyRoutes.filter((route) => allowAccount || !route.account);
  if (!permittedRoutes.length) {
    if (platform === 'twitter' && available.has('twitter') && !twitterCredentialsAvailable && !available.has('opencli')) {
      throw new Error('The twitter-cli backend requires TWITTER_AUTH_TOKEN and TWITTER_CT0 in the launching shell; alternatively install/configure OpenCLI. Forge will not extract browser cookies or read saved Agent-Reach credentials.');
    }
    if (!allowAccount && executableRoutes.some((route) => route.account)) {
      throw new Error(`${platform} has a local backend, but it may use an account or browser session. Re-run with --allow-account after reviewing that access boundary.`);
    }
    const expected = configuredRoutes.map((route) => route.command).join(' or ');
    throw new Error(`No supported local backend executable was found for ${platform} (expected ${expected}). Install/configure the backend yourself; Forge does not install tools or import cookies.`);
  }
  const selected = permittedRoutes[0];
  return {
    platform, backend: selected.backend, command: selected.command,
    args: selected.args(cleanQuery), query: cleanQuery,
    usesAccountSession: selected.account, channel: PLATFORM_CHANNEL[platform],
  };
}

// Retained for explicit diagnostics and unit tests; never called automatically by search.
export function parseAgentReachDoctor(raw) {
  let data;
  try { data = JSON.parse(raw); }
  catch { throw new Error('Agent-Reach did not return valid JSON for `doctor --json`; run `forge reach doctor` and inspect the installed version.'); }
  if (!data || typeof data !== 'object' || Array.isArray(data)) {
    throw new Error('Agent-Reach doctor result must be a JSON object.');
  }
  return data;
}
