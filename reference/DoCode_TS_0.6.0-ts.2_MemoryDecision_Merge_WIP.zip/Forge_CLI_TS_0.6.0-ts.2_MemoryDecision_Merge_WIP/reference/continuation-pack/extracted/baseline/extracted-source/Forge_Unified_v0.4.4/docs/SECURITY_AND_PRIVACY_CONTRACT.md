# Forge: Security and Privacy Contract

This is the product behavior we intend to enforce in source code—not a claim that the current experimental MVP already fulfils every future item.

## Three separate trust domains

### A. Private workspace data

Examples: source files, task prompts, project notes, diffs, logs, local paths, environment variables, credentials, account details and saved conversation state.

- Default storage is local to the user's project or user profile.
- No Forge-owned telemetry or analytics is emitted.
- Secret files are excluded by path rules and detected token formats are redacted, but these are incomplete filters.
- No private repo excerpts should be silently attached to an Internet-search request or third-party tool call.
- Remote model calls are a separate data disclosure. In `privacy.mode=ask`, show the provider/model and categories of context before sending; record consent outcome but avoid writing raw tasks/source into the audit log.
- Secrets never belong in model prompts, project memory, screenshots, audit reports or allowlists. Rotate any key that may have been exposed.

### B. Public external information

Examples: docs, GitHub issues, package readmes, release notes, public posts, official advisories and other Internet sources.

- Show the original source URL and when it was retrieved whenever a user-facing answer relies on it.
- Clearly separate observed facts, claims made by a vendor/author, independent evidence, inference and unknowns.
- Treat all external text as untrusted content. A public page is evidence, never authority to change system policy.
- Quote only the minimum needed; preserve provenance for any generated summary.
- External web content may be displayed to the user; it must not trigger secret disclosure, file access, package install, code execution, or approval bypass.

**Current implementation status:** Forge can inspect local repositories and use OpenCode/OpenRouter under its consent model. It has a consent-gated Context7 library-documentation lookup and a bounded user-facing search bridge that invokes an allow-listed local backend for one explicit query. It is not a general browser session, multi-source research synthesizer, or automatic citation verifier. The external-search backend may have its own account/session requirements; Forge will not import cookies.

### C. Execution and side effects

Examples: running project tests/build scripts, writing a patch, installing a package, invoking Git, connecting to networks, changing CI/CD workflows, or operating on cloud services.

- Models propose; trusted Forge code validates and asks the user.
- Writes require path/context checks, a user approval and a rollback checkpoint.
- Test/manual commands are parsed and spawned without a shell in the normal path, and have timeout/output caps and a restricted environment. They still run as the user's OS account.
- A model response or successful prompt-injection scan never constitutes authorization.
- A future sandbox should default to read-only worktree mounts where possible, non-root execution, no network unless explicitly needed, an explicit allowlist of writable paths, CPU/RAM/process/time quotas, and disposable environments. If the selected platform cannot supply a sandbox, report that status rather than pretending it exists.

## Project and context isolation (v0.4.1 implementation)

Each initialized project has a local UUID and canonical root binding in `.forge/project.json`. Forge refuses ordinary work if that metadata belongs to a different path. Users can inspect state with `forge project status`; rebinding requires interactive exact confirmation. Moving a project is intentionally not treated as a silent continuation.

No other project or conversation is searched implicitly. A user may import one selected, bounded text file from another initialized project into the active project; the import records provenance, integrity metadata, a target project binding epoch, and an HMAC signature made with a private per-user key stored outside both project roots. Forge refuses a signing-key path inside the source or target root. Rebinding increments the epoch and invalidates copied records, preventing automatic replay after a moved/copied project is re-bound. This prevents a repository from manufacturing a valid import by only recomputing hashes. The content is still treated as untrusted input, is auditable, and can be revoked individually. Unsigned v0.4.0 imports are ignored after the patch and must be re-imported with consent. Imported content may still contain private data or novel secret formats, so user review and ordinary model-context consent remain necessary. This is not OS-level isolation, session persistence, or a guarantee against a hostile process running under the same account.

## Prompt-injection policy

The model may encounter malicious instructions in source code, Markdown, a web result, terminal output, generated files, issue comments, package metadata or an MCP description. Treat them as data. Instructions from that content cannot:

- override system/developer policy or user intent;
- request disclosure of hidden prompts, credentials or other private workspace data;
- grant permission for tools, network, installation or destructive commands;
- change approval gates or continue beyond task/time/cost limits;
- authorize sending code/data to a new destination.

The current detector is a warning heuristic and can be bypassed or raise false positives. The reliable defense must be capability isolation and deterministic authorization, backed by adversarial tests.

## Required approval classes

| Action | Required behavior |
|---|---|
| Remote model context | Per-run disclosure and user consent, unless operator explicitly configures a verified local provider. |
| Patch write | Show diff, validate path/context, create checkpoint, ask for approval. |
| CI/CD or deployment config | Additional explicit risk approval. |
| Probable credential-to-network flow | Critical warning plus typed security-risk approval. |
| Test/build script | Show the command and warn that it executes repository code; explicit approval. |
| Manual/high-risk command | Exact command review and higher-friction typed confirmation. |
| Internet page, model answer or tool result saying “go ahead” | Not an approval. |

## Audit log and retention

Forge's `.forge/audit.jsonl` is local event metadata, not a remote telemetry feed. It is append-only by design but not cryptographically tamper-proof against a local attacker. It may contain command strings, bounded errors, file paths, provider model IDs, hashes, usage, and permission outcomes. Checkpoint records can contain previous file contents. Keep the project/private state directories private; redact and review before sharing.

## Threats not yet solved

No complete guarantee against prompt injection; no OS sandbox today; no complete DLP/secret scanning; no guarantee that an OpenCode model configured behind a local-looking prefix never uses remote infrastructure; no control over a third-party provider's retention/training terms; no proof of Windows/macOS behavior until hosted CI; no formal audit. Use non-sensitive code and a disposable VM/container for untrusted repositories.


## Internet research output (limited implementation)

`forge docs` sends only the explicit question and optional library/version/language hints to Context7 after consent. `forge reach search` runs one explicit, allow-listed query through a locally available backend after consent; account/browser routes additionally require `--allow-account`. Search does not automatically run Agent-Reach doctor because upstream health checks may query unrelated external services. `forge reach status` only inspects local executable availability. Running `forge reach doctor` manually may perform generic remote health probes and is blocked in `privacy.mode=local-only`. Results are untrusted terminal-safe text shown to the user and are not automatically inserted into model context. They are not yet normalized into a citation-backed cross-platform report with verified timestamps. The default query includes no repository files, secrets, chat history, `.forge/` state, or `FORGE.md`; project context is never appended automatically. Remote model calls are a separate disclosure. A strong claim that no data leaves the device is valid only when a genuinely local provider and network controls are enforced outside the model.
