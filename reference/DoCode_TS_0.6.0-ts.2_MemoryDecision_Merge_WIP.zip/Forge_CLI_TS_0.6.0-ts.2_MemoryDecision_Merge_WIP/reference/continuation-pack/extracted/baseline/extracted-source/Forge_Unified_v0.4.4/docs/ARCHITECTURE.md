# Forge architecture

## Design rule

Forge, not the LLM, is the authority over filesystem mutation and command execution. The model responds with bounded structured objects; Forge validates those objects and makes side effects pass through one controlled path.

## Data flow

```mermaid
flowchart TD
  U[User task] --> C[CLI / privacy consent]
  C --> I[Local repository indexer]
  I --> P[Planner prompt + FORGE.md]
  P --> M[OpenCode text-only adapter]
  M --> V[Structured JSON validation]
  V --> K[Coder proposes unified diff]
  K --> PV[Path, secret, symlink and context checks]
  PV --> A[Human approval]
  A --> CP[Checkpoint + local audit]
  CP --> W[Forge patch applier]
  W --> T[Allowlisted test command + approval]
  T --> R[Reviewer with change/test evidence]
  R --> D[Human-readable report]
```

## Runtime and module responsibilities

| Module | Responsibility | Boundary |
|---|---|---|
| `bin/forge.js`, `src/cli.js` | Command parsing, workflow, human approvals, delivery report | Does not execute model-owned tools. |
| `src/config.js` / `constants.js` | Default and project config, bounds validation | JSON config only; no external package registry or remote configuration. |
| `src/indexer.js` | Walks project, excludes ignored/sensitive files, extracts simple symbols/imports, ranks relevant files | Aggregate indexed-text budget (64 MiB default), file-count/file-size limits; heuristic retrieval, not a complete parser/LSP/semantic index. |
| `src/prompts.js` | Role-specific prompt and JSON output contracts | Prompt text is not an authorization boundary. |
| `src/llm.js` | Invokes OpenCode in an empty temporary directory; parses JSON event stream, records reported tokens/cost | Real OpenCode/GLM run is not verified in this environment. Tool denial is layered defense, not a proven sandbox. |
| `src/patch.js` | Parses unified diff; validates target paths/context/hash; atomically writes staged file contents with temp files | Delete/rename unsupported; not protected against a malicious process concurrently changing OS paths. |
| `src/runner.js` | Parses a single command, denies shell operators/substitution, recognizes risky commands, caps time/output | An allowed test command can still execute arbitrary code from the repo. No sandbox. |
| `src/git.js` | Git availability/status and Forge-owned content snapshots/undo | Not a Git commit/branch engine. A checkpoint only tracks paths in a Forge patch. |
| `src/audit.js` | JSONL local event record and best-effort usage summary | Audit is not cryptographically tamper-evident; local users can edit it. |
| `src/terminal.js` | Explicit context-sharing and side-effect prompts | Non-interactive remote requests and approvals fail closed. |

## Agent protocol

The MVP uses distinct role prompts but shares one CLI-owned session workflow. Role output is validated JSON, not a tool-execution envelope. The practical protocol is:

```json
{
  "role": "planner",
  "task": "fix date parsing edge case",
  "evidence": ["src/date.ts: parseDate", "package.json: test script"],
  "assumptions": ["UTC date strings are supported"],
  "risks": ["Existing timezone behavior could change"],
  "next_action": "propose a minimal patch"
}
```

The coder uses a JSON object containing `summary`, `patch` (unified diff), and `tests` (candidate command strings). The reviewer returns `verdict`, `findings`, and `verificationGaps`. The protocol is a prompt-level shape at this stage; schema validation is partial, and the system does not launch parallel workers. Agent labels must never be treated as a security boundary.

## Why no framework or vector database

Node built-ins provide child processes, filesystem operations, hashing, and JSON. Git provides version-control primitives. The MVP's retrieval bottleneck is not yet measured, so installing a vector database, framework, AST parser suite, or orchestration server would make packaging and memory worse before evidence justifies it. The July 2026 harness study reports that the systems it examined generally used hand-built loops and deterministic retrieval; Forge treats that as a hypothesis worth testing, not a universal rule. See [research notes](../evidence/RESEARCH_NOTES.md).

## Session and memory

- `FORGE.md` is project-level human-reviewed memory; it is not automatically rewritten.
- `.forge/audit.jsonl` stores event metadata and model-reported usage, not full prompt bodies or complete source dumps.
- `.forge/checkpoints/*.json` snapshots the pre-patch file contents for Forge-managed changes.
- This release does not persist a resumable multi-turn model session. OpenCode calls are isolated text requests; long-task persistence is a roadmap item.

## Lifecycle

1. `forge init` creates defaults without a model call.
2. `forge index/search` work locally.
3. Remote workflow requests context-sharing consent before indexing/sending context to the model. Local-only mode accepts only model IDs under known local prefixes; it does not prove the endpoint is local.
4. Planner's target paths are rechecked locally.
5. Coder's diff is parsed and validated before a human sees it.
6. If accepted, a checkpoint is created; hashes are checked again before patching.
7. Tests are inferred from repository metadata or model suggestions, filtered by allowlist, then individually approved.
8. Reviewer receives change/test evidence; its verdict is recorded but not treated as proof.
9. Final report distinguishes verification outcome and model-reported usage.

## Performance target

Target cold-start under 1 second after install for local commands such as `--help`, `doctor`, and `index` on a modest local repository. No latency or memory benchmark is claimed yet. Model latency dominates end-to-end AI tasks and depends on provider/network. `docs/BENCHMARKS.md` defines how to measure both local overhead and task quality.
