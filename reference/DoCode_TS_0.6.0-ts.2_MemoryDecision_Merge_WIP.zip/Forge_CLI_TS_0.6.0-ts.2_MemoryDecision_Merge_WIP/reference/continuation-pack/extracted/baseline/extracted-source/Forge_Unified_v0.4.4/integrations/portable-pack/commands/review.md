# Review the current change

Review the actual diff, not the summary alone. Prioritize correctness, regression risk, security/privacy, edge cases, maintainability, and mismatch with acceptance criteria. For each finding, include severity, file/line, evidence, impact, and a minimal fix. Separate confirmed defects from questions and style preferences. Do not claim tests passed without command output.
