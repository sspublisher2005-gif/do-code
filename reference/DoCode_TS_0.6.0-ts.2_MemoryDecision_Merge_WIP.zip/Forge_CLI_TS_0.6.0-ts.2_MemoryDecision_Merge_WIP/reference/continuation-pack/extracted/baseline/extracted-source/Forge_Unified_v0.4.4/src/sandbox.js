import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { randomUUID } from 'node:crypto';
import { spawn, spawnSync } from 'node:child_process';
import { parseCommand, terminateProcessTree } from './runner.js';

const DEFAULT_IMAGES = Object.freeze({
  node: 'node:22-bookworm-slim@sha256:c3de60bf2f9dd0ac6370e6117950ff62d6e339527e7472301c9c78a017978392',
  python: 'python:3.12-slim@sha256:a6e34c598f2467ed0e9a8d349809fcd8b5c603269512df273a0bb1784edc11b1',
  go: 'golang:1.26-bookworm@sha256:d9c68c2c51161e12fd77e4c6320687c9cd86e1af1e3ad6e6cd63ff970641453c',
  rust: 'rust:1-slim-bookworm@sha256:2775a09d208ff0d7c1f50490c45b62db929e87ba1dcbc3f2132ac71a704bcdd3',
  generic: 'alpine:3.23@sha256:85fe1e81d6758c208f3e1eed4338a1997e19d4be002d4dd32d3100c9a8c010a0',
});
const MAX_FILES = 30000;
const MAX_FILE_BYTES = 50 * 1024 * 1024;
const MAX_TREE_BYTES = 512 * 1024 * 1024;
// Container tasks must never run as UID 0, even if Forge itself was launched as root.
const SANDBOX_UID = 65532;
const SANDBOX_GID = 65532;
const EXCLUDED_DIRS = new Set(['.git', '.forge', '.hg', '.svn', '.aws', '.ssh', '.azure', '.gnupg', '.kube']);
const SECRET_NAMES = new Set([
  '.npmrc', '.pypirc', '.netrc', 'credentials', 'credentials.json', 'service-account.json',
  'id_rsa', 'id_ed25519', 'id_ecdsa', 'id_dsa', 'known_hosts',
  '.git-credentials', '.vault-token', '.terraformrc', 'terraform.rc', 'authorized_keys',
  'secrets.json', 'secrets.yml', 'secrets.yaml', 'tokens.json', 'access_tokens.db', 'credentials.db', 'auth.json',
]);
const SECRET_RELATIVE_PATHS = new Set([
  '.docker/config.json', '.config/gh/hosts.yml', '.config/gcloud/application_default_credentials.json',
  '.config/azure/azureprofile.json', '.cargo/credentials', '.cargo/credentials.toml', '.bundle/config',
  '.terraform.d/credentials.tfrc.json', '.pulumi/credentials.json', '.vercel/auth.json',
  '.firebase/credentials', '.local/share/keyrings/login.keyring',
]);
const SECRET_RELATIVE_DIRECTORIES = new Set([
  '.config/gcloud', '.config/azure', '.config/gh', '.config/oci', '.config/containers',
  '.config/pulumi', '.config/1password', '.local/share/keyrings', '.password-store',
  '.terraform.d', '.pulumi', '.vercel', '.firebase',
]);
const ENV_EXAMPLES = new Set(['.env.example', '.env.sample', '.env.template', '.env.test.example', '.env.development.example']);

function runtimeName(value) {
  const selected = String(value || 'auto').toLowerCase();
  if (!['auto', 'docker', 'podman'].includes(selected)) throw new Error('Sandbox runtime must be auto, docker, or podman.');
  return selected;
}

function resolveExecutable(name, env = process.env) {
  const searchPath = String(env.PATH || env.Path || '');
  const extensions = process.platform === 'win32'
    ? (String(env.PATHEXT || '.EXE;.CMD;.BAT').split(';'))
    : [''];
  for (const directory of searchPath.split(path.delimiter).filter(Boolean)) {
    for (const extension of extensions) {
      const candidate = path.join(directory, `${name}${extension}`);
      try {
        const info = fs.statSync(candidate);
        if (info.isFile() && (process.platform === 'win32' || (fs.statSync(candidate).mode & 0o111))) return candidate;
      } catch { /* Continue searching PATH. */ }
    }
  }
  return null;
}

function engineEnv(env = process.env) {
  const allowed = ['PATH', 'Path', 'HOME', 'USERPROFILE', 'TMPDIR', 'TEMP', 'TMP', 'LANG', 'LC_ALL', 'XDG_RUNTIME_DIR', 'SYSTEMROOT', 'WINDIR'];
  const result = {};
  for (const key of allowed) if (typeof env[key] === 'string') result[key] = env[key];
  // Deliberately do not forward Docker remote-context/host overrides or credentials to child containers.
  return result;
}

function chooseImage(root, env) {
  const explicitlySelected = env.FORGE_SANDBOX_IMAGE;
  if (explicitlySelected) {
    if (!/^[A-Za-z0-9][A-Za-z0-9._/:@+-]{0,220}$/.test(explicitlySelected)) throw new Error('FORGE_SANDBOX_IMAGE contains unsupported characters.');
    if (!/@sha256:[a-f0-9]{64}$/i.test(explicitlySelected)) {
      throw new Error('FORGE_SANDBOX_IMAGE must be a digest-pinned image reference ending in @sha256:<64 hex characters>; mutable tags are refused.');
    }
    return explicitlySelected;
  }
  if (fs.existsSync(path.join(root, 'package.json'))) return DEFAULT_IMAGES.node;
  if (['pyproject.toml', 'requirements.txt', 'pytest.ini', 'tox.ini'].some((name) => fs.existsSync(path.join(root, name)))) return DEFAULT_IMAGES.python;
  if (fs.existsSync(path.join(root, 'go.mod'))) return DEFAULT_IMAGES.go;
  if (fs.existsSync(path.join(root, 'Cargo.toml'))) return DEFAULT_IMAGES.rust;
  return DEFAULT_IMAGES.generic;
}

function runtimeArgs(runtime, args) {
  // Override CLI-level remote selection: this feature only accepts a local daemon/runtime.
  if (runtime === 'docker') return ['--context=default', ...args];
  if (runtime === 'podman') return ['--remote=false', ...args];
  throw new Error('Unsupported container runtime.');
}

function checkedRun(binary, args, { env, timeoutMs = 2500, runtime } = {}) {
  try {
    const result = spawnSync(binary, runtime ? runtimeArgs(runtime, args) : args, {
      env: engineEnv(env), encoding: 'utf8', timeout: timeoutMs, windowsHide: true,
      stdio: ['ignore', 'pipe', 'pipe'], maxBuffer: 256 * 1024,
    });
    return { ok: result.status === 0 && !result.error, status: result.status, error: result.error?.message, stdout: result.stdout || '', stderr: result.stderr || '' };
  } catch (error) {
    return { ok: false, status: null, error: error.message, stdout: '', stderr: '' };
  }
}

export function inspectSandbox({ cwd = process.cwd(), env = process.env, timeoutMs = 2500 } = {}) {
  const root = path.resolve(cwd);
  if (process.platform === 'win32') {
    return { supported: false, reason: 'Windows sandbox execution is not implemented in this release; Forge refuses to emulate isolation with host execution.', platform: process.platform, runtime: null, image: null, available: false };
  }
  let info;
  try { info = fs.lstatSync(root); }
  catch { return { supported: false, reason: 'The current project directory is unavailable.', platform: process.platform, runtime: null, image: null, available: false }; }
  if (info.isSymbolicLink() || !info.isDirectory()) return { supported: false, reason: 'The project root must be a real directory, not a symlink.', platform: process.platform, runtime: null, image: null, available: false };

  let selectedRuntime;
  let image;
  try {
    selectedRuntime = runtimeName(env.FORGE_SANDBOX_RUNTIME);
    image = chooseImage(root, env);
  } catch (error) {
    return {
      supported: true, reason: error.message, platform: process.platform,
      runtime: null, binary: null, image: env.FORGE_SANDBOX_IMAGE || null,
      imageId: null, available: false, candidates: [],
    };
  }
  const candidates = selectedRuntime === 'auto' ? ['docker', 'podman'] : [selectedRuntime];
  const candidatesInfo = [];
  for (const name of candidates) {
    const binary = resolveExecutable(name, env);
    if (!binary) {
      candidatesInfo.push({ runtime: name, installed: false, engineReady: false, imageAvailable: false, reason: `${name} executable is not on PATH.` });
      continue;
    }
    if (name === 'docker') {
      // `--context=default` alone does not prove that the configured default context is local.
      // Inspect the endpoint and reject TCP/SSH or unrecognized endpoints before talking to it.
      const context = checkedRun(binary, ['context', 'inspect', 'default', '--format={{.Endpoints.docker.Host}}'], { env, timeoutMs, runtime: name });
      const endpoint = context.stdout.trim().replace(/^['"]|['"]$/g, '');
      if (!context.ok || !endpoint.startsWith('unix://')) {
        const detail = context.ok ? `Docker default context endpoint is not a local Unix socket path (${endpoint || 'empty endpoint'}).` : 'Docker default context could not be inspected; locality is unverified.';
        candidatesInfo.push({ runtime: name, binary, installed: true, engineReady: false, imageAvailable: false, endpoint: endpoint || undefined, reason: `${detail} Remote or unverified Docker contexts are refused.` });
        continue;
      }
    }
    const engine = checkedRun(binary, ['info'], { env, timeoutMs, runtime: name });
    if (!engine.ok) {
      candidatesInfo.push({ runtime: name, binary, installed: true, engineReady: false, imageAvailable: false, reason: engine.error || 'Container engine is not ready or access is denied.' });
      continue;
    }
    const imageCheck = checkedRun(binary, ['image', 'inspect', '--format={{.Id}}', image], { env, timeoutMs, runtime: name });
    const imageId = imageCheck.stdout.trim();
    const imageAvailable = imageCheck.ok && /^sha256:[a-f0-9]{64}$/i.test(imageId);
    candidatesInfo.push({ runtime: name, binary, installed: true, engineReady: true, imageAvailable, imageId: imageAvailable ? imageId : undefined, reason: imageAvailable ? 'Ready; image tag resolved to an immutable local image ID.' : `Image ${image} is missing or did not return a valid immutable ID. Forge will not pull images automatically.` });
  }
  const chosen = candidatesInfo.find((item) => item.engineReady && item.imageAvailable);
  const anyEngine = candidatesInfo.find((item) => item.engineReady);
  return {
    supported: true, platform: process.platform, runtime: chosen?.runtime || anyEngine?.runtime || candidatesInfo.find((item) => item.installed)?.runtime || null,
    binary: chosen?.binary || anyEngine?.binary || null, image, imageId: chosen?.imageId || null, available: Boolean(chosen), candidates: candidatesInfo,
    reason: chosen ? 'Container engine and local image are ready.' : (candidatesInfo.map((item) => `${item.runtime}: ${item.reason}`).join(' ') || 'No supported container runtime was found.'),
  };
}

function secretRelativePath(relativePath) {
  const parts = relativePath.split(path.sep);
  const normalized = parts.join('/').toLowerCase();
  const base = parts.at(-1).toLowerCase();
  if (parts.some((part) => EXCLUDED_DIRS.has(part.toLowerCase()))) return true;
  if ([...SECRET_RELATIVE_PATHS].some((secretPath) => normalized === secretPath || normalized.endsWith(`/${secretPath}`))) return true;
  if ([...SECRET_RELATIVE_DIRECTORIES].some((directory) => normalized === directory || normalized.startsWith(`${directory}/`) || normalized.includes(`/${directory}/`) || normalized.endsWith(`/${directory}`))) return true;
  if (SECRET_NAMES.has(base)) return true;
  if (/^\.env(?:\..*)?$/i.test(base) && !ENV_EXAMPLES.has(base)) return true;
  if (/\.(?:pem|p12|pfx|key|token|secret|credentials)$/i.test(base)) return true;
  return false;
}

export function copySanitizedWorkspace(sourceRoot, destinationRoot, { maxFiles = MAX_FILES, maxEntries = 50000, maxBytes = MAX_TREE_BYTES, maxFileBytes = MAX_FILE_BYTES } = {}) {
  const source = path.resolve(sourceRoot);
  const sourceInfo = fs.lstatSync(source);
  if (sourceInfo.isSymbolicLink() || !sourceInfo.isDirectory()) throw new Error('Sandbox source must be a real directory.');
  const realSource = fs.realpathSync(source);
  let files = 0;
  let entries = 0;
  let bytes = 0;
  let skippedSymlinks = 0;
  let skippedSecrets = 0;
  let skippedSpecial = 0;

  fs.mkdirSync(destinationRoot, { recursive: true, mode: 0o755 });
  // The staged copy is mounted read-only; make non-secret files readable by the
  // dedicated unprivileged container UID rather than inheriting host-only mode 0600.
  fs.chmodSync(destinationRoot, 0o755);

  function walk(sourceDir, destinationDir, prefix = '') {
    let canonicalSourceDir;
    try { canonicalSourceDir = fs.realpathSync(sourceDir); }
    catch { throw new Error(`Sandbox source directory disappeared while staging: ${prefix || '.'}`); }
    if (canonicalSourceDir !== path.resolve(sourceDir)) throw new Error(`Sandbox source directory changed or traverses a symlink while staging: ${prefix || '.'}`);
    const entriesInDirectory = fs.readdirSync(sourceDir, { withFileTypes: true });
    if (fs.realpathSync(sourceDir) !== canonicalSourceDir) throw new Error(`Sandbox source directory changed while reading entries: ${prefix || '.'}`);
    for (const entry of entriesInDirectory) {
      entries += 1;
      if (entries > maxEntries) throw new Error(`Sandbox copy refused workspace with more than ${maxEntries} entries.`);
      const relative = prefix ? path.join(prefix, entry.name) : entry.name;
      if (secretRelativePath(relative)) { skippedSecrets += 1; continue; }
      const sourcePath = path.join(sourceDir, entry.name);
      const destinationPath = path.join(destinationDir, entry.name);
      if (fs.realpathSync(sourceDir) !== canonicalSourceDir) throw new Error(`Sandbox source directory changed during traversal: ${relative}`);
      const info = fs.lstatSync(sourcePath);
      if (info.isSymbolicLink()) { skippedSymlinks += 1; continue; }
      if (info.isDirectory()) {
        fs.mkdirSync(destinationPath, { recursive: true, mode: ((info.mode & 0o111) | 0o555) });
        fs.chmodSync(destinationPath, ((info.mode & 0o111) | 0o555));
        walk(sourcePath, destinationPath, relative);
      } else if (info.isFile()) {
        if (fs.realpathSync(sourceDir) !== canonicalSourceDir) throw new Error(`Sandbox source directory changed before file open: ${relative}`);
        if (info.size > maxFileBytes) throw new Error(`Sandbox copy refused file over ${Math.floor(maxFileBytes / (1024 * 1024))} MB: ${relative}`);
        files += 1;
        if (files > maxFiles) throw new Error(`Sandbox copy refused workspace with more than ${maxFiles} regular files.`);
        let sourceFd;
        let destinationFd;
        let copiedBytes = 0;
        try {
          // Open the source without following a final-component symlink and verify the
          // inode after open; this closes the file-level lstat/copyFile TOCTOU window.
          const noFollow = fs.constants.O_NOFOLLOW || 0;
          sourceFd = fs.openSync(sourcePath, fs.constants.O_RDONLY | noFollow);
          if (fs.realpathSync(sourceDir) !== canonicalSourceDir) throw new Error(`Sandbox source directory changed during file open: ${relative}`);
          const openedInfo = fs.fstatSync(sourceFd);
          if (!openedInfo.isFile() || openedInfo.dev !== info.dev || openedInfo.ino !== info.ino || openedInfo.size !== info.size || openedInfo.mtimeMs !== info.mtimeMs || openedInfo.ctimeMs !== info.ctimeMs) {
            throw new Error(`Sandbox source changed while staging; refusing to follow a replaced path: ${relative}`);
          }
          const outputMode = ((info.mode & 0o111) | 0o444);
          destinationFd = fs.openSync(destinationPath, 'wx', outputMode);
          const buffer = Buffer.allocUnsafe(1024 * 1024);
          while (true) {
            const count = fs.readSync(sourceFd, buffer, 0, buffer.length, null);
            if (count === 0) break;
            copiedBytes += count;
            bytes += count;
            if (copiedBytes > maxFileBytes) throw new Error(`Sandbox copy refused file that grew beyond ${Math.floor(maxFileBytes / (1024 * 1024))} MB while staging: ${relative}`);
            if (bytes > maxBytes) throw new Error(`Sandbox copy refused workspace over ${Math.floor(maxBytes / (1024 * 1024))} MB.`);
            let offset = 0;
            while (offset < count) {
              const written = fs.writeSync(destinationFd, buffer, offset, count - offset);
              if (written <= 0) throw new Error(`Sandbox staging could not finish writing file: ${relative}`);
              offset += written;
            }
          }
          const afterInfo = fs.fstatSync(sourceFd);
          if (copiedBytes !== openedInfo.size || afterInfo.size !== openedInfo.size || afterInfo.mtimeMs !== openedInfo.mtimeMs || afterInfo.ctimeMs !== openedInfo.ctimeMs) {
            throw new Error(`Sandbox source changed during staging; retry after project writes stop: ${relative}`);
          }
        } catch (error) {
          if (error?.code === 'ELOOP' || error?.code === 'ENOTDIR') throw new Error(`Sandbox source changed to a link or invalid path during staging: ${relative}`);
          throw error;
        } finally {
          if (destinationFd !== undefined) fs.closeSync(destinationFd);
          if (sourceFd !== undefined) fs.closeSync(sourceFd);
        }
      } else skippedSpecial += 1;
    }
  }

  if (!realSource) throw new Error('Unable to resolve sandbox source root.');
  walk(realSource, destinationRoot);
  return { files, entries, bytes, skippedSymlinks, skippedSecrets, skippedSpecial };
}

export async function runSandboxedCommand(commandText, {
  cwd = process.cwd(), timeoutMs = 120000, maxOutputBytes = 1200000, env = process.env,
  runtime = 'auto', image,
} = {}) {
  const tokens = parseCommand(commandText);
  if (process.platform === 'win32') throw new Error('Sandboxed command execution is unavailable on Windows in this release. Forge will not silently execute on the host instead.');
  const root = path.resolve(cwd);
  const rootInfo = fs.lstatSync(root);
  if (rootInfo.isSymbolicLink() || !rootInfo.isDirectory()) throw new Error('Sandboxed command requires a real project directory, not a symlink.');
  const sandboxEnv = { ...env, FORGE_SANDBOX_RUNTIME: runtime === 'auto' ? (env.FORGE_SANDBOX_RUNTIME || 'auto') : runtime };
  if (image) sandboxEnv.FORGE_SANDBOX_IMAGE = image;
  const status = inspectSandbox({ cwd: root, env: sandboxEnv });
  if (!status.available || !status.binary || !status.runtime) {
    throw new Error(`Required sandbox unavailable; command was not executed. ${status.reason}`);
  }
  const workspaceImage = status.imageId;
  if (!workspaceImage || !/^sha256:[a-f0-9]{64}$/i.test(workspaceImage)) throw new Error('Sandbox image did not resolve to a valid immutable local ID; command was not executed.');
  const tempRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'forge-sandbox-'));
  fs.chmodSync(tempRoot, 0o700);
  // Check canonical paths too: TMPDIR may itself be a symlink into the current repository.
  const canonicalRoot = fs.realpathSync(root);
  const canonicalTempRoot = fs.realpathSync(tempRoot);
  const relativeTemp = path.relative(canonicalRoot, canonicalTempRoot);
  const tempInsideProject = relativeTemp === '' || (relativeTemp !== '..' && !relativeTemp.startsWith(`..${path.sep}`) && !path.isAbsolute(relativeTemp));
  if (tempInsideProject) {
    fs.rmSync(tempRoot, { recursive: true, force: true });
    throw new Error('Sandbox staging directory would resolve inside the project root; command was not executed. Choose a separate temporary directory.');
  }
  if (canonicalTempRoot.includes(',')) {
    fs.rmSync(tempRoot, { recursive: true, force: true });
    throw new Error('Sandbox temporary path contains a comma that is ambiguous in container mount options; command was not executed. Configure a simpler TMPDIR.');
  }
  const stagedWorkspace = path.join(canonicalTempRoot, 'workspace');
  let copyStats;
  try {
    copyStats = copySanitizedWorkspace(root, stagedWorkspace);
    const uidGid = `${SANDBOX_UID}:${SANDBOX_GID}`;
    const containerName = `forge-sandbox-${randomUUID().replaceAll('-', '').slice(0, 18)}`;
    const args = [
      'run', '--name', containerName, '--rm', '--init', '--pull=never', '--network=none', '--read-only',
      '--tmpfs', `/tmp:rw,exec,nosuid,nodev,size=256m,uid=${SANDBOX_UID},gid=${SANDBOX_GID}`, 
      '--mount', `type=bind,src=${stagedWorkspace},dst=/input,readonly`,
      '--tmpfs', `/workspace:rw,exec,nosuid,nodev,size=512m,uid=${SANDBOX_UID},gid=${SANDBOX_GID}`,
      '--workdir', '/workspace', '--cap-drop=ALL', '--security-opt=no-new-privileges',
      '--pids-limit=128', '--memory=768m', '--cpus=1.5', '--user', uidGid,
      '--env', 'HOME=/tmp', '--env', 'CI=1', '--entrypoint=/bin/sh', workspaceImage,
      '-c', 'cp -R /input/. /workspace/ && chmod -R u+rwX /workspace && exec "$@"', 'forge-sandbox', ...tokens,
    ];
    return await new Promise((resolve, reject) => {
      let child;
      let stdout = '';
      let stderr = '';
      let outputBytes = 0;
      let timedOut = false;
      let overflow = false;
      let finished = false;
      let timeout;
      let escalation;
      let stopRequested = false;
      const done = (error, result) => {
        if (finished) return;
        finished = true;
        clearTimeout(timeout);
        clearTimeout(escalation);
        if (error) reject(error); else resolve(result);
      };
      try {
        child = spawn(status.binary, runtimeArgs(status.runtime, args), { cwd: tempRoot, env: engineEnv(sandboxEnv), shell: false, detached: true, windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] });
      } catch (error) { done(error); return; }
      const stop = () => {
        if (stopRequested || finished) return;
        stopRequested = true;
        // Killing the CLI alone may leave the daemon-managed container running; request daemon stop first.
        try { spawnSync(status.binary, runtimeArgs(status.runtime, ['stop', '--time', '1', containerName]), { env: engineEnv(sandboxEnv), encoding: 'utf8', timeout: 3500, stdio: 'ignore', windowsHide: true }); } catch { /* Still terminate the client process below. */ }
        terminateProcessTree(child, { env: engineEnv(sandboxEnv) });
        if (!escalation) escalation = setTimeout(() => terminateProcessTree(child, { force: true, env: engineEnv(sandboxEnv) }), 1200);
        escalation.unref?.();
      };
      const collect = (chunk, target) => {
        outputBytes += chunk.length;
        if (outputBytes > maxOutputBytes) { overflow = true; stop(); return; }
        if (target === 'stdout') stdout += chunk.toString('utf8'); else stderr += chunk.toString('utf8');
      };
      child.stdout.on('data', (chunk) => collect(chunk, 'stdout'));
      child.stderr.on('data', (chunk) => collect(chunk, 'stderr'));
      child.on('error', (error) => done(error));
      child.on('close', (code, signal) => done(null, {
        command: commandText, code: typeof code === 'number' ? code : -1, signal,
        stdout: stdout.slice(0, maxOutputBytes), stderr: stderr.slice(0, maxOutputBytes),
        timedOut, overflow, success: code === 0 && !timedOut && !overflow,
        sandbox: { runtime: status.runtime, image: status.image, imageId: workspaceImage, network: 'disabled', workspace: 'disposable-sanitized-copy', ...copyStats },
      }));
      timeout = setTimeout(() => { timedOut = true; stop(); }, Math.max(1000, timeoutMs));
      timeout.unref?.();
    });
  } finally {
    try { fs.rmSync(tempRoot, { recursive: true, force: true, maxRetries: 2, retryDelay: 100 }); }
    catch (error) { throw new Error(`Sandbox run finished, but Forge could not remove its temporary staging copy at ${tempRoot}: ${error.message}. Inspect and delete that exact directory manually before continuing.`); }
  }
}

export const sandboxDefaults = DEFAULT_IMAGES;
