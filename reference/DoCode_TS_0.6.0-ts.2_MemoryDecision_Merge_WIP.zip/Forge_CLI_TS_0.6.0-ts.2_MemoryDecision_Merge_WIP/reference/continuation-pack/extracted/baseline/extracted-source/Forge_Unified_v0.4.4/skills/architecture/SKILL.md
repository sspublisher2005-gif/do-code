---
name: Architecture Review
description: Inspect module boundaries, dependencies, data flow, and integration risks before a substantive redesign or refactor.
---

## Method
- Trace the execution path and identify the modules that own state, policy, I/O, and presentation.
- Look for the smallest cohesive change and compare alternatives only when their trade-offs matter.
- Preserve public APIs, existing conventions, data migrations, portability, cancellation, and error contracts unless change is required.
- Prefer explicit interfaces, deterministic behavior, bounded resources, and easy-to-test pure functions.
- Include failure paths and rollback behavior in the design.
- Avoid distributed orchestration, databases, background services, embeddings, or dependencies when a local deterministic solution is sufficient.

Record evidence versus inference. A diagram or proposal is not proof of implementation correctness.
