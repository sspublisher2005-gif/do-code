# Security audit

Review trust boundaries, authentication/authorization, input validation, secrets, network egress, filesystem paths, subprocesses, dependency lifecycle scripts, uploads, deserialization, injection, logging, and denial-of-service controls. Trace plausible attacker-controlled data paths. Report only evidence-based findings with severity, evidence location, impact, exploit preconditions, fix, and regression test. State coverage limitations. Do not attempt exploitation against external systems.
