# Browser QA

Inspect the application entry points and how it starts. Identify primary user journeys, visible outcomes, responsive states, browser console/page errors, failed network responses, accessibility signals, and game controls when relevant. Use the approved browser adapter if available. Save screenshots and structured evidence. Never claim browser execution if the browser was unavailable; do not reuse logged-in profiles or cookies without explicit authorization.
