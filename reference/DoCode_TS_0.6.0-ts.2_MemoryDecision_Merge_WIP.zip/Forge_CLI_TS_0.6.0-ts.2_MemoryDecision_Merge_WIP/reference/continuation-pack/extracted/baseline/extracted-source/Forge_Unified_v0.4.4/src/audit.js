import fs from 'node:fs';
import path from 'node:path';
import { redactSecrets, ensureRealDirectory } from './utils.js';

export function forgeDir(root) {
  const directory = path.join(root, '.forge');
  try {
    const info = fs.lstatSync(directory);
    if (info.isSymbolicLink() || !info.isDirectory()) throw new Error('.forge must be a real directory, not a symlink or file.');
  } catch (error) { if (error?.code !== 'ENOENT') throw error; }
  return directory;
}
export function auditPath(root) { return path.join(forgeDir(root), 'audit.jsonl'); }

function sanitizeAuditValue(value) {
  if (typeof value === 'string') return redactSecrets(value).slice(0, 12000);
  if (Array.isArray(value)) return value.slice(0, 200).map(sanitizeAuditValue);
  if (value && typeof value === 'object') {
    const safe = {};
    for (const [key, entry] of Object.entries(value).slice(0, 100)) safe[key] = sanitizeAuditValue(entry);
    return safe;
  }
  return value;
}

export function writeAudit(root, event) {
  const directory = ensureRealDirectory(forgeDir(root), 0o700);
  const file = auditPath(root);
  try { const info = fs.lstatSync(file); if (info.isSymbolicLink() || !info.isFile()) throw new Error('Forge audit path must be a regular file.'); }
  catch (error) { if (error?.code !== 'ENOENT') throw error; }
  const record = { timestamp: new Date().toISOString(), ...sanitizeAuditValue(event) };
  fs.appendFileSync(file, `${JSON.stringify(record)}\n`, { mode: 0o600 });
  return record;
}

export const MAX_AUDIT_READ_BYTES = 10 * 1024 * 1024;

export function readAudit(root) {
  const file = auditPath(root);
  let info;
  try { info = fs.lstatSync(file); }
  catch (error) { if (error?.code === 'ENOENT') return []; throw error; }
  if (info.isSymbolicLink() || !info.isFile()) return [];

  // Bound memory when a repository contains a huge/hostile audit log; active task records are appended at the end.
  const length = Math.min(info.size, MAX_AUDIT_READ_BYTES);
  const buffer = Buffer.allocUnsafe(length);
  const fd = fs.openSync(file, 'r');
  let bytesRead;
  try { bytesRead = fs.readSync(fd, buffer, 0, length, Math.max(0, info.size - length)); }
  finally { fs.closeSync(fd); }
  let content = buffer.subarray(0, bytesRead).toString('utf8');
  if (info.size > MAX_AUDIT_READ_BYTES) {
    const firstNewline = content.indexOf('\n');
    content = firstNewline === -1 ? '' : content.slice(firstNewline + 1);
  }
  const out = [];
  for (const line of content.split(/\r?\n/).filter(Boolean)) {
    try { out.push(JSON.parse(line)); } catch { /* Keep processing a damaged line-based log. */ }
  }
  return out;
}

export function summarizeCost(events) {
  const calls = events.filter((event) => event.action === 'model_call');
  const knownCosts = calls.filter((event) => Number.isFinite(event.costUsd));
  const knownTokenCalls = calls.filter((event) => Number.isFinite(event.tokensIn) || Number.isFinite(event.tokensOut));
  return {
    calls: calls.length,
    knownCostCalls: knownCosts.length,
    costUsd: knownCosts.reduce((sum, event) => sum + event.costUsd, 0),
    tokensIn: calls.reduce((sum, event) => sum + (Number.isFinite(event.tokensIn) ? event.tokensIn : 0), 0),
    tokensOut: calls.reduce((sum, event) => sum + (Number.isFinite(event.tokensOut) ? event.tokensOut : 0), 0),
    knownTokenCalls: knownTokenCalls.length,
  };
}
