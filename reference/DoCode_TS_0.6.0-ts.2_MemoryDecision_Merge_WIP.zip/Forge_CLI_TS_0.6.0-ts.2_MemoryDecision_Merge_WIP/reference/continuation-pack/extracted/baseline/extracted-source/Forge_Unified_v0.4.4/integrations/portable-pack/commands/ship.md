# Verify readiness to ship

Do not publish or deploy. Inspect repository instructions and status; determine the project's lint, typecheck, build, unit, integration, and end-to-end checks; run only checks allowed by the user's policy; inspect the final diff and Git status. Report a criterion-by-criterion table with command, exit code, result, and evidence path. If any required check did not run or failed, the result is NOT VERIFIED. Request approval before commit, push, release, deploy, migrations, or external side effects.
