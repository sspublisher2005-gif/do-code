/**
 * Heuristic prompt-injection indicators for repository-sourced text.
 * This is a warning layer, not a detector that can prove text is safe.
 * Authorization remains enforced by Forge's code paths and human gates.
 */
const INJECTION_RULES = [
  { id: 'instruction_override', label: 'instruction override', regex: /\bignore\s+(?:all\s+)?(?:previous|prior|earlier|above)\s+instructions\b/i },
  { id: 'system_prompt_extraction', label: 'hidden-instruction extraction', regex: /\b(?:reveal|print|dump|repeat|expose)\s+(?:the\s+)?(?:system|developer)\s+(?:prompt|instructions)\b/i },
  { id: 'secret_exfiltration', label: 'credential exfiltration instruction', regex: /\b(?:exfiltrate|send|upload|forward|transmit|post)\b.{0,100}\b(?:secrets?|credentials?|api[_ -]?keys?|access tokens?|private keys?|environment variables?)\b/i },
  { id: 'guardrail_bypass', label: 'safety-control bypass instruction', regex: /\b(?:disable|bypass|override|ignore)\b.{0,80}\b(?:approval|security policy|guardrails?|safety checks?|permission checks?)\b/i },
  { id: 'role_spoofing', label: 'embedded system/developer role marker', regex: /<\s*\/?\s*(?:system|developer)\s*>/i },
];

export function scanPromptInjection(index, memory = '') {
  const files = Array.isArray(index?.files) ? index.files : [];
  const candidates = files.map((file) => ({ path: file.path, text: String(file.content ?? '') }));
  if (memory) candidates.push({ path: 'FORGE.md', text: String(memory) });
  const findings = [];
  const seen = new Set();
  for (const item of candidates) {
    const labels = INJECTION_RULES.filter((rule) => rule.regex.test(item.text)).map((rule) => rule.label);
    if (!labels.length) continue;
    const key = `${item.path}:${labels.join(',')}`;
    if (seen.has(key)) continue;
    seen.add(key);
    findings.push({ path: item.path, indicators: labels });
    if (findings.length >= 30) break;
  }
  return findings;
}

/** Return whether a proposed patch needs a second, high-friction human approval. */
export function requiresElevatedPatchApproval(warnings) {
  return warnings.some((warning) => warning.severity === 'critical' || warning.risk === 'possible secret-to-network data flow');
}
