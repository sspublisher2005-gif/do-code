import fs from 'node:fs';
import { createHash } from 'node:crypto';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

export function findRepoRoot(startDir = process.cwd()) {
  const start = path.resolve(startDir);
  let current = start;
  while (true) {
    try {
      const gitPath = path.join(current, '.git');
      const info = fs.lstatSync(gitPath);
      // Worktrees/submodules may use a .git file rather than a directory.
      if (!info.isSymbolicLink() && (info.isDirectory() || info.isFile())) return fs.realpathSync(current);
    } catch { /* Continue toward the filesystem root. */ }
    const parent = path.dirname(current);
    if (parent === current) return fs.realpathSync(start);
    current = parent;
  }
}

export function isWithin(parent, candidate) {
  const relative = path.relative(parent, candidate);
  return relative === '' || (!relative.startsWith(`..${path.sep}`) && relative !== '..' && !path.isAbsolute(relative));
}

export function normalizeRelative(input) {
  if (typeof input !== 'string' || input.length === 0) throw new Error('Expected a non-empty relative path.');
  const normalized = input.replaceAll('\\', '/');
  if (normalized.startsWith('/') || /^[a-zA-Z]:/.test(normalized) || /[\u0000-\u001f\u007f-\u009f]/.test(normalized)) {
    throw new Error(`Unsafe path: ${input}`);
  }
  const segments = normalized.split('/');
  if (segments.some((part) => part === '..' || part === '.' || part === '')) throw new Error(`Unsafe path: ${input}`);
  return segments.join('/');
}


export function ensureRealDirectory(directory, mode = 0o700) {
  try {
    const info = fs.lstatSync(directory);
    if (info.isSymbolicLink() || !info.isDirectory()) throw new Error(`Refusing to use a symlink or non-directory: ${directory}`);
    return directory;
  } catch (error) {
    if (error?.code !== 'ENOENT') throw error;
  }
  // Non-recursive mkdir is deliberate: the parent must already be trusted and
  // this must never traverse an existing symlink at the path being created.
  try { fs.mkdirSync(directory, { mode }); }
  catch (error) { if (error?.code !== 'EEXIST') throw error; }
  const info = fs.lstatSync(directory);
  if (info.isSymbolicLink() || !info.isDirectory()) throw new Error(`Refusing to use a symlink or non-directory: ${directory}`);
  return directory;
}

export const SENSITIVE_NAME = /(^|\/)(\.env(?:\..*)?|\.npmrc|\.pypirc|\.netrc|secrets?(?:\..*)?|credentials?(?:\..*)?|id_rsa|id_ed25519|known_hosts|kubeconfig|.*\.(?:pem|p12|pfx|key|keystore|tfstate|tfstate\.backup))$/i;
export function isSensitivePath(relative) {
  const normalized = String(relative).replaceAll('\\', '/');
  return SENSITIVE_NAME.test(normalized) || /(^|\/)(?:\.aws|\.ssh|\.gnupg|\.kube|\.azure|\.terraform)(\/|$)/i.test(normalized) || /(^|\/)\.docker\/config\.json$/i.test(normalized);
}

export function resolveSafePath(root, relative, { allowMissing = true, rejectForge = true } = {}) {
  const normalized = normalizeRelative(relative);
  const segments = normalized.split('/');
  if (rejectForge && ['.forge', '.git'].includes(segments[0].toLowerCase())) throw new Error(`Protected Forge/Git path: ${relative}`);
  if (isSensitivePath(normalized)) throw new Error(`Sensitive path is blocked: ${relative}`);
  const absolute = path.resolve(root, ...segments);
  if (!isWithin(root, absolute)) throw new Error(`Path escapes repository: ${relative}`);

  let current = root;
  for (let i = 0; i < segments.length; i += 1) {
    current = path.join(current, segments[i]);
    let info;
    try { info = fs.lstatSync(current); } catch (error) {
      if (error?.code === 'ENOENT' && allowMissing) break;
      if (error?.code === 'ENOENT') throw new Error(`File does not exist: ${relative}`);
      throw error;
    }
    if (info.isSymbolicLink()) throw new Error(`Symlink paths are blocked: ${relative}`);
    if (i < segments.length - 1 && !info.isDirectory()) throw new Error(`Parent path is not a directory: ${relative}`);
  }
  return absolute;
}


/** Render untrusted text without allowing ANSI/VT control sequences to reach the terminal. */
export function safeTerminalText(value) {
  return String(value ?? '').replace(/[\u0000-\u0008\u000b-\u001f\u007f-\u009f]/g, (character) => {
    if (character === '\n' || character === '\t') return character;
    return `\\x${character.charCodeAt(0).toString(16).padStart(2, '0').toUpperCase()}`;
  });
}

export function redactSecrets(text) {
  return String(text)
    .replace(/\b(sk-or-v1-[A-Za-z0-9_-]{12,})\b/gi, '[REDACTED_OPENROUTER_KEY]')
    .replace(/\b(sk|rk)_(?:live|test)_[A-Za-z0-9]{16,}\b/gi, '[REDACTED_STRIPE_KEY]')
    .replace(/\b(sk-[A-Za-z0-9_-]{12,})\b/g, '[REDACTED_API_KEY]')
    .replace(/\b(github_pat_[A-Za-z0-9_]{20,}|gh[pousr]_[A-Za-z0-9]{20,})\b/gi, '[REDACTED_GITHUB_TOKEN]')
    .replace(/\b(xox[baprs]-[A-Za-z0-9-]{10,})\b/gi, '[REDACTED_SLACK_TOKEN]')
    .replace(/\b(AKIA[0-9A-Z]{16})\b/g, '[REDACTED_AWS_KEY]')
    .replace(/\b(AIza[0-9A-Za-z_-]{30,})\b/g, '[REDACTED_GOOGLE_KEY]')
    .replace(/\b(npm_[A-Za-z0-9]{20,})\b/g, '[REDACTED_NPM_TOKEN]')
    .replace(/\b(Bearer\s+)[A-Za-z0-9._~+\/-]{12,}/gi, '$1[REDACTED_TOKEN]')
    .replace(/((?:api[_-]?key|access[_-]?token|secret|password)\s*[:=]\s*)([\"']?)[^\s\"']{8,}\2/gi, '$1[REDACTED]');
}

export function sha256(text) {
  return createHash('sha256').update(String(text)).digest('hex');
}

export function safeReadText(filePath, maxBytes = 262144) {
  const stats = fs.statSync(filePath);
  if (!stats.isFile() || stats.size > maxBytes) return null;
  const buf = fs.readFileSync(filePath);
  if (buf.includes(0)) return null;
  const sample = buf.subarray(0, Math.min(buf.length, 8192));
  let unusual = 0;
  for (const byte of sample) if ((byte < 9 || (byte > 13 && byte < 32)) && byte !== 0) unusual += 1;
  if (sample.length && unusual / sample.length > 0.03) return null;
  return buf.toString('utf8');
}

export function isModuleMain(metaUrl) {
  if (!process.argv[1]) return false;
  try { return metaUrl === pathToFileURL(path.resolve(process.argv[1])).href; } catch { return false; }
}

export function truncate(text, max = 5000) {
  const string = String(text ?? '');
  return string.length > max ? `${string.slice(0, max)}\n… [truncated ${string.length - max} characters]` : string;
}
