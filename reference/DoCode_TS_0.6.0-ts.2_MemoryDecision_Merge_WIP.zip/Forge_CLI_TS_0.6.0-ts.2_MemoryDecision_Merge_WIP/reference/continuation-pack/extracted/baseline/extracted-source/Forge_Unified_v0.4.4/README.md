# Forge Coding Harness

**Version:** 0.4.4 · **Status:** experimental, integrated prototype · **Runtime:** Node.js 22+ · **Required runtime dependencies:** none

> **Product principle:** Your agent says “done.” Prove it.

Forge is a local-first, approval-first engineering harness for developers, founders, vibe coders, QA engineers, and small teams. It connects repository understanding, model-assisted planning and patches, reusable skills, bounded read-only specialist passes, approved verification, optional Playwright browser QA, checkpoints, audit events, and portable project instructions for Claude Code and OpenCode.

The aim is to make an outcome-driven coding workflow work in one place for beginners, vibe coders, students, developers, engineers, and experts. The interaction adapts within one CLI; these are not separate products. This version does **not** prove Forge is better than Claude Code, Codex, OpenCode, Pi, Antigravity, Jev, or any other incumbent. It is an experimental prototype with automated tests, not production-ready software. The v0.4.1 security patch authenticates explicitly imported context records with a private per-user MAC key. v0.4.2 adds encrypted, signed project-bound session records and restart-based resume. v0.4.3 added an opt-in disposable container command and `forge run --sandbox-tests` verification path; v0.4.4 runs the container workload as unprivileged UID/GID 65532:65532 and makes sanitized copied files readable to that identity, but it does not isolate ordinary approved commands or make the container path the default. Resume does not restore prior model transcript state or roll back partial edits.

## Start here

```bash
node --version                 # Node 22 or newer
npm test                       # unit + integration tests
npm run check                  # syntax check
node bin/forge.js --help
node bin/forge.js doctor
node bin/forge.js sandbox status
```

Use Forge in a disposable test project first. See `forge sandbox status` and [Sandbox Execution](docs/SANDBOX_EXECUTION.md). `forge sandbox run` uses the container path for one explicitly approved command; `forge run --sandbox-tests` opts recognized verification commands into the same path. Ordinary commands and default verification remain host-executed.


## Opt-in disposable sandbox (v0.4.4)

```bash
# Check whether local Docker/Podman and a suitable local image are ready
node bin/forge.js sandbox status

# Example for a Node.js project; first load an approved image using your own image policy
docker pull node:22-bookworm-slim@sha256:c3de60bf2f9dd0ac6370e6117950ff62d6e339527e7472301c9c78a017978392
node bin/forge.js sandbox run -- npm test
```

Forge never pulls the selected container image automatically. The sandbox executes one explicitly approved command against a disposable sanitized copy as unprivileged UID/GID 65532:65532, with networking disabled, a read-only container root, capped tmpfs workspace, resource limits, and a restricted environment. The built-in Node, Python, Go, Rust, and Alpine images are pinned to multi-platform digests; these digests establish immutable identity, not that images have no vulnerabilities. Changes are discarded. A local Docker/Podman engine and pre-existing project-appropriate image are required. Windows is not supported by this sandbox path yet and fails closed. Filename filtering cannot guarantee every secret is removed, and container/kernel vulnerabilities remain possible. This path is **opt-in** for `forge run --sandbox-tests`; it is not enabled by default and must not be treated as validated until a real Docker/Podman runtime and adversarial tests pass. See [Sandbox Execution](docs/SANDBOX_EXECUTION.md) and [remaining acceptance gates](docs/REMAINING_WORK_AND_ACCEPTANCE_GATES_2026-10-21.md).

## Project isolation and explicit sharing (v0.4.1)

Forge now treats each project root as a separate local context boundary. The project ID and bound filesystem root are stored privately in `.forge/project.json`. Normal commands stop if copied or moved project state points at a different root; inspect the mismatch with `project status` and use `project rebind` only if it is truly the same logical project.

```bash
node bin/forge.js init
node bin/forge.js project status
node bin/forge.js context list
```

Cross-project memory is never searched or loaded automatically. To share context, choose one reviewed file from another initialized Forge project. The command is interactive and requires typing `IMPORT SELECTED CONTEXT`:

```bash
node bin/forge.js context import --from /path/to/project-a --file docs/approved-architecture.md
node bin/forge.js context list
node bin/forge.js context remove CONTEXT_ID
```

Imports are stored in the target project's private `.forge/shared-context/` directory with source/target IDs, relative-path provenance and hashes. Only integrity-checked imports are added to context, and removal revokes future use. These controls are application-level isolation—not a hardened OS sandbox—and common secret redaction is not a guarantee. See [Project Isolation](docs/PROJECT_ISOLATION.md) for the complete contract and limits.

## What is integrated

### Adaptive clarification and decision support (v0.3.0)
- Small, clear fixes skip the interview and decision matrix by default; existing approval and verification gates still apply.
- For vague requests or consequential missing requirements, the planner can ask up to five blocking questions. Forge asks only what materially changes implementation or safety, then replans once; unresolved blockers stop the task rather than inviting guesses.
- While answering a question, `?` or `/explain` opens a separate, bounded help conversation. It sends only the current question, its reason/options, and the help question after separate consent. `/back` returns to the same question without changing the answer.
- Explicit compare/rank/choose requests, or a real material trade-off identified on a complex task, can use a strict decision matrix. Forge validates the schema and computes weighted scores locally. A disagreement between the model's recommendation and the calculated ranking—or low-confidence/missing evidence—forces an explicit user choice for implementation.
- A decision-only request returns the comparison and does not edit source files. Scores remain model assessments, not facts; cited sources are not automatically verified. This is inspired by the typed-decision concept associated with Jev/TypeSafe, but it does not call Jev and has no demonstrated accuracy advantage over it.

### Main coding harness
- OpenCode CLI transport or direct OpenRouter Chat Completions transport.
- Bounded repository indexing, file relevance ranking, symbol/import hints, common secret-path exclusions, and curated `FORGE.md` project context.
- Automatic routing to built-in skills and relevant project/user skills; bounded skill context and symlink refusal.
- A planner → patch proposer → human approval → checkpoint → approved test → reviewer workflow.
- Diff/path/symlink validation, small-scope patch rules, checkpoint undo, and a freeze/unfreeze emergency stop.
- One optional correction cycle after a failing test; corrective changes need another approval.
- Conditional post-change security review and heuristic risk flags.
- Local append-only audit events, redaction, cost reporting when a provider supplies usage data, and truthful unverified states.
- Local approximate code graph, Context7 documentation lookup, and selected consent-gated read-only research routes.

### Bounded read-only specialist passes
For sufficiently complex tasks, Forge can run up to three additional model calls in parallel. The specialists are selected according to task signals: repository explorer, test strategist, security reviewer, browser QA planner, or architecture advisor. They receive a bounded repository map/source excerpt and have no Forge tools, file-write path, or command-execution path. Their findings are passed to the main planner as **unverified model-generated hypotheses**, not ground truth.

```bash
# Complex task: up to two specialist calls by default
node /path/to/Forge_Unified/bin/forge.js run "Refactor the login API, check security, and add regression tests" --max-subagents 2

# No extra specialist model calls
node /path/to/Forge_Unified/bin/forge.js run --no-subagents "Explain this function"

# Explicitly cap to zero, one, two, or three
node /path/to/Forge_Unified/bin/forge.js run --max-subagents 3 "Integrate the API migration across the frontend and backend"
```

All passes use the same configured provider/model. This is not cross-model consensus and does not create long-lived independent agents that can write code. The main Forge process retains responsibility for all edits and approvals. Additional calls can increase latency and provider cost.

### Portable skills, agents, and commands
The portable pack is authored for project-scoped use with Claude Code and OpenCode. It contains 14 reusable skills, 8 read-only specialist profiles per target CLI, and 7 workflow commands, plus shared `AGENTS.md` rules and a Claude Code `CLAUDE.md` import.

Preview before writing:

```bash
node bin/forge.js layer preview --tool both
node bin/forge.js layer preview --tool claude
node bin/forge.js layer preview --tool opencode
```

Install into the current project only:

```bash
node /path/to/Forge_Unified/bin/forge.js layer install --tool both --target .
```

The installer writes only beneath the chosen project directory. It never changes global user settings or model configuration. Existing files are preserved by default. `--force` updates only tracked Forge-managed files that have not been edited since installation; it does not overwrite modified or user-owned files.

```bash
# Update unchanged Forge-managed files only
node /path/to/Forge_Unified/bin/forge.js layer install --tool both --target . --force

# Interactive uninstall; deletes only files still matching the saved manifest
node /path/to/Forge_Unified/bin/forge.js layer uninstall --target .
```

OpenCode and Claude Code agent metadata use separate files because these tools do not share identical agent permission/configuration schemas. The pack definitions give specialist profiles read-only file inspection and deny shell/task delegation where the respective configuration supports it. Validate against the installed version of each CLI before team rollout; this environment did not perform fresh live Claude Code/OpenCode CLI validation of the portable pack.

## Model configuration

Forge uses OpenCode CLI by default, or you can choose OpenRouter. It does not bundle a model or promise unlimited free inference.

OpenRouter example (PowerShell):

```powershell
node bin/forge.js init
$env:OPENROUTER_API_KEY = "YOUR_API_KEY"
node bin/forge.js config set provider openrouter
node bin/forge.js config set model "YOUR_PROVIDER_MODEL_ID"
node bin/forge.js doctor
node bin/forge.js run --dry-run "Inspect the date parser and propose a minimal fix"
```

Use your chosen provider's current model ID, quota, pricing, and terms. Never put secrets in project config, source control, `FORGE.md`, agent prompts, or reports. A remote model sees the context disclosed through Forge's consent workflow. “Local-first” is not the same as a guarantee that no data ever leaves the device.

## Run a coding task

```bash
# Local checks, no model call
node bin/forge.js doctor
node bin/forge.js index
node bin/forge.js graph
node bin/forge.js search "authentication token"
node bin/forge.js skills list
node bin/forge.js agents

# Ask for a patch; dry run never applies it or runs tests
node bin/forge.js run --dry-run "Fix the edge case in the date parser and add a regression test"

# Normal run; review the proposed diff and approve writes/commands as prompted
node bin/forge.js run "Fix the edge case in the date parser and add a regression test"

# Browser-only task routes directly to browser QA if Playwright is installed
node bin/forge.js browser status
node bin/forge.js browser test http://127.0.0.1:5173

# Stop guarded actions during an incident
node bin/forge.js freeze "Investigating unexpected behavior"
node bin/forge.js unfreeze

# Inspect saved evidence and rollback checkpoints
node bin/forge.js audit --tail 50
node bin/forge.js cost
node bin/forge.js undo
```

## Browser QA

Playwright is optional. Forge's browser adapter uses a fresh browser context, blocks non-allowlisted third-party origins, captures local screenshots and a bounded report, flags runtime/response/layout/accessibility signals, and can optionally start only recognized development-server scripts after consent.

```bash
node bin/forge.js browser setup
node bin/forge.js browser test http://127.0.0.1:5173
node bin/forge.js browser test --start
node bin/forge.js browser test http://127.0.0.1:5173 --exercise
```

Setup adds `playwright-core` to the target project's dev dependencies after consent; browser downloads are not performed by the setup command. The Forge Node adapter itself has **not** been driven through a real site in this environment: the Node `playwright`/`playwright-core` package is not present and registry installation was unavailable earlier in this session. Separately, a host Python Playwright 1.57 + system Chromium 144 smoke test exercised a controlled in-memory fixture, form calculation, accessible labels, desktop/mobile viewport rendering, console errors, screenshots, and detection of a seeded calculation defect. That validates the available browser engine and this fixture only; it does not validate Forge’s own Node adapter or a production website.

## Skills and specialist catalog

Built-in skills: `browser-testing`, `frontend-debugging`, `game-testing`, `test-driven-development`, `security-review`, `documentation-research`, `planning`, `architecture`, `backend-api`, `performance`, `accessibility`, `code-review`, `root-cause-debugging`, `ship-verification`.

Portable specialist profiles: `forge-explorer`, `forge-planner`, `forge-reviewer`, `forge-tester`, `forge-security-auditor`, `forge-browser-qa`, `forge-architect`, `forge-docs-researcher`. They are read-only analysis profiles, not unrestricted co-editors.

Portable commands: `/plan`, `/review`, `/ship`, `/security-audit`, `/debug`, `/browser-test`, `/unblock`.

## Sessions and restart-based resume (v0.4.3)

Forge stores task session records in the private user-state directory (default `~/.forge-cli/sessions/`, or the directory set by `FORGE_HOME`) rather than inside the project repository. Task text is encrypted at rest with AES-256-GCM using a derived key from the private per-user key. Records are authenticated with HMAC and bound to the active project ID, canonical root path, and project binding epoch. Forge rejects altered records and sessions from copied, moved, rebound, or unrelated roots. The session key and session store must remain outside the active repository.

```bash
node bin/forge.js sessions list
node bin/forge.js sessions show SESSION_ID
node bin/forge.js resume SESSION_ID
```

`forge sessions delete SESSION_ID` removes one authenticated session record after an exact typed confirmation; it does not undo project changes, delete the audit trail, or promise forensic secure erasure. A resume is deliberately a **restart of the saved task**, not restoration of the model's hidden conversation or exact interrupted internal step. It requires an interactive exact confirmation, starts a fresh attempt against the current filesystem, and keeps any partial edits from prior attempts. Review `git diff`, the session report, and `forge audit` before resuming. Finished sessions with verified checks and explicitly cancelled sessions cannot be restarted through this command. This foundation helps continuity but is not yet a crash-safe multi-step task graph or persistent semantic memory.

Forge loads project guidance from `FORGE.md`, builds a local repository index for the current run, and writes local audit/checkpoint evidence. Decision/interview metadata is recorded with hashes where described, and the question-help prompt avoids sending repository contents, but the primary coding/research model can receive the task and bounded repository context after consent.

## Security contract and limitations

- Patch application and test commands require approval; changes are checkpointed first.
- Ordinary `forge command` and default verification/test-repair commands still execute with the OS account’s available permissions after approval. Forge’s policy code is not a sandbox.
- `forge sandbox run -- COMMAND` and `forge run --sandbox-tests` use the opt-in disposable container path when a local Docker/Podman runtime and a pre-loaded image are available. The input copy is read-only, command changes are confined to capped tmpfs storage and discarded, network is disabled, and common secret paths are omitted. This is a risk reduction, not a hardened VM or guaranteed secret detector.
- Prompt-injection scanning is heuristic and can miss attacks. Repository content and browser data are treated as untrusted input, but text policy alone cannot guarantee immunity.
- Remote provider costs are not hard-enforced across all provider schemas. `forge cost` reports only usage/cost the provider actually returns.
- The research routes are consent-gated and read-only by intent; returned external text is untrusted. Some optional backend routes depend on local CLIs and account setup.
- Browser smoke audit is not a substitute for a maintained end-to-end test suite or manual QA.

See [Security Gate](docs/SECURITY_GATE.md), [Unified Architecture](docs/UNIFIED_ARCHITECTURE.md), [Sessions and Resume](docs/SESSIONS_AND_RESUME.md), [Competitor and User Pain Points](docs/COMPETITOR_AND_USER_PAINPOINTS_2026-10-21.md), [Source Reconciliation](docs/SOURCE_RECONCILIATION.md), and [Roadmap](docs/ROADMAP_UNIFIED.md), [Sandbox Execution](docs/SANDBOX_EXECUTION.md), [Three-Expert Review](docs/THREE_EXPERT_REVIEW_2026-10-21.md), and [Remaining Work](docs/REMAINING_WORK_AND_ACCEPTANCE_GATES_2026-10-21.md).

## Test status for this v0.4.4 review build

| Check | Result | What it means |
|---|---:|---|
| Automated unit/integration suite | **129 passed, 0 failed, 0 skipped** | Includes project/context isolation, encrypted signed sessions, session locks, SIGKILL recovery, sandbox staging, digest-pin checks, fail-closed behavior, secret-path filtering, approvals, and CLI flows. |
| JavaScript syntax check | **32 files checked** | All executable JavaScript modules passed `node --check`; syntax is not a substitute for runtime coverage. |
| Reproducible package verification | **PASS** | `npm run check:release` packs a tarball, validates required paths/no traversal, extracts it, runs its own 129 tests and syntax checker, and verifies CLI version/help. Result: 121 packaged entries, 0 failures. |
| Clean dependency install | **PASS** | `npm ci --ignore-scripts` completed from the committed lockfile in this environment. |
| npm audit | **0 reported vulnerabilities** | The package currently declares no external runtime dependencies, so this is a shallow dependency-tree result; it is not a source-code or container-image security audit. |
| CLI version/help | **PASS** | Extracted package reports version `0.4.4` and renders help including sandbox commands. |
| Chromium UI smoke fixture | **PASS, separate harness** | Python Playwright 1.57 + system Chromium 144 rendered a controlled fixture; form calculation, accessible labels, mobile viewport fit and zero console/page errors passed. Screenshots are included in the release evidence. A seeded wrong-tax calculation was detected (expected 41.25; faulty result 37.50). |
| Forge Node Playwright adapter | **Not fully verified** | The host has no Node Playwright package installed and registry install access failed earlier. The unit tests mock important adapter behaviors; the separate Python browser fixture is not a substitute for driving Forge’s actual adapter. |
| Sandbox-policy regression tests | **PASS** | A fake runtime verifies policy arguments, selected local endpoint behavior, digest-pinned defaults, sanitized-copy bounds, fixed UID/GID `65532:65532`, excluded secrets, and fail-closed behavior. This is not proof that a real runtime enforces the controls. |
| Real Docker/Podman isolation | **BLOCKED** | Docker, Podman, bwrap and firejail are not installed in this environment. Actual network denial, host-secret isolation, container cleanup and escape testing remain open. A Docker-enabled CI job is configured but no hosted run was available to inspect. |
| Third-party image scan/provenance | **BLOCKED** | Registry access/image pull and scanning were not run here. Digests prove immutable references, not trusted publisher provenance or vulnerability-free content. |
| Live provider-backed coding task | **NOT RUN** | No usable live coding agent/provider was available in this environment; no model-powered coding success is claimed. |
| Cross-platform hosted CI | **CONFIGURED, NOT VERIFIED** | Workflow matrix targets Linux, Windows and macOS, but no GitHub Actions run is available. Windows sandbox intentionally fails closed. |
| Independent security review / customer validation / matched benchmark | **NOT DONE** | No external reviewer, representative 20–30 user study, or controlled competitor run occurred. No superiority or product-market-fit claim is justified. |

Evidence logs and desktop/mobile screenshots are provided in the full source ZIP’s `evidence/` directory. The real-container, live-provider, hosted-CI, independent-review, and customer/benchmark gates are intentionally left open rather than marked green without evidence.

## Product goal

Forge should become one place where a user can describe a software outcome and the harness can understand the repository, choose skills/tools, delegate useful read-only investigations, make a minimal approved change, test the actual behavior, repair failures within limits, preserve evidence, and report remaining gaps truthfully. The current build integrates a practical slice of that workflow; proving it is better than competing agents requires repeated, held-out, matched benchmarks. See [Competitor Benchmark Plan](docs/COMPETITOR_BENCHMARK_PLAN.md).
