import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { installPortableLayer, previewPortableLayer, uninstallPortableLayer } from '../src/layer.js';

function tempDir() { return fs.mkdtempSync(path.join(os.tmpdir(), 'forge-layer-test-')); }

function exists(root, relative) { return fs.existsSync(path.join(root, ...relative.split('/'))); }

test('portable layer preview is read-only and supports each target CLI', () => {
  const before = fs.readdirSync(process.cwd());
  const both = previewPortableLayer({ tool: 'both' });
  const claude = previewPortableLayer({ tool: 'claude' });
  const opencode = previewPortableLayer({ tool: 'opencode' });
  assert.ok(both.length > claude.length);
  assert.ok(claude.some((item) => item.destination.startsWith('.claude/agents/')));
  assert.ok(opencode.some((item) => item.destination.startsWith('.opencode/agents/')));
  assert.deepEqual(fs.readdirSync(process.cwd()), before);
});

test('install targets only project-local paths and preserves existing user-owned files', () => {
  const root = tempDir();
  fs.writeFileSync(path.join(root, 'AGENTS.md'), '# My project rules\n');
  const result = installPortableLayer({ target: root, tool: 'both' });
  assert.ok(result.created.length > 20);
  assert.ok(result.preserved.includes('AGENTS.md'));
  assert.equal(fs.readFileSync(path.join(root, 'AGENTS.md'), 'utf8'), '# My project rules\n');
  assert.ok(exists(root, '.claude/agents/forge-explorer.md'));
  assert.ok(exists(root, '.opencode/agents/forge-security-auditor.md'));
  assert.ok(exists(root, '.claude/skills/browser-testing/SKILL.md'));
  assert.ok(exists(root, '.opencode/skills/ship-verification/SKILL.md'));
  assert.ok(exists(root, '.forge/portable-layer-manifest.json'));
  const layerManifest = JSON.parse(fs.readFileSync(path.join(root, '.forge/portable-layer-manifest.json'), 'utf8'));
  assert.equal(layerManifest.packVersion, '0.4.4');
  assert.ok(!exists(root, 'CLAUDE.md') || fs.readFileSync(path.join(root, 'CLAUDE.md'), 'utf8').includes('@AGENTS.md'));
  fs.rmSync(root, { recursive: true, force: true });
});

test('rerun is idempotent and --force updates only unmodified Forge-managed files', () => {
  const root = tempDir();
  const first = installPortableLayer({ target: root, tool: 'claude' });
  assert.ok(first.created.length > 10);
  const targetFile = path.join(root, '.claude/agents/forge-explorer.md');
  const second = installPortableLayer({ target: root, tool: 'claude' });
  assert.equal(second.created.length, 0);
  assert.ok(second.unchanged.length > 10);
  const original = fs.readFileSync(targetFile, 'utf8');
  fs.writeFileSync(targetFile, `${original}\n# user edit\n`);
  const third = installPortableLayer({ target: root, tool: 'claude', force: true });
  assert.ok(third.preserved.includes('.claude/agents/forge-explorer.md'));
  assert.match(fs.readFileSync(targetFile, 'utf8'), /# user edit/);
  fs.rmSync(root, { recursive: true, force: true });
});

test('uninstall removes only unchanged managed files and preserves modified files', () => {
  const root = tempDir();
  installPortableLayer({ target: root, tool: 'claude' });
  const managed = path.join(root, '.claude/agents/forge-planner.md');
  const userOwned = path.join(root, '.claude/agents/custom.md');
  fs.writeFileSync(userOwned, 'Keep me');
  fs.appendFileSync(managed, '\n# edited by user\n');
  const result = uninstallPortableLayer({ target: root });
  assert.ok(result.removed.includes('.claude/skills/browser-testing/SKILL.md'));
  assert.ok(result.preserved.includes('.claude/agents/forge-planner.md'));
  assert.match(fs.readFileSync(managed, 'utf8'), /edited by user/);
  assert.equal(fs.readFileSync(userOwned, 'utf8'), 'Keep me');
  assert.ok(exists(root, '.forge/portable-layer-manifest.json'));
  fs.rmSync(root, { recursive: true, force: true });
});

test('installer refuses symlink targets and symlinked destination directories', (t) => {
  const root = tempDir();
  const elsewhere = tempDir();
  const targetLink = path.join(root, 'target-link');
  try { fs.symlinkSync(elsewhere, targetLink, 'dir'); } catch { t.skip('directory symlinks unavailable'); return; }
  assert.throws(() => installPortableLayer({ target: targetLink }), /symlink/);
  const destination = path.join(root, 'dest'); fs.mkdirSync(destination);
  fs.symlinkSync(elsewhere, path.join(destination, '.claude'), 'dir');
  assert.throws(() => installPortableLayer({ target: destination, tool: 'claude' }), /symlink/);
  assert.equal(fs.existsSync(path.join(elsewhere, 'agents', 'forge-explorer.md')), false, 'symlink target receives no agent files');
  fs.rmSync(path.join(destination, '.claude'));
  fs.symlinkSync(elsewhere, path.join(destination, '.opencode'), 'dir');
  assert.throws(() => installPortableLayer({ target: destination, tool: 'both' }), /symlink/);
  assert.equal(fs.existsSync(path.join(destination, '.claude', 'agents', 'forge-explorer.md')), false, 'preflight prevents partial installation before discovering the later symlink');
  fs.rmSync(root, { recursive: true, force: true }); fs.rmSync(elsewhere, { recursive: true, force: true });
});

test('uninstall without a manifest is a no-op', () => {
  const root = tempDir();
  assert.deepEqual(uninstallPortableLayer({ target: root }).removed, []);
  fs.rmSync(root, { recursive: true, force: true });
});
