# Forge research and design adoption record — 2026-10-20

## Executive decision

Build Forge as a small, auditable controller with replaceable provider/model adapters. The trusted controller—not a system prompt—owns the active workspace, context boundaries, approvals, file writes, execution policy, verification, and the evidence ledger. Use other agents as design references and integration targets, not as code to merge wholesale.

Research performed 2026-10-20 against the public sources listed below. This was documentation/repository pattern research, not a full hands-on benchmark of every product.

## Adopt / adapt / reject decisions

| Source / pattern | Decision | How Forge applies it | Boundary / caution |
|---|---|---|---|
| OpenCode primary agents, subagents, and per-tool permissions | Adopt the pattern | Distinct planner/reviewer/specialist roles; tool permissions are explicit and centrally enforced; skills are loaded when relevant. | A model role is not a security boundary. Forge’s specialist passes remain hypotheses, not independent ground truth. |
| OpenCode and Gemini CLI project-level skills | Adopt and adapt | Project-local `FORGE.md`, skills discovered from current repository, bounded relevance-based loading, no silent user-wide memory merge. | Global skill discovery can be useful but may cross project boundaries; Forge keeps memory/project data separate and only imports context explicitly. |
| Pi JSONL session trees and explicit resume/branch commands | Adopt the UX and data-model lesson | Project-bound, versioned session state and safe resume are an architectural priority. | Full session persistence/resume is not implemented in v0.4.0; do not market it as complete. |
| Codex/Gemini/OpenHands sandbox approaches | Adopt as required security architecture | A trusted runner must enforce workspace isolation, minimal privileges, restricted networking, time/resource limits and cancellation. | Current Forge still does not supply a hardened OS sandbox. The v0.4.0 project-identity gate is not a sandbox. |
| Aider architect/ask/code separation and Git-aware workflow | Adopt the workflow separation | Separate decisions from source edits; show a bounded diff; checkpoints and independent test outcomes gate claims of completion. | Do not force a plan interview for small fixes; Forge's task triage keeps trivial work lightweight. |
| Hermes agent-managed skills and memory | Adopt with human review | Future lessons can become proposed, staged memory/skill changes with provenance and approval. | No autonomous silent memory write or unreviewed cross-project memory transfer. |
| Model-generated scores, consensus, and self-improvement | Restrict | Validate structured output and calculate rankings locally; benchmark proposals against controls before promotion. | Agreement between models is not truth. A self-improving optimizer needs immutable evaluation logic and held-out tasks. |
| Whole-repository code copying or mixing runtimes | Reject as default | Implement only small, justified interfaces and patterns; record provenance, license and tests for any borrowed code. | Verify the license and notices for each dependency/file before incorporation; repository-level labels can hide mixed-license files. |

## Current release improvement shipped

The highest-priority context risk was project boundary ambiguity. v0.4.0 adds:

1. a stable local project UUID and root binding;
2. a command guard for copied/moved identities;
3. active-project visibility;
4. explicit one-file imports from a distinct initialized project;
5. source/target provenance and content-hash validation;
6. removal/revocation and local audit events;
7. negative tests for cross-project context, sensitive paths, symlinks, tampering, relocation and mismatched roots.

This release still does not have durable task/session resume, hardened command execution isolation, real-provider end-to-end evidence, or fair comparative benchmark results.

## Research sources checked

- OpenCode — Agents and permissions: https://opencode.ai/docs/agents/
- OpenCode — Agent Skills: https://docs.opencode.ai/docs/skills/
- Gemini CLI — Sandboxing: https://github.com/google-gemini/gemini-cli/blob/main/docs/cli/sandbox.md
- Gemini CLI — Configuration and security settings: https://github.com/google-gemini/gemini-cli/blob/main/docs/reference/configuration.md
- Gemini CLI — Agent Skills: https://github.com/google-gemini/gemini-cli/blob/main/docs/cli/using-agent-skills.md
- OpenHands — Sandboxes (current V1 docs): https://github.com/OpenHands/docs/blob/main/openhands/usage/sandboxes/overview.mdx
- Aider — Ask, architect, code and help modes: https://aider.chat/docs/usage/modes.html
- Pi — Coding-agent sessions, resume, branches and ephemeral mode: https://github.com/badlogic/pi-mono/tree/main/packages/coding-agent
- MCP — 2026-07-28 specification and authorization changes: https://blog.modelcontextprotocol.io/posts/2026-07-28/
- Codex CLI source repository and license: https://github.com/openai/codex and https://github.com/openai/codex/blob/main/docs/license.md

The OpenHands page's older Docker-runtime article explicitly warns that mounted workspaces can still be changed by an agent, which is why “containerized” alone is not a sufficient security claim. Sandbox settings differ among tools and can be optional; Forge should expose the exact execution boundary in `doctor` and fail closed when the requested isolation level is unavailable.

## Product and engineering acceptance criteria

Forge is not considered production-ready until it can demonstrate all of the following on a clean supported environment:

- **Isolation:** tests prove no cross-project memory/files are loaded by default; only explicitly imported items enter target context; removal prevents future loads; relocation cannot silently use the previous identity.
- **Persistence/resume:** kill/restart at every workflow phase; resume within the same project without duplicate patches or losing approval state; wrong-project resume is blocked; a replay report identifies what is restored and what must be reapproved.
- **Execution safety:** disposable runner; workspace-only write boundary; secret-withholding; configurable egress; process-tree cancellation; resource limits; adversarial tests.
- **Provider reality:** at least one supported local provider and one explicitly approved remote provider finish a real change task with captured task artifact, diff, test exit code and redacted usage metadata.
- **Verification:** acceptance criteria are tied to observed test/build/browser commands and their exit codes; model prose alone never marks a requirement verified.
- **Research/benchmark:** pinned competitors/versions/models; task families and held-out set; multiple runs; raw per-task outcomes, cost, latency, safety failures and confidence intervals.
- **Release:** Linux, Windows PowerShell and macOS CI results; install/uninstall tests; license audit; checksum; documented migration and rollback.

Until these are evidenced, Forge remains an experimental engineering prototype.
