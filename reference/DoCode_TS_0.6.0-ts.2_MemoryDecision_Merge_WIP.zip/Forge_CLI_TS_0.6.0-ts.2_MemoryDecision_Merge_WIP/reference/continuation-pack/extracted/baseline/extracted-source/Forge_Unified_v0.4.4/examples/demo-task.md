# Demo: a minimal regression fix

Use a disposable directory, not a production repository.

1. Create `src/calc.js`:

   ```js
   export function average(values) {
     return values.reduce((sum, value) => sum + value, 0) / values.length;
   }
   ```

2. Create `package.json`:

   ```json
   { "name": "forge-demo", "private": true, "type": "module", "scripts": { "test": "node --test" } }
   ```

3. Create `calc.test.js` with tests for `[2, 4] → 3` and `[] → null` (the intended behavior for this demo).
4. Run `forge init` and `forge index`.
5. Run `forge run --dry-run "Make average return null for an empty array and add a regression test"`. Inspect the proposed diff. No patch is applied and no test is run in dry-run mode.
6. For an actual change, run the task normally in an interactive terminal. Approve only if you accept the exact diff and test command.
7. Run `forge undo` to see the hash-checked checkpoint rollback prompt.

A model provider is required for plan/coder/reviewer steps. `forge init`, `forge index`, and Forge's own test suite do not require a provider. `forge undo` can only revert a patch that Forge applied and checkpointed.
