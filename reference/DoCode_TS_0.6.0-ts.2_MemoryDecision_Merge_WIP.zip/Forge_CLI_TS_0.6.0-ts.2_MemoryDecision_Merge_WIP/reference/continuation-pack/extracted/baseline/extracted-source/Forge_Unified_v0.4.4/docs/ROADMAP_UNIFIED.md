# Forge roadmap and release gates

## v0.4.4 implementation update (2026-10-21)

Locally implemented: fixed unprivileged container UID/GID; digest-pinned built-in image references; expanded cloud/CLI secret-path exclusions; regular-file no-follow copy with inode/metadata checks and file/directory symlink-swap tests; user-writable disposable tmpfs copy; SIGKILL session recovery test; completion-gate hardening against false-green reports; clean npm-package verifier; lockfile and configured dependency-audit/cross-platform CI. Fresh local evidence: 129 automated tests passed, 32 JS modules syntax-checked, npm audit reports zero known vulnerabilities for the zero-dependency package, npm pack/extraction verification passed, and a separate Python Playwright + Chromium fixture passed. This does **not** close the production gates: no Docker/Podman runtime, no image scans, no Forge-native Node Playwright E2E, no live model task, no hosted CI, no independent review, and no customer/benchmark evidence.

# Unified Roadmap and Release Gates

Priorities are ordered by risk reduction and evidence quality, not by feature excitement. Completing one gate does not imply completion of later gates.

## v0.4.3 implemented a partial sandbox runner (not a release gate closure)

- Added `forge sandbox status` and `forge sandbox run -- COMMAND`.
- Added `forge run --sandbox-tests` to route recognized verification commands to a disposable sanitized copy; failures/unavailability do not fall back to host execution. Real runtime behavior remains unverified.
- Docker remote TCP/SSH context schemes are refused; a local Unix-socket proxy to a remote daemon cannot be detected by endpoint syntax alone and must be trusted. Podman is forced into local mode. Image tags resolve to immutable local image IDs for launch. No network, no automatic image pull, readonly input, capped tmpfs workspace, restricted environment, dropped capabilities, resource limits, bounded staging, timeout cleanup request and cleanup error reporting.
- Automated tests use a fake runtime and do not demonstrate real container security. The runner is opt-in and does not currently cover ordinary manual commands, provider CLIs, browser dev-server startup or all possible tool execution paths. Real runtime testing, image pinning, independent review, Windows support and safe write-back remain open.

## P0 — Make core runs safe and reproducible

1. **Complete and validate the trusted execution runner.** v0.4.3 contains an opt-in disposable container path, but this gate stays open until real Docker/Podman behavior, host-secret isolation, deny-by-default egress, resource limits, process-tree/container termination, image provenance and adversarial cases are independently validated.
2. **Reliability matrix.** Run unit/integration tests and CLI smoke checks on supported Node versions and Linux/Windows/macOS. Acceptance: recorded green runs with exact versions and no unresolved platform failures.
3. **Policy regression suite.** Path/symlink races, approval bypass, freeze handling, prompt injection, tool output redaction, provider error shapes, installer preservation and cancellation.
4. **Provider protocol validation.** Real endpoints only with an approved budget and explicit consent. Validate tool/result schemas, rate limit handling, retries, timeout, cancellation and cost/usage normalization.

## P1 — Prove the end-to-end engineering value

1. **Live coding task.** On a disposable sample repository, use one approved local provider and (if founder-authorized) one remote OpenAI-compatible provider. Capture redacted transcript, changed files, command exit codes, task duration, usage/cost when available and remaining defects.
2. **Browser end-to-end acceptance.** Launch a harmless sample web app, run Playwright against named user journeys, save trace/screenshots/console/network observations, reproduce at least one seeded defect, and prove report accuracy. No external customer site until explicit authorization.
3. **Independent security review.** Review the execution boundary, prompt/context policy, credentials, model/provider adapter, MCP, browser, installer/uninstaller and event logging; publish resolved findings and accepted risks.
4. **Session lifecycle hardening.** v0.4.3 adds per-session process locks and stale-attempt marking; run crash-injection and cross-process race tests before claiming crash-safe resume.
5. **Feature-level compatibility tests.** Validate generated instructions/agents/skills against supported versions of Claude Code and OpenCode, in project-local sandbox repos. Keep model and CLI versions recorded.
6. **Usability workflow.** Have representative beginner, vibe coder and experienced developer users attempt real tasks; record assistance needed, success, time, unsafe actions and trust calibration.

## P1 — Benchmark instead of claiming superiority

- Define held-out tasks by language, framework, task family and difficulty.
- Compare the same model family/version and comparable context/tool/time budgets where legally and operationally available.
- Repeat task runs with seeds or task variants; keep task artifacts and evaluator versions.
- Score functional correctness, tests/regressions, patch quality, task completion, wall time, provider cost, human interventions, failure-to-recover, security incidents and truthful report accuracy.
- Publish raw JSON/CSV outputs and uncertainty intervals. Do not select only successful screenshots or hand-picked examples.

## v0.4.3 session concurrency/recovery increment

- Added atomic per-session process locks for fresh runs and restarts; a second active attempt is rejected.
- Same-host stale locks can be recovered after the recorded PID disappears; malformed and remote-host lock files require manual review.
- Before restart, an old `running` attempt is labeled `interrupted` with an explicit note that transcript state is unavailable.
- Direct module regression tests cover active-lock rejection and stale-lock recovery; crash-injection and subprocess race stress remain open.

## Session storage foundation introduced in v0.4.2 (not a production-readiness gate)

- User-state session records stored outside the repository; task text is encrypted with AES-256-GCM and the full record is authenticated with a private per-user HMAC key.
- Each session bound to project UUID, canonical root path and binding epoch; altered, moved/copied, or rebound records fail closed.
- Added `forge sessions list`, `forge sessions show ID`, exact-confirmation `forge sessions delete ID`, and interactive exact-confirmation `forge resume ID`.
- Session outcome derives from Forge audit evidence, distinguishing verified completion from unverified/blocked/cancelled states.
- Resume restarts the saved task from the beginning against current filesystem state. It does not restore prior model transcript, exact internal step, or roll back changes. This is safer than falsely claiming exact resume but is not a persistent multi-step task graph.

## Completed in v0.4.0 — project-isolation foundation (not a production-readiness gate)

- Local project UUID bound to canonical filesystem root.
- Fail-closed command boundary for mismatched moved/copied project identities; status/rebind recovery with exact confirmation.
- Per-run active-project visibility.
- Explicit one-file cross-project context imports with target/source provenance, content-hash checks, bounded inclusion, symlink/sensitive-path/oversize rejection, revocation and local audit events.
- Regression coverage for identity mismatch, relocation, selected-file-only import, tampering, revocation and symlink-backed context directory.
- Application-level boundary only: does not equal OS isolation, protect against a same-user malicious process, or solve conversation/session resumption.

## Completed in v0.3.0 — interaction and decision support (not a production-readiness gate)

- Adaptive task triage: clear small fixes skip interviews and ranking by default.
- Up to five blocking clarification questions, a single replan after answers, and stop-before-patch behavior when material ambiguity remains.
- Separate consented question-explainer side conversation using only minimal interview-question context; returning to the interview preserves the original answer state.
- Strict typed decision matrix with deterministic weighted ranking, evidence/unknown fields, and user-choice gate when ranking conflicts, confidence is low, or evidence is missing.
- Decision-only tasks return a comparison without proposing code edits. Unit tests cover these module behaviors; no live model-backed UX validation or decision-accuracy benchmark has run.

## P2 — Extend only after core gates

- Cross-session verified memory with inspect/edit/export controls; true transcript/step restoration, durable multi-step task graphs, comprehensive crash-injection recovery, and session export. v0.4.3 has basic stale-lock detection, but resume still restarts the task and does not restore prior execution state.
- Optional cross-provider / independent verification roles (requires clear cost, consent, privacy and model availability).
- Richer browser/game QA with explicit per-site allowlists and richer traces.
- IDE, GUI, team collaboration and shared workflow management.
- Controlled harness self-improvement: candidate diffs in isolated sandboxes, matched tests and human-approved promotion. No automatic promotion of model-generated rules.

## Founder gate

The founder approves material scope changes, external costs, provider usage budgets, publication, redistribution, and major security trade-offs. Until approval, use local-first/free-first options and keep publication/deployment off.
