import test from 'node:test';
import assert from 'node:assert/strict';
import { selectReadOnlySpecialists, buildSpecialistPrompt, formatSpecialistFindings, specialistDefinitions } from '../src/specialists.js';
import { buildExecutionPlan, selectSkillIds } from '../src/harness.js';

const complexTask = 'Refactor the authentication API across multiple services, add regression tests, check security boundaries, and verify the browser login journey end-to-end.';

test('small tasks do not trigger extra model calls', () => {
  assert.deepEqual(selectReadOnlySpecialists('Fix one typo in the README.'), []);
  assert.deepEqual(selectReadOnlySpecialists('Explain what this function does.'), []);
});

test('complex tasks select bounded specialists relevant to the task', () => {
  const security = selectReadOnlySpecialists(complexTask, { maxAgents: 3 });
  assert.deepEqual(security.map((agent) => agent.id), ['repository-explorer', 'security-reviewer', 'browser-qa-planner']);
  assert.ok(security.length <= 3);
  assert.ok(selectReadOnlySpecialists('Refactor the architecture and migrate the database across services.', { maxAgents: 2 }).some((agent) => agent.id === 'architecture-advisor'));
  assert.deepEqual(selectReadOnlySpecialists(complexTask, { enabled: false, maxAgents: 3 }), []);
  assert.deepEqual(selectReadOnlySpecialists(complexTask, { maxAgents: 0 }), []);
});

test('execution plan records specialist passes and honors disable/cap options', () => {
  const plan = buildExecutionPlan(complexTask, { maxSubagents: 3 });
  assert.equal(plan.subagents.length, 3);
  assert.ok(plan.roles.some((role) => role.includes('specialist fan-out')));
  assert.equal(buildExecutionPlan(complexTask, { noSubagents: true }).subagents.length, 0);
  assert.equal(buildExecutionPlan(complexTask, { maxSubagents: 1 }).subagents.length, 1);
  assert.equal(buildExecutionPlan('Test this website in the browser').subagents.length, 0, 'browser-only tasks route directly to browser QA');
});

test('specialist prompts enforce no tools, no writes, and evidence labeling', () => {
  const specialist = specialistDefinitions().find((item) => item.id === 'security-reviewer');
  const prompt = buildSpecialistPrompt({ specialist, task: 'Audit this app', repositorySummary: 'src/auth.js', excerpts: 'const token = "REDACTED";' });
  assert.match(prompt, /no tools/);
  assert.match(prompt, /no filesystem access/);
  assert.match(prompt, /untrusted DATA/);
  assert.match(prompt, /Never claim a tool was run/);
  assert.match(prompt, /Return exactly one JSON object/);
});

test('specialist findings are bounded and scrub secrets before reaching the planner', () => {
  const report = formatSpecialistFindings([{
    specialist: 'security-reviewer', status: 'complete', summary: 'Found possible API key sk-proj-12345678901234567890.',
    findings: [{ claim: 'Credential risk', evidence: 'secret: ghp_123456789012345678901234567890' }],
    relevantFiles: ['src/auth.js'], verificationIdeas: ['Run focused security tests'], unknowns: ['Runtime not tested'],
  }], 2500);
  assert.ok(report.length <= 2500);
  assert.doesNotMatch(report, /sk-proj-12345678901234567890|ghp_123456789012345678901234567890/);
  assert.match(report, /Credential risk/);
});

test('skill router selects focused newly added engineering skills', () => {
  assert.ok(selectSkillIds('Review the API authentication refactor for performance regressions').includes('backend-api'));
  assert.ok(selectSkillIds('Check keyboard access and WCAG contrast').includes('accessibility'));
  assert.ok(selectSkillIds('Find the root cause of this crash').includes('root-cause-debugging'));
  assert.ok(selectSkillIds('Prepare final release verification').includes('ship-verification'));
});
