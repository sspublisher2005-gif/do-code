import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { randomUUID } from 'node:crypto';
import { inspectSandbox, runSandboxedCommand } from '../src/sandbox.js';

function assert(condition, message) {
  if (!condition) throw new Error(message);
}

const image = process.env.FORGE_SANDBOX_IMAGE || 'node:22-bookworm-slim@sha256:c3de60bf2f9dd0ac6370e6117950ff62d6e339527e7472301c9c78a017978392';
const root = fs.mkdtempSync(path.join(os.tmpdir(), 'forge-real-sandbox-project-'));
const hostSecret = path.join(os.tmpdir(), `forge-host-secret-${randomUUID()}.txt`);
let report;
try {
  fs.writeFileSync(path.join(root, 'package.json'), JSON.stringify({ name: 'forge-real-sandbox-probe', version: '1.0.0' }));
  fs.writeFileSync(path.join(root, '.env'), 'FORGE_SANDBOX_SENTINEL=not-for-container\n');
  fs.writeFileSync(path.join(root, 'source.txt'), 'original source remains unchanged\n');
  fs.writeFileSync(hostSecret, 'host-only secret sentinel\n', { mode: 0o600 });
  const probe = `
import fs from 'node:fs';
import net from 'node:net';
const hostSecretPath = ${JSON.stringify(hostSecret)};
const results = { hostSecretReadable: false, envSecretVisible: Boolean(process.env.FORGE_SANDBOX_TEST_SECRET), envFileVisible: false, inputReadOnly: false, networkBlocked: false, workspaceCopyWritable: false };
try { fs.readFileSync(hostSecretPath, 'utf8'); results.hostSecretReadable = true; } catch { results.hostSecretReadable = false; }
try { fs.readFileSync('/input/.env', 'utf8'); results.envFileVisible = true; } catch { results.envFileVisible = false; }
try { fs.writeFileSync('/input/source.txt', 'modified'); } catch (error) { results.inputReadOnly = ['EROFS', 'EACCES', 'EPERM'].includes(error.code); }
results.networkBlocked = await new Promise((resolve) => {
  const socket = net.createConnection({ host: '1.1.1.1', port: 80 });
  let complete = false;
  const finish = (blocked) => { if (complete) return; complete = true; socket.destroy(); resolve(blocked); };
  socket.setTimeout(1500);
  socket.once('connect', () => finish(false));
  socket.once('error', () => finish(true));
  socket.once('timeout', () => finish(true));
});
try { fs.writeFileSync('/workspace/source.txt', 'modified only in disposable copy'); results.workspaceCopyWritable = fs.readFileSync('/workspace/source.txt', 'utf8') === 'modified only in disposable copy'; } catch { results.workspaceCopyWritable = false; }
fs.writeFileSync('/workspace/sandbox-output.txt', 'container-only output');
console.log(JSON.stringify(results));
`;
  fs.writeFileSync(path.join(root, 'sandbox-probe.mjs'), probe);
  const status = inspectSandbox({ cwd: root, env: { ...process.env, FORGE_SANDBOX_IMAGE: image } });
  assert(status.available, `Real sandbox runtime/image must be ready. ${status.reason}`);
  report = await runSandboxedCommand('node sandbox-probe.mjs', {
    cwd: root,
    timeoutMs: 15000,
    maxOutputBytes: 50000,
    env: { ...process.env, FORGE_SANDBOX_IMAGE: image },
  });
  assert(report.success, `Sandbox probe command failed (exit ${report.code}): ${report.stderr}`);
  const parsed = JSON.parse(report.stdout.trim().split(/\r?\n/).at(-1));
  assert(!parsed.hostSecretReadable, 'Container could read a host-only sentinel path.');
  assert(!parsed.envSecretVisible, 'Container inherited the sandbox-test secret environment variable.');
  assert(!parsed.envFileVisible, 'Sanitization copied .env into the sandbox input mount.');
  assert(parsed.inputReadOnly, 'Container could write to the read-only /input mount.');
  assert(parsed.networkBlocked, 'Container unexpectedly reached 1.1.1.1:80 despite --network=none.');
  assert(parsed.workspaceCopyWritable, 'Unprivileged sandbox could not modify its disposable workspace copy.');
  assert(fs.readFileSync(path.join(root, 'source.txt'), 'utf8') === 'original source remains unchanged\n', 'Original workspace file was modified.');
  assert(!fs.existsSync(path.join(root, 'sandbox-output.txt')), 'Disposable container output unexpectedly appeared in the original workspace.');
  console.log(JSON.stringify({
    result: 'PASS', runtime: report.sandbox.runtime, image: report.sandbox.image,
    immutableImageId: report.sandbox.imageId, assertions: {
      hostSecretNotReadable: true, providerStyleEnvNotInherited: true,
      dotenvOmitted: true, inputMountReadOnly: true, outboundNetworkBlocked: true,
      disposableWorkspaceWritable: true, originalProjectPreserved: true, containerWritesDiscarded: true,
    },
  }, null, 2));
} finally {
  fs.rmSync(root, { recursive: true, force: true, maxRetries: 2, retryDelay: 100 });
  fs.rmSync(hostSecret, { force: true });
}
