import readline from 'node:readline/promises';
import process from 'node:process';

export function createTerminal() {
  return readline.createInterface({ input: process.stdin, output: process.stdout, terminal: Boolean(process.stdin.isTTY && process.stdout.isTTY) });
}

export function canPrompt() { return Boolean(process.stdin.isTTY && process.stdout.isTTY); }

export async function askYesNo(rl, question) {
  if (!canPrompt()) return false;
  const answer = await rl.question(`${question} [y/N] `);
  return /^y(?:es)?$/i.test(answer.trim());
}

export async function askExactApproval(rl, question, phrase = 'APPROVE') {
  if (!canPrompt()) return false;
  const answer = await rl.question(`${question}\nType ${phrase} to continue: `);
  return answer.trim() === phrase;
}

export async function requestModelConsent(rl, config) {
  if (config.privacy.mode === 'local-only') return true;
  console.log(`\nPrivacy checkpoint: Forge will send the task, repository map, selected file excerpts, proposed diffs, and test results to the configured model through ${config.provider === 'openrouter' ? 'OpenRouter' : 'OpenCode'}. Forge excludes common secret files and redacts common token patterns, but redaction is not perfect. Provider account policies apply. No telemetry is sent by Forge.`);
  return askYesNo(rl, `Allow this run to send project context to ${config.model}?`);
}
