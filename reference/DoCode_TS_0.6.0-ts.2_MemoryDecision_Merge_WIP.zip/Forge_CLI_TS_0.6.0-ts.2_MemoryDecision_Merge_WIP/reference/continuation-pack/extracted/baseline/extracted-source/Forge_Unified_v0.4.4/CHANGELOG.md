# Changelog

## 0.4.4 — Unprivileged sandbox and release verification hardening

- Rejects mutable tags for custom `FORGE_SANDBOX_IMAGE` overrides; an explicit `@sha256:<64 hex>` digest is required. Local image presence and immutable ID checks still do not prove publisher identity or safety.

- Run sandbox workloads as fixed unprivileged UID/GID `65532:65532`, never inheriting host UID 0 into the container.
- Make the staged input root traversable and staged source files readable by the unprivileged identity while preserving executable bits and omitting common credentials, symlinks, and special files.
- Pin the built-in Node, Python, Go, Rust, and Alpine sandbox image references to immutable multi-platform digests; the operator-selected local image ID is still what the runtime executes. Image vulnerability and provenance scans remain open.
- Add tests for sandbox user identity and host source files that were mode `0600`.
- Make the disposable workspace copy user-writable inside tmpfs after copy; add a real POSIX UID/GID permission probe and a real-runtime writeability assertion.
- Reduce completion false positives: outstanding deterministic security warnings, a non-PASS conditional security verdict, or a browser result other than PASS keep the session at `needs_review`. Add direct regression tests for these gates.
- Add file- and directory-symlink TOCTOU regressions to fail closed if a path is swapped to an outside link during copy; set up the container init process for child reaping/signal forwarding.
- Exclude additional cloud/CLI credential stores from the staged copy and copy regular files through a no-follow descriptor with inode/metadata stability checks to reduce final-component symlink/overwrite races.
- Add a lockfile and CI dependency-audit step; GitHub Actions remain pinned to full commit SHAs.
- Add clean npm-package extraction verification and update release instructions.
- Do not claim real sandbox security, hosted CI, or live model-backed coding is complete until the dedicated jobs actually pass.

# Changelog

## 0.4.3 — Opt-in sandbox and session recovery hardening

- Added `forge sandbox status` to inspect local Docker/Podman availability and the project-appropriate local image.
- Added explicit `forge sandbox run -- COMMAND` that requires exact interactive approval and fails closed when a local runtime/image is unavailable.
- Added bounded sanitized workspace staging: omit `.git`, `.forge`, common credential paths, environment files other than examples, key/secret-like files, symlinks, and special files.
- Added no-network, no-auto-pull, read-only container root, read-only staging input, capped writable tmpfs workspace, dropped capabilities, no-new-privileges, process/memory/CPU bounds, restricted container environment, timeout handling, and explicit cleanup failure reporting.
- Inspect the Docker default context and fail closed unless it resolves to a local Unix socket; force Podman into local mode and drop remote endpoint environment overrides. Resolve local image tags to immutable image IDs for execution.
- Added tests for sanitized copy behavior, fail-closed behavior, remote Docker context rejection, immutable image-ID use, sandbox runtime flags, credential non-inheritance, and workspace bounds.
- Added atomic per-session locks for active runs/resumes/deletion; reject concurrent attempts, recover stale same-host locks, and label abandoned running attempts `interrupted` on restart.
- Updated `forge doctor` to describe sandbox readiness and clarify that ordinary approved host commands remain host-executed.
- Limitation: actual Docker/Podman runtime, adversarial escape, Linux kernel, image provenance, Windows backend, process-kill stress, and subprocess races have not been verified. The `--sandbox-tests` route is opt-in and does not make sandboxed coding/write-back the default.

- Added `scripts/real-sandbox-check.mjs` and a separate Ubuntu CI job that pulls the explicitly selected Node image and probes a real Docker runtime. This workflow has been configured but has not run from this environment; it is not counted as passing evidence until GitHub reports a green run.
- Added sanitization for common Docker/GitHub CLI/cloud SDK credential files and checked the canonical temporary staging path to reject a symlinked temp directory resolving into the project.

## 0.4.2 — Project-bound sessions and safe restart semantics

- Added HMAC-authenticated sessions bound to project identity, root, and binding epoch.
- Encrypted saved task text at rest and keyed the task fingerprint.
- Added list, show, explicit restart, and exact-confirmation session deletion.
- Resume re-runs the saved task against current files; it does not restore a prior model transcript or undo partial edits.

## 0.4.1 — Authenticate explicit context imports

- Require per-user HMAC authenticity for imported context records and bind records to the target project binding epoch.
- Reject signing-key paths inside participating projects.

## 0.4.0 — Project isolation baseline

- Added project identity/root binding and explicit selected-file context import/revoke operations.
