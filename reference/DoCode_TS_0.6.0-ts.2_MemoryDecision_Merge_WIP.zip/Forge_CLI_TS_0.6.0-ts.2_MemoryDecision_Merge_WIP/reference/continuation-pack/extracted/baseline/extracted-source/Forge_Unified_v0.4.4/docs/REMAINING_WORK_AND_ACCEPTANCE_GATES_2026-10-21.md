# Forge remaining work — v0.4.4 acceptance gates

**Baseline:** Forge Unified v0.4.4. This is a live checklist; each row separates code that exists from evidence that can close the gate. Do not mark completion based on a source file or mocked test alone.

## P0 — security and core trust

| Work | Current state | Acceptance evidence | Status |
|---|---|---|---|
| Container execution isolation | v0.4.4 uses an opt-in disposable container, fixed UID/GID `65532:65532`, no network, read-only input, read-only rootfs, capability drop, resource limits, sanitized files, and digest-pinned built-in references. Fake-runtime tests assert policy; real Docker/Podman are absent here. A Docker CI job is configured but no hosted run is available. | Green real Docker and Podman runs: network denial, host-secret sentinel, outside-file sentinel, writable tmpfs limits, timeout/child cancellation, daemon cleanup, plus adversarial review. | **OPEN — real runtime blocked** |
| Trusted image provenance | Built-in refs are digest-pinned. No image was pulled/scanned or signature/provenance verified in this environment; custom image overrides must be digest-pinned but remain operator-trusted. | Approved image allowlist/signature/provenance policy, image SBOM, vulnerability scan, update and rollback process. | **OPEN** |
| Crash-safe task lifecycle | Session locks and stale-attempt marking exist. A child process SIGKILL regression verifies interrupted-attempt marking/restart prevention. Resume re-runs the saved task from the beginning and leaves prior partial edits in place. | Crash injection at each phase, sustained multi-process contention, filesystem/power-loss recovery, stale-PID handling and partial-edit conflict/rollback behavior. | **PARTIAL** |
| Project/privacy isolation | Root-bound project IDs, explicit cross-project selected-file import, authenticated context, encrypted session task text, project-binding epochs and symlink/credential guards have regression coverage. This is app-level protection, not defense against all hostile same-user processes. | Full path/symlink race test matrix, credential leak review, import provenance/revocation, security review and external threat-model review. | **PARTIAL — local regressions pass** |
| Truthful completion reporting | Session attempts, exit codes, test status and audit events are recorded; task criteria/acceptance evidence are not fully enforced for all workflows. | Versioned task contract linking each acceptance criterion to test/browser/manual proof; fail on missing evidence; test false-positive/claim injection. | **OPEN** |
| Live model-backed coding | No model-backed task was run in this environment. No usable OpenCode/Codex/Claude agent CLI/provider was available, and live credentials must not be invented or silently used. | At least one simple and one multi-step task with approved provider, source diff, actual test commands, output/status, failure handling, token/cost or explicit unknown value, independent review and reproducible logs. | **BLOCKED — provider/agent unavailable** |

## P1 — coding quality and product trust

| Work | Current state | Acceptance evidence | Status |
|---|---|---|---|
| Provider adapter reliability | Providers and OpenCode subprocess logic exist; full live provider schemas/429/5xx/timeout/cancellation/cost variants are not validated. | Contract tests plus live provider tests against an explicitly approved test account. | **PARTIAL** |
| Fair coding benchmark | Public-source competitor research and a benchmark design exist; no matched benchmark was run. | 30–50 held-out tasks initially, controlled model/version/budget/tools, multiple seeds, success/cost/latency/safety and raw artifacts/human scoring. | **OPEN** |
| Cross-platform support | A GitHub Actions Linux/Windows/macOS Node 22 matrix is configured. No actual hosted run is available; Windows sandbox intentionally fails closed. | Obtain green hosted CI on all three operating systems and test package distribution. | **CONFIGURED, NOT VERIFIED** |
| Browser QA integration | Forge’s Node Playwright adapter has policy tests; its Playwright package is optional and missing here. A separate Python Playwright 1.57 + Chromium 144 smoke fixture passed desktop/mobile interactions and detected a deliberately seeded faulty calculation. | Drive Forge’s own Node adapter against a real sample app, save its report/screenshots, verify console/network/error handling, and validate the seeded-bug detection path. | **PARTIAL — separate fixture passed** |
| Dependency/supply chain | Lockfile added, zero runtime/dev dependencies declared, `npm ci --ignore-scripts` works, and `npm audit --audit-level=high` reports 0 known vulnerabilities for the zero-dependency tree. No source scanner or image scanner was run. | SBOM, source secret scan/review, image scan/provenance and hosted audit repeat. | **PARTIAL** |
| Reproducible release | Release verifier freshly packs/extracts npm tarball, validates safe paths/required files, runs packaged tests and syntax checks, and checks CLI version/help. Full source ZIP can be verified with ZIP test/checksum. | Repeatable CI release artifact generation, hosted artifact retention, checksums/signing and cross-OS install. | **PARTIAL — local checks green** |
| Independent security review | Internal simulated security review exists; it is not an external assessment. | External reviewer’s severity-ranked findings, fixes/regression tests and accepted risks with owner/date. | **OPEN** |

## P2 — onboarding, operations and customer validation

| Work | Current state | Acceptance evidence | Status |
|---|---|---|---|
| First-run setup | CLI help/doctor and local regression tests exist. No beginner usability study. | Clean-machine user completes setup and one verified code change with and without configured model, measure friction and abandonment. | **OPEN** |
| Cost transparency | Cost reporting reflects provider-returned usage and unknown values; no universal hard budget guarantee. | Provider-priced budget gates with date/versioned pricing and strict refusal before known budget overrun. | **PARTIAL** |
| User validation | Public reports/hypotheses only; no customer interviews. | Observe 20–30 target users with scripted real tasks; record success, time-to-verified-change, repeat usage and willingness to pay. | **OPEN** |
| Licensing/documentation | MIT license and third-party docs are present; release wording updated to avoid overstating unverified sandbox/browser status. | Full dependency/notices/license review, support policy and user-tested docs. | **PARTIAL** |
| Release operations | Local artifacts/checksums can be produced. The extracted npm source has no Git metadata or upstream; the connected GitHub listing exposes no repositories. Nothing was pushed or published. | Identify owner-controlled repository, push/PR after explicit destination confirmation, green hosted CI and signed/versioned release. | **BLOCKED — no upstream known** |

## P3 — defer until P0/P1 pass

- Full multi-step durable execution plans and exact transcript/step restoration.
- Agent teams with write-owning subagents and cross-model consensus.
- ACP/remote MCP/OAuth, IDE/GUI, marketplaces, hosted/team execution and managed services.
- Broader semantic memory/search and automatic write-back from sandbox, while maintaining strict project boundaries.

## Release rule

Forge is **not 100% complete** until its agreed criteria all have evidence. Current local checks are strong, but real sandbox/runtime validation, live provider tasks, Forge-native browser E2E, hosted cross-platform CI, independent security review, customer validation and fair competitor benchmarks remain open. Do not turn blocked work into a completion percentage by counting plans, source files, screenshots from an unrelated fixture, or mocked tests as proof.
