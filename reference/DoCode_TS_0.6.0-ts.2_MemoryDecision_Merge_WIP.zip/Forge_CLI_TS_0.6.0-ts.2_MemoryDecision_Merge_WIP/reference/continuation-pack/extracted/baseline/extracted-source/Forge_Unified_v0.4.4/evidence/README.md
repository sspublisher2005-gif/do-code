# Forge v0.4.4 evidence bundle

These files are outputs of the local validation actions conducted for the source release. Logs are kept separate from the npm package by the repository's `.npmignore`; the full source ZIP includes them for auditability.

## Interpretation rules

- `forge-v0.4.4-npm-test.log`: source test output; final suite is 129 passed, 0 failed/skipped.
- `forge-v0.4.4-check-release.log`: clean npm pack/extract test, test/syntax check in the packed package, and CLI version/help verification.
- `forge-v0.4.4-check.log`: syntax checks for 32 JavaScript files.
- `forge-v0.4.4-npm-ci.log`: clean dependency install; no external dependencies are currently declared.
- `forge-v0.4.4-npm-audit.log`: npm audit result for that dependency tree, not a source-code or image scanner.
- `forge-v0.4.4-cli-smoke.log`, `forge-v0.4.4-doctor.log`: CLI command outputs.
- `forge-v0.4.4-sandbox-status.log` and `forge-v0.4.4-sandbox-fail-closed.log`: demonstrate that sandboxing is not ready here and a payload command is refused before execution because Docker/Podman are absent. They do not prove container isolation.
- `forge-v0.4.4-browser-smoke.log` and screenshots: separate Python Playwright + Chromium test fixture loaded in-memory with `page.set_content`; it is not the Forge Node Playwright adapter or a live service.
- `forge-v0.4.4-workspace-permission-probe.log`: host POSIX file-permission reproduction under UID/GID 65532; it is not a container test.
- `forge-v0.4.4-environment-capabilities.log`: local executables and runtime availability. No environment secrets are recorded.
- `forge-v0.4.4-npm-pack.log`: npm's package file inventory and integrity metadata.
- `forge-v0.4.4-source-zip-tests.log`, `forge-v0.4.4-source-zip-check.log`, `forge-v0.4.4-source-zip-release-check.log`: reruns from this copied full-source tree.
- `forge-v0.4.4-npm-pack-dry-run.json`: final ZIP-tree dry-run inventory; its assertions verify `evidence/` is excluded from the installable package.

## Explicitly not proven

No real Docker/Podman execution, image scan/SBOM/signature verification, Forge-native Node Playwright E2E, live model-backed coding task, hosted GitHub Actions result, independent security review, external customer study, or matched competitor benchmark is present in this bundle.
