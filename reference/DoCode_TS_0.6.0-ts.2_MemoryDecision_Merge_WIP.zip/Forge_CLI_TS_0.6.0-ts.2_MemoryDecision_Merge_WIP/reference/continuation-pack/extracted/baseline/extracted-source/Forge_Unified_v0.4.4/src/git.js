import fs from 'node:fs';
import path from 'node:path';
import { createHmac, randomBytes, randomUUID, timingSafeEqual } from 'node:crypto';
import os from 'node:os';
import { spawnSync } from 'node:child_process';
import { forgeDir, writeAudit } from './audit.js';
import { buildCommandEnv } from './runner.js';
import { resolveSafePath, sha256, ensureRealDirectory, normalizeRelative, isSensitivePath } from './utils.js';

export function gitAvailable() {
  // Probes a trusted executable outside the project and must not expose provider secrets.
  const env = { ...buildCommandEnv(), GIT_CONFIG_NOSYSTEM: '1', GIT_OPTIONAL_LOCKS: '0' };
  const result = spawnSync('git', ['--version'], { cwd: os.tmpdir(), env, encoding: 'utf8', timeout: 1500, windowsHide: true });
  return result.status === 0;
}

export function gitStatus(root) {
  if (!fs.existsSync(path.join(root, '.git'))) return { available: gitAvailable(), isRepo: false, output: '' };
  // `git status` is not treated as a trusted no-op: local Git config can set core.fsmonitor
  // to an executable. Force it off before consulting project metadata and keep credentials
  // and system Git configuration out of the child environment.
  const env = { ...buildCommandEnv(), GIT_CONFIG_NOSYSTEM: '1', GIT_OPTIONAL_LOCKS: '0' };
  const result = spawnSync('git', ['-c', 'core.fsmonitor=false', '-c', 'core.untrackedCache=false', '--no-optional-locks', 'status', '--short'], { cwd: root, env, encoding: 'utf8', timeout: 3000, windowsHide: true });
  return { available: result.status === 0, isRepo: result.status === 0, output: result.stdout ?? '', error: result.status === 0 ? '' : (result.stderr ?? '') };
}

function checkpointKeyPath() {
  const home = process.env.FORGE_HOME?.trim() ? path.resolve(process.env.FORGE_HOME) : path.join(os.homedir(), '.forge-cli');
  return { directory: home, keyPath: path.join(home, 'checkpoint-key') };
}

function getCheckpointKey({ create = false } = {}) {
  const { directory, keyPath } = checkpointKeyPath();
  let directoryExists = false;
  try {
    const info = fs.lstatSync(directory);
    if (info.isSymbolicLink() || !info.isDirectory()) throw new Error('Forge user-state directory must be a real directory, not a symlink or special file.');
    directoryExists = true;
  } catch (error) { if (error?.code !== 'ENOENT') throw error; }
  if (!directoryExists) {
    if (!create) return null;
    ensureRealDirectory(directory, 0o700);
  }
  try {
    const info = fs.lstatSync(keyPath);
    if (info.isSymbolicLink() || !info.isFile() || info.size !== 32) throw new Error('Forge checkpoint signing key is invalid; do not replace it from a project repository.');
    if (process.platform !== 'win32' && (info.mode & 0o077)) fs.chmodSync(keyPath, 0o600);
    return fs.readFileSync(keyPath);
  } catch (error) {
    if (error?.code !== 'ENOENT' || !create) {
      if (error?.code === 'ENOENT') return null;
      throw error;
    }
  }
  const key = randomBytes(32);
  try { fs.writeFileSync(keyPath, key, { mode: 0o600, flag: 'wx' }); return key; }
  catch (error) {
    if (error?.code !== 'EEXIST') throw error;
    const info = fs.lstatSync(keyPath);
    if (info.isSymbolicLink() || !info.isFile() || info.size !== 32) throw new Error('Forge checkpoint signing key changed during initialization.');
    return fs.readFileSync(keyPath);
  }
}

function checkpointMac(snapshot, root, key) {
  const { mac, ...unsignedSnapshot } = snapshot;
  const binding = { version: 1, root: fs.realpathSync(root), snapshot: unsignedSnapshot };
  return createHmac('sha256', key).update(JSON.stringify(binding)).digest('hex');
}

function signCheckpoint(snapshot, root) {
  const key = getCheckpointKey({ create: true });
  snapshot.mac = checkpointMac(snapshot, root, key);
  return snapshot;
}

function validateCheckpoint(snapshot, root, filenameId, key) {
  if (!snapshot || typeof snapshot !== 'object' || Array.isArray(snapshot)) return false;
  if (typeof snapshot.id !== 'string' || snapshot.id !== filenameId || !isCheckpointId(snapshot.id)) return false;
  if (typeof snapshot.undone !== 'boolean' || !Array.isArray(snapshot.files) || snapshot.files.length < 1 || snapshot.files.length > 64) return false;
  if (typeof snapshot.createdAt !== 'string' || Number.isNaN(Date.parse(snapshot.createdAt))) return false;
  if (snapshot.undoneAt !== undefined && (typeof snapshot.undoneAt !== 'string' || Number.isNaN(Date.parse(snapshot.undoneAt)))) return false;
  if (typeof snapshot.mac !== 'string' || !/^[a-f0-9]{64}$/i.test(snapshot.mac)) return false;
  if (!key) return false;
  const expected = Buffer.from(checkpointMac(snapshot, root, key), 'hex');
  const supplied = Buffer.from(snapshot.mac, 'hex');
  if (expected.length !== supplied.length || !timingSafeEqual(expected, supplied)) return false;
  for (const file of snapshot.files) {
    if (!file || typeof file !== 'object' || typeof file.path !== 'string' || typeof file.existed !== 'boolean') return false;
    try { if (normalizeRelative(file.path) !== file.path || isSensitivePath(file.path)) return false; } catch { return false; }
    if (!/^[a-f0-9]{64}$/i.test(file.afterHash ?? '')) return false;
    if (file.existed) {
      if (!/^[a-f0-9]{64}$/i.test(file.beforeHash ?? '') || typeof file.contentBase64 !== 'string') return false;
      if (Buffer.from(file.contentBase64, 'base64').toString('base64') !== file.contentBase64) return false;
    } else if (file.beforeHash !== null || file.contentBase64 !== null) return false;
    if (!Number.isSafeInteger(file.mode) || file.mode < 0 || file.mode > 0o777) return false;
  }
  return true;
}

export function createCheckpoint(root, changes) {
  const internal = ensureRealDirectory(forgeDir(root), 0o700);
  const directory = ensureRealDirectory(path.join(internal, 'checkpoints'), 0o700);
  const id = `${new Date().toISOString().replaceAll(':', '-').replaceAll('.', '-')}-${randomUUID()}`;
  const snapshot = signCheckpoint({
    id,
    createdAt: new Date().toISOString(),
    undone: false,
    files: changes.map((change) => ({
      path: change.path,
      existed: change.existed,
      contentBase64: change.existed ? Buffer.from(change.original, 'utf8').toString('base64') : null,
      beforeHash: change.beforeHash,
      afterHash: change.afterHash,
      mode: change.mode ?? 0o600,
    })),
  }, root);
  fs.writeFileSync(path.join(directory, `${id}.json`), `${JSON.stringify(snapshot, null, 2)}\n`, { mode: 0o600, flag: 'wx' });
  writeAudit(root, { action: 'checkpoint_created', checkpointId: id, files: snapshot.files.map((file) => file.path) });
  return snapshot;
}

function isCheckpointId(id) {
  return /^\d{4}-\d{2}-\d{2}T\d{2}-\d{2}-\d{2}-\d{3}Z-[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(id);
}

export function listCheckpoints(root) {
  const directory = path.join(forgeDir(root), 'checkpoints');
  if (!fs.existsSync(directory)) return [];
  const info = fs.lstatSync(directory);
  if (info.isSymbolicLink() || !info.isDirectory()) return [];
  let key;
  try { key = getCheckpointKey({ create: false }); } catch { return []; }
  if (!key) return [];
  return fs.readdirSync(directory).filter((name) => name.endsWith('.json')).sort().reverse().flatMap((name) => {
    try {
      const full = path.join(directory, name);
      const stat = fs.lstatSync(full);
      if (stat.isSymbolicLink() || !stat.isFile() || stat.size > 2_000_000) return [];
      const snapshot = JSON.parse(fs.readFileSync(full, 'utf8'));
      const filenameId = name.slice(0, -'.json'.length);
      // Checkpoints may be copied from an untrusted repository. Bind them to the user's private signing key and canonical workspace path.
      if (!validateCheckpoint(snapshot, root, filenameId, key)) return [];
      return [snapshot];
    } catch { return []; }
  });
}

function atomicRestoreWrite(absolute, content, mode) {
  const temp = `${absolute}.forge-undo-${randomUUID()}`;
  try {
    fs.writeFileSync(temp, content, { mode: mode ?? 0o600, flag: 'wx' });
    fs.renameSync(temp, absolute);
  } catch (error) {
    try { fs.rmSync(temp, { force: true }); } catch { /* Best effort. */ }
    throw error;
  }
}

export function restoreLatestCheckpoint(root) {
  const candidates = listCheckpoints(root).filter((snapshot) => !snapshot.undone);
  if (!candidates.length) throw new Error('No unused Forge checkpoint was found.');
  const checkpoint = candidates[0];
  const beforeRestore = [];
  for (const file of checkpoint.files) {
    const absolute = resolveSafePath(root, file.path, { allowMissing: true });
    const exists = fs.existsSync(absolute);
    if (exists) {
      const stats = fs.lstatSync(absolute);
      if (!stats.isFile()) throw new Error(`Cannot undo: ${file.path} is no longer a regular file.`);
      const current = fs.readFileSync(absolute, 'utf8');
      if (sha256(current) !== file.afterHash) throw new Error(`Cannot safely undo ${file.path}: it changed after Forge's patch. Review it manually or use Git.`);
      beforeRestore.push({ file, absolute, current, exists: true, currentMode: stats.mode & 0o777 });
    } else {
      if (file.existed) throw new Error(`Cannot safely undo ${file.path}: it disappeared after Forge's patch.`);
      beforeRestore.push({ file, absolute, current: null, exists: false });
    }
  }
  const completed = [];
  try {
    for (const entry of beforeRestore) {
      if (entry.file.existed) {
        const original = Buffer.from(entry.file.contentBase64, 'base64').toString('utf8');
        atomicRestoreWrite(entry.absolute, original, entry.file.mode ?? 0o600);
      } else fs.rmSync(entry.absolute, { force: true });
      completed.push(entry);
    }
  } catch (error) {
    // Best-effort roll-forward to the exact post-patch state if a multi-file undo fails mid-transaction.
    for (const entry of completed.reverse()) {
      try {
        if (entry.exists) atomicRestoreWrite(entry.absolute, entry.current, entry.currentMode ?? 0o600);
        else fs.rmSync(entry.absolute, { force: true });
      } catch { /* Keep the original error; a human must inspect the checkpoint. */ }
    }
    throw new Error(`Undo failed while restoring files: ${error.message}`);
  }
  checkpoint.undone = true;
  checkpoint.undoneAt = new Date().toISOString();
  if (!isCheckpointId(checkpoint.id)) throw new Error('Refusing to update checkpoint metadata with an invalid identifier.');
  signCheckpoint(checkpoint, root);
  const checkpointPath = path.join(forgeDir(root), 'checkpoints', `${checkpoint.id}.json`);
  atomicRestoreWrite(checkpointPath, `${JSON.stringify(checkpoint, null, 2)}\n`, 0o600);
  writeAudit(root, { action: 'checkpoint_restored', checkpointId: checkpoint.id, files: checkpoint.files.map((file) => file.path) });
  return checkpoint;
}
