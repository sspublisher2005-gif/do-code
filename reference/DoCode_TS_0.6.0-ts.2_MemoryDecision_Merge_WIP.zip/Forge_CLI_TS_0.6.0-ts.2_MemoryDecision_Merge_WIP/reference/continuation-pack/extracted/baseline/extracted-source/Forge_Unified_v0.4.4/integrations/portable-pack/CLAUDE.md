<!-- Forge-managed file; safe to replace only when recorded in .forge/portable-layer-manifest.json -->
@AGENTS.md
