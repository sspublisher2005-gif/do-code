import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { VERSION } from './constants.js';

const PROJECT_ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const PACK_ROOT = path.join(PROJECT_ROOT, 'integrations', 'portable-pack');

function safeRelativePath(value) {
  if (typeof value !== 'string' || !value || path.isAbsolute(value) || value.includes('\0')) throw new Error('Unsafe layer path.');
  const normalized = value.replaceAll('\\', '/');
  if (normalized.split('/').some((part) => !part || part === '.' || part === '..')) throw new Error('Unsafe layer path.');
  return normalized;
}

function digest(content) {
  return crypto.createHash('sha256').update(content).digest('hex');
}

function assertRegularOrMissing(file) {
  try {
    const stat = fs.lstatSync(file);
    if (stat.isSymbolicLink() || !stat.isFile()) throw new Error(`Refusing symlink or non-file path: ${file}`);
    return true;
  } catch (error) {
    if (error?.code === 'ENOENT') return false;
    throw error;
  }
}

function ensureSafeDirectories(root, relativeDirectory) {
  const rel = safeRelativePath(relativeDirectory);
  let current = root;
  for (const segment of rel.split('/')) {
    current = path.join(current, segment);
    try {
      const stat = fs.lstatSync(current);
      if (stat.isSymbolicLink() || !stat.isDirectory()) throw new Error(`Refusing symlink or non-directory path: ${current}`);
    } catch (error) {
      if (error?.code !== 'ENOENT') throw error;
      try { fs.mkdirSync(current, { mode: 0o700 }); }
      catch (createError) { if (createError?.code !== 'EEXIST') throw createError; }
      const stat = fs.lstatSync(current);
      if (stat.isSymbolicLink() || !stat.isDirectory()) throw new Error(`Unsafe directory appeared during install: ${current}`);
    }
  }
}

function preflightManagedPath(root, relative, { leaf = 'file' } = {}) {
  const segments = safeRelativePath(relative).split('/');
  let current = root;
  for (let index = 0; index < segments.length; index += 1) {
    current = path.join(current, segments[index]);
    const isLeaf = index === segments.length - 1;
    try {
      const stat = fs.lstatSync(current);
      if (stat.isSymbolicLink()) throw new Error(`Refusing symlink in portable-layer path: ${current}`);
      if (!isLeaf && !stat.isDirectory()) throw new Error(`Portable-layer parent is not a directory: ${current}`);
      if (isLeaf && leaf === 'file' && !stat.isFile()) throw new Error(`Portable-layer destination is not a regular file: ${current}`);
      if (isLeaf && leaf === 'directory' && !stat.isDirectory()) throw new Error(`Portable-layer destination is not a directory: ${current}`);
    } catch (error) {
      if (error?.code === 'ENOENT') return;
      throw error;
    }
  }
}

function walkFiles(directory, prefix = '') {
  const results = [];
  for (const entry of fs.readdirSync(directory, { withFileTypes: true }).sort((a, b) => a.name.localeCompare(b.name))) {
    const absolute = path.join(directory, entry.name);
    if (entry.isSymbolicLink()) throw new Error(`Portable layer source contains a symlink: ${absolute}`);
    const relative = prefix ? `${prefix}/${entry.name}` : entry.name;
    if (entry.isDirectory()) results.push(...walkFiles(absolute, relative));
    else if (entry.isFile()) results.push(relative);
  }
  return results;
}

function loadManifest(root) {
  const file = path.join(root, '.forge', 'portable-layer-manifest.json');
  if (!assertRegularOrMissing(file)) return { file, data: { schemaVersion: 1, managedFiles: {} } };
  let parsed;
  try { parsed = JSON.parse(fs.readFileSync(file, 'utf8')); }
  catch { throw new Error('Existing portable-layer manifest is invalid JSON; refusing to overwrite files.'); }
  if (parsed?.schemaVersion !== 1 || !parsed.managedFiles || typeof parsed.managedFiles !== 'object' || Array.isArray(parsed.managedFiles)) {
    throw new Error('Existing portable-layer manifest has an unsupported shape; refusing to overwrite files.');
  }
  return { file, data: parsed };
}

function buildPlan(tool) {
  const entries = [];
  const addTree = (sourceDirectory, destinationPrefix) => {
    for (const file of walkFiles(sourceDirectory)) {
      entries.push({ source: path.join(sourceDirectory, file), destination: `${destinationPrefix}/${file}` });
    }
  };

  if (tool === 'both' || tool === 'claude') {
    addTree(path.join(PACK_ROOT, 'claude', 'agents'), '.claude/agents');
    addTree(path.join(PACK_ROOT, 'commands'), '.claude/commands');
    addTree(path.join(PROJECT_ROOT, 'skills'), '.claude/skills');
    entries.push({ source: path.join(PACK_ROOT, 'AGENTS.md'), destination: 'AGENTS.md' });
    entries.push({ source: path.join(PACK_ROOT, 'CLAUDE.md'), destination: 'CLAUDE.md' });
  }
  if (tool === 'both' || tool === 'opencode') {
    addTree(path.join(PACK_ROOT, 'opencode', 'agents'), '.opencode/agents');
    addTree(path.join(PACK_ROOT, 'commands'), '.opencode/command');
    addTree(path.join(PROJECT_ROOT, 'skills'), '.opencode/skills');
    entries.push({ source: path.join(PACK_ROOT, 'AGENTS.md'), destination: 'AGENTS.md' });
  }
  const deduped = new Map();
  for (const entry of entries) deduped.set(entry.destination, entry);
  return [...deduped.values()].sort((a, b) => a.destination.localeCompare(b.destination));
}

export function previewPortableLayer({ tool = 'both' } = {}) {
  if (!['both', 'claude', 'opencode'].includes(tool)) throw new Error('tool must be both, claude, or opencode.');
  return buildPlan(tool).map((entry) => ({ destination: entry.destination, bytes: fs.statSync(entry.source).size }));
}

export function installPortableLayer({ target = process.cwd(), tool = 'both', force = false } = {}) {
  if (!['both', 'claude', 'opencode'].includes(tool)) throw new Error('tool must be both, claude, or opencode.');
  const targetInput = path.resolve(String(target));
  const targetStat = fs.lstatSync(targetInput);
  if (targetStat.isSymbolicLink() || !targetStat.isDirectory()) throw new Error('Target must be an existing regular directory, not a symlink.');
  const root = fs.realpathSync(targetInput);
  if (root === path.parse(root).root) throw new Error('Refusing to install into a filesystem root.');
  if (!fs.statSync(PACK_ROOT).isDirectory()) throw new Error('The bundled portable layer pack is missing.');

  const plan = buildPlan(tool);
  // Validate every existing destination and the manifest path before the first write. This avoids
  // partially installing Claude files before discovering an unsafe OpenCode target (or vice versa).
  preflightManagedPath(root, '.forge', { leaf: 'directory' });
  preflightManagedPath(root, '.forge/portable-layer-manifest.json');
  for (const entry of plan) preflightManagedPath(root, entry.destination);
  ensureSafeDirectories(root, '.forge');
  const manifest = loadManifest(root);
  const oldManaged = { ...manifest.data.managedFiles };
  const nextManaged = { ...oldManaged };
  const summary = { target: root, tool, created: [], updated: [], unchanged: [], preserved: [], errors: [] };

  for (const entry of plan) {
    const relative = safeRelativePath(entry.destination);
    const segments = relative.split('/');
    const dest = path.join(root, ...segments);
    const resolved = path.resolve(dest);
    if (resolved !== root && !resolved.startsWith(`${root}${path.sep}`)) throw new Error('Layer path escapes target.');
    const sourceContent = fs.readFileSync(entry.source, 'utf8');
    const currentDigest = digest(sourceContent);
    if (segments.length > 1) ensureSafeDirectories(root, segments.slice(0, -1).join('/'));

    const exists = assertRegularOrMissing(dest);
    if (exists) {
      const existingContent = fs.readFileSync(dest, 'utf8');
      const existingDigest = digest(existingContent);
      if (existingDigest === currentDigest) {
        summary.unchanged.push(relative);
        // Do not claim an identical but previously untracked user file as managed.
        if (oldManaged[relative] === existingDigest) nextManaged[relative] = currentDigest;
        continue;
      }
      const wasManagedAndUntouched = oldManaged[relative] && existingDigest === oldManaged[relative];
      if (force && wasManagedAndUntouched) {
        fs.writeFileSync(dest, sourceContent, { mode: 0o600 });
        summary.updated.push(relative);
        nextManaged[relative] = currentDigest;
      } else {
        summary.preserved.push(relative);
        // Do not claim a user-edited/existing file as Forge-managed.
        if (!wasManagedAndUntouched) delete nextManaged[relative];
      }
      continue;
    }
    try {
      fs.writeFileSync(dest, sourceContent, { flag: 'wx', mode: 0o600 });
      summary.created.push(relative);
      nextManaged[relative] = currentDigest;
    } catch (error) {
      if (error?.code === 'EEXIST') {
        summary.preserved.push(relative);
        continue;
      }
      throw error;
    }
  }

  const manifestContent = `${JSON.stringify({ schemaVersion: 1, packVersion: VERSION, tool, managedFiles: nextManaged }, null, 2)}\n`;
  const manifestExists = assertRegularOrMissing(manifest.file);
  const tempManifest = path.join(root, '.forge', `.portable-layer-manifest.${process.pid}.tmp`);
  fs.writeFileSync(tempManifest, manifestContent, { flag: 'wx', mode: 0o600 });
  try { fs.renameSync(tempManifest, manifest.file); }
  catch (error) {
    try { fs.rmSync(tempManifest, { force: true }); } catch { /* best effort */ }
    if (!manifestExists && error?.code !== 'ENOENT') throw error;
    throw error;
  }
  summary.manifest = path.relative(root, manifest.file).replaceAll('\\', '/');
  summary.warning = fs.existsSync(path.join(root, '.git')) ? null : 'Target does not appear to be a Git repository. Most coding agents discover project instructions more reliably inside a repository root.';
  return summary;
}


export function uninstallPortableLayer({ target = process.cwd() } = {}) {
  const targetInput = path.resolve(String(target));
  const targetStat = fs.lstatSync(targetInput);
  if (targetStat.isSymbolicLink() || !targetStat.isDirectory()) throw new Error('Target must be an existing regular directory, not a symlink.');
  const root = fs.realpathSync(targetInput);
  if (root === path.parse(root).root) throw new Error('Refusing to uninstall from a filesystem root.');
  const forgeDirectory = path.join(root, '.forge');
  try {
    const forgeStat = fs.lstatSync(forgeDirectory);
    if (forgeStat.isSymbolicLink() || !forgeStat.isDirectory()) throw new Error('Refusing to uninstall through an unsafe .forge path.');
  } catch (error) {
    if (error?.code === 'ENOENT') return { target: root, removed: [], preserved: [] };
    throw error;
  }
  const { file, data } = loadManifest(root);
  if (!Object.keys(data.managedFiles).length) return { target: root, removed: [], preserved: [] };
  const removed = [];
  const preserved = [];
  for (const [relative, expectedDigest] of Object.entries(data.managedFiles)) {
    const safeRelative = safeRelativePath(relative);
    const segments = safeRelative.split('/');
    const absolute = path.resolve(root, ...segments);
    if (absolute !== root && !absolute.startsWith(`${root}${path.sep}`)) throw new Error(`Managed path escapes target: ${relative}`);
    try {
      const stat = fs.lstatSync(absolute);
      if (stat.isSymbolicLink() || !stat.isFile()) { preserved.push(relative); continue; }
      const content = fs.readFileSync(absolute, 'utf8');
      if (digest(content) !== expectedDigest) { preserved.push(relative); continue; }
      fs.unlinkSync(absolute);
      removed.push(relative);
    } catch (error) {
      if (error?.code !== 'ENOENT') throw error;
    }
  }
  const remainingManaged = {};
  for (const relative of preserved) {
    if (data.managedFiles[relative]) {
      remainingManaged[relative] = data.managedFiles[relative];
    }
  }
  if (Object.keys(remainingManaged).length) {
    fs.writeFileSync(file, `${JSON.stringify({ schemaVersion: 1, packVersion: data.packVersion || '0.2.0', tool: data.tool || 'both', managedFiles: remainingManaged }, null, 2)}\n`, { mode: 0o600 });
  } else {
    fs.unlinkSync(file);
    try { fs.rmdirSync(path.dirname(file)); } catch { /* preserve other Forge data */ }
  }
  return { target: root, removed, preserved };
}
