# Unblock a stalled task

Identify the precise blocker, what has already been tried, and whether the last attempt produced new evidence. Stop loops with no new information. Offer at most three options with trade-offs, choose the safest reversible next step, and state what access or founder decision is genuinely required. Do not ask for information already present in the repository or handoff.
