# Forge sandbox execution (v0.4.4)

## Status

Forge v0.4.4 adds an opt-in, fail-closed container path for one explicitly approved command and for recognized verification commands when `forge run --sandbox-tests` is selected. It is **not enabled by default**. Ordinary `forge command`, and runs without `--sandbox-tests`, remain host-executed after their existing approval checks. This reduces a major risk but does not close the production sandbox gate.

## Usage

```bash
# Check platform, runtime availability, and whether the chosen image is already local
forge sandbox status

# Example for a Node.js repository; the image must already exist locally
# Load/pin/scan the image yourself under your organization's image policy.
docker pull node:22-bookworm-slim@sha256:c3de60bf2f9dd0ac6370e6117950ff62d6e339527e7472301c9c78a017978392
forge sandbox run -- npm test
```

Forge never pulls images automatically. It chooses a default local image according to the project marker files and refuses to execute if a supported runtime is not ready or the image is missing. `FORGE_SANDBOX_RUNTIME=docker|podman|auto` selects the local engine; `FORGE_SANDBOX_IMAGE` overrides the project-default image. Forge resolves the selected local image reference to an immutable image ID and runs that ID to avoid a tag swap between inspection and launch. All built-in Node, Python, Go, Rust, and generic Alpine image references are pinned to multi-platform manifest digests. A digest proves reference immutability, not publisher identity, safety, or the absence of vulnerabilities. Custom `FORGE_SANDBOX_IMAGE` references must include an explicit `@sha256:<64 hex>` digest, so mutable tags are refused, but the selected digest still remains operator-trusted and is not automatically verified for provenance. It does not verify the image's publisher, signature, provenance, or vulnerability status; operators must apply their own image trust policy.

## Isolation controls applied to the command

- Docker's default endpoint is inspected and must use a local Unix-socket path; TCP/SSH or unverified context schemes fail closed. This checks the configured endpoint form, not the physical location of the daemon: a local socket proxy can still relay to another engine, so operators must trust that endpoint. Podman is invoked with `--remote=false`. Remote Docker host/context environment overrides are not passed through.
- No container network (`--network=none`) and no image pulls (`--pull=never`).
- Read-only container root filesystem, all Linux capabilities dropped, `no-new-privileges`, 128-process limit, 768 MiB memory limit, and 1.5 CPU limit.
- Common writable temporary storage is a capped tmpfs. The writable workspace is another capped tmpfs (512 MiB); it does not bind-mount the original project writable.
- The sanitized host-side project copy is mounted read-only at `/input`, copied into the capped container tmpfs, and the requested command runs in that copy. Changes made by the command are discarded. The workload runs under fixed unprivileged UID/GID `65532:65532`, even when Forge itself was started by root. Staged regular files are opened with `O_NOFOLLOW` where the platform provides it and the opened inode/metadata are checked before and after copying.
- The container receives only a small explicit environment (`HOME=/tmp`, `CI=1`), not provider tokens or the user's general environment.
- `.git`, `.forge`, common credential directories/files, `.env` variants (except example templates), private-key/secret-like filenames, symlinks, and special files are omitted from the staged copy. The copy has bounds on regular file count and total/individual file size. File-level no-follow and directory canonical-path checks reduce TOCTOU exposure, but they do not establish a fully race-free kernel boundary against a concurrent same-host writer.
- The runtime uses an init process to reap children and forward signals. Timeout/output-limit paths try to stop the daemon-managed container before terminating the local CLI process. Cleanup failures are errors, not a successful result.

## Image references pinned for v0.4.4

The built-in multi-platform references were checked against public Docker Hub image metadata on 2026-10-21: Node 22 Bookworm slim, Python 3.12 slim, Go 1.26 Bookworm, Rust 1 slim Bookworm, and Alpine 3.23. The package includes exact manifest-index digests in `src/sandbox.js`. These references have not been pulled or scanned in the implementation environment because registry DNS is unavailable; image SBOM/vulnerability results and signature/provenance validation remain open.

## Important limitations

1. A container is not a perfect VM. Kernel/container-runtime vulnerabilities, host misconfiguration, daemon privilege, and denial-of-service risks still exist.
2. This release only supports the POSIX execution path; Windows fails closed rather than silently running the command on the host.
3. Network is disabled. Tests requiring new dependency downloads will fail; pre-provision dependencies into the project or an approved local image before the run.
4. Common secret-name/path filtering is not semantic secret detection. Secrets in unusual filenames, source fixtures, test data, or other copied files could still be present. Review what the project contains before running untrusted code.
5. Symlinks are omitted. Projects relying on pnpm-style symlinked `node_modules` or linked source trees may not run correctly in this sandbox.
6. Results and artifacts are intentionally not copied back into the project. This command is for isolated inspection/verification, not a write-back workflow.
7. Ordinary approved host commands, browser dev-server startup and provider CLIs are not routed through this sandbox. The `--sandbox-tests` flag routes recognized test/build/lint/typecheck commands to it for both initial verification and the one corrective verification cycle; the model itself and patch writes still operate on the host workspace under approval.
8. No real Docker/Podman engine was available in the development environment at implementation time. Automated tests use a fake runtime to validate argument policy, sanitized-copy behavior, and fail-closed behavior. `scripts/real-sandbox-check.mjs` and a dedicated Ubuntu GitHub Actions job now probe actual filesystem, environment, network, and discarded-output boundaries, but that workflow has not yet run; a green run and broader adversarial review remain release gates.

## Release acceptance requirements still open

- Exercise a real local Docker and Podman engine; test actual network denial, filesystem confinement, timeout cancellation, output overflow, and daemon cleanup. v0.4.4 configures a Docker-hosted CI job, but no green hosted result is recorded yet.
- Use an approved image digest, image signature/provenance policy, SBOM and vulnerability scan.
- Add a bounded, explicit write-back workflow for coding tasks, if needed, without exposing host secrets or turning the original workspace into a writable container mount.
- Keep sandbox verification opt-in until real-runtime gates pass; then decide whether it should become the default without breaking dependency installation or artifact handling.
- Add Windows-native isolation backend; do not make host fallback implicit.
- Independently review the container runtime flags and attack surface.
