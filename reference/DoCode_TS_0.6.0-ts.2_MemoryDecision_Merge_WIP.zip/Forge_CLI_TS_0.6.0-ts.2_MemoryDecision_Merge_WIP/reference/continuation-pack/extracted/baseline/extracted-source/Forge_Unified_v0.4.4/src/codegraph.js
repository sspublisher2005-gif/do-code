import path from 'node:path';

const SOURCE_EXTENSIONS = ['.js', '.mjs', '.cjs', '.jsx', '.ts', '.tsx', '.py', '.go', '.rs'];
const INDEX_NAMES = ['index.js', 'index.mjs', 'index.ts', 'index.tsx', '__init__.py', 'mod.rs'];

function resolveInRepo(fromPath, specifier, known) {
  if (typeof specifier !== 'string' || !specifier.startsWith('.') || specifier.includes('\0') || specifier.includes('\\')) return null;
  const base = path.posix.normalize(path.posix.join(path.posix.dirname(fromPath), specifier));
  if (base === '..' || base.startsWith('../') || base.startsWith('/')) return null;
  const candidates = [base, ...SOURCE_EXTENSIONS.map((extension) => `${base}${extension}`), ...INDEX_NAMES.map((name) => `${base}/${name}`)];
  return candidates.find((candidate) => known.has(candidate)) ?? null;
}

/**
 * Build a deterministic, local-only import graph from Forge's already bounded index.
 * This intentionally uses conservative regex hints, not language parsers or code execution.
 */
export function buildLocalCodeGraph(index) {
  const files = Array.isArray(index?.files) ? index.files : [];
  const known = new Set(files.map((file) => file.path));
  const nodes = files.map((file) => ({
    id: file.path,
    kind: SOURCE_EXTENSIONS.includes(path.posix.extname(file.path)) ? 'source' : 'document',
    lineCount: Number.isSafeInteger(file.lines) ? file.lines : 0,
    symbols: (Array.isArray(file.symbols) ? file.symbols : []).slice(0, 120).map((symbol) => ({ name: String(symbol.name).slice(0, 200), line: symbol.line })),
  })).sort((a, b) => a.id.localeCompare(b.id));
  const edges = [];
  const externalPackages = new Set();
  for (const file of files) {
    const imports = Array.isArray(file.imports) ? file.imports : [];
    for (const specifier of imports.slice(0, 100)) {
      if (typeof specifier !== 'string' || !specifier || specifier.length > 300 || /[\x00-\x1f\x7f]/.test(specifier)) continue;
      const resolved = resolveInRepo(file.path, specifier, known);
      if (resolved) edges.push({ from: file.path, to: resolved, kind: 'imports', evidence: 'source-import', resolution: 'resolved-in-repository' });
      else if (!specifier.startsWith('.')) {
        const packageName = specifier.startsWith('@') ? specifier.split('/').slice(0, 2).join('/') : specifier.split('/')[0];
        if (packageName && /^[A-Za-z0-9@._:-]{1,160}$/.test(packageName)) {
          externalPackages.add(packageName);
          edges.push({ from: file.path, to: `external:${packageName}`, kind: 'imports', evidence: 'source-import', resolution: 'external-or-unresolved' });
        }
      }
    }
  }
  for (const name of [...externalPackages].sort()) nodes.push({ id: `external:${name}`, kind: 'external-package', lineCount: 0, symbols: [] });
  edges.sort((a, b) => a.from.localeCompare(b.from) || a.to.localeCompare(b.to));
  const inDegree = new Map(); const outDegree = new Map();
  for (const edge of edges) {
    outDegree.set(edge.from, (outDegree.get(edge.from) ?? 0) + 1);
    inDegree.set(edge.to, (inDegree.get(edge.to) ?? 0) + 1);
  }
  return {
    schemaVersion: 1,
    provenance: 'Derived locally from bounded text index; static regex import hints only; no code execution, network calls, embeddings, or semantic claims.',
    stats: { nodes: nodes.length, sourceFiles: files.length, edges: edges.length, internalEdges: edges.filter((edge) => edge.resolution === 'resolved-in-repository').length, externalOrUnresolvedEdges: edges.filter((edge) => edge.resolution !== 'resolved-in-repository').length },
    nodes,
    edges,
    hubs: [...known].map((id) => ({ id, incoming: inDegree.get(id) ?? 0, outgoing: outDegree.get(id) ?? 0 })).filter((item) => item.incoming + item.outgoing > 0).sort((a, b) => (b.incoming + b.outgoing) - (a.incoming + a.outgoing) || a.id.localeCompare(b.id)).slice(0, 20),
  };
}

export function renderGraphReport(graph) {
  const top = graph.hubs.length ? graph.hubs.map((item) => `- \`${item.id}\` — ${item.incoming} incoming, ${item.outgoing} outgoing`).join('\n') : '- No resolved import relationships found.';
  return `# Forge Local Code Graph\n\n> Generated locally from Forge's bounded index. Regex-based import hints are not a complete language parser. Unresolved and external edges are not proof of missing modules.\n\n## Summary\n\n- Nodes: ${graph.stats.nodes}\n- Files indexed: ${graph.stats.sourceFiles}\n- Import edges: ${graph.stats.edges}\n- Resolved internal imports: ${graph.stats.internalEdges}\n- External or unresolved imports: ${graph.stats.externalOrUnresolvedEdges}\n\n## Connected files\n\n${top}\n\n## Privacy and accuracy\n\n- Source file contents are not copied into this graph; it contains paths, symbol names/line numbers, import specifiers resolved to paths, and aggregate counts.\n- Secret/symlink exclusions come from Forge's repository indexer.\n- No model or network call was made.\n- This graph is a navigation aid, not a security proof or full semantic dependency graph.\n`;
}
