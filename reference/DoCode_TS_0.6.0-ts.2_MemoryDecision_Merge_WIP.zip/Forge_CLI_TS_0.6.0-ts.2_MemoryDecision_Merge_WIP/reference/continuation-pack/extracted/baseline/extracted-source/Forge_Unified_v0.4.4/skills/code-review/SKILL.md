---
name: Code Review
description: Review diffs for functional defects, regressions, security issues, scope creep, and maintainability with evidence.
---

## Review order
1. Correctness against acceptance criteria and real call paths.
2. Security/privacy, authorization, secret handling, and untrusted inputs.
3. Edge cases, error handling, cancellation, resource bounds, and concurrency.
4. Backward compatibility, data migrations, cross-platform behavior, and rollback.
5. Tests that establish the intended behavior and reproduce the bug.
6. Scope, maintainability, and style only where consequential.

For each finding: severity, exact file/line or path, concrete evidence, impact, and minimal fix. Do not report speculative style preferences as bugs. If evidence is insufficient, state the gap.
