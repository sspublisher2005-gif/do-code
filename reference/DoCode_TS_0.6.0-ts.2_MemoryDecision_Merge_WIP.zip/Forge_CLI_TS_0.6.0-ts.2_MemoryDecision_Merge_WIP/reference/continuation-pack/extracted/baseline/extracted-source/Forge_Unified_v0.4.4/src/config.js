import fs from 'node:fs';
import path from 'node:path';
import { randomUUID } from 'node:crypto';
import { DEFAULT_CONFIG } from './constants.js';

export const CONFIG_NAME = 'forge.config.json';

export function loadConfig(root) {
  const target = path.join(root, CONFIG_NAME);
  try {
    const info = fs.lstatSync(target);
    if (info.isSymbolicLink() || !info.isFile() || info.size > 128000) throw new Error(`${CONFIG_NAME} must be a regular JSON file under 128 KB.`);
  } catch (error) { if (error?.code === 'ENOENT') return structuredClone(DEFAULT_CONFIG); throw error; }
  let raw;
  try { raw = JSON.parse(fs.readFileSync(target, 'utf8')); }
  catch (error) { throw new Error(`Cannot parse ${CONFIG_NAME}: ${error.message}`); }
  const merged = mergeConfig(structuredClone(DEFAULT_CONFIG), raw);
  validateConfig(merged);
  return merged;
}

function mergeConfig(base, override) {
  if (!override || typeof override !== 'object' || Array.isArray(override)) throw new Error('Forge config must be a JSON object.');
  for (const [key, value] of Object.entries(override)) {
    if (['__proto__', 'prototype', 'constructor'].includes(key)) throw new Error(`Unsupported dangerous configuration key: ${key}`);
    if (value && typeof value === 'object' && !Array.isArray(value) && base[key] && typeof base[key] === 'object') {
      base[key] = mergeConfig(base[key], value);
    } else base[key] = value;
  }
  return base;
}

export function validateConfig(config) {
  if (!['opencode', 'openrouter'].includes(config.provider)) throw new Error('config.provider must be \"opencode\" or \"openrouter\".');
  if (typeof config.openrouter?.baseUrl !== 'string' || config.openrouter.baseUrl.length > 300) throw new Error('openrouter.baseUrl must be the official OpenRouter API base URL.');
  let openRouterUrl;
  try { openRouterUrl = new URL(config.openrouter.baseUrl); } catch { throw new Error('openrouter.baseUrl must be the official OpenRouter API base URL.'); }
  if (openRouterUrl.protocol !== 'https:' || openRouterUrl.hostname !== 'openrouter.ai' || openRouterUrl.port || openRouterUrl.username || openRouterUrl.password || openRouterUrl.search || openRouterUrl.hash || !['/api/v1', '/api/v1/'].includes(openRouterUrl.pathname)) {
    throw new Error('openrouter.baseUrl must use the official https://openrouter.ai/api/v1 endpoint. Custom hosts are blocked to prevent API-key disclosure through untrusted project configuration.');
  }
  if (!Number.isSafeInteger(config.openrouter?.maxTokens) || config.openrouter.maxTokens < 1 || config.openrouter.maxTokens > 32768) throw new Error('openrouter.maxTokens must be an integer between 1 and 32768.');
  if (typeof config.model !== 'string' || !/^[\w./:@+-]{1,150}$/.test(config.model)) throw new Error('config.model must be a model id such as opencode/glm-5.3-flash.');
  if (config.opencodeCommand !== 'opencode') throw new Error('forge.config.json may not select an arbitrary executable. Set FORGE_OPENCODE_COMMAND in your shell for an operator-controlled override.');
  if (!['ask', 'local-only'].includes(config.privacy?.mode)) throw new Error('privacy.mode must be "ask" or "local-only".');
  const bounds = {
    maxFiles: [1, 100000],
    maxFileBytes: [1024, 10485760],
    maxIndexBytes: [1024, 268435456],
    maxContextChars: [1000, 1000000],
    maxTargetFiles: [1, 64],
    maxOutputBytes: [4096, 10000000],
    modelTimeoutMs: [1000, 3600000],
    commandTimeoutMs: [1000, 1800000],
  };
  for (const [key, [min, max]] of Object.entries(bounds)) {
    if (!Number.isSafeInteger(config.limits?.[key]) || config.limits[key] < min || config.limits[key] > max) {
      throw new Error(`limits.${key} must be an integer between ${min} and ${max}.`);
    }
  }
  if (typeof config.review?.enabled !== 'boolean') throw new Error('review.enabled must be a boolean.');
  if (typeof config.agent !== 'string' || !/^[A-Za-z0-9_-]{1,64}$/.test(config.agent)) throw new Error('config.agent must be a short agent name.');
}

export function saveConfig(root, config) {
  validateConfig(config);
  const target = path.join(root, CONFIG_NAME);
  try { const info = fs.lstatSync(target); if (info.isSymbolicLink() || !info.isFile()) throw new Error(`${CONFIG_NAME} must not be a symlink or special file.`); }
  catch (error) { if (error?.code !== 'ENOENT') throw error; }
  const temp = `${target}.tmp-${randomUUID()}`;
  fs.writeFileSync(temp, `${JSON.stringify(config, null, 2)}\n`, { mode: 0o600, flag: 'wx' });
  fs.renameSync(temp, target);
}

export function setConfigValue(config, key, rawValue) {
  const setters = {
    provider(value) { config.provider = value; },
    model(value) { config.model = value; },
    'openrouter.baseUrl'(value) { config.openrouter.baseUrl = value; },
    'openrouter.maxTokens'(value) { config.openrouter.maxTokens = Number(value); },
    'privacy.mode'(value) { config.privacy.mode = value; },
    'limits.maxFiles'(value) { config.limits.maxFiles = Number(value); },
    'limits.maxFileBytes'(value) { config.limits.maxFileBytes = Number(value); },
    'limits.maxIndexBytes'(value) { config.limits.maxIndexBytes = Number(value); },
    'limits.maxContextChars'(value) { config.limits.maxContextChars = Number(value); },
    'limits.maxTargetFiles'(value) { config.limits.maxTargetFiles = Number(value); },
    'limits.modelTimeoutMs'(value) { config.limits.modelTimeoutMs = Number(value); },
    'review.enabled'(value) {
      if (!['true', 'false'].includes(value)) throw new Error('review.enabled must be true or false.');
      config.review.enabled = value === 'true';
    },
  };
  if (!Object.hasOwn(setters, key)) throw new Error(`Unsupported config key: ${key}. Use: ${Object.keys(setters).join(', ')}`);
  setters[key](rawValue);
  validateConfig(config);
}
