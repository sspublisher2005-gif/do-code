# Third-Party Notices and Provenance

## Included code baseline

This distribution retains the `LICENSE` included with the MIT-licensed JavaScript Forge source snapshot (Copyright (c) 2026 Forge contributors). The MIT permission notice is reproduced in the root `LICENSE`. Inspect individual source-file headers and retained notices before redistributing modified builds.

## Portable integration pack

`integrations/portable-pack/` contains newly authored Forge project instructions, Claude Code/OpenCode agent-profile Markdown, and common workflow command templates. They are compatibility examples, not official files from Anthropic, OpenAI, OpenCode, Google, Pi, or any other vendor. Vendor names identify target integrations only.

The separate uploaded OpenCode AI Work Harness archive has a root license that identifies the source as proprietary/commercial. Its source files were not copied into this distribution. Do not copy files from that archive unless the rights holder confirms applicable permissions in writing.

## Optional Playwright

Playwright is not bundled into the runtime package by this source ZIP. The optional setup flow may install `playwright-core` into a target project; consult the dependency's current package metadata and license before redistributing that dependency or browser binaries. The user must deliberately initiate dependency installation.

## Trademarks and upstream projects

Claude Code, Codex, OpenCode, Pi, Antigravity, Playwright and other referenced names belong to their respective owners. This project is independent and not endorsed by those providers. No upstream provider source is claimed to be included beyond the MIT-licensed Forge baseline noted above.
