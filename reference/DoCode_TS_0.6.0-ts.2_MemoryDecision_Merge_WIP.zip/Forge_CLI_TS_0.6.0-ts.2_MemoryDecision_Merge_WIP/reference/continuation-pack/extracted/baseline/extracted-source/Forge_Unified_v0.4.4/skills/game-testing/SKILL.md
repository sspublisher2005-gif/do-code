---
name: Game Testing
description: Verify web games, canvas applications, controls, resize behavior, runtime errors, and play loops.
---
# Game testing skill

First identify the renderer (DOM, Canvas, WebGL) and visible control labels. Passive inspection is the default. Only send control keys or click a game-start control after the user explicitly requested exercise/testing of gameplay and approved the browser test. Do not purchase, submit scores to external services, post, or alter accounts. Capture desktop/mobile evidence and report what was actually exercised; do not infer that a game is fun or correct from a screenshot alone.
