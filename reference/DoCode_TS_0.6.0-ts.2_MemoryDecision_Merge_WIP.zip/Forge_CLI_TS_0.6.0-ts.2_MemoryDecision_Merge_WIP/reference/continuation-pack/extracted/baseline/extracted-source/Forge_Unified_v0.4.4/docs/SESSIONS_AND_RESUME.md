# Forge sessions and resume semantics (v0.4.3)

## Commands

```bash
forge sessions list
forge sessions show SESSION_ID
forge sessions delete SESSION_ID
forge resume SESSION_ID
```

`forge sessions list` shows the latest 50 authenticated sessions for the active project. `show` decrypts and displays the saved task, attempt IDs, states, phase, and last outcome. `delete` removes one authenticated record after an exact typed confirmation. `resume` requires an interactive terminal and the exact confirmation `RESTART SAVED TASK`.

## Persistence and trust boundary

- Session records live under the user-state directory (default `~/.forge-cli/sessions/<project-id>/`; override with `FORGE_HOME`).
- The user-state directory and signing key must be outside the active project root. Session records have private file permissions on POSIX systems.
- A per-user 32-byte key authenticates the full session record using HMAC-SHA-256 and timing-safe MAC comparison.
- Saved task text is encrypted at rest using AES-256-GCM with a separately derived key; the random nonce, authentication tag, ciphertext and a key-derived task fingerprint are included in the signed record. Task text is decrypted only after record authentication and project binding succeed.
- Each record is bound to the project's UUID, canonical root path, and `bindingEpoch`. Copies/rebinds do not silently inherit session state.
- Tampered, malformed, symlink-backed, oversized, unsigned, or foreign-root records are rejected or excluded from listing.
- Sessions are not automatically imported from another project. There is no cross-project session search.
- The HMAC protects against repository-created/altered session records; it does not defend against a compromised user account, a malicious same-user process with access to the signing key, or a compromised host.

## What `resume` actually does

A resume **restarts the saved user task from the beginning** with a new run ID and the recorded non-secret run options. It evaluates the current working tree, not an immutable snapshot. Existing partial changes remain in place. It does not restore the prior model conversation, exact planner/coder/reviewer step, process state, or pending tool call. It does not run in the background and cannot know with certainty whether a separately launched Forge process remains active.

Before resume, inspect `git diff`, `forge sessions show SESSION_ID`, and `forge audit`. If partial changes make a restart unsafe, create a fresh disposable branch/worktree and copy only reviewed changes first. A completed session with tests reported passing and reviewer verdict `PASS`, or a session explicitly cancelled by the user, cannot be restarted by this command.

## Outcome semantics

| State | Meaning |
|---|---|
| `running` | An attempt was marked active. A process crash can leave this state behind until a stale same-host lock is observed during a restart. |
| `completed` | Forge recorded a finished task with all attempted checks passing and reviewer verdict `PASS`. It is still evidence from that task run, not a universal correctness proof. |
| `needs_review` | A task did not reach the strict completion gate, a dry-run produced only a proposal, or a final completion event was unavailable. Inspect actual reports. |
| `blocked` | Forge stopped for a material ambiguity or safety gate. |
| `cancelled` | User cancelled or declined an action. |
| `failed` | The CLI threw an error during an attempt. |
| `interrupted` | Applied to an earlier running attempt when resume acquires a stale same-host lock and restarts the task. |

Session state is derived from authenticated local records. A process can still exit before finalization and leave the saved status `running`, but v0.4.3 creates an exclusive per-session lock, rejects concurrent attempts, and recovers a stale same-host lock if the recorded PID no longer exists. A prior running attempt is marked `interrupted` when a new attempt starts. PID reuse can cause a conservative false-positive lock; malformed or remote-host locks are never auto-removed. This is not exact crash-safe transcript restoration and does not roll back partial source edits.

## Privacy notes

Saved task text can contain sensitive information; it is encrypted within a private local user-state directory, but local disk encryption is not provided by Forge. A user/process with access to the per-user key can decrypt it. Do not place API keys or passwords directly in task prompts. `forge sessions show` intentionally displays the saved task on request, and `forge sessions list` displays a short task preview. The delete command removes the record but is not a secure forensic-erasure guarantee and does not clear audit events or reverse project changes.

## Verification required before stronger claims

The module tests cover encrypted task storage, authenticated storage, task/status tampering, same-project listing and deletion, copied/rebound project rejection, key placement, completed-session refusal, and non-interactive resume/deletion guards. v0.4.3 adds atomic per-session process locks, refuses concurrent attempts, can recover a stale same-host lock after the owning PID disappears, and records a prior running attempt as interrupted before restart. Module tests cover active-lock rejection, same-host stale-lock recovery, and fail-closed handling of malformed or remote-host lock files. This is not yet a repeated SIGKILL/crash-consistency stress test, full power-loss durability guarantee, exact transcript resume, OS sandbox, or independent security audit.
