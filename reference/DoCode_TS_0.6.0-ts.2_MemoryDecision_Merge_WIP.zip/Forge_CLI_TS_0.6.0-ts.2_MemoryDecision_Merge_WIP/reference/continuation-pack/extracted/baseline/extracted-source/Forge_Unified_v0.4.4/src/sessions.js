import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { createCipheriv, createDecipheriv, createHmac, randomBytes, randomUUID, timingSafeEqual } from 'node:crypto';
import { ensureRealDirectory } from './utils.js';

const SESSION_SCHEMA = 2;
const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const MAX_SESSION_BYTES = 256 * 1024;
const MAX_TASK_CHARS = 12000;

function userStateDirectory() {
  return process.env.FORGE_HOME?.trim()
    ? path.resolve(process.env.FORGE_HOME)
    : path.join(os.homedir(), '.forge-cli');
}

function isWithin(base, target) {
  const relative = path.relative(path.resolve(base), path.resolve(target));
  return relative === '' || (relative !== '..' && !relative.startsWith(`..${path.sep}`) && !path.isAbsolute(relative));
}

// Resolve a path that may not exist yet while still honoring symlinked existing
// ancestors. This prevents a lexically external FORGE_HOME from aliasing a path
// inside the active repository via a parent symlink.
function resolveProspectiveRealPath(target) {
  let cursor = path.resolve(target);
  const missingParts = [];
  while (true) {
    try {
      fs.lstatSync(cursor);
      const realAncestor = fs.realpathSync(cursor);
      return path.resolve(realAncestor, ...missingParts.reverse());
    } catch (error) {
      if (error?.code !== 'ENOENT') throw error;
      const parent = path.dirname(cursor);
      if (parent === cursor) throw new Error(`Cannot resolve Forge state path: ${target}`);
      missingParts.push(path.basename(cursor));
      cursor = parent;
    }
  }
}

function ensureStoreOutsideProject(root) {
  const rootReal = fs.realpathSync(root);
  const stateDir = userStateDirectory();
  if (isWithin(rootReal, stateDir) || isWithin(rootReal, resolveProspectiveRealPath(stateDir))) {
    throw new Error('Forge session storage must live outside the active project, including through symlinked parent directories. Set FORGE_HOME to a private user-state directory outside repositories.');
  }
  try {
    const info = fs.lstatSync(stateDir);
    if (info.isSymbolicLink() || !info.isDirectory()) throw new Error('Forge user-state directory must be a real directory, not a symlink or special file.');
  } catch (error) {
    if (error?.code !== 'ENOENT') throw error;
    ensureRealDirectory(stateDir, 0o700);
  }
  if (process.platform !== 'win32') {
    try { fs.chmodSync(stateDir, 0o700); } catch { /* permissions are reported by the platform */ }
  }
  return stateDir;
}

function readOrCreateKey(root, create) {
  const base = ensureStoreOutsideProject(root);
  const keyPath = path.join(base, 'session-signing-key');
  try {
    const info = fs.lstatSync(keyPath);
    if (info.isSymbolicLink() || !info.isFile() || info.size !== 32) {
      throw new Error('Forge session signing key is invalid; refusing to trust session state. Do not replace it from a project repository.');
    }
    if (process.platform !== 'win32' && (info.mode & 0o077)) fs.chmodSync(keyPath, 0o600);
    const key = fs.readFileSync(keyPath);
    if (key.length !== 32) throw new Error('Forge session signing key changed during access.');
    return key;
  } catch (error) {
    if (error?.code !== 'ENOENT' || !create) {
      if (error?.code === 'ENOENT') return null;
      throw error;
    }
  }
  const key = randomBytes(32);
  try { fs.writeFileSync(keyPath, key, { mode: 0o600, flag: 'wx' }); return key; }
  catch (error) {
    if (error?.code !== 'EEXIST') throw error;
    const info = fs.lstatSync(keyPath);
    if (info.isSymbolicLink() || !info.isFile() || info.size !== 32) throw new Error('Forge session signing key changed during initialization.');
    return fs.readFileSync(keyPath);
  }
}

function canonical(value) {
  if (Array.isArray(value)) return value.map(canonical);
  if (value && typeof value === 'object') {
    return Object.fromEntries(Object.keys(value).sort().map((key) => [key, canonical(value[key])]));
  }
  return value;
}

function macFor(record, key) {
  const { mac: _mac, ...unsigned } = record;
  return createHmac('sha256', key).update(JSON.stringify(canonical(unsigned))).digest('hex');
}

function encryptionKey(key) {
  return createHmac('sha256', key).update('forge-session-task-encryption-v1').digest();
}

function taskFingerprint(task, key) {
  return createHmac('sha256', encryptionKey(key))
    .update('forge-session-task-fingerprint-v1\0', 'utf8')
    .update(task, 'utf8')
    .digest('hex');
}

function encryptTask(task, key) {
  const nonce = randomBytes(12);
  const cipher = createCipheriv('aes-256-gcm', encryptionKey(key), nonce);
  const ciphertext = Buffer.concat([cipher.update(task, 'utf8'), cipher.final()]);
  return {
    taskCiphertext: ciphertext.toString('base64'),
    taskNonce: nonce.toString('base64'),
    taskTag: cipher.getAuthTag().toString('base64'),
  };
}

function decryptTask(record, key) {
  try {
    const nonce = Buffer.from(record.taskNonce, 'base64');
    const ciphertext = Buffer.from(record.taskCiphertext, 'base64');
    const tag = Buffer.from(record.taskTag, 'base64');
    if (nonce.length !== 12 || tag.length !== 16 || ciphertext.length > MAX_TASK_CHARS * 4) throw new Error('invalid cipher fields');
    const decipher = createDecipheriv('aes-256-gcm', encryptionKey(key), nonce);
    decipher.setAuthTag(tag);
    const plaintext = Buffer.concat([decipher.update(ciphertext), decipher.final()]).toString('utf8');
    if (!plaintext.trim() || plaintext.length > MAX_TASK_CHARS || plaintext.includes('\0') || taskFingerprint(plaintext, key) !== record.taskHash) throw new Error('invalid task content');
    return plaintext;
  } catch {
    throw new Error('Forge session task decryption failed. The session may be damaged or the per-user key may not match.');
  }
}

function verifyRecord(record, key, filenameId) {
  if (!record || typeof record !== 'object' || Array.isArray(record)) return false;
  if (record.schemaVersion !== SESSION_SCHEMA || record.sessionId !== filenameId || !UUID_RE.test(record.sessionId || '')) return false;
  if (!UUID_RE.test(record.projectId || '') || typeof record.projectRoot !== 'string' || !path.isAbsolute(record.projectRoot)) return false;
  if (!Number.isInteger(record.bindingEpoch) || record.bindingEpoch < 1) return false;
  if (typeof record.taskCiphertext !== 'string' || typeof record.taskNonce !== 'string' || typeof record.taskTag !== 'string') return false;
  if (!/^[a-f0-9]{64}$/i.test(record.taskHash || '')) return false;
  if (!['running', 'interrupted', 'failed', 'blocked', 'cancelled', 'needs_review', 'completed'].includes(record.status)) return false;
  if (!Array.isArray(record.attempts) || record.attempts.length > 100) return false;
  if (!/^[a-f0-9]{64}$/i.test(record.mac || '')) return false;
  const expected = Buffer.from(macFor(record, key), 'hex');
  const supplied = Buffer.from(record.mac, 'hex');
  return expected.length === supplied.length && timingSafeEqual(expected, supplied);
}

function decodeRecord(record, key) {
  const task = decryptTask(record, key);
  const { taskCiphertext: _ciphertext, taskNonce: _nonce, taskTag: _tag, ...rest } = record;
  return { ...rest, task };
}

function sessionDirectory(root, identity, create = false) {
  const base = ensureStoreOutsideProject(root);
  const sessions = path.join(base, 'sessions');
  if (create) ensureRealDirectory(sessions, 0o700);
  else {
    try {
      const info = fs.lstatSync(sessions);
      if (info.isSymbolicLink() || !info.isDirectory()) throw new Error('Forge sessions storage must be a real directory.');
    } catch (error) { if (error?.code === 'ENOENT') return null; throw error; }
  }
  const projectPath = path.join(sessions, identity.projectId);
  if (create) ensureRealDirectory(projectPath, 0o700);
  else {
    try {
      const info = fs.lstatSync(projectPath);
      if (info.isSymbolicLink() || !info.isDirectory()) throw new Error('Forge project session storage must be a real directory.');
    } catch (error) { if (error?.code === 'ENOENT') return null; throw error; }
  }
  return projectPath;
}


function lockFilename(root, identity, sessionId, createDirectory = false) {
  if (!UUID_RE.test(sessionId || '')) throw new Error('Provide a valid Forge session ID.');
  const directory = sessionDirectory(root, identity, createDirectory);
  if (!directory) throw new Error(`No Forge sessions are stored for project ${identity.projectId}.`);
  return path.join(directory, `.${sessionId}.lock`);
}

function processIsAlive(pid) {
  try { process.kill(pid, 0); return true; }
  catch (error) { return error?.code !== 'ESRCH'; }
}

function readLockRecord(filename) {
  const info = fs.lstatSync(filename);
  if (info.isSymbolicLink() || !info.isFile() || info.size > 8192) {
    throw new Error('Forge session lock is not a trusted small regular file; inspect it manually rather than deleting it automatically.');
  }
  let lock;
  try { lock = JSON.parse(fs.readFileSync(filename, 'utf8')); }
  catch { throw new Error('Forge session lock is malformed; refusing to remove it automatically. Inspect the lock file manually.'); }
  if (!lock || typeof lock !== 'object' || !Number.isSafeInteger(lock.pid) || lock.pid < 1 || typeof lock.host !== 'string' || !lock.host || typeof lock.token !== 'string' || !/^[0-9a-f-]{36}$/i.test(lock.token)) {
    throw new Error('Forge session lock has an invalid schema; refusing to remove it automatically. Inspect the lock file manually.');
  }
  return { lock, info };
}

/**
 * Atomically acquire a per-session process lock. A dead same-host PID is recoverable;
 * remote-host/invalid locks are not auto-removed because a shared state directory may be in use.
 */
export function acquireSessionLock({ root, identity, sessionId }) {
  const filename = lockFilename(root, identity, sessionId, true);
  for (let attempt = 0; attempt < 2; attempt += 1) {
    const token = randomUUID();
    const record = {
      schemaVersion: 1, token, sessionId, projectId: identity.projectId,
      projectRoot: fs.realpathSync(root), pid: process.pid, host: os.hostname(),
      startedAt: new Date().toISOString(),
    };
    let fd;
    let createdInfo;
    let createdByThisAttempt = false;
    try {
      fd = fs.openSync(filename, 'wx', 0o600);
      createdByThisAttempt = true;
      createdInfo = fs.fstatSync(fd);
      fs.writeFileSync(fd, `${JSON.stringify(record)}\n`);
      fs.fsyncSync(fd);
      fs.closeSync(fd);
      fd = undefined;
      if (process.platform !== 'win32') fs.chmodSync(filename, 0o600);
      let released = false;
      return {
        sessionId,
        token,
        release() {
          if (released) return true;
          released = true;
          try {
            const { lock, info } = readLockRecord(filename);
            if (lock.token !== token || lock.pid !== process.pid || lock.host !== os.hostname() || lock.sessionId !== sessionId || lock.projectId !== identity.projectId || lock.projectRoot !== fs.realpathSync(root)) return false;
            const current = fs.lstatSync(filename);
            if (current.dev !== info.dev || current.ino !== info.ino) return false;
            fs.unlinkSync(filename);
            return true;
          } catch (error) {
            if (error?.code === 'ENOENT') return true;
            return false;
          }
        },
      };
    } catch (error) {
      if (fd !== undefined) { try { fs.closeSync(fd); } catch { /* best effort */ } }
      if (createdByThisAttempt) {
        try { const current = fs.lstatSync(filename); if (createdInfo && current.dev === createdInfo.dev && current.ino === createdInfo.ino) fs.unlinkSync(filename); } catch { /* Preserve the original lock-creation failure. */ }
      }
      if (error?.code !== 'EEXIST') throw error;
      const { lock, info } = readLockRecord(filename);
      if (lock.sessionId !== sessionId || lock.projectId !== identity.projectId || lock.projectRoot !== fs.realpathSync(root)) {
        throw new Error('Forge session lock belongs to a different project binding; refusing concurrent execution. Inspect the lock file manually.');
      }
      if (lock.host !== os.hostname()) {
        throw new Error(`Forge session is locked by host ${lock.host}; shared state locks from another host are not auto-recovered. Verify that process is inactive before manually resolving ${filename}.`);
      }
      if (processIsAlive(lock.pid)) {
        throw new Error(`Forge session ${sessionId} is already active in process ${lock.pid}. Forge refuses to start a concurrent attempt.`);
      }
      const current = fs.lstatSync(filename);
      if (current.dev !== info.dev || current.ino !== info.ino) continue;
      fs.unlinkSync(filename);
      // Retry exclusive creation exactly once after removing a stale same-host lock.
    }
  }
  throw new Error(`Could not acquire the Forge session lock for ${sessionId}; another process may have raced to recover it. Try again after inspecting the session state.`);
}

function persist(root, identity, record) {
  const key = readOrCreateKey(root, true);
  const directory = sessionDirectory(root, identity, true);
  const { task, taskCiphertext: _oldCiphertext, taskNonce: _oldNonce, taskTag: _oldTag, ...rest } = record;
  if (typeof task !== 'string' || !task.trim() || task.length > MAX_TASK_CHARS || task.includes('\0')) {
    throw new Error('Refusing to persist a Forge session with an invalid task payload.');
  }
  const taskHash = taskFingerprint(task, key);
  const signed = { ...rest, taskHash, ...encryptTask(task, key) };
  delete signed.mac;
  signed.mac = macFor(signed, key);
  const target = path.join(directory, `${signed.sessionId}.json`);
  try {
    const info = fs.lstatSync(target);
    if (info.isSymbolicLink() || !info.isFile()) throw new Error('Forge session file must be a regular file.');
  } catch (error) { if (error?.code !== 'ENOENT') throw error; }
  const temporary = path.join(directory, `.session-${randomUUID()}.tmp`);
  try {
    fs.writeFileSync(temporary, `${JSON.stringify(signed, null, 2)}\n`, { mode: 0o600, flag: 'wx' });
    fs.renameSync(temporary, target);
    if (process.platform !== 'win32') fs.chmodSync(target, 0o600);
  } catch (error) {
    try { fs.rmSync(temporary, { force: true }); } catch { /* best effort */ }
    throw error;
  }
  return { ...record, taskHash, mac: signed.mac };
}

export function createSession({ root, identity, task, options = {}, runId = randomUUID(), acquireLock = false }) {
  if (typeof task !== 'string' || !task.trim() || task.length > MAX_TASK_CHARS || task.includes('\0')) {
    throw new Error(`Forge tasks must be 1–${MAX_TASK_CHARS} characters and contain no NUL byte.`);
  }
  const now = new Date().toISOString();
  const sessionId = randomUUID();
  const sessionLock = acquireLock ? acquireSessionLock({ root, identity, sessionId }) : null;
  const record = {
    schemaVersion: SESSION_SCHEMA,
    sessionId,
    projectId: identity.projectId,
    projectRoot: fs.realpathSync(root),
    bindingEpoch: identity.bindingEpoch ?? 1,
    createdAt: now,
    updatedAt: now,
    status: 'running',
    phase: 'initializing',
    task: task.trim(),
    options: {
      dryRun: Boolean(options.dryRun),
      sandboxTests: Boolean(options.sandboxTests),
      noSubagents: Boolean(options.noSubagents),
      maxSubagents: Number.isInteger(options.maxSubagents) ? Math.min(3, Math.max(0, options.maxSubagents)) : 2,
      ...(typeof options.model === 'string' && options.model.length <= 160 ? { model: options.model } : {}),
    },
    attempts: [{ runId, startedAt: now, status: 'running', phase: 'initializing', resumed: false }],
  };
  try {
    const saved = persist(root, identity, record);
    return { ...saved, runId, ...(sessionLock ? { sessionLock } : {}) };
  } catch (error) {
    sessionLock?.release();
    throw error;
  }
}

export function loadSession({ root, identity, sessionId }) {
  if (!UUID_RE.test(sessionId || '')) throw new Error('Provide a valid Forge session ID.');
  const directory = sessionDirectory(root, identity, false);
  if (!directory) throw new Error(`No Forge sessions are stored for project ${identity.projectId}.`);
  const filename = path.join(directory, `${sessionId}.json`);
  let info;
  try { info = fs.lstatSync(filename); }
  catch (error) { if (error?.code === 'ENOENT') throw new Error(`Session ${sessionId} was not found in the active project. Forge will not search other projects for it.`); throw error; }
  if (info.isSymbolicLink() || !info.isFile() || info.size > MAX_SESSION_BYTES) throw new Error('Forge session record is not a trusted small regular file.');
  let record;
  try { record = JSON.parse(fs.readFileSync(filename, 'utf8')); }
  catch { throw new Error('Forge session record is invalid JSON. Refusing to resume it.'); }
  const key = readOrCreateKey(root, false);
  if (!key || !verifyRecord(record, key, sessionId)) throw new Error('Forge session integrity check failed. The record may be altered or the session signing key may be missing.');
  if (record.projectId !== identity.projectId || record.projectRoot !== fs.realpathSync(root) || record.bindingEpoch !== (identity.bindingEpoch ?? 1)) {
    throw new Error('SESSION PROJECT BOUNDARY MISMATCH: this session belongs to a different project root or binding epoch. Forge refused to load it.');
  }
  return decodeRecord(record, key);
}

export function deleteSession({ root, identity, sessionId }) {
  const record = loadSession({ root, identity, sessionId });
  const lock = acquireSessionLock({ root, identity, sessionId });
  try {
    const directory = sessionDirectory(root, identity, false);
    if (!directory) throw new Error(`No Forge sessions are stored for project ${identity.projectId}.`);
    const filename = path.join(directory, `${sessionId}.json`);
    const info = fs.lstatSync(filename);
    if (info.isSymbolicLink() || !info.isFile()) throw new Error('Forge session record is not a regular file; refusing to delete it.');
    // A second authenticated read detects a replacement before deletion.
    const current = loadSession({ root, identity, sessionId });
    if (current.mac !== record.mac) throw new Error('Forge session changed during deletion; refusing to remove it.');
    fs.unlinkSync(filename);
    return { sessionId: record.sessionId, projectId: record.projectId, taskHash: record.taskHash };
  } finally {
    lock.release();
  }
}

export function updateSession({ root, identity, sessionId, changes = {} }) {
  const current = loadSession({ root, identity, sessionId });
  const next = { ...current, ...changes, updatedAt: new Date().toISOString() };
  return persist(root, identity, next);
}

export function beginSessionAttempt({ root, identity, sessionId, runId = randomUUID() }) {
  const current = loadSession({ root, identity, sessionId });
  if (current.status === 'completed') throw new Error('This Forge session is already completed. Start a new `forge run` instead of replaying finished work.');
  if (current.status === 'cancelled') throw new Error('This Forge session was explicitly cancelled. Start a new `forge run` if you want to try again.');
  if (current.task.length > MAX_TASK_CHARS) throw new Error('Saved task exceeds current safety limits; create a new task instead.');
  const now = new Date().toISOString();
  const attempt = { runId, startedAt: now, status: 'running', phase: 'restarting_from_current_files', resumed: true };
  const recoveredAttempts = current.attempts.map((item) => item.status === 'running'
    ? { ...item, status: 'interrupted', finishedAt: now, outcome: { recovered: true, evidence: 'A new resume was started after the previous running attempt no longer held the session lock. Previous hidden model state is unavailable.' } }
    : item);
  const saved = persist(root, identity, {
    ...current,
    status: 'running',
    phase: attempt.phase,
    updatedAt: now,
    attempts: [...recoveredAttempts, attempt].slice(-100),
  });
  return { ...saved, runId };
}

export function setSessionPhase({ root, identity, sessionId, runId, phase }) {
  const current = loadSession({ root, identity, sessionId });
  const attempts = current.attempts.map((item) => item.runId === runId ? { ...item, phase } : item);
  return persist(root, identity, { ...current, phase, attempts, updatedAt: new Date().toISOString() });
}

export function finishSessionAttempt({ root, identity, sessionId, runId, status, phase, outcome = {} }) {
  const allowed = new Set(['interrupted', 'failed', 'blocked', 'cancelled', 'needs_review', 'completed']);
  if (!allowed.has(status)) throw new Error('Unsupported Forge session completion state.');
  const current = loadSession({ root, identity, sessionId });
  const now = new Date().toISOString();
  const attempts = current.attempts.map((item) => item.runId === runId
    ? { ...item, finishedAt: now, status, phase: phase || item.phase, outcome }
    : item);
  return persist(root, identity, {
    ...current,
    status,
    phase: phase || status,
    updatedAt: now,
    attempts,
    lastOutcome: outcome,
  });
}

export function listSessions({ root, identity, limit = 50 }) {
  const directory = sessionDirectory(root, identity, false);
  if (!directory) return { sessions: [], invalidCount: 0 };
  const key = readOrCreateKey(root, false);
  if (!key) return { sessions: [], invalidCount: 0 };
  const records = [];
  let invalidCount = 0;
  for (const name of fs.readdirSync(directory).filter((item) => item.endsWith('.json')).slice(-1000)) {
    try {
      const file = path.join(directory, name);
      const info = fs.lstatSync(file);
      if (info.isSymbolicLink() || !info.isFile() || info.size > MAX_SESSION_BYTES) { invalidCount += 1; continue; }
      const record = JSON.parse(fs.readFileSync(file, 'utf8'));
      const filenameId = name.slice(0, -5);
      if (!verifyRecord(record, key, filenameId) || record.projectId !== identity.projectId || record.projectRoot !== fs.realpathSync(root) || record.bindingEpoch !== (identity.bindingEpoch ?? 1)) {
        invalidCount += 1; continue;
      }
      records.push(decodeRecord(record, key));
    } catch { invalidCount += 1; }
  }
  records.sort((a, b) => Date.parse(b.updatedAt) - Date.parse(a.updatedAt));
  return { sessions: records.slice(0, Math.max(1, Math.min(200, limit))), invalidCount };
}
