---
name: Root-Cause Debugging
description: Reproduce failures, distinguish hypotheses, isolate a minimal cause, and prevent ineffective repair loops.
---

## Method
- Capture the exact command/input, observed behavior, exit code, expected behavior, environment, and relevant recent changes.
- Reproduce before changing code when practical. If impossible, state precisely why.
- List competing hypotheses and identify a discriminating test for each.
- Change one causal variable at a time; add a regression test when a stable reproduction is possible.
- Compare fresh outputs after each attempt. If the evidence has not changed, stop repeating the same fix.
- Do not silence exceptions, loosen assertions, skip tests, disable policy, or change unrelated files to make the failure disappear.
- Report root cause only when evidence separates it from alternatives; otherwise report the strongest hypothesis and next experiment.
