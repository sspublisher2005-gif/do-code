import fs from 'node:fs';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { buildCommandEnv, terminateProcessTree } from './runner.js';

const SAFE_SCRIPTS = new Map([
  ['vite', { framework: 'vite', args: ['--host', '127.0.0.1', '--port', '{PORT}', '--strictPort'], defaultPort: 5173 }],
  ['vite preview', { framework: 'vite', args: ['--host', '127.0.0.1', '--port', '{PORT}', '--strictPort'], defaultPort: 4173 }],
  ['astro dev', { framework: 'astro', args: ['--host', '127.0.0.1', '--port', '{PORT}'], defaultPort: 4321 }],
  ['astro preview', { framework: 'astro', args: ['--host', '127.0.0.1', '--port', '{PORT}'], defaultPort: 4321 }],
  ['next dev', { framework: 'next', args: ['--hostname', '127.0.0.1', '--port', '{PORT}'], defaultPort: 3000 }],
  ['next start', { framework: 'next', args: ['--hostname', '127.0.0.1', '--port', '{PORT}'], defaultPort: 3000 }],
  ['nuxt dev', { framework: 'nuxt', args: ['--host', '127.0.0.1', '--port', '{PORT}'], defaultPort: 3000 }],
  ['nuxt preview', { framework: 'nuxt', args: ['--host', '127.0.0.1', '--port', '{PORT}'], defaultPort: 3000 }],
  ['nuxi dev', { framework: 'nuxt', args: ['--host', '127.0.0.1', '--port', '{PORT}'], defaultPort: 3000 }],
  ['nuxi preview', { framework: 'nuxt', args: ['--host', '127.0.0.1', '--port', '{PORT}'], defaultPort: 3000 }],
  ['react-scripts start', { framework: 'create-react-app', args: [], defaultPort: 3000 }],
]);

function readPackage(root) {
  const filename = path.join(root, 'package.json');
  try {
    const info = fs.lstatSync(filename);
    if (info.isSymbolicLink() || !info.isFile() || info.size > 1024 * 1024) return null;
    const value = JSON.parse(fs.readFileSync(filename, 'utf8'));
    return value && typeof value === 'object' && !Array.isArray(value) ? value : null;
  } catch { return null; }
}

function normalizeScript(script) {
  return String(script || '').trim().replace(/\s+/g, ' ').toLowerCase();
}

export function inspectLocalDevServer(root, requestedScript = '') {
  const pkg = readPackage(root);
  if (!pkg) return { available: false, reason: 'No safe regular package.json was found in this workspace.' };
  if (!pkg.scripts || typeof pkg.scripts !== 'object' || Array.isArray(pkg.scripts)) {
    return { available: false, reason: 'package.json does not define application scripts.' };
  }
  const candidateNames = requestedScript ? [requestedScript] : ['dev', 'preview', 'start', 'serve'];
  for (const name of candidateNames) {
    if (!['dev', 'preview', 'start', 'serve'].includes(name)) return { available: false, reason: 'Only the named dev, preview, start or serve script can be considered for automatic startup.' };
    const raw = pkg.scripts[name];
    if (typeof raw !== 'string') continue;
    const normalized = normalizeScript(raw);
    const matched = SAFE_SCRIPTS.get(normalized);
    if (!matched) continue;
    const pre = `pre${name}`;
    const post = `post${name}`;
    if (typeof pkg.scripts[pre] === 'string' || typeof pkg.scripts[post] === 'string') {
      return { available: false, reason: `Automatic startup is disabled because ${pre}/${post} lifecycle hooks are defined. Inspect those hooks and start the server manually.` };
    }
    return {
      available: true,
      scriptName: name,
      framework: matched.framework,
      command: normalized,
      args: matched.args,
      defaultPort: matched.defaultPort,
      root,
    };
  }
  return { available: false, reason: 'No recognized safe framework command was found. Supported automatic scripts are standard Vite, Astro, Next.js, Nuxt and Create React App commands; run the app yourself and pass its local URL.' };
}

function findNpmCli() {
  const bin = path.dirname(process.execPath);
  const candidates = [
    path.join(bin, 'node_modules', 'npm', 'bin', 'npm-cli.js'),
    path.resolve(bin, '..', 'lib', 'node_modules', 'npm', 'bin', 'npm-cli.js'),
    path.resolve(bin, '..', 'node_modules', 'npm', 'bin', 'npm-cli.js'),
  ];
  for (const filename of candidates) {
    try {
      const info = fs.lstatSync(filename);
      if (info.isFile() && !info.isSymbolicLink()) return filename;
    } catch { /* Try next location. */ }
  }
  throw new Error('Cannot locate a regular npm-cli.js next to the active Node.js installation; automatic startup is disabled. Start the server manually and pass its URL.');
}

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

export async function startLocalDevServer(root, inspection, { port = inspection?.defaultPort || 4173, startupTimeoutMs = 20000, env: sourceEnv = process.env, fetchImpl = fetch } = {}) {
  if (!inspection?.available || inspection.root !== root) throw new Error('Automatic dev-server startup requires a recognized inspection result for this exact workspace.');
  if (!Number.isInteger(port) || port < 1024 || port > 65535) throw new Error('Local dev-server port must be between 1024 and 65535.');
  if (!Number.isInteger(startupTimeoutMs) || startupTimeoutMs < 1000 || startupTimeoutMs > 60000) throw new Error('Dev-server startup timeout must be between 1000 and 60000 ms.');

  const npmCli = findNpmCli();
  const env = buildCommandEnv(sourceEnv);
  // Do not let a repository-local .npmrc choose an arbitrary script shell.
  // Force the OS shell explicitly while keeping spawn(shell:false).
  const scriptShell = process.platform === 'win32'
    ? path.join(env.SystemRoot || env.SYSTEMROOT || 'C:\\Windows', 'System32', 'cmd.exe')
    : '/bin/sh';
  // Clear npm's node-options override too: a project .npmrc must not inject
  // a hidden Node --require hook into every script subprocess.
  const args = [npmCli, `--script-shell=${scriptShell}`, '--node-options=', 'run', inspection.scriptName];
  const frameworkArgs = inspection.args.map((value) => value === '{PORT}' ? String(port) : value);
  if (frameworkArgs.length) args.push('--', ...frameworkArgs);
  env.HOST = '127.0.0.1';
  env.PORT = String(port);
  env.BROWSER = 'none';
  env.CI = '1';
  const url = `http://127.0.0.1:${port}/`;
  let child;
  let closed = false;
  let exitCode = null;
  let spawnError = null;
  let outputBytes = 0;
  try {
    child = spawn(process.execPath, args, {
      cwd: root,
      env,
      shell: false,
      detached: process.platform !== 'win32',
      windowsHide: true,
      stdio: ['ignore', 'pipe', 'pipe'],
    });
  } catch (error) {
    throw new Error(`Could not start the recognized local dev server: ${String(error.message).slice(0, 200)}`);
  }
  const countOutput = (chunk) => { outputBytes += chunk.length; };
  child.stdout?.on('data', countOutput);
  child.stderr?.on('data', countOutput);
  child.once('error', (error) => { spawnError = error; });
  child.once('close', (code) => { closed = true; exitCode = code; });

  const stop = async () => {
    if (!child || closed) return;
    terminateProcessTree(child, { env });
    const deadline = Date.now() + 1200;
    while (!closed && Date.now() < deadline) await delay(50);
    if (!closed) {
      terminateProcessTree(child, { env, force: true });
      const finalDeadline = Date.now() + 1000;
      while (!closed && Date.now() < finalDeadline) await delay(50);
    }
  };

  try {
    const deadline = Date.now() + startupTimeoutMs;
    while (Date.now() < deadline) {
      if (spawnError) throw new Error(`Dev server process could not start: ${String(spawnError.message).slice(0, 160)}`);
      if (closed) throw new Error(`Dev server exited before becoming ready (exit ${exitCode ?? 'unknown'}). Inspect the project script and dependency installation.`);
      const controller = new AbortController();
      const requestTimer = setTimeout(() => controller.abort(), 500);
      try {
        const response = await fetchImpl(url, { method: 'GET', redirect: 'manual', signal: controller.signal });
        try { await response.body?.cancel(); } catch { /* Do not buffer app responses. */ }
        clearTimeout(requestTimer);
        if (response && response.status >= 100 && response.status < 600) {
          return { url, port, scriptName: inspection.scriptName, framework: inspection.framework, pid: child.pid, capturedOutputBytes: outputBytes, stop };
        }
      } catch { clearTimeout(requestTimer); }
      await delay(200);
    }
    throw new Error(`Dev server did not respond on ${url} within ${startupTimeoutMs} ms. Forge will stop the server and will not guess another port.`);
  } catch (error) {
    await stop();
    throw error;
  }
}
