import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { classifySessionOutcome } from '../src/cli.js';
import { writeAudit } from '../src/audit.js';

function root() { return fs.mkdtempSync(path.join(os.tmpdir(), 'forge-completion-gate-')); }
function classify(event) {
  const project = root();
  try {
    writeAudit(project, { action: 'task_finished', runId: 'run-test', ...event });
    return classifySessionOutcome(project, 'run-test');
  } finally {
    fs.rmSync(project, { recursive: true, force: true, maxRetries: 2 });
  }
}

test('completion requires actual passing tests, review PASS, no security warnings, and passing conditional reviews/browser QA', () => {
  const result = classify({ testsPassed: true, reviewVerdict: 'PASS', securityWarningCount: 0 });
  assert.equal(result.status, 'completed');
  assert.equal(result.phase, 'verified');
});

test('deterministic security warnings block completed status even when tests and reviewer pass', () => {
  const result = classify({ testsPassed: true, reviewVerdict: 'PASS', securityWarningCount: 1 });
  assert.equal(result.status, 'needs_review');
  assert.equal(result.phase, 'finished_with_unverified_or_failing_checks');
  assert.equal(result.outcome.securityWarningCount, 1);
});

test('a conditional security review that did not pass blocks completed status', () => {
  for (const verdict of ['WARN', 'FAIL', 'UNVERIFIED']) {
    assert.equal(classify({ testsPassed: true, reviewVerdict: 'PASS', securityWarningCount: 0, securitySubagentVerdict: verdict }).status, 'needs_review');
  }
  assert.equal(classify({ testsPassed: true, reviewVerdict: 'PASS', securityWarningCount: 0, securitySubagentVerdict: 'PASS' }).status, 'completed');
});

test('browser QA failure cannot be overridden by a passing reviewer', () => {
  assert.equal(classify({ testsPassed: false, reviewVerdict: 'PASS', securityWarningCount: 0, browserStatus: 'FAIL' }).status, 'needs_review');
  assert.equal(classify({ testsPassed: true, reviewVerdict: 'PASS', securityWarningCount: 0, browserStatus: 'PASS' }).status, 'completed');
});

test('missing test evidence or reviewer verdict never counts as completion', () => {
  assert.equal(classify({ reviewVerdict: 'PASS', securityWarningCount: 0 }).status, 'needs_review');
  assert.equal(classify({ testsPassed: true, securityWarningCount: 0 }).status, 'needs_review');
});
