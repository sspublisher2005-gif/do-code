import { spawn, spawnSync } from 'node:child_process';
import { isAbsolute, basename } from 'node:path';

const SAFE_TOKEN = /^[A-Za-z0-9._/:@=+*,-]+$/;
const HIGH_RISK_EXECUTABLES = new Set([
  'rm', 'rmdir', 'del', 'erase', 'format', 'diskpart', 'shutdown', 'reboot',
  'sudo', 'su', 'bash', 'sh', 'zsh', 'cmd', 'powershell', 'pwsh', 'curl',
  'wget', 'ftp', 'scp', 'ssh', 'sftp', 'nc', 'netcat', 'docker', 'podman',
  'kubectl', 'helm', 'terraform', 'ansible', 'reg', 'regedit', 'mount', 'umount',
  'chmod', 'chown', 'takeown', 'icacls', 'taskkill', 'kill', 'pkill', 'killall',
  'crontab', 'launchctl', 'systemctl', 'service', 'diskutil', 'dd', 'mkfs',
  'apt', 'apt-get', 'dnf', 'yum', 'pacman', 'brew', 'winget', 'choco', 'npx', 'pnpx', 'bunx',
  'find', 'xargs', 'tee', 'cp', 'mv', 'truncate', 'rsync', 'tar', 'zip', 'unzip', 'install',
]);
const DANGEROUS_GIT_SUBCOMMANDS = new Set([
  'push', 'pull', 'fetch', 'clone', 'reset', 'clean', 'rebase', 'merge',
  'checkout', 'restore', 'switch', 'submodule', 'worktree', 'gc', 'prune', 'add', 'commit', 'stash',
  'cherry-pick', 'revert', 'apply', 'am', 'remote', 'config', 'tag', 'filter-branch', 'filter-repo',
]);
const PACKAGE_MUTATION_COMMANDS = new Set(['install', 'add', 'remove', 'uninstall', 'update', 'upgrade', 'publish', 'link', 'unlink', 'exec', 'dlx', 'npx', 'create']);
const SAFE_COMMAND_ENV_KEYS = new Set([
  'PATH', 'HOME', 'USERPROFILE', 'APPDATA', 'LOCALAPPDATA',
  'XDG_CONFIG_HOME', 'XDG_CACHE_HOME', 'XDG_DATA_HOME', 'XDG_STATE_HOME',
  'TMP', 'TEMP', 'TMPDIR', 'SYSTEMROOT', 'WINDIR', 'COMSPEC', 'PATHEXT',
  'LANG', 'LC_ALL', 'LC_CTYPE', 'TERM', 'COLORTERM', 'NO_COLOR', 'FORCE_COLOR', 'CI', 'NODE_ENV',
]);
const NEVER_ALLOW_COMMAND_ENV = /^(?:FORGE_.*|CONTEXT7_API_KEY|OPENROUTER_API_KEY|OPENAI_API_KEY|ANTHROPIC_API_KEY|AZURE_OPENAI_API_KEY|GEMINI_API_KEY|GOOGLE_API_KEY|TWITTER_AUTH_TOKEN|TWITTER_CT0|AWS_ACCESS_KEY_ID|AWS_SECRET_ACCESS_KEY|AWS_SESSION_TOKEN|GITHUB_TOKEN|GH_TOKEN|NODE_OPTIONS|NODE_PATH|LD_PRELOAD|LD_LIBRARY_PATH|DYLD_INSERT_LIBRARIES|DYLD_LIBRARY_PATH|PYTHONPATH|PYTHONHOME|BASH_ENV|ENV|COMSPEC|SHELL)$/i;

const COMMON_TEST_COMMANDS = new Set([
  'npm test', 'npm run test', 'npm run build', 'npm run lint', 'npm run typecheck',
  'pnpm test', 'pnpm run test', 'pnpm run build', 'pnpm run lint', 'pnpm run typecheck',
  'yarn test', 'yarn build', 'yarn lint', 'yarn typecheck', 'bun test', 'bun run test', 'bun run build',
  'node --test', 'python -m pytest', 'python3 -m pytest', 'pytest', 'cargo test', 'go test ./...', 'git diff --check',
]);

export function parseCommand(commandText) {
  const text = String(commandText ?? '').trim();
  if (!text || text.length > 500 || /[\r\n;&|<>`$(){}!%\\]/.test(text)) throw new Error('Command rejected: use one plain command without shell operators, substitutions, or newlines.');
  const tokens = text.split(/\s+/);
  if (tokens.some((token) => !SAFE_TOKEN.test(token))) throw new Error('Command rejected: an argument contains unsupported characters.');
  if (isAbsolute(tokens[0])) throw new Error('Absolute executable paths are not allowed.');
  return tokens;
}

export function commandRisk(commandText) {
  let tokens;
  try { tokens = parseCommand(commandText); } catch { return true; }
  if (!tokens.length) return true;
  // The explicit verification allowlist is already individually shown and confirmed before execution.
  if (isCommonTestCommand(commandText)) return false;
  const executable = basename(tokens[0]).replace(/\.(?:exe|cmd|bat|com)$/i, '').toLowerCase();
  const args = tokens.slice(1);
  const firstArg = (args[0] ?? '').toLowerCase();
  if (HIGH_RISK_EXECUTABLES.has(executable)) return true;
  if (executable === 'git' && DANGEROUS_GIT_SUBCOMMANDS.has(firstArg)) return true;
  if (executable === 'git' && firstArg === 'branch' && args.some((arg) => /^-[dD]$/.test(arg))) return true;
  if (['npm', 'pnpm', 'yarn', 'bun'].includes(executable)) {
    if (PACKAGE_MUTATION_COMMANDS.has(firstArg)) return true;
    if (executable === 'pnpm' && ['dlx', 'import', 'patch', 'deploy'].includes(firstArg)) return true;
    if (executable === 'yarn' && ['dlx', 'plugin', 'set', 'workspaces'].includes(firstArg)) return true;
  }
  if (['pip', 'pip3', 'pipx', 'uv', 'conda', 'cargo', 'go', 'gem'].includes(executable)) {
    if (['install', 'add', 'remove', 'uninstall', 'update', 'upgrade', 'publish'].includes(firstArg)) return true;
  }
  if (['node', 'nodejs', 'python', 'python3', 'python2', 'ruby', 'perl', 'lua', 'bun', 'tsx', 'ts-node'].includes(executable)) {
    if (args.some((arg) => /^(?:-c|-e|-exec|--eval)(?:=|$)/i.test(arg) || /^-[ce].+/i.test(arg))) return true;
    // Executing a source file is materially different from checking the runtime version.
    if (args.some((arg) => /\.(?:[cm]?js|jsx|ts|tsx|py|pyw|rb|pl|pm|lua)$/i.test(arg)) && !args.includes('--test')) return true;
  }
  if (['npm', 'pnpm', 'yarn', 'bun'].includes(executable) && firstArg === 'run' && !isCommonTestCommand(commandText)) return true;
  if (args.some((arg) => /^(?:--force|--delete|--recursive|--no-preserve-root|--overwrite|--upload-pack|--receive-pack)$/i.test(arg))) return true;
  if (args.some((arg) => /^-[^-]*[rf][^-]*$/i.test(arg)) && ['rm', 'rmdir', 'del', 'erase', 'git', 'find'].includes(executable)) return true;
  return false;
}

/**
 * Repository-controlled scripts must not inherit unrelated cloud/API credentials.
 * The operator can explicitly pass ordinary custom variables via
 * FORGE_COMMAND_ENV_ALLOWLIST=DATABASE_URL,MY_TEST_MODE. Common API keys,
 * Forge internals, and runtime-injection variables remain blocked even by opt-in.
 */
export function buildCommandEnv(sourceEnv = process.env) {
  const env = {};
  const findName = (wanted) => Object.keys(sourceEnv).find((actual) => actual.toLowerCase() === wanted.toLowerCase());
  for (const wanted of SAFE_COMMAND_ENV_KEYS) {
    const actual = findName(wanted);
    if (actual && sourceEnv[actual] !== undefined) env[actual] = sourceEnv[actual];
  }
  const allowlistName = findName('FORGE_COMMAND_ENV_ALLOWLIST');
  const requestedNames = typeof sourceEnv[allowlistName] === 'string'
    ? sourceEnv[allowlistName].split(',').map((name) => name.trim()).filter(Boolean)
    : [];
  for (const name of requestedNames) {
    if (!/^[A-Za-z_][A-Za-z0-9_]*$/.test(name) || NEVER_ALLOW_COMMAND_ENV.test(name)) continue;
    const actual = findName(name);
    if (actual && sourceEnv[actual] !== undefined) env[actual] = sourceEnv[actual];
  }
  return env;
}


/** Terminate a child and its descendants after a timeout/output-limit event. */
export function terminateProcessTree(child, { force = false, env = buildCommandEnv() } = {}) {
  const signal = force ? 'SIGKILL' : 'SIGTERM';
  if (!child?.pid) {
    try { child?.kill(signal); } catch { /* Process may already have exited. */ }
    return;
  }
  if (process.platform === 'win32') {
    // taskkill /T addresses descendants; /F is used only after the grace period.
    const args = ['/PID', String(child.pid), '/T'];
    if (force) args.push('/F');
    try {
      const result = spawnSync('taskkill.exe', args, { env, encoding: 'utf8', timeout: 2000, windowsHide: true, stdio: 'ignore' });
      if (result.status === 0) return;
    } catch { /* Fall back to killing the direct child. */ }
    try { child.kill(signal); } catch { /* Process may already have exited. */ }
    return;
  }
  // Spawned processes use detached process groups on POSIX, so this reaches grandchildren too.
  try { process.kill(-child.pid, signal); return; } catch { /* Group may already be gone. */ }
  try { child.kill(signal); } catch { /* Process may already have exited. */ }
}

export function isCommonTestCommand(commandText) {
  const trimmed = String(commandText).trim();
  return COMMON_TEST_COMMANDS.has(trimmed) || /^(npm|pnpm)\s+run\s+(test|build|lint|typecheck|check|unit|integration)$/.test(trimmed) || /^(yarn|bun)\s+run\s+(test|build|lint|typecheck|check|unit|integration)$/.test(trimmed);
}

export function runProcess(commandText, { cwd, timeoutMs = 120000, maxOutputBytes = 1200000, env = buildCommandEnv() } = {}) {
  const tokens = parseCommand(commandText);
  const command = tokens[0];
  const args = tokens.slice(1);
  return new Promise((resolve, reject) => {
    let child;
    let stdout = '';
    let stderr = '';
    let outputBytes = 0;
    let timedOut = false;
    let overflow = false;
    let finished = false;
    let timer;
    let killEscalationTimer;
    const stopTree = () => {
      terminateProcessTree(child, { env });
      if (!killEscalationTimer) {
        killEscalationTimer = setTimeout(() => terminateProcessTree(child, { force: true, env }), 1200);
        killEscalationTimer.unref?.();
      }
    };

    const finish = (error, result) => {
      if (finished) return;
      finished = true;
      clearTimeout(timer);
      if (error) reject(error); else resolve(result);
    };

    try {
      if (process.platform === 'win32' && /\.(?:cmd|bat)$/i.test(command)) {
        const commandLine = [command, ...args].map((part) => `"${part.replaceAll('"', '""')}"`).join(' ');
        child = spawn(env.ComSpec || env.COMSPEC || 'cmd.exe', ['/d', '/s', '/c', commandLine], { cwd, env, shell: false, windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] });
      } else if (process.platform === 'win32' && ['npm', 'npx', 'pnpm', 'yarn', 'bun'].includes(command)) {
        const commandLine = [`${command}.cmd`, ...args].map((part) => `"${part.replaceAll('"', '""')}"`).join(' ');
        child = spawn(env.ComSpec || env.COMSPEC || 'cmd.exe', ['/d', '/s', '/c', commandLine], { cwd, env, shell: false, windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] });
      } else {
        child = spawn(command, args, { cwd, env, shell: false, detached: process.platform !== 'win32', windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] });
      }
    } catch (error) {
      finish(error);
      return;
    }

    const capture = (target, chunk, stream) => {
      outputBytes += chunk.length;
      if (outputBytes > maxOutputBytes) {
        overflow = true;
        stopTree();
        return;
      }
      if (stream === 'stdout') stdout += chunk.toString('utf8');
      else stderr += chunk.toString('utf8');
      if (target.length > maxOutputBytes) return;
    };
    child.stdout.on('data', (chunk) => capture(stdout, chunk, 'stdout'));
    child.stderr.on('data', (chunk) => capture(stderr, chunk, 'stderr'));
    child.on('error', (error) => finish(error));
    child.on('close', (code, signal) => {
      finish(null, {
        command: commandText,
        code: typeof code === 'number' ? code : -1,
        signal,
        stdout: stdout.slice(0, maxOutputBytes),
        stderr: stderr.slice(0, maxOutputBytes),
        timedOut,
        overflow,
        success: code === 0 && !timedOut && !overflow,
      });
    });
    timer = setTimeout(() => {
      timedOut = true;
      child.kill('SIGTERM');
      stopTree();
    }, timeoutMs);
    timer.unref?.();
  });
}

export function testCommandCandidates(index) {
  const packageJson = index.files.find((file) => file.path === 'package.json');
  if (packageJson) {
    try {
      const parsed = JSON.parse(packageJson.content);
      if (parsed.scripts?.test) return [`${parsed.packageManager?.startsWith('pnpm') ? 'pnpm' : parsed.packageManager?.startsWith('yarn') ? 'yarn' : parsed.packageManager?.startsWith('bun') ? 'bun' : 'npm'} test`];
    } catch { /* Malformed package.json will be shown in the review context. */ }
  }
  if (index.files.some((file) => ['pyproject.toml', 'pytest.ini', 'tox.ini'].includes(file.path))) return ['python -m pytest'];
  if (index.files.some((file) => file.path === 'Cargo.toml')) return ['cargo test'];
  if (index.files.some((file) => file.path === 'go.mod')) return ['go test ./...'];
  if (index.files.some((file) => file.path.endsWith('.test.js') || file.path.endsWith('.test.mjs'))) return ['node --test'];
  return [];
}
