# Plan an engineering task

Inspect the repository and task. Produce the intended outcome, acceptance criteria, relevant files, minimal ordered steps, risks, dependencies, and exact verification checks. Mark assumptions and unknowns. Do not edit files or run commands during planning.
