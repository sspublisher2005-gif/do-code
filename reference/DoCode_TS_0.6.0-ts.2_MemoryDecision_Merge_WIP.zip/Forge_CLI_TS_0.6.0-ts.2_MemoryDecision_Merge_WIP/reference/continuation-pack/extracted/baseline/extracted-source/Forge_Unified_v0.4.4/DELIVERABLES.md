# Forge Unified 0.4.4 — deliverables and open gates

This release bundle contains the full executable source and tests, rather than only a review-document ZIP. It remains an experimental coding-agent CLI, not a production-certified product.

## Start and verify

Requires Node.js 22 or newer:

```bash
npm ci --ignore-scripts
npm test
npm run check
npm run check:release
node bin/forge.js --version
node bin/forge.js --help
node bin/forge.js doctor
node bin/forge.js sandbox status
```

Install the generated package with `npm install -g ./forge-coding-harness-0.4.4.tgz`. Forge never pulls sandbox images automatically. The experimental container path requires a local Docker/Podman runtime, local trusted image and explicit opt-in; Windows sandbox execution fails closed.

## Included

1. **CLI source and tests:** `bin/`, `src/`, `tests/`, `scripts/`, `skills/`, `integrations/`, `examples/`.
2. **Dependency lockfile and CI:** `package-lock.json` and `.github/workflows/ci.yml`.
3. **Public-source competitor/user pain research:** `docs/COMPETITOR_AND_USER_PAINPOINTS_2026-10-21.md`.
4. **Three specialist perspectives:** `docs/THREE_EXPERT_REVIEW_2026-10-21.md` (simulated internal reviews, not outside independent experts).
5. **Remaining-work checklist:** `docs/REMAINING_WORK_AND_ACCEPTANCE_GATES_2026-10-21.md`.
6. **Sandbox details:** `docs/SANDBOX_EXECUTION.md`.
7. **Session and project isolation:** `docs/SESSIONS_AND_RESUME.md`, `docs/PROJECT_ISOLATION.md` and related security documents.
8. **Benchmark plan:** `docs/COMPETITOR_BENCHMARK_PLAN.md` and `docs/BENCHMARKS.md`.
9. **Verification evidence:** `evidence/` contains raw test/CI/package/browser logs, screenshots, checksums and the release verdict.

## Important evidence limits

Local suite/package checks are green. The npm audit has a zero-dependency tree and reports zero known vulnerabilities, but does not scan source code or container images. The real-Docker CI job is configured but has not run. No live provider-backed coding task, Forge Node Playwright-adapter E2E run, Windows/macOS/Linux hosted results, image provenance/SBOM scan, independent security review, representative customer interviews or matched competitor benchmark is available. Do not market Forge as superior to competitors or label it 100% complete until these gates pass.
