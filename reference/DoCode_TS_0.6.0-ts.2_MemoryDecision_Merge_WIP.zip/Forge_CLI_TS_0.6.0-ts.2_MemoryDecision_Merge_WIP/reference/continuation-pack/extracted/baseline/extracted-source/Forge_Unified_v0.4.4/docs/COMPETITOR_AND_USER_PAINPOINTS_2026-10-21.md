# Forge competitive and user-pain-point review

**Research date:** 21 October 2026  
**Decision use:** prioritize Forge engineering work; not a market-size report and not a claim of competitor superiority.

## Research discipline

This review separates official product documentation, public issue reports, and founder hypotheses. A public bug report demonstrates a reported failure mode, not its prevalence across all users. The research did not conduct direct customer interviews, run paid ads, access private competitor analytics, or run matched task benchmarks. No popularity, retention, or willingness-to-pay figure is inferred.

## Competitive lessons verified from public documentation

| Product | Evidence checked | Product lesson for Forge |
|---|---|---|
| OpenAI Codex CLI | OpenAI Help Center describes approval modes, local terminal workflows, and a sandboxed autonomous mode scoped to a directory with network disabled. https://help.openai.com/en/articles/11096431 | Approval UX and real sandboxing are separate controls. Forge's application policy is not equivalent to host isolation. |
| Gemini CLI | Official Gemini CLI docs describe container/OS sandbox backends and expansion requests: https://github.com/google-gemini/gemini-cli/blob/main/docs/cli/sandbox.md | Explain the boundary to users, fail visibly when required isolation is unavailable, and make any permission expansion explicit. |
| Gemini CLI | Official checkpoint docs describe project snapshots plus conversation/tool-call history before file modification: https://github.com/google-gemini/gemini-cli/blob/main/docs/cli/checkpointing.md | Forge checkpoints need a clear inspect/recover story, and long tasks need persistence. A checkpoint alone does not restore a coding session. |
| OpenCode | Official CLI docs describe configurable agents with named modes and explicit tool permissions, plus session continuation/selection: https://github.com/anomalyco/opencode/blob/dev/packages/web/src/content/docs/cli.mdx | Prefer explicit least-privilege permission profiles, project-bound sessions, and inspectable controls over opaque agent magic. |
| Aider | Official usage docs describe switching between ask, architect, and code modes: https://github.com/Aider-AI/aider/blob/main/aider/website/docs/usage/modes.md | Users benefit from a clear distinction between planning/discussion and editing; Forge can keep the workflow adaptive rather than expose every internal agent as a separate persona. |

### Benchmarking caution

OpenAI's February 2026 article explains why it no longer recommends SWE-bench Verified as a frontier-capability measure and recommends SWE-bench Pro instead: https://openai.com/index/why-we-no-longer-evaluate-swe-bench-verified/. Forge should not market superiority based only on a single published benchmark, GitHub stars, a cherry-picked demo, or unit-test count. It needs matched, held-out tasks and exact artifact/cost/latency evidence.

## Public pain reports worth learning from

These links are issue reports from a competitor repository; they are anecdotes with reproduction descriptions, not independently confirmed frequency estimates:

- A resume-from-summary failure report describes session resume being blocked by a context/usage error: https://github.com/anthropics/claude-code/issues/49838
- An auto-compaction report describes a long session reaching the context limit and ending in a restart requirement, while manual compaction reportedly worked: https://github.com/anthropics/claude-code/issues/83682
- A resume report alleges silent loss of old conversation messages: https://github.com/anthropics/claude-code/issues/40487
- A reported session-resume cache issue alleges excess usage caused by prompt-prefix changes: https://github.com/anthropics/claude-code/issues/42338
- An OpenCode feature request describes persisted session data without a simple way to re-attach to prior context in a new terminal: https://github.com/anomalyco/opencode/issues/29181
- An OpenCode bug report describes context compaction repeatedly failing to reduce context and looping: https://github.com/anomalyco/opencode/issues/27924
- Another OpenCode report describes a session becoming stuck after a provider HTTP 400 and a failed compaction path: https://github.com/anomalyco/opencode/issues/52463
- A Gemini CLI issue describes a resume command printed after resuming that later references an invalid session ID: https://github.com/google-gemini/gemini-cli/issues/24360

**Customer pain hypotheses derived from these examples:** continuity loss is costly; hidden or failed compaction can damage trust; users need clear session provenance and recovery behavior; usage accounting must show unknown values as unknown; the CLI should not suggest an unverified resume ID. These are failure modes reported by individual users, not estimates of prevalence. They need direct interviews and user-task observation before we treat them as market facts.

## Community signals from Reddit (anecdotal, not a survey)

A targeted Reddit search surfaced similar themes, independently of the issue tracker:

- **Context drift after compaction and between sessions:** posters ask how to stop agents losing focus after compaction or losing previous decisions between sessions. Examples: https://www.reddit.com/r/ClaudeAI/comments/1plgyff/how_to_prevent_claude_code_from_losing_its_focus/ and https://www.reddit.com/r/ClaudeAI/comments/1qn64j4/how_do_you_handle_context_loss_between_claude/.
- **Compaction and usage-limit surprises:** an individual post reports using a full five-hour usage allowance after compacting an older session; this is an unverified account report, not a billing diagnosis: https://www.reddit.com/r/ClaudeAI/comments/1v1lr3g/how_is_it_that_i_just_logged_in_to_claude_code/.
- **Post-generation cleanup:** a LocalLLaMA discussion frames agent output as creating extensive cleanup work. The stated “60%” is one poster's estimate, not a measured population statistic: https://www.reddit.com/r/LocalLLaMA/comments/1mdg9z1/do_ai_coding_agents_actually_save_you_time_or/.
- **Local-first trust:** an OpenCode discussion focuses on what configuration is needed for a genuinely local experience. This supports making network/provider behavior visible, not declaring the product itself insecure: https://www.reddit.com/r/LocalLLaMA/comments/1rv690j/opencode_concerns_not_truely_local/.

These discussions are useful for discovering questions to test, not for estimating how common a problem is. Forge's product response should therefore be measurable: encrypted project-bound session records, exclusive session locks and deliberate restart semantics now exist; exact transcript restoration, provider-level budget enforcement, real-engine sandbox validation and live task-quality evidence remain outstanding.

## Persona views

### Beginner / vibe coder

**Needs:** describe an outcome in normal language, understand what Forge will change, avoid destroying work, and know which next step to take.  
**Failure to avoid:** jargon, silent background actions, asking for approval without explaining consequences, and declaring success when the build/tests are unknown.  
**Design response:** short explainable plan; explicit changed-file list; safe defaults; readable blockers; one clear verification report; interactive resume confirmation.

### Experienced developer / professional

**Needs:** minimal diffs, reproducible commands, known provider/model, predictable context/cost, project/session isolation, fast controls, good Git behavior, and no hidden changes.  
**Failure to avoid:** automatically importing unrelated project data, unreviewed shell/network side effects, broken resume, oversized context, flaky tool invocation.  
**Design response:** project-bound signed sessions with encrypted task text and exact-confirmation deletion; visible model/provider; audit trail; explicit tests and exit codes; dry-run and rollback; the opt-in sandbox hardened in v0.4.4 with fixed unprivileged UID/GID, digest-pinned built-in references, extended credential-path filtering and no-follow regular-file staging; real-engine validation remains open.

### Security-conscious team / maintainer

**Needs:** least privilege, secret isolation, policy visibility, tamper-evident evidence, clear data egress, reproducibility and cross-platform proof.  
**Failure to avoid:** treating prompt text as a security boundary or approving a tool call without a system-enforced boundary.  
**Design response:** treat the OS/container runner as a P0 release gate; keep context imports explicit; avoid claiming sandboxing; eventually add signed evidence export and configurable retention.

### Founder / CEO / buyer

**Needs:** a sharp wedge, fast first success, repeat usage, a trustworthy demo, supportable unit economics and an upgrade path.  
**Failure to avoid:** copying a long feature matrix without measurable differentiated outcomes, broad positioning against every incumbent, or spending money before a validated workflow.  
**Design response:** position Forge around project isolation + evidence-backed delivery; track task completion, regressions, human interventions, time-to-first-success, resume success and known/unknown inference cost. Validate with 15–30 external testers before planning a large launch.

### QA / engineering lead

**Needs:** observable behavior, acceptance criteria tied to tests, reliable cancellation, browser and runtime evidence, and clear failure reasons.  
**Failure to avoid:** model-written success summaries without corresponding command output.  
**Design response:** persist run outcomes from audit evidence; keep the completion gate strict; store actual command exit status and verification limitations; add live browser tests and seeded-defect tasks.

## Founder decision and prioritization

| Priority | Work | Why now | Release evidence |
|---|---|---|---|
| P0 | Real sandbox runner with OS/container enforcement, egress policy, secret isolation, quotas and process-tree cancellation | A prompt and app-level path checks cannot contain arbitrary test/build scripts. Codex/Gemini documentation already establishes real sandboxing as a competitive safety feature. | Adversarial path/secret/network fixtures prove blocked behavior; platform-specific results. |
| P0 | Real end-to-end provider-backed coding task on a disposable fixture | Unit tests do not prove Forge can complete a live coding workflow. | Change is built from original task, tests run, independent review catches a seeded fault, and cost/latency are captured. |
| P0 | True resumable task state and session lifecycle | v0.4.3 introduced exclusive per-session locks and stale-attempt marking; v0.4.4 adds a SIGKILL recovery regression test; resume remains task replay, not transcript/step restoration, and partial edits are not rolled back. | Kill/restart tests at every phase, multi-process locking, current-files/conflict checks, exact audit history. |
| P0 | Cross-platform CI, dependency/secret audit, independent security review | Current local passing tests cannot certify portability or security. | Ubuntu/Windows/macOS CI, lockfile and audit reports, external review findings triaged. |
| P1 | First-success onboarding and cost visibility | Beginners need a guided outcome; experts need honest usage data. | Beginner and pro users complete pre-defined tasks without developer help; unknown usage is never represented as zero. |
| P1 | Held-out matched benchmark vs current competitors | Product claims need evidence, not opinion. | Same task set/model/version/budget, repeated runs, source artifacts and confidence intervals. |
| P1 | User validation and retention signal | Popularity and monetization are unproven. | 15–30 external testers; follow-up usage, failure rate, retention and willingness-to-pay evidence. |

## What not to build yet

- Do not add more subagents merely to increase the advertised agent count.
- Do not build a hosted service, IDE, mobile app or large connector catalog before core CLI reliability and security pass.
- Do not claim “better than Claude Code/Codex/OpenCode” without matched evidence.
- Do not present inferred cost as exact cost when providers omit usage metadata.
- Do not automatically mix projects, conversations, credentials or memory.

## Sources

All pages below were opened/checked during research on 21 October 2026; dynamic documentation may change:

1. OpenAI Help Center — Codex CLI overview/approval modes: https://help.openai.com/en/articles/11096431
2. Gemini CLI — sandboxing: https://github.com/google-gemini/gemini-cli/blob/main/docs/cli/sandbox.md
3. Gemini CLI — checkpointing: https://github.com/google-gemini/gemini-cli/blob/main/docs/cli/checkpointing.md
4. OpenCode — CLI, agent permissions, and session flags: https://github.com/anomalyco/opencode/blob/dev/packages/web/src/content/docs/cli.mdx
5. Aider — usage modes: https://github.com/Aider-AI/aider/blob/main/aider/website/docs/usage/modes.md
6. OpenAI — benchmark limitations and SWE-bench Pro recommendation (23 February 2026): https://openai.com/index/why-we-no-longer-evaluate-swe-bench-verified/
7. Claude Code public issue — resume from summary error: https://github.com/anthropics/claude-code/issues/49838
8. Claude Code public issue — auto-compaction failure: https://github.com/anthropics/claude-code/issues/83682
9. Claude Code public issue — reported message loss on resume: https://github.com/anthropics/claude-code/issues/40487
10. Claude Code public issue — reported cache usage on resume: https://github.com/anthropics/claude-code/issues/42338
11. OpenCode public issue — resume/context re-attach request: https://github.com/anomalyco/opencode/issues/29181
12. OpenCode public issue — compaction loop report: https://github.com/anomalyco/opencode/issues/27924
13. OpenCode public issue — session stuck after provider error and compaction failure: https://github.com/anomalyco/opencode/issues/52463
14. Gemini CLI public issue — invalid resume ID in displayed command: https://github.com/google-gemini/gemini-cli/issues/24360
15. Reddit / r/ClaudeAI — compaction context drift: https://www.reddit.com/r/ClaudeAI/comments/1plgyff/how_to_prevent_claude_code_from_losing_its_focus/
16. Reddit / r/ClaudeAI — context loss between sessions: https://www.reddit.com/r/ClaudeAI/comments/1qn64j4/how_do_you_handle_context_loss_between_claude/
17. Reddit / r/ClaudeAI — usage-limit surprise after compaction (individual report): https://www.reddit.com/r/ClaudeAI/comments/1v1lr3g/how_is_it_that_i_just_logged_in_to_claude_code/
18. Reddit / r/LocalLLaMA — cleanup time from coding agents (individual estimate): https://www.reddit.com/r/LocalLLaMA/comments/1mdg9z1/do_ai_coding_agents_actually_save_you_time_or/
19. Reddit / r/LocalLLaMA — local-first configuration concerns: https://www.reddit.com/r/LocalLLaMA/comments/1rv690j/opencode_concerns_not_truely_local/
