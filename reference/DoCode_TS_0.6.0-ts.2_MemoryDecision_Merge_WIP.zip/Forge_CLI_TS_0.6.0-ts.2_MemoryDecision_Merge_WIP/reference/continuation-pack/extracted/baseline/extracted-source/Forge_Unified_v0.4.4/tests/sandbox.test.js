import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { copySanitizedWorkspace, inspectSandbox, runSandboxedCommand, sandboxDefaults } from '../src/sandbox.js';

function tempDir(prefix = 'forge-sandbox-test-') {
  return fs.mkdtempSync(path.join(os.tmpdir(), prefix));
}

function fakeDocker(binDir, logPath, contextHost = 'unix:///var/run/docker.sock') {
  fs.mkdirSync(binDir, { recursive: true });
  const binary = path.join(binDir, 'docker');
  fs.writeFileSync(binary, `#!/usr/bin/env node
import fs from 'node:fs';
const raw = process.argv.slice(2);
const args = raw[0] === '--context=default' ? raw.slice(1) : raw[0] === '--remote=false' ? raw.slice(1) : raw;
if (args[0] === 'context' && args[1] === 'inspect') { process.stdout.write(${JSON.stringify(contextHost)} + String.fromCharCode(10)); process.exit(0); }
if (args[0] === 'info') process.exit(0);
if (args[0] === 'image' && args[1] === 'inspect') { process.stdout.write('sha256:' + 'a'.repeat(64) + String.fromCharCode(10)); process.exit(0); }
if (args[0] === 'run') {
  const mount = args[args.indexOf('--mount') + 1] || '';
  const root = mount.split(',dst=/input')[0].replace(/^type=bind,src=/, '');
  const record = {
    args,
    cwdFiles: root ? fs.readdirSync(root).sort() : [],
    rootHasEnv: root ? fs.existsSync(root + '/.env') : null,
    rootHasEnvExample: root ? fs.existsSync(root + '/.env.example') : null,
    rootHasOutsideLink: root ? fs.existsSync(root + '/outside-link') : null,
    rootMode: root ? (fs.statSync(root).mode & 0o777) : null,
    appMode: root && fs.existsSync(root + '/app.js') ? (fs.statSync(root + '/app.js').mode & 0o777) : null,
    privateModeSourceMode: root && fs.existsSync(root + '/private-mode-source.txt') ? (fs.statSync(root + '/private-mode-source.txt').mode & 0o777) : null,
    envKeys: Object.keys(process.env).sort(),
  };
  fs.writeFileSync(${JSON.stringify(logPath)}, JSON.stringify(record));
  console.log('FAKE_SANDBOX_OK');
  process.exit(0);
}
process.exit(9);
`, { mode: 0o700 });
  fs.chmodSync(binary, 0o700);
  return binary;
}

test('sandbox copy omits common secrets, Forge internals, and symlinks', (t) => {
  const root = tempDir();
  const output = tempDir();
  const outside = path.join(tempDir(), 'outside-secret.txt');
  const outsideDirectory = tempDir();
  fs.writeFileSync(path.join(outsideDirectory, 'outside-dir-secret.txt'), 'outside directory content');
  fs.writeFileSync(path.join(root, 'app.js'), 'console.log("ok")');
  fs.writeFileSync(path.join(root, 'private-mode-source.txt'), 'source from host mode 0600', { mode: 0o600 });
  fs.writeFileSync(path.join(root, '.env'), 'API_KEY=example-secret');
  fs.writeFileSync(path.join(root, '.env.example'), 'API_KEY=');
  fs.mkdirSync(path.join(root, '.forge'));
  fs.writeFileSync(path.join(root, '.forge', 'audit.jsonl'), 'private event');
  fs.mkdirSync(path.join(root, '.docker'));
  fs.writeFileSync(path.join(root, '.docker', 'config.json'), '{\"auths\":{}}');
  fs.mkdirSync(path.join(root, '.config', 'gh'), { recursive: true });
  fs.writeFileSync(path.join(root, '.config', 'gh', 'hosts.yml'), 'github.com: oauth_token: secret');
  fs.mkdirSync(path.join(root, 'nested-project', '.config', 'gh'), { recursive: true });
  fs.writeFileSync(path.join(root, 'nested-project', '.config', 'gh', 'hosts.yml'), 'nested oauth token');
  fs.mkdirSync(path.join(root, '.config', 'gcloud'), { recursive: true });
  fs.writeFileSync(path.join(root, '.config', 'gcloud', 'credentials.db'), 'cloud tokens');
  fs.mkdirSync(path.join(root, '.terraform.d'), { recursive: true });
  fs.writeFileSync(path.join(root, '.terraform.d', 'credentials.tfrc.json'), '{"credentials":{}}');
  fs.writeFileSync(path.join(root, '.git-credentials'), 'https://user:token@example.invalid');
  fs.writeFileSync(outside, 'outside');
  try {
    fs.symlinkSync(outside, path.join(root, 'outside-link'));
    fs.symlinkSync(outsideDirectory, path.join(root, 'outside-dir-link'), 'dir');
  } catch (error) { t.skip(`Symlinks unavailable: ${error.message}`); return; }

  const stats = copySanitizedWorkspace(root, output);
  assert.equal(fs.readFileSync(path.join(output, 'app.js'), 'utf8'), 'console.log("ok")');
  assert.ok(fs.statSync(output).mode & 0o005, 'staged root must be traversable by the fixed unprivileged container identity');
  assert.ok(fs.statSync(path.join(output, 'private-mode-source.txt')).mode & 0o004, 'copied source files must be readable by the unprivileged container identity');
  assert.equal(fs.existsSync(path.join(output, '.env')), false);
  assert.equal(fs.existsSync(path.join(output, '.env.example')), true);
  assert.equal(fs.existsSync(path.join(output, '.forge')), false);
  assert.equal(fs.existsSync(path.join(output, '.docker', 'config.json')), false);
  assert.equal(fs.existsSync(path.join(output, '.config', 'gh', 'hosts.yml')), false);
  assert.equal(fs.existsSync(path.join(output, 'nested-project', '.config', 'gh', 'hosts.yml')), false);
  assert.equal(fs.existsSync(path.join(output, '.config', 'gcloud', 'credentials.db')), false);
  assert.equal(fs.existsSync(path.join(output, '.terraform.d', 'credentials.tfrc.json')), false);
  assert.equal(fs.existsSync(path.join(output, '.git-credentials')), false);
  assert.equal(fs.existsSync(path.join(output, 'outside-link')), false);
  assert.equal(fs.existsSync(path.join(output, 'outside-dir-link')), false);
  assert.ok(stats.skippedSecrets >= 7);
  assert.equal(stats.skippedSymlinks, 2);
});

test('sandbox staging rejects a regular file swapped to a symlink between lstat and open', (t) => {
  if (process.platform === 'win32' || !fs.constants.O_NOFOLLOW) { t.skip('O_NOFOLLOW race regression requires a POSIX platform that supports it.'); return; }
  const root = tempDir();
  const output = tempDir();
  const outsideRoot = tempDir();
  const source = path.join(root, 'source.txt');
  const backup = path.join(root, 'source.original');
  const outside = path.join(outsideRoot, 'outside-secret.txt');
  fs.writeFileSync(source, 'trusted-at-lstat');
  fs.writeFileSync(outside, 'outside-secret-must-not-be-copied');
  const originalLstat = fs.lstatSync;
  let swapped = false;
  fs.lstatSync = function patchedLstat(target, ...args) {
    const info = originalLstat.call(fs, target, ...args);
    if (!swapped && path.resolve(String(target)) === path.resolve(source)) {
      swapped = true;
      fs.renameSync(source, backup);
      fs.symlinkSync(outside, source);
    }
    return info;
  };
  try {
    assert.throws(() => copySanitizedWorkspace(root, output), /source changed|symlink|link or invalid path/i);
    assert.equal(swapped, true, 'the adversarial path swap should run between lstat and open');
    assert.equal(fs.existsSync(path.join(output, 'source.txt')), false, 'outside symlink target must not enter staged input');
  } finally {
    fs.lstatSync = originalLstat;
    fs.rmSync(root, { recursive: true, force: true, maxRetries: 2 });
    fs.rmSync(output, { recursive: true, force: true, maxRetries: 2 });
    fs.rmSync(outsideRoot, { recursive: true, force: true, maxRetries: 2 });
  }
});

test('sandbox staging rejects a directory swapped to an outside symlink during traversal', (t) => {
  if (process.platform === 'win32') { t.skip('POSIX symlink race regression.'); return; }
  const root = tempDir();
  const output = tempDir();
  const outsideRoot = tempDir();
  const sourceDir = path.join(root, 'source-dir');
  const backupDir = path.join(root, 'source-dir.original');
  fs.mkdirSync(sourceDir);
  fs.writeFileSync(path.join(sourceDir, 'expected.txt'), 'in-project');
  fs.writeFileSync(path.join(outsideRoot, 'outside-secret.txt'), 'outside-secret-must-not-be-copied');
  const originalLstat = fs.lstatSync;
  let swapped = false;
  fs.lstatSync = function patchedLstat(target, ...args) {
    const info = originalLstat.call(fs, target, ...args);
    if (!swapped && path.resolve(String(target)) === path.resolve(sourceDir)) {
      swapped = true;
      fs.renameSync(sourceDir, backupDir);
      fs.symlinkSync(outsideRoot, sourceDir, 'dir');
    }
    return info;
  };
  try {
    assert.throws(() => copySanitizedWorkspace(root, output), /source directory changed|symlink/i);
    assert.equal(swapped, true, 'the adversarial directory swap should run between lstat and recursion');
    assert.equal(fs.existsSync(path.join(output, 'source-dir', 'outside-secret.txt')), false, 'outside directory contents must not enter staged input');
  } finally {
    fs.lstatSync = originalLstat;
    fs.rmSync(root, { recursive: true, force: true, maxRetries: 2 });
    fs.rmSync(output, { recursive: true, force: true, maxRetries: 2 });
    fs.rmSync(outsideRoot, { recursive: true, force: true, maxRetries: 2 });
  }
});

test('sandbox runner fails closed when no container runtime exists', async () => {
  const root = tempDir();
  fs.writeFileSync(path.join(root, 'package.json'), '{"scripts":{"test":"node --test"}}');
  const status = inspectSandbox({ cwd: root, env: { PATH: '', HOME: os.tmpdir() } });
  assert.equal(status.available, false);
  await assert.rejects(
    () => runSandboxedCommand('node --version', { cwd: root, env: { PATH: '', HOME: os.tmpdir() } }),
    /Required sandbox unavailable; command was not executed/,
  );
});

test('sandbox runner passes strict no-network/no-credential options to runtime and uses a sanitized temporary copy', async (t) => {
  if (process.platform === 'win32') { t.skip('POSIX fake runtime executable fixture.'); return; }
  const root = tempDir();
  const binDir = path.join(root, 'fake-bin');
  const logPath = path.join(root, 'runtime-log.json');
  fs.mkdirSync(binDir);
  fs.writeFileSync(path.join(root, 'package.json'), '{"scripts":{"test":"node --test"}}');
  fs.writeFileSync(path.join(root, 'app.js'), 'safe');
  fs.writeFileSync(path.join(root, 'private-mode-source.txt'), 'readable from disposable container', { mode: 0o600 });
  fs.writeFileSync(path.join(root, '.env'), 'OPENAI_API_KEY=do-not-copy');
  fs.writeFileSync(path.join(root, '.env.example'), 'OPENAI_API_KEY=');
  try { fs.symlinkSync(path.join(root, 'app.js'), path.join(root, 'outside-link')); }
  catch (error) { t.skip(`Symlinks unavailable: ${error.message}`); return; }
  fakeDocker(binDir, logPath);

  const result = await runSandboxedCommand('node --version', {
    cwd: root, timeoutMs: 5000, maxOutputBytes: 20000,
    env: {
      PATH: `${binDir}${path.delimiter}${process.env.PATH || ''}`,
      HOME: os.tmpdir(), FORGE_SANDBOX_RUNTIME: 'docker', OPENAI_API_KEY: 'must-not-pass',
      DOCKER_HOST: 'tcp://untrusted.invalid:2375',
    },
  });
  assert.equal(result.success, true);
  assert.match(result.stdout, /FAKE_SANDBOX_OK/);
  assert.equal(result.sandbox.network, 'disabled');
  assert.equal(result.sandbox.workspace, 'disposable-sanitized-copy');
  assert.ok(result.sandbox.skippedSecrets >= 1);
  assert.equal(result.sandbox.skippedSymlinks, 1);
  const recorded = JSON.parse(fs.readFileSync(logPath, 'utf8'));
  assert.ok(recorded.args.includes('--network=none'));
  assert.ok(recorded.args.includes('--read-only'));
  assert.ok(recorded.args.includes('--cap-drop=ALL'));
  assert.ok(recorded.args.includes('--security-opt=no-new-privileges'));
  assert.ok(recorded.args.includes('--user'));
  assert.equal(recorded.args[recorded.args.indexOf('--user') + 1], '65532:65532', 'sandbox workload must never run as root, even if Forge runs as root');
  assert.ok(recorded.args.includes('--pull=never'));
  assert.ok(recorded.args.includes('--init'), 'container init should reap child processes and forward signals');
  assert.ok(recorded.args.includes('--memory=768m'));
  assert.ok(recorded.args.some((arg) => arg.startsWith('/workspace:rw,exec,nosuid,nodev,size=512m,uid=')));
  assert.ok(recorded.args.some((arg) => arg.startsWith('type=bind,src=') && arg.endsWith(',dst=/input,readonly')));
  assert.ok(recorded.args.includes('--entrypoint=/bin/sh'));
  assert.ok(recorded.args.includes('cp -R /input/. /workspace/ && chmod -R u+rwX /workspace && exec "$@"'), 'copied tmpfs source tree must be writable by the unprivileged test user');
  assert.ok(recorded.args.includes('sha256:' + 'a'.repeat(64)), 'container runs the immutable inspected image ID, not a mutable tag');
  assert.equal(recorded.rootHasEnv, false);
  assert.equal(recorded.rootHasEnvExample, true);
  assert.equal(recorded.rootHasOutsideLink, false);
  assert.ok(recorded.rootMode & 0o005, 'mounted input root must be traversable by UID 65532');
  assert.ok(recorded.appMode & 0o004, 'staged application files must be readable by UID 65532');
  assert.ok(recorded.privateModeSourceMode & 0o004, 'source files originally mode 0600 must be readable in disposable workspace');
  assert.ok(!recorded.envKeys.includes('OPENAI_API_KEY'));
  assert.ok(!recorded.envKeys.includes('DOCKER_HOST'));
  assert.equal(fs.existsSync(path.join(root, '.env')), true, 'original project is preserved');
});


test('sandbox refuses a TMPDIR symlink whose real destination is inside the project', async (t) => {
  if (process.platform === 'win32') { t.skip('POSIX fake runtime and symlink fixture.'); return; }
  const root = tempDir();
  const binDir = path.join(root, 'fake-bin');
  const actualTemp = path.join(root, 'actual-temp');
  const linkedTemp = path.join(root, 'linked-temp');
  fs.mkdirSync(actualTemp);
  fs.mkdirSync(binDir);
  fs.writeFileSync(path.join(root, 'package.json'), '{"scripts":{"test":"node --test"}}');
  fakeDocker(binDir, path.join(root, 'unused.json'));
  try { fs.symlinkSync(actualTemp, linkedTemp, 'dir'); }
  catch (error) { t.skip(`Symlinks unavailable: ${error.message}`); return; }
  const oldTmpdir = process.env.TMPDIR;
  process.env.TMPDIR = linkedTemp;
  try {
    await assert.rejects(
      () => runSandboxedCommand('node --version', { cwd: root, env: { PATH: `${binDir}${path.delimiter}${process.env.PATH || ''}`, HOME: os.tmpdir(), FORGE_SANDBOX_RUNTIME: 'docker' } }),
      /resolve inside the project root/,
    );
  } finally {
    if (oldTmpdir === undefined) delete process.env.TMPDIR;
    else process.env.TMPDIR = oldTmpdir;
  }
});

test('sandbox refuses a Docker default context that points at a remote or unverified endpoint', (t) => {
  if (process.platform === 'win32') { t.skip('POSIX fake runtime executable fixture.'); return; }
  const root = tempDir();
  const binDir = path.join(root, 'fake-bin');
  fs.mkdirSync(binDir);
  fakeDocker(binDir, path.join(root, 'unused.json'), 'ssh://developer@remote.example');
  const status = inspectSandbox({ cwd: root, env: { PATH: `${binDir}${path.delimiter}${process.env.PATH || ''}`, HOME: os.tmpdir(), FORGE_SANDBOX_RUNTIME: 'docker' } });
  assert.equal(status.available, false);
  assert.match(status.reason, /not a local Unix socket path/);
});

test('sandbox staging bounds unusually large workspace files', () => {
  const root = tempDir();
  const output = tempDir();
  fs.writeFileSync(path.join(root, 'large.bin'), Buffer.alloc(1024));
  assert.throws(() => copySanitizedWorkspace(root, output, { maxFileBytes: 100 }), /refused file over/);
});


test('all built-in sandbox images are digest-pinned rather than mutable tags', () => {
  for (const [language, reference] of Object.entries(sandboxDefaults)) {
    assert.match(reference, /^[^@]+@sha256:[a-f0-9]{64}$/i, `${language} default image must have an immutable digest`);
  }
});

test('custom sandbox image overrides require a digest and mutable tags fail closed', (t) => {
  const root = tempDir();
  fs.writeFileSync(path.join(root, 'package.json'), '{"name":"custom-image-check"}');
  const status = inspectSandbox({ cwd: root, env: { PATH: '', HOME: os.tmpdir(), FORGE_SANDBOX_IMAGE: 'example.invalid/forge-test:latest' } });
  assert.equal(status.available, false);
  assert.match(status.reason, /must be a digest-pinned image reference/);
});

test('custom digest-pinned sandbox image references are inspectable by a local runtime', (t) => {
  if (process.platform === 'win32') { t.skip('POSIX fake runtime executable fixture.'); return; }
  const root = tempDir();
  const binDir = path.join(root, 'fake-bin');
  fs.mkdirSync(binDir);
  fakeDocker(binDir, path.join(root, 'unused.json'));
  fs.writeFileSync(path.join(root, 'package.json'), '{"name":"custom-image-check"}');
  const image = `example.invalid/forge-test@sha256:${'b'.repeat(64)}`;
  const status = inspectSandbox({ cwd: root, env: { PATH: `${binDir}${path.delimiter}${process.env.PATH || ''}`, HOME: os.tmpdir(), FORGE_SANDBOX_RUNTIME: 'docker', FORGE_SANDBOX_IMAGE: image } });
  assert.equal(status.available, true);
  assert.equal(status.image, image);
});
