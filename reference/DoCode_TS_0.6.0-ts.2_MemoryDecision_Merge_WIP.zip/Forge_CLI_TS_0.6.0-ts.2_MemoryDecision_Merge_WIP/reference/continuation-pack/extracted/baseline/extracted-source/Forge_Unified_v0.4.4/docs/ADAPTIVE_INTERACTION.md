# Adaptive interaction: clarification interviews and typed decisions

This is part of the **Forge coding CLI only**. It does not merge or implement the separate Build Validate AI product. Forge's beginner-friendly defaults, professional engineering workflow, and expert controls are one adaptive CLI—not three separate products.

## 1. Default interaction policy

Forge should not force every task through a long interview or a decision matrix.

| Task | Default behavior |
|---|---|
| Clear typo, formatting change, narrow lint fix | Small-fix path; no clarification interview or comparison matrix unless the user explicitly asks for one. Existing patch/approval/testing safety gates still apply. |
| Clear normal coding request | Plan and proceed with the standard workflow. Ask only if the planner identifies a genuine blocking ambiguity. |
| Large/multi-file/security/data-model task | Use the planner and relevant bounded specialists. Ask a bounded interview only if the missing answer materially affects implementation or safety. |
| Vague shorthand such as `fix it` | Produce a plain-language blocking question rather than guessing at the target. |
| Explicit compare/rank/choose request | Generate a typed decision matrix, validate it, compute the ranking locally, and report evidence/assumptions. A decision-only request does not make code changes. |
| High-impact alternative detected during a complex task | Decision analysis is allowed only when the planner flags a real material trade-off; complexity alone does not trigger it. Ask for the user's choice if preferences or consequences materially decide the outcome. |

## 2. Clarification interview

The planner may propose up to five questions, each with an ID, the question, why it matters, whether it blocks safe implementation, optional options, and an optional low-risk default. The runtime sanitizes and bounds those fields. Only blocking questions are asked.

After answers, Forge replans once with the answers included as user requirements. If a blocking ambiguity remains, Forge stops before proposing a patch instead of looping or guessing. If the command is non-interactive, Forge also stops before proposing a patch and asks the user to rerun in an interactive terminal.

### Explain a question without changing the answer

While answering, enter `?` or `/explain`, optionally followed by what is confusing. Forge opens a separate, bounded question-help conversation. It receives only the current question, its reason/options, and the user's help question—not repository files or the main task transcript. Type `/back` to return to the exact same interview question. The user must still choose and submit their own answer.

The help exchange is not an independent background process; it temporarily pauses the interview while preserving its question and answer state. It cannot edit files or change the task. A separate model request is used, requires confirmation, and is recorded in the local audit log using hashes rather than storing the raw side-question text.

## 3. Typed decision matrices

Forge asks for a decision matrix only when the user explicitly requests comparison/ranking or a complex task has a specific, material trade-off. The independent decision prompt expects:

- A decision question.
- Two to eight options and two to eight criteria.
- Unique bounded IDs and positive criterion weights.
- One numeric 1–5 score for every option/criterion pair, where higher is better.
- Pros, cons, risks, evidence references, confidence, assumptions, and unknowns.
- A recommendation ID and whether the user must choose.

Forge validates the output at runtime, rejects malformed/duplicate IDs and missing/out-of-range scores, and recomputes weighted option scores itself. It does not trust the model's stated rank. If the model's recommendation conflicts with the computed top score, Forge highlights the discrepancy and requires user choice. Low-confidence outputs also require user choice for coding tasks. A decision-only request returns the matrix and exits without modifying source code or running commands.

The scores are **model estimates**, not measured truth. Weighted arithmetic is deterministic once inputs are accepted; the correctness of evidence, scores, and assumptions is not guaranteed. If a schema is invalid, Forge refuses to display an invalid ranking. An explicit comparison request stops before code changes when a valid matrix cannot be produced; optional internal decision support can be skipped and the standard workflow can continue.

## 4. Jev AI / TypeSafe inspiration and boundary

Jev by TypeSafe AI is documented as a decision model that returns typed choices, scores, and yes/no probabilities rather than a prose answer ([TypeSafe AI](https://typesafe.ai/), [Jev AI GitHub](https://github.com/jev-ai)). Forge adopts the general engineering principle that software decisions should use bounded, validated output instead of parsing unconstrained prose.

Forge does **not** call the Jev service in this implementation. Its matrix is produced by the configured Forge model and then runtime-validated; weighted ranking is computed locally. Forge adds an explicit comparison report, provenance labels, missing-evidence warnings, assumptions/unknowns, a disagreement check, and a user-choice gate. That is an architectural difference—not proof of better decision accuracy. A claim that Forge is more accurate than Jev would require a matched decision benchmark, which has not been performed.

## 5. Privacy and safety

- The normal model-consent gate remains in force.
- A question-help request asks separately for consent and sends only minimal question context.
- No repo code, entire conversation, credentials, or file excerpts are sent to the side-help request.
- Decision matrix prompts can include the task, planner output, and a bounded repository summary; these use the same provider consent policy as the coding run.
- Model output never grants tool permissions, overrides policy, or proves that a source claim is true.
- Interviews and rankings cannot approve patch application, commands, dependency installation, network access, Git operations, or deployment.
- Decision and interview events record bounded metadata/hashes; do not treat local logs as signed or tamper-proof storage.

## 6. Commands and examples

No extra command is required for the normal adaptive flow:

```text
forge run "Fix the typo in README.md"
# Small-fix path; no interview/matrix by default.

forge run "fix it"
# A blocking clarification should be asked before a patch.

forge run "Compare SQLite and Postgres for this repository"
# Typed ranking only; no code patch for this decision-only request.

forge run "Compare SQLite and Postgres for this application, then implement the selected option"
# Rank; ask for the user's choice if the evidence/confidence/decision indicates that choice is material.
```

## 7. Verification boundaries

Unit tests cover task triage, schema validation, deterministic score calculation, malformed output rejection, bounded interview questions, and the side-help state boundary. They do not prove model accuracy, UX clarity for all users, remote provider behavior, or that a model will always return well-formed clarifying questions. Live provider-backed interview/decision flows still require an approved integration test and benchmark.
