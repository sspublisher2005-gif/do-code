# Forge Unified Architecture (v0.3.0)

## Product contract

Forge is an approval-first coding harness that surrounds a configured model with repository context, constrained planning, patch review, checks, optional browser QA, local evidence, and bounded recovery. It is not a model, an IDE replacement, a secure sandbox, or a proven market leader.

## Architectural layers

1. **CLI and task controller** — parses user goals, validates configuration, creates a task run, applies the project freeze state, and owns the end-to-end workflow.
2. **Context and capability routing** — builds a deterministic repository index, loads project guidance and memory, selects relevant skills, and proposes a bounded set of specialist passes for complex tasks.
3. **Model adapter** — calls the user-configured supported provider after context-sharing consent. Credentials are configuration inputs and must never be committed.
4. **Read-only specialist fan-out** — optionally issues up to three concurrent, separate prompts for repository exploration, test planning, security review, browser QA planning, or architecture advice. The specialist interface itself has no tools and cannot edit files. Calls use the same configured provider/model, so this is role-based decomposition, not cross-model consensus or independent execution.
5. **Patch control and recovery** — validates proposed paths and patch structure, requires approval under applicable policy, checkpoints the workspace, and applies an accepted patch. The main controller remains the only coding writer in this flow.
6. **Verification** — invokes only permitted checks; browser QA is optional and requires Playwright plus a supported target/setup. Reports are based on observed tool outputs when those checks ran. A model saying “done” is not sufficient.
7. **Adaptive clarification and decision support** — small fixes bypass interviews by default; material ambiguity can trigger up to five blocking questions and one replan. `?` / `/explain` uses a separately consented, minimal-context help exchange without changing the answer. Explicit comparison or real material trade-offs can trigger a strict decision schema whose weighted scores are recomputed locally; uncertain or conflicting recommendations require a user choice. Scores are model assessments, not verified facts.
8. **Evidence and audit** — records task transcripts, checkpoint/audit events, decision metadata and browser evidence where applicable. Hash-chained logs help detect some tampering; they are not signed tamper-proof storage.
9. **Project-scoped portable layer** — independently authored instruction templates, 8 Claude Code agent profiles, 8 OpenCode agent profiles, 7 slash-command templates and reusable skills. Install/uninstall is limited to the target project. Existing user-owned files are preserved; force updates only files still matching a recorded Forge-managed digest.

## Representative flow

`Goal → consent/configuration → repository index → skill selection → plan → [blocking clarification if needed → one replan] → [typed comparison if requested/material → user choice if needed] → proposed patch → approval/checkpoint → apply → approved checks → optional browser QA → final evidence report`

A specialist pass can fail without blocking the main workflow; the controller marks it unavailable. Its output is an untrusted hypothesis and is secret-redacted/bounded before entering the planner context. It is not treated as proof that tests were run.

## Extension compatibility

`forge layer preview --tool both` previews project-scoped files. `forge layer install --tool both --target PATH` installs both Claude Code and OpenCode instruction/agent/command/skill trees. `forge layer uninstall --target PATH` requires the exact interactive confirmation string. The installer uses a manifest under `.forge/portable-layer-manifest.json`, preserves pre-existing or user-edited files, refuses unsafe symlink paths, and does not modify global configuration.

The layer templates are newly authored for this project and make no promise that every instruction format will remain compatible with every future upstream CLI release. Re-run the target CLI validators after installing and before relying on them.

## Browser QA boundary

The existing optional browser adapter is built around Playwright and is intended for controlled, visible QA such as a local development website or supported web game. It uses a separate context rather than the user's normal browser profile. Browser checks must not be described as performed unless Playwright actually launches and the run produces evidence. Browser automation remains process execution and is not a security sandbox; keep it isolated from production credentials and sensitive browser sessions.

## Security boundary

Forge has application-level path checks, approval gates, context consent, heuristic secret/prompt-injection checks, bounded retries, and audit records. The adaptive interview and decision matrix do not grant any tool permissions. These are defense-in-depth measures, not a substitute for an OS/container sandbox. The current build does not guarantee network-egress denial, host-secret isolation, process-tree containment, or escape prevention for malicious task code or third-party MCP servers. Until a trusted runner passes adversarial tests, use Forge only on trusted projects or inside a sandbox you control. The separate Build Validate AI product is out of scope; adaptive interaction here is for coding-task clarification and implementation decisions only.
