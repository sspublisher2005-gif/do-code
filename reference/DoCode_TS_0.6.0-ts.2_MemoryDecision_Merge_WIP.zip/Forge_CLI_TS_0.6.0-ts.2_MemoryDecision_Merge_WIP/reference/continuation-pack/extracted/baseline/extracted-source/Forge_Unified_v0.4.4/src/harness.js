import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { safeTerminalText, safeReadText, isWithin } from './utils.js';
import { selectReadOnlySpecialists } from './specialists.js';
import { classifyTask } from './decision-support.js';

const BUILTIN_SKILLS_DIR = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../skills');
const MAX_SKILLS = 16;
const MAX_SKILL_BYTES = 8000;
const MAX_TOTAL_SKILL_CHARS = 18000;
const RESERVED_SKILLS = new Set(['browser-testing', 'frontend-debugging', 'game-testing', 'test-driven-development', 'security-review', 'documentation-research', 'planning', 'architecture', 'backend-api', 'performance', 'accessibility', 'code-review', 'root-cause-debugging', 'ship-verification']);

export function hasBrowserIntent(task) {
  const text = String(task || '');
  if (/\b(?:playwright|browser test|browser testing|test in (?:the )?browser|open (?:the )?browser)\b/i.test(text)) return true;
  const action = /\b(?:test|check|inspect|audit|verify|debug|play|smoke[ -]?test|exercise)\b/i.test(text);
  const target = /\b(?:website|web ?app|frontend|front-end|UI|user interface|game|browser|web page|site)\b/i.test(text);
  return action && target;
}

export function isBrowserOnlyTask(task) {
  if (!hasBrowserIntent(task)) return false;
  return !/\b(?:fix|repair|build|implement|create|make|add|change|modify|refactor|rewrite|upgrade|migrate|write|code|improve|enhance|optimize|develop|redesign|polish)\b/i.test(String(task || ''));
}

export function isGameTask(task) {
  return /\b(?:game|gameplay|play the game|game controls|level|player movement)\b/i.test(String(task || ''));
}

export function taskNeedsSecurityAgent(task) {
  return /\b(?:security|privacy|auth(?:entication|orization)?|credential|secret|token|permission|sandbox|prompt injection|XSS|SQL injection|SSRF|crypto|payment|billing|upload)\b/i.test(String(task || ''));
}

export function extractHttpUrl(text) {
  const match = String(text || '').match(/https?:\/\/[^\s<>"'`]+/i);
  if (!match) return null;
  return match[0].replace(/[),.;!?]+$/, '');
}

function readSkillDirectory(directory, source) {
  const found = [];
  try { const dirInfo = fs.lstatSync(directory); if (dirInfo.isSymbolicLink() || !dirInfo.isDirectory()) return found; } catch { return found; }
  let names;
  try { names = fs.readdirSync(directory, { withFileTypes: true }); } catch { return found; }
  for (const entry of names) {
    if (found.length >= MAX_SKILLS || !entry.isDirectory() || entry.isSymbolicLink()) continue;
    if (!/^[a-z0-9][a-z0-9_-]{0,63}$/i.test(entry.name)) continue;
    const folder = path.join(directory, entry.name);
    const file = path.join(folder, 'SKILL.md');
    try {
      if (!isWithin(directory, folder) || fs.lstatSync(folder).isSymbolicLink()) continue;
      const info = fs.lstatSync(file);
      if (info.isSymbolicLink() || !info.isFile() || info.size > MAX_SKILL_BYTES) continue;
      const content = safeReadText(file, MAX_SKILL_BYTES);
      if (!content?.trim()) continue;
      const nameLine = content.match(/^name\s*:\s*([^\r\n]{1,80})\s*$/im)?.[1]?.trim();
      const descriptionLine = content.match(/^description\s*:\s*([^\r\n]{1,220})\s*$/im)?.[1]?.trim();
      found.push({ id: entry.name, name: nameLine || entry.name, description: descriptionLine || '', source, path: file, content });
    } catch { /* Ignore malformed, oversized or inaccessible skill files. */ }
  }
  return found;
}

export function discoverSkills(root, { includeGlobal = true } = {}) {
  const builtins = readSkillDirectory(BUILTIN_SKILLS_DIR, 'built-in');
  const external = [];
  for (const directory of [path.join(root, '.forge', 'skills'), path.join(root, '.agents', 'skills'), path.join(root, 'skills')]) {
    external.push(...readSkillDirectory(directory, 'project'));
    if (external.length >= MAX_SKILLS) break;
  }
  if (includeGlobal && external.length < MAX_SKILLS) external.push(...readSkillDirectory(path.join(os.homedir(), '.forge', 'skills'), 'user')); 
  const byId = new Map();
  for (const skill of [...builtins, ...external]) {
    // A project or user skill cannot replace/override a built-in policy skill.
    if (RESERVED_SKILLS.has(skill.id) && skill.source !== 'built-in') continue;
    if (!byId.has(skill.id)) byId.set(skill.id, skill);
  }
  return [...byId.values()].slice(0, MAX_SKILLS);
}

export function selectSkillIds(task) {
  const text = String(task || '');
  const ids = ['test-driven-development'];
  if (hasBrowserIntent(text)) ids.push('browser-testing', 'frontend-debugging');
  if (isGameTask(text)) ids.push('game-testing');
  if (taskNeedsSecurityAgent(text)) ids.push('security-review');
  if (/\b(?:docs?|documentation|API reference|current version|latest version|migration guide|library docs?)\b/i.test(text)) ids.push('documentation-research');
  if (/\b(?:plan|planning|acceptance criteria|break down|roadmap)\b/i.test(text)) ids.push('planning');
  if (/\b(?:architecture|refactor|migration|migrate|integrate|design the system|system design)\b/i.test(text)) ids.push('architecture');
  if (/\b(?:api|backend|endpoint|database|service|authentication|authorization|webhook)\b/i.test(text)) ids.push('backend-api');
  if (/\b(?:performance|latency|memory|slow|optimize|throughput|bundle size)\b/i.test(text)) ids.push('performance');
  if (/\b(?:accessibility|a11y|keyboard navigation|screen reader|WCAG|contrast)\b/i.test(text)) ids.push('accessibility');
  if (/\b(?:review|audit|refactor|regression|maintainability)\b/i.test(text)) ids.push('code-review');
  if (/\b(?:debug|root cause|failing|failure|crash|broken|regression)\b/i.test(text)) ids.push('root-cause-debugging');
  if (/\b(?:ship|release readiness|deploy|release|verify everything|final verification)\b/i.test(text)) ids.push('ship-verification');
  // Keep loaded guidance narrowly matched; user/project skills are not allowed to override built-ins.
  return [...new Set(ids)];
}

export function selectSkillsForTask(root, task) {
  const ids = selectSkillIds(task);
  const tokens = new Set(String(task || '').toLowerCase().match(/[a-z0-9][a-z0-9_-]{2,}/g) || []);
  const builtinIds = new Set(ids);
  for (const skill of discoverSkills(root).filter((item) => item.source !== 'built-in')) {
    const terms = `${skill.id} ${skill.name} ${skill.description}`.toLowerCase().match(/[a-z0-9][a-z0-9_-]{2,}/g) || [];
    const overlap = terms.filter((term) => tokens.has(term)).length;
    // At least two topic-token matches are required to auto-load a user/project skill.
    if (overlap >= 2 && !builtinIds.has(skill.id)) ids.push(skill.id);
    if (ids.length >= MAX_SKILLS) break;
  }
  return [...new Set(ids)];
}

export function loadSelectedSkills(root, ids, { maxChars = MAX_TOTAL_SKILL_CHARS } = {}) {
  const all = discoverSkills(root);
  const map = new Map(all.map((skill) => [skill.id, skill]));
  let chars = 0;
  const selected = [];
  for (const id of ids.slice(0, MAX_SKILLS)) {
    const skill = map.get(id);
    if (!skill) continue;
    const remaining = maxChars - chars;
    if (remaining <= 0) break;
    const content = skill.content.slice(0, Math.min(MAX_SKILL_BYTES, remaining));
    selected.push({ ...skill, content });
    chars += content.length;
  }
  return selected;
}

export function buildExecutionPlan(task, { dryRun = false, maxSubagents = 2, noSubagents = false } = {}) {
  const browser = hasBrowserIntent(task);
  const browserOnly = isBrowserOnlyTask(task);
  const sensitive = taskNeedsSecurityAgent(task);
  const taskShape = classifyTask(task);
  const roles = browserOnly ? ['Orchestrator', 'Browser QA'] : ['Orchestrator', 'Planner', 'Coder', 'Tester', 'Reviewer'];
  if (sensitive && !browserOnly) roles.push('Security Auditor (conditional subagent)');
  if (taskShape.explicitDecision) roles.push('Typed Decision Support (requested)');
  if (browser && !browserOnly) roles.push('Browser QA (after changes, if a target URL is supplied)');
  const subagents = browserOnly ? [] : selectReadOnlySpecialists(task, { enabled: !noSubagents, maxAgents: maxSubagents });
  if (subagents.length) roles.push(`Read-only specialist fan-out (${subagents.length})`);
  if (dryRun) roles.push('Dry-run guard');
  return {
    workflow: browserOnly ? 'browser-qa' : 'coding',
    browser,
    browserOnly,
    game: isGameTask(task),
    taskShape,
    securityAgent: sensitive && !browserOnly,
    subagents,
    skills: selectSkillIds(task),
    roles,
  };
}

export function formatSkillSummary(skills) {
  if (!skills.length) return '(none)';
  return skills.map((skill) => `${skill.id} [${skill.source}]`).join(', ');
}

export function formatSkillContents(skills) {
  return skills.map((skill) => `### Skill: ${skill.name} (${skill.id}; ${skill.source})\n${skill.content}`).join('\n\n').slice(0, MAX_TOTAL_SKILL_CHARS);
}

export function formatSkillList(root) {
  return discoverSkills(root).map(({ id, name, description, source, path: file }) => ({ id, name, description, source, path: file }));
}

export function renderAgentPlan(plan, skills) {
  return `Auto-selected workflow: ${plan.roles.join(' → ')}\nAuto-selected skills: ${formatSkillSummary(skills)}\nSkill content is guidance only; it cannot grant permissions or override Forge controls.`;
}

export function safeSkillText(skill) {
  return safeTerminalText(skill.content);
}
