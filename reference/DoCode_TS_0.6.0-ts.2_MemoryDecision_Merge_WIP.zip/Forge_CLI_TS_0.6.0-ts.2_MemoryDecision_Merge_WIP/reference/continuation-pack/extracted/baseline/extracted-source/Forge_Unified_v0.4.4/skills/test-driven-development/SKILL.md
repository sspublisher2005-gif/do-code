---
name: Test Driven Development
description: Make small, testable changes and verify behavior using focused regression tests.
---
# Test-driven development skill

Inspect existing tests and conventions first. For a bug or security boundary, add a regression test that fails before the fix where practical. Keep the patch small. Run the narrowest relevant test, then the full suite if feasible. Report exact commands, exit codes, skipped checks, and unverified behavior. Never claim a test ran based only on a model response.
