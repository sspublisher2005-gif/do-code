import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { execFileSync, spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const projectRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const cli = path.join(projectRoot, 'bin', 'forge.js');
function tempDir() { return fs.mkdtempSync(path.join(os.tmpdir(), 'forge-cli-layer-')); }

test('CLI layer install writes only the selected temporary project and is repeatable', () => {
  const target = tempDir();
  try {
    const output = execFileSync(process.execPath, [cli, 'layer', 'install', '--tool', 'claude', '--target', target], { cwd: projectRoot, encoding: 'utf8' });
    assert.match(output, /Forge layer install completed/);
    assert.ok(fs.existsSync(path.join(target, '.claude', 'agents', 'forge-explorer.md')));
    assert.ok(fs.existsSync(path.join(target, '.forge', 'portable-layer-manifest.json')));
    const second = execFileSync(process.execPath, [cli, 'layer', 'install', '--tool', 'claude', '--target', target], { cwd: projectRoot, encoding: 'utf8' });
    assert.match(second, /Created: 0/);
    assert.ok(!fs.existsSync(path.join(projectRoot, '.claude')), 'source checkout must not receive target files');
  } finally { fs.rmSync(target, { recursive: true, force: true }); }
});

test('CLI rejects a missing --target value without writing into the source tree', () => {
  const result = spawnSync(process.execPath, [cli, 'layer', 'install', '--target', '--tool', 'claude'], { cwd: projectRoot, encoding: 'utf8' });
  assert.notEqual(result.status, 0);
  assert.match(`${result.stdout}\n${result.stderr}`, /--target needs a directory path/);
  assert.ok(!fs.existsSync(path.join(projectRoot, '.forge', 'portable-layer-manifest.json')));
});
