# Source Reconciliation and Merge Boundaries

Report date: 2026-10-20. This document distinguishes code actually carried into Forge Unified from design lessons that were only described in handoff reports.

## Source A — MIT-licensed JavaScript Forge v0.1.5

**Disposition: used as the code baseline and upgraded to 0.2.0.** The `Forge_Master_Handoff_2026-10-20(1).zip` archive contains the JavaScript/Node CLI source, tests, documents and an MIT `LICENSE` identifying Forge contributors. The source test suite was rerun before the new integration work and passed 67/67 tests in this environment. The 0.2.0 changes add bounded read-only specialist passes, new task-routed skills, a fresh portable pack, a project-scoped installer/uninstaller, tests and updated documentation. Original notices are retained.

## Source B — OpenCode project-scoped AI Work Harness

**Disposition: source code was not copied.** The uploaded `handoff-2026-10-20.zip` contains a repository whose actual root `LICENSE` says “PROPRIETARY / COMMERCIAL SOFTWARE LICENSE” and restricts publication/distribution and derivative use without permission. Some accompanying handoff prose describes a portable layer as MIT, but the archive's actual license and legal policy conflict with that description. Forge Unified therefore does not copy its source, skills, agents, or exact file templates. The independently written portable layer is a new compatibility implementation guided by the user's requested behavior (project-local install, conservative permissions, specialist roles, commands and reusable workflow instructions). This is a conservative license boundary, not a legal opinion. Obtain rights-holder clarification before redistributing or incorporating any file from the proprietary archive.

## Source C — Python Forge v0.3.0 handoff

**Disposition: documented design only; implementation was not merged.** The supplied handoff files describe a Python implementation with repository mapping, bounded model/tool loops, skills, read-only subagents, MCP stdio, task contracts, event chains and candidate evaluation. However, the actual Python v0.3.0 source ZIP and wheel described in those reports were not among the accessible uploaded archives. It would be inaccurate to claim that their implementation, tests or APIs were merged into this Node project. Related goals were evaluated as architecture requirements, not as reusable source code.

## Shared ChatGPT links and transcript coverage

The external shared conversation URLs were not retrievable in the earlier inspection environment. Their contents are not claimed to have been read or merged. Attached history reports and vision documents were read as supplied, but they explicitly document gaps and discrepancies; they are not substitutes for the missing raw transcript or source package.

## Verification claims carried forward

- Legacy JavaScript source baseline: 67/67 tests passed when rerun in this environment, with syntax check passing for 21 JavaScript files.
- Unified 0.2.0 baseline test/syntax outcomes are in `../evidence/UNIFIED_VERIFICATION_2026-10-20.md` and must be regenerated for future source edits.
- No live provider-backed coding run, independent penetration test, real end-to-end browser run for this release, all-platform CI result, or fair benchmark against competitors is claimed here.

## Repository integrity and owner authority

No commit, push, publication, marketplace upload or deployment was performed as part of this consolidation. Do not change the project direction, incur material paid service costs, or distribute source from restricted archives without the founder's decision.
