# Forge Harness Research and Adoption Decisions

**Review date:** 2026-10-20  
**Scope:** public GitHub code/docs and official project documentation; not a full line-by-line source audit of every repository. Repository snapshots may change after this date.  
**Rule:** reuse ideas and interfaces, not large source trees. Forge currently has zero runtime dependencies and no third-party agent framework is embedded.

## Executive decision

Build **Forge's own thin, deterministic TypeScript/JavaScript harness** around the current Node.js CLI. Adopt selected patterns from mature projects only where they improve safety or verifiability. Do not merge several complete frameworks into one application, and do not equate a multi-agent swarm with quality.

The most durable architecture is a small privileged controller plus replaceable text-only model adapters, a deterministic workspace/patch layer, a bounded execution loop, and pluggable sandbox backends. All model/tool requests should cross explicit interfaces and capability checks.

## Repositories reviewed

| Project | Useful lesson | Forge decision | Why not directly embed it |
|---|---|---|---|
| [OpenAI Codex CLI](https://github.com/openai/codex) | Explicit permission profiles, execution/sandbox boundary, process lifecycle controls, capped output and cancellation are part of the harness rather than prompt wording alone. The repo is Rust-heavy and actively evolving. | **Adopt design principles.** Keep the model unable to use workspace tools; preserve explicit approvals and bounded output/time. Treat an OS sandbox and network policy as a required future execution backend, not a prompt promise. | Its Rust runtime is not a drop-in dependency for this zero-dependency Node MVP. A partial copy of sandbox code would be dangerous without its platform-specific tests and support code. |
| [LangChain Deep Agents](https://github.com/langchain-ai/deepagents) | A batteries-included harness separates middleware, state/checkpointing, context management, task lists, skills and subagent interfaces. The project offers JS/TS as well as Python packages. | **Adopt concepts, not framework dependency.** Define explicit turn state, task checklist, provider interface and future middleware hooks; checkpoint state at boundaries and keep role-specific context constrained. | The full stack adds framework-specific assumptions, dependencies and possibly remote tracing/deployment. Permission checks only protect operations that actually pass through the guarded tool/backend boundary. |
| [mini-SWE-agent](https://github.com/SWE-agent/mini-swe-agent) | Simple linear history and a small agent loop are easier to reproduce and debug than elaborate orchestration. The upstream SWE-agent README now directs new users toward mini-SWE-agent. | **Adopt the small-loop philosophy.** Keep planning → propose → verify → at most one corrective pass today; add measurable no-progress detection before raising the retry budget. | Its shell-first agent contract can have broader command authority than Forge's current patch-proposal workflow. Importing it would not give Forge safe execution automatically. |
| [Ponytail](https://github.com/DietrichGebert/ponytail) | Minimal-change discipline: inspect affected call sites, reuse standard-library features, avoid speculative abstractions, add tests where logic/security branches require them, and explicitly say what was not verified. Its performance claims are project-reported benchmark results, not independent proof. | **Adopt principles in Forge prompts and reviews.** The planner/coder emphasizes the smallest complete patch, call-path review, focused tests, and honest verification gaps. | No runtime dependency or third-party skill is copied wholesale; prompt rules help but do not enforce permissions. |
| [Graphify](https://github.com/Graphify-Labs/graphify) | Local source graph and connected-file/hub reporting can improve code navigation. | **Adopt graph idea, implement a tiny built-in `forge graph`.** It derives conservative import edges from Forge's existing bounded index and writes `.forge/code-graph.json` plus `CODE_GRAPH.md`, without sending source to a model. | Current Forge graph is regex-derived, not a semantic/tree-sitter graph. We deliberately do not import all of Graphify: advisory [GHSA-pcc4-rvhr-2pr8](https://github.com/Graphify-Labs/graphify/security/advisories/GHSA-pcc4-rvhr-2pr8), published 2026-09-27, describes high-severity host-file read/exfiltration risk in an affected Fortran extractor version before 0.9.70 while indexing an untrusted repository. Forge does not use that extractor. This is not a claim that all current Graphify versions are vulnerable. |
| [Context7](https://github.com/upstash/context7) | Current, version-aware library docs can reduce API guesswork; results can include code/info snippets and sources. | **Adopt a narrow `forge docs` command**, using a fixed HTTPS endpoint, bounded response, redirect rejection, visible consent, explicit query/hints only, source display when present, and untrusted-output labeling. `CONTEXT7_API_KEY` stays in the launching environment. | Not general web search; Context7 receives the explicit query. Its current API docs describe lower rate limits without a key. Returned results still need review; Forge does not attach repository files to queries. |
| [Agent-Reach](https://github.com/Panniantong/Agent-Reach) | Capability layer that checks/routes among tools for web pages, GitHub, YouTube, RSS and configurable social platforms including X, Reddit, Xiaohongshu, Facebook and Instagram. Some backends require browser sessions/cookies and separate CLI dependencies. | **Adopted a bounded read-only search bridge:** `forge reach status`, `forge reach doctor`, and `forge reach search --platform ...`. `status` only inspects `PATH` and never launches a binary. `doctor` is a separate explicit operation because upstream health probes can contact unrelated platforms; it is blocked in `privacy.mode=local-only`. Search routes are allow-listed and shell-free, require explicit external-query consent, and account/browser routes additionally require `--allow-account`. Forge never installs tools, logs into sites, exports browser cookies, or automatically sends returned results to the coding model. The local audit stores a query hash, not the raw query. | This is not the entire Agent-Reach skill/tool layer and only works when a documented backend executable is present on the local PATH. On Windows, `.cmd`/`.bat` shims are intentionally ignored because this bridge refuses to use a shell; some npm/pipx-installed tools may therefore appear unavailable on Windows. No live social searches were part of local testing. Account credentials are not imported; some backends must already be configured by the user. Instagram's search route is user/profile search, not global post-keyword search. Results remain untrusted and may contain prompt injection. |
| [REA governance layer](https://github.com/bookedsolidtech/rea) | Policy-enforced hooks/MCP, autonomy ceilings, audit records and a durable HALT kill switch; aimed primarily at Claude Code. | **Adopt the control concept, not the package.** Forge supports `forge freeze [reason]` and interactive exact-confirmation `forge unfreeze`; guarded coding, graph writes, remote docs, research bridge actions and manual commands stop while HALT is active. | REA's hooks/MCP wiring is specific to another runtime. Forge's gate only covers explicit call sites; it is not a kernel sandbox. “REA” is ambiguous: this decision means `bookedsolidtech/rea`, not reverse-engineering projects named REA. |
| [Aider repository map](https://github.com/Aider-AI/aider/blob/main/aider/website/docs/repomap.md) | A compact map of relevant files and symbols lets the model navigate a codebase without sending every file on each turn. | **Adopt progressively.** Forge already builds a bounded local file/symbol/import map. Improve symbol accuracy and retrieval quality with evals before adding embeddings or external services. | A full language-aware parser is a larger maintenance surface; model context still needs minimization and untrusted-data labeling. |
| [AgentDojo](https://github.com/ethz-spylab/agentdojo) | Purpose-built tasks can measure prompt-injection success and defense regressions instead of relying on a warning regex or manual demos. Its docs say the package API is under development. | **Adopt as an evaluation reference.** Build a small local attack/regression suite first; later run controlled AgentDojo-style cases and publish rates with the exact versions/models used. | It is a benchmark/test dependency, not production enforcement. The benchmark itself is not a defense, and adding it to runtime would be unnecessary. |
| [Invariant Labs MCP-Scan](https://github.com/invariantlabs-ai/mcp-scan) | Third-party tool descriptions and MCP metadata are trust boundaries; inspect tool names/descriptions and permissions before granting access. Its documented scanning/service modes raise data-transfer choices. | **Adopt the trust-boundary concept only for now.** No third-party MCP tools enabled by default. Future MCP support must be opt-in, per-tool, permissioned, with metadata inspection and a local-only mode. | MCP tool descriptions can be hostile, and a scanner that uploads metadata would violate Forge's local-first expectations unless separately consented to. |
| [Continue](https://github.com/continuedev/continue) | Per-project rules and user-selectable context help shape coding behavior. | **Keep the project-memory concept** via `FORGE.md`, but mark it as untrusted data and never as security policy. | The current repository README says the repo is read-only/final-release; it is not a suitable foundation for a new harness. |
| [Daytona](https://github.com/daytonaio/daytona) | A sandbox boundary needs filesystem, process, network and resource controls—not merely a temp folder. | **Use as a case study for sandbox design, not a dependency.** Provide a backend interface and keep cloud sandboxes opt-in only. | The repository README states core development moved to a private codebase in June 2026. Hosted execution would also send code outside the device. |
| [Microsoft Agent Framework](https://github.com/microsoft/agent-framework) | Middleware/harness factories can compose tool calling, state, context compaction, task tracking, approval hooks and observability. | **Adopt composability principles only.** Each future subsystem should be individually testable and replaceable. | The general-purpose framework is broader than the current CLI and does not make application-specific permission/data-flow boundaries automatic. |

| [OpenCode](https://github.com/anomalyco/opencode) | Model/provider flexibility and read-only planning alongside a higher-permission build mode. | **Keep as Forge's existing optional model CLI transport** and retain a separate plan/propose/approve loop. | OpenCode tool permissions are not Forge policy; Forge keeps patch application outside the model. |
| [Karpathy autoresearch](https://github.com/karpathy/autoresearch) | A narrow editable surface, fixed time budget, one measurable objective and experiment logs make iterations comparable. | **Adopt bounded experiment discipline:** record baseline, make one controlled repair pass, check actual exit codes/results, stop on repeated failure or exhausted budget. | Autoresearch is a specific ML training experiment with a fixed 5-minute run and one validation metric—not a generic coding-agent loop. Forge will not emulate unattended infinite iterations. |

We did not copy source code from these repositories into Forge. This is a design comparison, not a legal review of every license or dependency in each upstream project.

## Implemented integration boundary (2026-10-20)

`forge reach search --platform PLATFORM [--allow-account] [--yes] QUERY` now provides a narrow, read-only invocation route for supported Agent-Reach backends:

- **Public/research-oriented routes:** `web` (Exa through `mcporter`), `youtube` (`yt-dlp` with user config ignored and downloads disabled), and `bilibili` (`bili-cli` where it is the selected backend).
- **GitHub:** `gh search repos`; it requires `--allow-account` because `gh` may use the user's existing CLI authorization.
- **Account/session-aware routes:** `twitter`, `reddit`, `xiaohongshu`, `facebook`, and `instagram`, plus any alternate backend that uses OpenCLI/browser session state. These require `--allow-account`, and interactive consent is still required unless `--yes` is explicitly provided.

The bridge checks PATH locally and invokes only fixed executable/argument combinations with `shell: false`; it does not trust remote metadata or execute arbitrary doctor-supplied commands. It applies time/output bounds, redacts likely secrets, sanitizes terminal control sequences, marks results as untrusted, and records only a query hash/length and outcome metadata. It does not read repository context or project memory to create the query. Research output is shown to the human, **not silently inserted into a model prompt**. This prevents a search result from immediately becoming an instruction to an autonomous coding loop, but it does not remove malicious text from returned results or prove source truthfulness.

Examples:

```sh
forge reach search --platform web "official documentation Node.js test runner"
forge reach search --platform youtube --yes "coding agent evaluation"
forge reach search --platform github --allow-account "prompt injection coding agent"
forge reach search --platform reddit --allow-account "coding CLI agent experience"
```

`--yes` bypasses the per-query confirmation only; it does not bypass `privacy.mode=local-only`, the HALT marker, platform allowlists, local executable discovery, or the separate `--allow-account` flag. For the Twitter CLI route, users must explicitly provide `TWITTER_AUTH_TOKEN` and `TWITTER_CT0` to Forge's launching shell; Forge does not extract tokens from Agent-Reach files or browser storage. No social platform query has been live-verified in this local test run.

## Practitioner-inspired design lenses (not impersonation or endorsement)

These are interpretations of public artifacts and statements, not a claim that the named people reviewed or approved Forge.

- **Boris Cherny / Claude Code:** public workflow advice emphasizes verification as the most impactful practice, and also describes multiple sessions, persistent project instructions, and different verification methods by task. Forge adopts durable `FORGE.md` context (still untrusted), a bounded workflow, reviewable patches, and checks based on actual command outcomes. It does **not** copy the “five parallel sessions” habit as a default; Forge lacks isolated parallel worktrees and budget accounting to make that safe/useful yet. Source: [Claude Code power-user tips](https://support.claude.com/en/articles/14554000-claude-code-power-user-tips) and [Boris Cherny's public workflow thread](https://twitter-thread.com/t/2007179832300581177).
- **Dax Raad / OpenCode:** the useful product lesson is model/provider choice with a direct terminal workflow. Forge keeps its own approval and patch system around OpenCode instead of equating OpenCode's own permissions with Forge's policy. Source: [OpenCode](https://github.com/anomalyco/opencode) and [provider documentation](https://github.com/anomalyco/opencode/blob/dev/packages/web/src/content/docs/providers.mdx).
- **Andrej Karpathy / autoresearch:** keep the editable surface narrow, establish a baseline, define a real metric, bound each experiment, and preserve logs that let a human compare outcomes. Forge takes the bounded experiment/measurement idea. It intentionally does not copy autoresearch's task-specific 5-minute GPU loop or any “repeat forever” interpretation into repository editing. Source: [autoresearch README](https://github.com/karpathy/autoresearch) and [program.md](https://github.com/karpathy/autoresearch/blob/master/program.md).

## Implementation status in this build

Implemented and locally tested in this source snapshot:

- `forge graph`: local approximate import graph and Markdown report. No graph source text is sent to a provider. Graph data still includes paths and symbols; treat `.forge/` as private.
- `forge docs`: explicit Context7 docs query using a fixed HTTPS endpoint, bounded responses, redirect rejection, consent, optional `CONTEXT7_API_KEY`, source snippets when returned, terminal-safe output, and audit metadata. No repository text is included in the query. Official docs currently state unauthenticated access has lower rate limits ([Context7 API guide](https://github.com/upstash/context7/blob/master/docs/api-guide.mdx)).
- `forge reach status`: passive `PATH` inspection only. It never executes an arbitrary `agent-reach` binary just to print status. `forge reach doctor` is a separate explicit launch that may make generic remote health probes, does not install tools or import cookies, and is blocked under `privacy.mode=local-only`. Search never invokes it automatically.
- `forge reach search`: explicit, allow-listed read-only search for supported Agent-Reach web, GitHub, YouTube, Bilibili, X, Reddit, Xiaohongshu, Facebook and Instagram backends. A fixed backend is selected from locally available executables without invoking Agent-Reach health probes; account/browser routes require `--allow-account`, external queries are consent-gated, and results remain user-facing untrusted text rather than automatic model context.
- `forge freeze` and `forge unfreeze`: fail-closed emergency stop, with exact interactive confirmation for unfreezing. Guarded coding and selected write/network/command actions stop while HALT is active. The gate needs ongoing call-site tests as new commands are added.
- Prompt patterns influenced by Ponytail's small-change/test discipline are in the actual prompts, with regression tests; they are not an imported skill or enforcement boundary.

Local check at report update: `npm test` **53/53 passed**; `npm run check` **18 JavaScript files syntax-checked**. Mocked Context7 and Agent-Reach bridge tests do not prove live service/backend compatibility. Hosted CI, live OpenRouter/OpenCode calls, live social/web queries, an OS sandbox, and an independent penetration test remain unverified/not available in this build.

## Architecture to build

### Keep trusted authority small

1. **Policy/controller layer (trusted code):** owns workspace root, user approvals, path validation, command policy, budgets, provider selection and audit events.
2. **Model adapter layer (untrusted response):** accepts a prompt and returns bounded text + reported usage. It never receives host tools directly in the default configuration.
3. **Context layer:** produces a capped file/symbol map, selected excerpts and exact source references; redacts common secret formats and skips known credential paths.
4. **Patch layer:** parses a unified diff, validates every target/path/context, checks for changes made while awaiting approval, and writes only after approval/checkpoint.
5. **Execution layer:** runs only whitelisted verification commands after a second approval, with restricted environment, timeout and output limits. This remains unsandboxed in the current version.
6. **Evidence/review layer:** records exit codes and concrete diagnostics; the model reviewer can flag gaps but cannot certify tests or override deterministic results.
7. **Future source connector layer:** returns external material as untrusted, attributed evidence (`URL`, retrieval time, short relevant excerpt, claim type). It must not receive private project source by default.

### Loop engineering contract

Current cap: planner + coder + reviewer, with one optional corrective patch. Next version should add explicit state transitions and stop reasons:

`DISCOVER → PLAN → PROPOSE → STATIC CHECKS → USER APPROVAL → APPLY → VERIFY → (ONE REPAIR) → REVIEW → REPORT`

Every transition should have a stable run/task ID, input/output limits, timeout/budget accounting and an event that contains no raw secrets by design. Terminate when the task is complete, the retry limit is reached, the same patch/failure repeats, required approval is declined, an external call fails, or the budget expires. No infinite “continue” loop; never hide an exhausted budget behind a success message.

### Multi-agent strategy

Do not start with eight agents acting in parallel. First make one controller reliable. Then introduce optional specialist roles with **read-only scoped context** (planner, implementer, test analyst, security reviewer), each with distinct output schema and bounded token/turn budget. Agent disagreement is a review signal—not a security control. Only the controller can ask the user for authorization or apply a patch. Subagents must not inherit unrestricted tools or credentials.

## Prompt-injection and untrusted input

Prompt text is helpful but not enforcement. Attacks can be indirect, encoded, multilingual, split across files, hidden in comments or output by tests. Forge therefore needs:

- no model-owned filesystem/network/shell tools by default;
- path, command, endpoint and permission checks in ordinary code;
- clear labels for untrusted repo/project memory/model/test/Internet data;
- user consent before remote prompt/context sharing;
- independent review gates on high-risk patches;
- a sandbox for execution and policy-controlled network access;
- adversarial regression/evaluation suites, including false-positive tracking.

The current `scanPromptInjection()` is a heuristic warning gate. It intentionally does **not** claim that an unflagged repository is safe. Real containment comes from restricting capabilities and isolating execution.

## Privacy contract

- No Forge-owned analytics/telemetry is sent by the CLI. `forge graph` writes local metadata; paths/symbol names can still reveal project structure, so `.forge/` must remain private and ignored by Git.
- Local indexing excludes common secret files and redacts several common credential formats, but cannot guarantee complete secret removal.
- In `privacy.mode=ask`, the user sees a per-run disclosure before task, repo map, excerpts, diffs and possible test output can be sent to the selected provider.
- `privacy.mode=local-only` only checks known model ID prefixes and rejects OpenRouter; it is **not** a network firewall and cannot prove an OpenCode custom provider is local.
- Local `.forge/` checkpoints contain pre-change file content; audit files may contain bounded event diagnostics. Do not upload them without review.
- `forge docs` sends an explicit question and optional library/version/language hints to Context7 after consent; it never automatically attaches project files. Context7 documents lower unauthenticated rate limits, while `CONTEXT7_API_KEY` is optionally read from the launching shell. Returned content is untrusted; source links are shown when present. Context7 is a docs-specific route; general web and selected social-source querying use the separate Agent-Reach bridge described above.

## Evidence and verification status

Verified locally for this snapshot:

- `npm test`: 53 tests passed after local graph, Context7, emergency HALT, subprocess-boundary and Agent-Reach routing additions.
- `npm run check`: syntax checker passes for all 18 JavaScript files.
- `forge graph`: integration test checks local-only graph metadata is written and source content is not copied into graph nodes.
- `forge docs`: integration test confirms a non-interactive call without explicit consent makes no network request. Context7 behavior is mocked; no live request was made.
- `forge freeze`: integration test confirms guarded coding tasks stop before provider startup and non-interactive unfreeze fails closed.
- CI definition exists for Ubuntu, Windows and macOS, uses a read-only GitHub token permission, disables checkout credential persistence, disables setup-node package-manager caching, pins both actions to full commit SHAs, and has a job timeout.

Not verified in this local container:

- Hosted GitHub Actions execution, including Windows and macOS.
- A live OpenRouter HTTP call or real OpenCode model run.
- Actual sandboxed execution: Forge has no OS/container sandbox implementation yet.
- Prompt-injection detection rates on AgentDojo or a representative adversarial corpus.
- Agent-Reach search/read tools exposed directly to the coding-model tool loop: not implemented. The user-facing `forge reach search` command is implemented for a bounded allowlist; retrieved results are not automatically passed to the model.
- Live Context7 API connectivity and returned-snippet schema compatibility: not tested against the real service in this environment.
- Full browser navigation, automatic source-citation synthesis from multi-platform searches, and live cross-platform search were not verified. The current bridge only runs one explicit query against one selected platform/backend per invocation.
- Formal security audit, fuzzing at scale, dependency/publish supply-chain attestation, or production readiness.

## Sources consulted (primary/project sources)

- OpenAI Codex CLI: https://github.com/openai/codex
- Deep Agents: https://github.com/langchain-ai/deepagents
- mini-SWE-agent: https://github.com/SWE-agent/mini-swe-agent
- SWE-agent README (now recommends mini-SWE-agent): https://github.com/SWE-agent/SWE-agent
- Aider repo map documentation: https://github.com/Aider-AI/aider/blob/main/aider/website/docs/repomap.md
- AgentDojo: https://github.com/ethz-spylab/agentdojo
- MCP-Scan: https://github.com/invariantlabs-ai/mcp-scan
- Continue: https://github.com/continuedev/continue
- Daytona: https://github.com/daytonaio/daytona
- Microsoft Agent Framework: https://github.com/microsoft/agent-framework
- Ponytail: https://github.com/DietrichGebert/ponytail
- Graphify and advisory: https://github.com/Graphify-Labs/graphify and https://github.com/Graphify-Labs/graphify/security/advisories/GHSA-pcc4-rvhr-2pr8
- Context7 API guide: https://github.com/upstash/context7/blob/master/docs/api-guide.mdx
- Agent-Reach: https://github.com/Panniantong/Agent-Reach (English docs: https://github.com/Panniantong/Agent-Reach/blob/main/docs/README_en.md)
- REA governance layer: https://github.com/bookedsolidtech/rea
- OpenCode: https://github.com/anomalyco/opencode
- Karpathy autoresearch: https://github.com/karpathy/autoresearch
- Node child process docs: https://nodejs.org/api/child_process.html (child process `env` defaults to `process.env` if omitted)
- GitHub Actions secure use: https://docs.github.com/en/actions/reference/security/secure-use (pin actions to a full-length commit SHA)

Review these primary sources again before making implementation/licensing decisions; their code, status and releases can change.
