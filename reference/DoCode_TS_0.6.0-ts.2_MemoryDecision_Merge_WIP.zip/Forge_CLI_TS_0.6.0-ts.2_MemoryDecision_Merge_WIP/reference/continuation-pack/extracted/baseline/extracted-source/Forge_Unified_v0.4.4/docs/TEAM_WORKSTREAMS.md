# Forge Team Workstreams

These are internal role assignments used to coordinate work. They are not claims that named external people or actual employees performed this work. The founder is the final decision-maker.

## 1. Product lead / CEO lens

**Mission:** protect Forge's original vision; keep it useful to developers, vibe coders, engineers and solo founders without turning it into a feature pile.

**Responsibilities:** prioritize workflows by user evidence, define acceptance criteria, protect free-first/local-first constraints, approve any material pivot or cost, and reject unsupported superiority claims.

**Deliverables:** prioritized roadmap, user-task definition, decision log and release readiness decision.

## 2. Principal architect

**Mission:** maintain a coherent, provider-agnostic engineering loop with one accountable controller.

**Responsibilities:** integration seams, API contracts, bounded planner/coder/reviewer flow, task persistence, provider interoperability, skill routing, and compatibility across CLI environments.

**Acceptance:** narrow diffs, stable interfaces, predictable failure states, clear migration path, and runnable tests.

## 3. Security and privacy engineer

**Mission:** ensure the agent's authority is enforced by code and operating-system boundaries—not merely described in prompts.

**Responsibilities:** sandbox design, secrets and network isolation, approvals, tool allowlists, untrusted content handling, cancellation, redaction, MCP/browser threat models and independent review.

**Acceptance:** attack-oriented regression tests and explicit residual risks; never mark a prompt-only guard as an OS sandbox.

## 4. QA and benchmark engineer

**Mission:** independently establish whether the requested workflow actually works.

**Responsibilities:** unit/integration/e2e tests, browser traces, cross-platform CI, seeded-failure recovery, repeatable benchmark tasks and raw result capture.

**Acceptance:** all reports identify command, exit code, runtime/environment, expected versus observed outcome, and what's still unverified.

## 5. Integration and skills maintainer

**Mission:** make Forge useful inside the tools developers already use without damaging user configuration.

**Responsibilities:** compatible project-scoped installs, skill/agent/command schemas, safe upgrade/uninstall, version checks, docs examples and extension template tests.

**Acceptance:** installation is opt-in, previewable, idempotent, symlink-safe, preserves user edits, and never writes global config.

## Work order

Security and QA block high-risk autonomy increases. Architecture supplies the minimal design; integration creates safe workflows; QA reproduces results; product lead prioritizes and approves trade-offs. Nothing is called release-ready until the gates in `SECURITY_GATE.md` and `ROADMAP_UNIFIED.md` are met.
