---
name: Ship Verification
description: Prepare an evidence-backed readiness report from actual checks, diffs, risk review, and unresolved work.
---

## Required gates
- Acceptance criteria are explicit and mapped to evidence.
- Final diff is reviewed for scope, accidental edits, secrets, and security-sensitive paths.
- Run the narrowest relevant tests, then applicable typecheck/lint/build/integration checks that the user authorized.
- For web apps, run the user journey in a real browser if available and capture reports/screenshots; test responsive behavior when relevant.
- Confirm all required commands and statuses from their real exit codes. A skipped/blocked/unavailable check is not a pass.
- Check Git status and ensure generated evidence contains no secrets or sensitive page data.
- Do not commit, push, release, publish, deploy, migrate production, or incur costs without explicit authorization.

Use statuses: PASS, FAIL, BLOCKED, NOT RUN, NOT APPLICABLE. Do not claim production readiness merely because local tests pass.
