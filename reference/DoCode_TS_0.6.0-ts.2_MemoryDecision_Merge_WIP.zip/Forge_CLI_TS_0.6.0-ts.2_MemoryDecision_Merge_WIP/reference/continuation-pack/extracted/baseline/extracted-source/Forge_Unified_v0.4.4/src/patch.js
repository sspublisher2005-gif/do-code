import fs from 'node:fs';
import path from 'node:path';
import { randomUUID } from 'node:crypto';
import { resolveSafePath, sha256 } from './utils.js';

function parseDiffPath(line, prefix) {
  let value = line.slice(prefix.length).split('\t')[0].trim();
  if (value === '/dev/null') return value;
  if (value.startsWith('a/') || value.startsWith('b/')) value = value.slice(2);
  return value;
}

function splitContent(content) {
  const hasFinalNewline = content.endsWith('\n') || content.endsWith('\r');
  const lines = content.replace(/\r\n/g, '\n').split('\n');
  if (hasFinalNewline) lines.pop();
  return { lines, hasFinalNewline };
}

export function parseUnifiedDiff(patch) {
  if (typeof patch !== 'string' || !patch.trim()) throw new Error('The model returned an empty patch.');
  const lines = patch.replace(/\r\n/g, '\n').split('\n');
  const files = [];
  let i = 0;
  while (i < lines.length) {
    if (!lines[i].startsWith('--- ')) { i += 1; continue; }
    const oldPath = parseDiffPath(lines[i], '--- ');
    i += 1;
    if (i >= lines.length || !lines[i].startsWith('+++ ')) throw new Error('Malformed unified diff: expected +++ header.');
    const newPath = parseDiffPath(lines[i], '+++ ');
    i += 1;
    if (newPath === '/dev/null') throw new Error('File deletion patches are not supported in the MVP.');
    if (oldPath !== '/dev/null' && oldPath !== newPath) throw new Error('File renames are not supported in the MVP.');
    const relative = newPath;
    const hunks = [];
    while (i < lines.length && !lines[i].startsWith('--- ')) {
      const header = lines[i].match(/^@@\s+-(\d+)(?:,(\d+))?\s+\+(\d+)(?:,(\d+))?\s+@@/);
      if (!header) { i += 1; continue; }
      const oldStart = Number(header[1]);
      const newStart = Number(header[3]);
      i += 1;
      const hunkLines = [];
      while (i < lines.length && !lines[i].startsWith('@@ ') && !lines[i].startsWith('--- ')) {
        const line = lines[i];
        if (line.startsWith('diff --git ')) break;
        if (line.startsWith('\\ No newline at end of file')) { i += 1; continue; }
        if (line.startsWith(' ') || line.startsWith('+') || line.startsWith('-')) hunkLines.push(line);
        else if (line === '' && i === lines.length - 1) { i += 1; break; }
        else throw new Error(`Malformed patch line near: ${line.slice(0, 120)}`);
        i += 1;
      }
      if (!hunkLines.length) throw new Error('Empty patch hunk.');
      hunks.push({ oldStart, newStart, lines: hunkLines });
    }
    if (!hunks.length) throw new Error(`No hunks found for ${relative}.`);
    files.push({ oldPath, newPath, path: relative, isNew: oldPath === '/dev/null', hunks });
  }
  if (!files.length) throw new Error('No unified diff file headers were found.');
  const unique = new Set();
  for (const file of files) {
    if (unique.has(file.path)) throw new Error(`Duplicate patch section for ${file.path}.`);
    unique.add(file.path);
  }
  return files;
}

export function preparePatch(root, patch) {
  const parsed = parseUnifiedDiff(patch);
  const changes = [];
  for (const file of parsed) {
    const absolute = resolveSafePath(root, file.path, { allowMissing: true });
    let original = '';
    let existed = false;
    let mode = 0o600;
    try {
      const stats = fs.lstatSync(absolute);
      if (!stats.isFile()) throw new Error(`Patch target is not a regular file: ${file.path}`);
      original = fs.readFileSync(absolute, 'utf8');
      mode = stats.mode & 0o777;
      existed = true;
    } catch (error) {
      if (error?.code !== 'ENOENT') throw error;
    }
    if (file.isNew && existed) throw new Error(`Patch tries to create an existing file: ${file.path}`);
    if (!file.isNew && !existed) throw new Error(`Patch target does not exist: ${file.path}`);
    const source = file.isNew ? { lines: [], hasFinalNewline: true } : splitContent(original);
    const output = [];
    let cursor = 0;
    for (const hunk of file.hunks) {
      const targetIndex = file.isNew ? 0 : Math.max(0, hunk.oldStart - 1);
      if (targetIndex < cursor) throw new Error(`Out-of-order hunk in ${file.path}.`);
      output.push(...source.lines.slice(cursor, targetIndex));
      cursor = targetIndex;
      for (const line of hunk.lines) {
        const marker = line[0];
        const value = line.slice(1);
        if (marker === ' ') {
          if (source.lines[cursor] !== value) throw new Error(`Patch context mismatch in ${file.path} at original line ${cursor + 1}.`);
          output.push(value);
          cursor += 1;
        } else if (marker === '-') {
          if (source.lines[cursor] !== value) throw new Error(`Patch removal mismatch in ${file.path} at original line ${cursor + 1}.`);
          cursor += 1;
        } else if (marker === '+') {
          output.push(value);
        }
      }
    }
    output.push(...source.lines.slice(cursor));
    const next = output.join('\n') + (source.hasFinalNewline || file.isNew ? '\n' : '');
    changes.push({ path: file.path, absolute, existed, original, next, mode, beforeHash: existed ? sha256(original) : null, afterHash: sha256(next) });
  }
  return changes;
}

export function applyPreparedPatch(root, changes) {
  for (const change of changes) {
    const absolute = resolveSafePath(root, change.path, { allowMissing: true });
    if (absolute !== change.absolute) throw new Error(`Target path changed while patch was being prepared: ${change.path}`);
    const existsNow = fs.existsSync(absolute);
    if (existsNow !== change.existed) throw new Error(`Target changed while waiting for approval: ${change.path}`);
    if (existsNow) {
      const now = fs.readFileSync(absolute, 'utf8');
      if (sha256(now) !== change.beforeHash) throw new Error(`Target changed while waiting for approval: ${change.path}`);
    }
  }
  const written = [];
  const temporaryFiles = [];
  try {
    for (const change of changes) {
      const parent = path.dirname(change.absolute);
      fs.mkdirSync(parent, { recursive: true });
      const temp = `${change.absolute}.forge-tmp-${randomUUID()}`;
      temporaryFiles.push(temp);
      fs.writeFileSync(temp, change.next, { mode: change.mode ?? 0o600, flag: 'wx' });
      fs.renameSync(temp, change.absolute);
      written.push(change);
    }
  } catch (error) {
    for (const temp of temporaryFiles) {
      try { fs.rmSync(temp, { force: true }); } catch { /* Best-effort cleanup. */ }
    }
    for (const change of written.reverse()) {
      try {
        if (change.existed) fs.writeFileSync(change.absolute, change.original, { mode: change.mode ?? 0o600 });
        else fs.rmSync(change.absolute, { force: true });
      } catch { /* Report the original failure; undo/checkpoint remains available. */ }
    }
    throw error;
  }
  return changes.map(({ path: relative, beforeHash, afterHash, existed }) => ({ path: relative, beforeHash, afterHash, existed }));
}

export function formatPatchSummary(changes) {
  return changes.map((item) => `${item.existed ? 'M' : 'A'} ${item.path} (${item.beforeHash ? item.beforeHash.slice(0, 8) : 'new'} → ${item.afterHash.slice(0, 8)})`).join('\n');
}
