import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { validateConfig } from './config.js';
import { terminateProcessTree } from './runner.js';
import { redactSecrets } from './utils.js';

const LOCAL_MODEL_PREFIXES = ['ollama/', 'lmstudio/', 'llama.cpp/', 'local/'];

export function isLocalModel(model) {
  return LOCAL_MODEL_PREFIXES.some((prefix) => model.startsWith(prefix));
}

export function validatePrivacyMode(config) {
  if (config.privacy.mode === 'local-only' && !isLocalModel(config.model)) {
    throw new Error(`privacy.mode is local-only, but model "${config.model}" is not a recognized local-provider id. Configure an OpenCode local provider model first.`);
  }
}

export function makeIsolatedOpenCodeConfig(agentName = 'forge-model') {
  return {
    '$schema': 'https://opencode.ai/config.json',
    permission: {
      '*': 'deny', read: 'deny', edit: 'deny', bash: 'deny', task: 'deny', external_directory: 'deny',
      glob: 'deny', grep: 'deny', list: 'deny', webfetch: 'deny', websearch: 'deny', todowrite: 'deny', todoread: 'deny',
      question: 'deny', lsp: 'deny', skill: 'deny', doom_loop: 'deny',
    },
    agent: {
      [agentName]: {
        mode: 'primary',
        description: 'Text-only model adapter for Forge; workspace tools are disabled.',
        permission: { '*': 'deny' },
        tools: { '*': false },
      },
    },
    share: 'disabled',
  };
}

export function buildOpenCodeArgs({ model, tempDir, prompt, agent = 'forge-model' }) {
  // --pure turns off user/project plugins; --dir places OpenCode in an empty temp project.
  return ['--pure', 'run', '--format', 'json', '--agent', agent, '--model', model, '--dir', tempDir, prompt];
}

function parseEventLine(line, state) {
  let event;
  try { event = JSON.parse(line); } catch { return false; }
  state.sawJson = true;
  const type = event.type ?? event.part?.type;
  if (type === 'text' || event.part?.type === 'text') {
    const text = event.part?.text ?? event.text;
    if (typeof text === 'string') state.textParts.push(text);
  }
  const tokenInfo = event.part?.tokens ?? event.tokens;
  if (tokenInfo && typeof tokenInfo === 'object') {
    if (Number.isFinite(tokenInfo.input)) state.tokensIn += tokenInfo.input;
    if (Number.isFinite(tokenInfo.output)) state.tokensOut += tokenInfo.output;
  }
  const cost = event.cost ?? event.part?.cost;
  if (Number.isFinite(cost)) state.costUsd += cost;
  if (event.type === 'step_finish' || event.type === 'step-finish' || event.part?.type === 'step-finish') state.sawStepFinish = true;
  return true;
}

function parseOutput(stdout) {
  const state = { sawJson: false, textParts: [], tokensIn: 0, tokensOut: 0, costUsd: 0, sawStepFinish: false };
  for (const line of stdout.split(/\r?\n/)) parseEventLine(line.trim(), state);
  let text = state.textParts.join('\n').trim();
  if (!text && !state.sawJson) text = stdout.trim();
  return {
    text,
    tokensIn: state.tokensIn,
    tokensOut: state.tokensOut,
    costUsd: state.costUsd,
    hasCost: state.costUsd > 0 || /"cost"\s*:\s*0(?:\.0+)?/.test(stdout),
    sawStepFinish: state.sawStepFinish,
    rawBytes: Buffer.byteLength(stdout),
  };
}

export function extractJsonObject(text) {
  const raw = String(text ?? '').trim().replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '');
  try {
    const direct = JSON.parse(raw);
    if (direct && typeof direct === 'object' && !Array.isArray(direct)) return direct;
  } catch { /* Try a balanced-object scan below. */ }
  let start = -1;
  let depth = 0;
  let inString = false;
  let escape = false;
  for (let i = 0; i < raw.length; i += 1) {
    const char = raw[i];
    if (start === -1) {
      if (char === '{') { start = i; depth = 1; }
      continue;
    }
    if (inString) {
      if (escape) escape = false;
      else if (char === '\\') escape = true;
      else if (char === '"') inString = false;
      continue;
    }
    if (char === '"') inString = true;
    else if (char === '{') depth += 1;
    else if (char === '}') {
      depth -= 1;
      if (depth === 0) {
        try {
          const parsed = JSON.parse(raw.slice(start, i + 1));
          if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) return parsed;
        } catch { /* Continue looking for a valid object. */ }
        start = -1;
      }
    }
  }
  throw new Error(`Model did not return a valid JSON object. Output begins: ${raw.slice(0, 240).replace(/\s+/g, ' ')}`);
}

export function getOpenCodeCommand(config) {
  // Project-local config is untrusted; custom executable selection must come from the operator's process environment.
  const command = process.env.FORGE_OPENCODE_COMMAND?.trim() || config.opencodeCommand || 'opencode';
  if (!command || command.includes('\0') || command.length > 1000) throw new Error('FORGE_OPENCODE_COMMAND is invalid.');
  return command;
}

const SAFE_OPENCODE_ENV_KEYS = new Set([
  'PATH', 'HOME', 'USERPROFILE', 'APPDATA', 'LOCALAPPDATA',
  'XDG_CONFIG_HOME', 'XDG_DATA_HOME', 'XDG_STATE_HOME', 'XDG_CACHE_HOME',
  'TMP', 'TEMP', 'TMPDIR', 'SYSTEMROOT', 'WINDIR', 'COMSPEC', 'PATHEXT',
  'LANG', 'LC_ALL', 'LC_CTYPE', 'TERM', 'COLORTERM', 'NO_COLOR', 'FORCE_COLOR',
  'HTTP_PROXY', 'HTTPS_PROXY', 'ALL_PROXY', 'NO_PROXY',
  'SSL_CERT_FILE', 'SSL_CERT_DIR', 'NODE_EXTRA_CA_CERTS',
]);
const NEVER_ALLOW_OPENCODE_ENV = /^(?:FORGE_.*|OPENCODE_.*|OPENROUTER_API_KEY|NODE_OPTIONS|NODE_PATH|LD_PRELOAD|LD_LIBRARY_PATH|DYLD_INSERT_LIBRARIES|DYLD_LIBRARY_PATH|PYTHONPATH|PYTHONHOME|BASH_ENV|ENV)$/i;

/**
 * Builds a small OpenCode subprocess environment. API credentials are not inherited by default.
 * An operator can explicitly pass provider-specific environment variables by setting
 * FORGE_OPENCODE_ENV_ALLOWLIST=OPENAI_API_KEY,ANTHROPIC_API_KEY in the parent shell.
 */
export function buildOpenCodeEnv({ configPath, serializedConfig, sourceEnv = process.env }) {
  const env = {};
  const findName = (wanted) => Object.keys(sourceEnv).find((actual) => actual.toLowerCase() === wanted.toLowerCase());
  for (const wanted of SAFE_OPENCODE_ENV_KEYS) {
    const actual = findName(wanted);
    if (actual && sourceEnv[actual] !== undefined) env[actual] = sourceEnv[actual];
  }
  const allowlistName = findName('FORGE_OPENCODE_ENV_ALLOWLIST');
  const requestedNames = typeof sourceEnv[allowlistName] === 'string'
    ? sourceEnv[allowlistName].split(',').map((name) => name.trim()).filter(Boolean)
    : [];
  for (const name of requestedNames) {
    if (!/^[A-Za-z_][A-Za-z0-9_]*$/.test(name) || NEVER_ALLOW_OPENCODE_ENV.test(name)) continue;
    const actual = findName(name);
    if (actual && sourceEnv[actual] !== undefined) env[actual] = sourceEnv[actual];
  }
  env.OPENCODE_CONFIG = configPath;
  env.OPENCODE_CONFIG_CONTENT = serializedConfig;
  return env;
}

export function invokeOpenCode({ config, prompt, role = 'general' }) {
  validatePrivacyMode(config);
  const opencodeCommand = getOpenCodeCommand(config);
  return new Promise((resolve, reject) => {
    const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'forge-model-'));
    const configPath = path.join(tempDir, 'forge-opencode.json');
    const agentName = config.agent || 'forge-model';
    const isolatedConfig = makeIsolatedOpenCodeConfig(agentName);
    const serializedConfig = JSON.stringify(isolatedConfig);
    fs.writeFileSync(configPath, `${JSON.stringify(isolatedConfig, null, 2)}\n`, { mode: 0o600 });

    const args = buildOpenCodeArgs({ model: config.model, tempDir, prompt, agent: agentName });
    // OPENCODE_CONFIG_CONTENT is loaded after project configs, so the deny policy is explicit.
    // --pure also prevents normal user/project plugins from extending the agent. The child receives
    // a minimal environment; arbitrary cloud credentials and app tokens are not inherited by default.
    const env = buildOpenCodeEnv({ configPath, serializedConfig });

    let child;
    let killEscalationTimer;
    const stopTree = () => {
      terminateProcessTree(child, { env });
      if (!killEscalationTimer) {
        killEscalationTimer = setTimeout(() => terminateProcessTree(child, { force: true, env }), 1200);
        killEscalationTimer.unref?.();
      }
    };
    let stdout = '';
    let stderr = '';
    let settled = false;
    let timedOut = false;
    const deadline = setTimeout(() => {
      timedOut = true;
      stopTree();
    }, config.limits.modelTimeoutMs);
    deadline.unref?.();

    const cleanUp = () => {
      clearTimeout(deadline);
      try { fs.rmSync(tempDir, { recursive: true, force: true }); } catch { /* Temporary cleanup is best effort. */ }
    };
    const finish = (error, value) => {
      if (settled) return;
      settled = true;
      cleanUp();
      if (error) reject(error); else resolve(value);
    };

    try {
      child = spawn(opencodeCommand, args, { cwd: tempDir, env, shell: false, detached: process.platform !== 'win32', windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] });
    } catch (error) {
      finish(error);
      return;
    }
    let stdoutBytes = 0;
    let stdoutOverflow = false;
    child.stdout.on('data', (chunk) => {
      stdoutBytes += chunk.length;
      if (stdoutBytes > config.limits.maxOutputBytes) {
        // Stop retaining output as soon as the cap is exceeded; a noisy child must not grow memory unboundedly.
        stdoutOverflow = true;
        stopTree();
        return;
      }
      stdout += chunk.toString('utf8');
    });
    child.stderr.on('data', (chunk) => {
      stderr += chunk.toString('utf8');
      if (Buffer.byteLength(stderr) > 160000) stderr = stderr.slice(-160000);
    });
    child.on('error', (error) => finish(new Error(`Could not start OpenCode (${opencodeCommand}): ${redactSecrets(error.message)}`)));
    child.on('close', (code, signal) => {
      if (timedOut) return finish(new Error(`OpenCode model call timed out after ${Math.round(config.limits.modelTimeoutMs / 1000)} seconds.`));
      if (stdoutOverflow || Buffer.byteLength(stdout) > config.limits.maxOutputBytes) return finish(new Error('OpenCode output exceeded the configured limit.'));
      const parsed = parseOutput(stdout);
      if (code !== 0) return finish(new Error(`OpenCode failed (exit ${code ?? signal}). ${redactSecrets(stderr.trim()).slice(-1800)}`));
      if (!parsed.text) return finish(new Error(`OpenCode produced no text response. ${redactSecrets(stderr.trim()).slice(-1200)}`));
      finish(null, { ...parsed, stderr: stderr.slice(-3000), role });
    });
  });
}



async function readLimitedResponseText(response, maxBytes) {
  const declaredLength = Number(response.headers?.get?.('content-length'));
  if (Number.isFinite(declaredLength) && declaredLength > maxBytes) throw new Error(`OpenRouter response exceeded the ${maxBytes}-byte safety limit.`);
  if (!response.body?.getReader) {
    // Compatibility path for injected test doubles; real Fetch responses use the bounded streaming path below.
    const text = await response.text();
    if (Buffer.byteLength(text, 'utf8') > maxBytes) throw new Error(`OpenRouter response exceeded the ${maxBytes}-byte safety limit.`);
    return text;
  }
  const reader = response.body.getReader();
  const chunks = [];
  let total = 0;
  try {
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      total += value.byteLength;
      if (total > maxBytes) {
        await reader.cancel('Forge response limit exceeded').catch(() => {});
        throw new Error(`OpenRouter response exceeded the ${maxBytes}-byte safety limit.`);
      }
      chunks.push(Buffer.from(value));
    }
  } finally {
    reader.releaseLock?.();
  }
  return Buffer.concat(chunks, total).toString('utf8');
}

/** Direct OpenRouter adapter. API key is read only from process environment and never written to config/audit. */
export async function invokeOpenRouter({ config, prompt, role = 'general', fetchImpl = globalThis.fetch }) {
  validateConfig(config);
  if (config.privacy.mode === 'local-only') throw new Error('OpenRouter is a remote provider and cannot be used with privacy.mode=local-only.');
  validatePrivacyMode(config);
  const apiKey = process.env.OPENROUTER_API_KEY;
  if (!apiKey || !apiKey.trim()) throw new Error('OPENROUTER_API_KEY is not set. Set it in your shell environment; do not put it in forge.config.json.');
  if (typeof fetchImpl !== 'function') throw new Error('This Node.js runtime does not provide fetch(). Use Node.js 22 or newer.');
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), config.limits.modelTimeoutMs);
  timeout.unref?.();
  try {
    const response = await fetchImpl(`${config.openrouter.baseUrl.replace(/\/+$/, '')}/chat/completions`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
        'X-OpenRouter-Title': 'Forge CLI',
      },
      body: JSON.stringify({
        model: config.model,
        messages: [{ role: 'user', content: prompt }],
        max_tokens: config.openrouter.maxTokens,
        stream: false,
      }),
      redirect: 'error',
      signal: controller.signal,
    });
    const raw = await readLimitedResponseText(response, 2_000_000);
    if (!response.ok) {
      // Do not include request headers or the API key in surfaced error text.
      let detail = raw.slice(0, 1200);
      try { const body = JSON.parse(raw); detail = body?.error?.message || body?.message || detail; } catch { /* preserve bounded response */ }
      throw new Error(`OpenRouter request failed (HTTP ${response.status}): ${redactSecrets(String(detail)).slice(0, 1200)}`);
    }
    let data;
    try { data = JSON.parse(raw); } catch { throw new Error('OpenRouter returned invalid JSON.'); }
    const text = data?.choices?.[0]?.message?.content;
    if (typeof text !== 'string' || !text.trim()) throw new Error('OpenRouter returned no text content. The selected model may have returned a non-text response.');
    const usage = data.usage || {};
    const promptTokens = Number(usage.prompt_tokens ?? usage.input_tokens ?? 0);
    const completionTokens = Number(usage.completion_tokens ?? usage.output_tokens ?? 0);
    const cost = Number(usage.cost ?? data.cost ?? 0);
    return {
      text: text.trim(), tokensIn: Number.isFinite(promptTokens) ? promptTokens : 0,
      tokensOut: Number.isFinite(completionTokens) ? completionTokens : 0,
      costUsd: Number.isFinite(cost) ? cost : 0,
      hasCost: Number.isFinite(cost) && (usage.cost !== undefined || data.cost !== undefined),
      rawBytes: Buffer.byteLength(raw), role, provider: 'openrouter',
    };
  } catch (error) {
    if (error?.name === 'AbortError') throw new Error(`OpenRouter request timed out after ${Math.round(config.limits.modelTimeoutMs / 1000)} seconds.`);
    throw error;
  } finally { clearTimeout(timeout); }
}

export function invokeModel(options) {
  if (options.config.provider === 'openrouter') return invokeOpenRouter(options);
  return invokeOpenCode(options);
}
