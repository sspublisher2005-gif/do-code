# Forge Browser QA: design, security boundaries, and evidence

**Implementation version:** Forge 0.1.5  
**Status:** optional Playwright adapter implemented; real Node-Playwright execution not verified in the authoring environment  
**Purpose:** automatically route browser-testing tasks to an isolated, repeatable browser workflow without making browser access a new unbounded AI tool.

## Decision summary

Forge uses the official Playwright Node API as its only built-in browser engine. It is optional and is not included in `dependencies`. This keeps the base CLI lightweight and lets the harness perform deterministic checks, screenshots, and local evidence collection without an additional model-driven browser loop.

| Candidate | Decision | Evidence and reason |
|---|---|---|
| Playwright Node API | **Adopted** | Direct automation and isolated contexts suit repeatable app smoke checks; official docs describe browser contexts as isolated, incognito-like sessions: <https://playwright.dev/docs/browser-contexts>. |
| Microsoft Playwright MCP | Defer | Useful for exploratory/model-driven interactions with structured accessibility snapshots. The project distinguishes MCP for persistent iterative exploration from CLI/skill flows that can be more token-efficient for coding-agent workflows: <https://github.com/microsoft/playwright-mcp>. Forge's first use case is deterministic smoke QA, so a second model-facing browser tool would add surface area without improving baseline evidence. |
| Vercel `agent-browser` | Defer as alternative adapter | A capable browser-agent CLI with compact accessibility snapshots and element references: <https://github.com/vercel-labs/agent-browser>. It overlaps with Playwright for this initial capability. Reconsider only if Forge needs long-lived interactive sessions, structured snapshots, or browser recordings beyond this audit. |
| `browser-use` / session-reusing tools | **Not default** | Session/cookie reuse adds privacy and account-action risk. Forge intentionally does not attach to the user's everyday profile, export cookies, or assume an authenticated session. |

These are architectural decisions based on documented capabilities, not a claim that one project is universally superior.

## Automatic routing

- Phrases such as “test this website/game in the browser”, “inspect the frontend”, or “verify the web app” route to Browser QA instead of making an unnecessary model call.
- If the task also asks Forge to change code, it runs the normal planner → coder → approved patch → approved tests → reviewer flow first, then Browser QA when requested.
- Browser QA, game-testing, frontend-debugging, test-driven-development, security-review, and documentation-research skills are built in. Project/user skills can be discovered, but are treated as untrusted guidance and cannot grant permissions.
- The Security Auditor is conditional, not a permanently running swarm. This avoids adding latency and duplicated model calls to simple tasks.

## Local dev-server startup

If no URL is supplied, Forge can inspect a regular `package.json` and offer only standard command forms from a narrow allowlist:

- `vite`, `vite preview`
- `astro dev`, `astro preview`
- `next dev`, `next start`
- `nuxt dev`, `nuxt preview`, `nuxi dev`, `nuxi preview`
- `react-scripts start`

Unknown commands and shell chains are rejected. A `pre<name>` or `post<name>` lifecycle hook also disables automatic startup. Forge does not run package installation automatically. On approval, it launches the known framework script with loopback host/port settings, a restricted environment, and no shell command supplied by the model. It polls the local URL, runs the browser audit, and attempts to terminate the process tree in a `finally` block. This executes repository code and is **not OS-sandboxed**; user consent does not turn it into sandboxed execution. Under `privacy.mode=local-only`, start the server manually and test its loopback URL.

## Browser test and data policy

1. Only HTTP(S) targets are accepted; embedded credentials and terminal-control characters are rejected.
2. Browser navigation requires a consent checkpoint unless the user explicitly supplied `--yes`. A task routed automatically does not bypass the checkpoint.
3. Chromium is launched with sandboxing requested; Forge never adds `--no-sandbox`. Browser contexts are fresh, downloads disabled, service workers blocked, dialogs dismissed, and pop-ups closed. The user's Chrome profile, cookies, local storage, or browser history are not reused.
4. The default network allowlist is the target origin only. Additional origins require explicit `--allow-origin`. Private/LAN targets are rejected unless the user explicitly supplies `--allow-private-network`; that override is dangerous and should be restricted to an owned environment.
5. Public DNS hostnames are resolved before Chromium starts, and host resolver rules pin them to a vetted public address to reduce DNS-rebinding SSRF. HTTP(S) and WebSocket routing block origins/schemes outside the allowlist; Playwright v1.48+ is mandatory and older versions fail closed. This is not an OS-level firewall, and WebRTC/UDP or other browser network surfaces may bypass request routing; external egress controls are required for hostile targets. The private-network override intentionally disables public-only restrictions and accepts that risk.
6. Desktop/mobile screenshots and bounded JSON metadata are written to `.forge/browser-runs/<run-id>/` with restrictive filesystem permissions. Screenshots may contain private page information and stay local. Raw DOM text is used only for an in-memory heuristic prompt-injection scan; it is not saved in the report or sent to a model. The report stores only indicator categories.
7. Page text, HTML, console output, request errors, and browser reports are untrusted data. None can authorize commands, apply patches, approve external requests, or change Forge policy.
8. Passive mode does not submit forms or click generic controls. Explicit game exercise may click a visible button whose accessible label exactly matches a small start-game allowlist and send basic arrow/WASD key events. It is not a general arbitrary-clicking agent.

## What the audit measures

- Navigation response status and navigation failures.
- Uncaught page JavaScript errors, console errors, HTTP failures, failed requests, and policy-blocked requests.
- Desktop 1365×850 and mobile 390×844 viewport metadata and screenshots.
- Title/language/headings, horizontal overflow, missing image `alt`, basic accessible names on buttons/links, input labels, canvas and WebGL presence.
- If explicitly requested, a constrained game-start/movement exercise plus a follow-up screenshot.
- Heuristic prompt-injection indicators, persisted as categories only.

A `PASS` means these bounded checks found no configured failure signals; it does **not** prove that every feature works. `WARN` means review the findings; `FAIL` means navigation or JavaScript failures matched the current failure policy. Screenshots must be visually reviewed for product quality, game logic still needs task-specific assertions, and authenticated flows require a deliberately designed separate test account/context—not the user's normal browser session.

## Commands

```sh
forge browser status
forge browser setup
forge browser test http://127.0.0.1:5173
forge browser test --start
forge browser test http://127.0.0.1:5173 --exercise
forge browser test https://public-demo.example --allow-origin https://assets.example
```

`forge browser setup` requests explicit permission to install `playwright-core` with package lifecycle scripts disabled. It does not download a browser. Use an installed Chrome/Chromium/Edge binary or deliberately install the full `playwright` package and managed Chromium. `FORGE_BROWSER_EXECUTABLE` can point to a reviewed browser binary. Do not set `FORGE_PLAYWRIGHT_MODULE` to unknown code.

## Tests and evidence in this source snapshot

- URL validation rejects file/data/javascript schemes, embedded credentials and control characters.
- Report labels strip query/fragment data and mask long ID-like path components.
- Fake-Playwright contract tests verify isolated contexts, no `--no-sandbox`, screenshot/evidence writing, no persisted page text, injection-category-only reporting, layout warnings, page-error failure classification, private-network denial, and pinned DNS resolver rules.
- Dev-server tests verify the allowlist rejects shell chains and lifecycle hooks, a Vite-like local fixture binds to loopback, returns HTTP, and is stopped after the test. A hostile project `.npmrc` setting both `script-shell` and `node-options=--require` is overridden; a marker test confirms the injected preload did not run. WebSocket tests verify disallowed origins close before connection and missing routing support fails closed.
- CLI integration tests verify the natural-language browser task routes to Browser QA and that the repository's server script does not run if Playwright is absent; skill and role listings expose the built-in capabilities.
- On the authoring host, `npm test` passed **67 tests** and `npm run check` syntax-checked **21 JS files** after the implementation. The actual `playwright`/`playwright-core` Node package was not present and npm registry access was unavailable, so these are adapter/mocked checks—not a claim that Forge's Node adapter visited a real website in this run. Browser engine execution still needs verification on a machine with Playwright installed.
- Windows and macOS CI are configured but have not yet completed in hosted CI from this workspace.

## Known remaining risks

- Browser QA is not an OS/container sandbox. Repository scripts, browser processes, and target-page JavaScript can still exploit OS/browser defects; run untrusted projects in a disposable restricted VM/container.
- Heuristic injection detection is incomplete and must not be used as the security boundary.
- Visual, accessibility, WebGL, input, network, and gameplay checks are partial. Task-specific app tests are required for correctness.
- Authenticated applications and state-changing flows are intentionally not automated with the everyday user profile.
- DNS pinning and origin blocking reduce exposure but do not replace OS-level egress controls.

## Primary references

- Playwright browser contexts: <https://playwright.dev/docs/browser-contexts>
- Playwright browser API: <https://playwright.dev/docs/api/class-browser>
- Playwright MCP and CLI/skill design comparison: <https://github.com/microsoft/playwright-mcp>
- Vercel agent-browser: <https://github.com/vercel-labs/agent-browser>
- OWASP Top 10 for LLM Applications: <https://owasp.org/www-project-top-10-for-large-language-model-applications/>
