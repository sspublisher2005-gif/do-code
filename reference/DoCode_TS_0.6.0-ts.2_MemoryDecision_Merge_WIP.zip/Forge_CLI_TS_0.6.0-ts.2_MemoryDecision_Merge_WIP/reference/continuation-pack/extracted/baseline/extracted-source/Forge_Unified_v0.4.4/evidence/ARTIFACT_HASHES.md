# Artifact hashes

- npm tarball: `forge-coding-harness-0.4.4.tgz`
- SHA-256: `b6697318ac7b3b4c6f0a662b0fe91a15ead0ea95a10b06d473ffa10e4fd51852`

The full source ZIP's SHA-256 is provided in the external sidecar `Forge_Unified_v0.4.4.sha256` next to the archive. The ZIP cannot contain its own final hash without making the hash self-referential.
