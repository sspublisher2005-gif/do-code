# Forge v0.4.4 Release Verification — 2026-10-21

## Verdict

**LOCAL PACKAGE CHECKS: PASS. FULL PRODUCTION READINESS: NOT PROVEN.**

This report separates checks executed in this environment from real-system gates that could not run. It does not claim 100% completion.

## Results completed locally

| Check | Result | Evidence / limitation |
|---|---|---|
| Automated Node test suite | PASS — 129 passed, 0 failed | Run on source and again from the freshly packed npm tarball; see `evidence/forge-v0.4.4-npm-test.log` and release-check output. |
| JavaScript syntax check | PASS — 32 files | `npm run check`; see `evidence/forge-v0.4.4-check.log`. |
| Clean npm install | PASS | `npm ci --ignore-scripts`; see `evidence/forge-v0.4.4-npm-ci.log`. |
| Dependency audit | PASS for the declared dependency tree | `npm audit --audit-level=high` reported zero vulnerabilities. This package currently declares no runtime dependencies, so this is not a source-code, base-image, or container security audit. |
| Clean packaged-install verification | PASS | `npm run check:release` creates and extracts a fresh tarball, checks package paths and required files, runs the packaged tests and syntax checker, and checks CLI version/help. Exact final metrics are recorded in `evidence/forge-v0.4.4-check-release.log`. |
| CLI version/help | PASS — version `0.4.4` | `evidence/forge-v0.4.4-cli-smoke.log`. |
| Doctor and sandbox status | PASS as diagnostic commands | The output reports that no usable OpenCode provider and no container runtime are available. See `evidence/forge-v0.4.4-doctor.log` and `evidence/forge-v0.4.4-sandbox-status.log`. |
| Fail-closed sandbox behavior | PASS | A sandbox run exits before running the payload when Docker/Podman is missing. See `evidence/forge-v0.4.4-sandbox-fail-closed.log`. This does not prove sandbox isolation. |
| Browser fixture | PASS on system Chromium via Python Playwright | Desktop/mobile screenshots, calculation, accessible labels, browser error checks and detection of a deliberately seeded incorrect total passed. See `evidence/forge-v0.4.4-browser-smoke.log`, `evidence/forge-v0.4.4-browser-desktop.png`, and `evidence/forge-v0.4.4-browser-mobile.png`. This used a controlled in-memory page, not Forge's Node Playwright adapter or a live HTTP-served app. |
| Workspace permission rehearsal | PASS on the host under unprivileged UID/GID 65532 | The copied private/read-only source files became writable in the disposable copy while the original stayed unchanged. See `evidence/forge-v0.4.4-workspace-permission-probe.log`. This is a POSIX permission test, not a container test. |
| GitHub workflow and repo access | NOT VERIFIED | The GitHub connector returned no repositories accessible to the linked account; the extracted source has no `.git` metadata/upstream URL. CI is configured but has no observed hosted run. |

## Important changes in this build

- Sandbox requests fail closed when a usable local Docker/Podman engine is unavailable.
- Container execution requests a non-root numeric UID/GID (`65532:65532`), disabled networking, read-only container root, a read-only source mount, resource limits, dropped capabilities and `no-new-privileges`.
- The disposable workspace is staged from a filtered copy and made writable only in the copy so builds/tests can update files. Common credential paths are filtered; exclusions are heuristic and are not a complete secret-discovery system. Custom `FORGE_SANDBOX_IMAGE` values must be digest-pinned; digest pinning does not validate signatures, provenance, publisher identity or vulnerabilities.
- Default container images use digest-qualified references. A pinned digest provides immutability, not proof that the image is vulnerability-free or trustworthy. No image scan/SBOM/provenance report was generated in this environment.
- Staging rejects observed file/directory symlink substitutions and validates file identity during reads. Residual concurrent path-race limitations remain documented; this is not a replacement for independent security review or descriptor-relative `openat2`-style traversal.
- Session completion now requires tests to pass, an overall review verdict of `PASS`, no unresolved deterministic security warnings, and passing conditional security/browser review results when those checks are present. A non-green verification gate becomes `needs_review`.
- Added regression tests for sandbox command construction, fail-closed behavior, symlink swaps, copy permissions and completion-state gating.
- CI workflow uses full commit SHA pins for third-party actions, lockfile-backed installs and platform jobs, plus a Docker-enabled real-sandbox job. It is configuration only until it runs on a hosted runner.

## NOT AVAILABLE IN THIS ENVIRONMENT

1. **Docker/Podman runtime:** not installed; real-container isolation, network denial, mount behavior, cleanup, cancellation and adversarial escape checks were not executed.
2. **Live coding provider/agent:** no working Codex, OpenCode, Claude or Gemini CLI provider was available, and no user model credential was used. No live model-backed coding task was completed.
3. **Node Playwright adapter:** Node `playwright`/`playwright-core` was not installed and registry access was not reliable. The separate Python Playwright/Chromium fixture does not validate Forge's Node browser integration.
4. **Hosted CI:** no upstream repository was found/authorized in the connected GitHub account, so no CI run result exists.
5. **Image security:** no container images were pulled/scanned; no SBOM, signature or trusted-provenance check was generated.
6. **Independent external security review and customer tests:** not performed. Specialist perspectives in project docs are internal simulated review roles, not independent people or customer interviews.
7. **Matched competitor benchmark and cost/usage measurement:** not performed because live task runs/providers were unavailable.

## Research basis

The selected sandbox controls follow supported container-run primitives documented by Docker: network, mounts, read-only root filesystem, PID limits, pull policies and security options. GitHub recommends pinning third-party Actions to full-length commit SHAs. OpenCode documents configurable `allow`, `ask`, and `deny` permission modes. These design comparisons do not establish feature parity or superior coding performance.

- Docker container run reference: https://docs.docker.com/reference/cli/docker/container/run/
- GitHub Actions secure-use reference: https://docs.github.com/en/actions/reference/security/secure-use
- OpenCode agents and permission reference: https://opencode.ai/docs/agents/

## Release gate decision

v0.4.4 can be shared as a **local engineering release candidate** with its limitations stated. Do not describe it as production-ready or 100% complete until the real sandbox job, hosted platform CI, live-provider coding tasks, independent security review and external validation have passing evidence.
