---
name: Backend and API Engineering
description: Implement or debug backend services and APIs with input validation, authorization, stable contracts, and focused regression tests.
---

## Checklist
- Trace route → middleware → validation → domain/service → persistence/external dependency → response.
- Validate types, bounds, formats, ownership, and authorization at the server boundary.
- Keep authentication distinct from authorization. Fail closed when identity/permission evidence is missing.
- Avoid leaking secrets in logs, errors, traces, URLs, or telemetry.
- Apply timeouts, response-size limits, retries only for transient/idempotent cases, and cancellation where supported.
- Preserve status codes and response schemas or document the breaking change.
- Add tests for unauthorized access, invalid inputs, absent data, duplicate requests, dependency failure, and limits.
- Never claim production readiness without real integration, migration, and operational evidence.
