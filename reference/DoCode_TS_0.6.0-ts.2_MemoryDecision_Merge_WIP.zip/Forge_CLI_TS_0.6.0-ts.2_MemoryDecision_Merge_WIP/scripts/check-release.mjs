import { access, readFile, stat } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { join } from 'node:path';
const root = new URL('../', import.meta.url);
const packageJson = JSON.parse(await readFile(new URL('../package.json', import.meta.url), 'utf8'));
const required = ['dist/cli/main.js', 'dist/cli/command-router.js', 'README.md', 'LICENSE'];
for (const relative of required) await access(new URL(`../${relative}`, import.meta.url));
const mainPath = new URL('../dist/cli/main.js', import.meta.url);
const main = await readFile(mainPath);
if (!main.toString('utf8').startsWith('#!/usr/bin/env node')) throw new Error('CLI entrypoint missing Node shebang');
const result = {
  version: packageJson.version,
  requiredFiles: required.length,
  cliEntryBytes: (await stat(mainPath)).size,
  cliEntrySha256: createHash('sha256').update(main).digest('hex'),
  note: 'Structural release check only; not a clean-room packed install, dependency audit, SBOM, sandbox test, or hosted CI result.'
};
process.stdout.write(`${JSON.stringify(result, null, 2)}\n`);
