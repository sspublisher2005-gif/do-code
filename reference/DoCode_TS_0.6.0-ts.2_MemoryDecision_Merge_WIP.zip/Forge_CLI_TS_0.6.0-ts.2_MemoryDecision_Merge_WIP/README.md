# Forge CLI — TypeScript development stream

**Version:** `0.6.0-ts.2`  
**Status:** Development preview — not production-qualified.

Forge is an evidence-first, project-isolated AI coding harness. This TypeScript worktree is a separate development line. The earlier JavaScript Forge Unified v0.4.4 baseline and the saved continuation pack remain preserved under `reference/` and in the master transfer archive.

## Implemented in this worktree

- Strict TypeScript contracts for missions, steps, agent messages, tool calls, safety decisions, evidence references and verification results.
- CLI commands for init/doctor/config, model diagnostics, safe file listing/reading/search, repo indexing/context packs, mission planning/runs/status, patch preview/apply/undo, freeze/unfreeze, audit, sandbox diagnostics, local memory and Decision Arena Lite.
- `forge.config.toml` supported-schema parsing/validation and project instruction memory via `FORGE.md`.
- OpenAI-compatible HTTP provider, direct Anthropic and Google GenAI adapters, normalized token usage and truthful unknown cost values. Ollama can use an OpenAI-compatible local endpoint. No live provider-backed coding result is claimed.
- Repo walking with `.gitignore` handling, heuristic symbols/import graph, bounded context packs, credential-shaped content exclusions and project-bound indexes.
- Mission persistence, legal state transitions, locks and stale-lock handling, evidence SHA-256 integrity, local redacted JSONL audit, patch checkpoints, explicit apply approval and conflict-aware undo.
- A Linux namespace isolation prototype with tested negative cases. This is for a fixed `forge sandbox self-test` only; the normal sandbox resolver stays blocked.
- Local Learning Memory: structured, confirmation-gated Markdown decisions with global/project scope separation, index hashes, import/export/reindex/edit/reset and local-only operations. Memory notes are not implicitly injected into prompts.
- Decision Arena Lite: deterministic trigger reasons, offline decision brief, and an opt-in model-backed brief that requires both `--live` and `--approve-context-sharing`; the request contains only the decision/options, never repository files or memory. Perspective sections are one model response, not independent agents/experts.
- Unit, integration and security tests using Node's built-in runner.

## Run from a source checkout

Requirements: Node.js 22.12+; TypeScript and Node type declarations for development. A real committed lockfile is still a release blocker; do not treat globally installed type-check dependencies as reproducible setup.

```bash
npm run typecheck
npm run build
npm test
node dist/cli/main.js --help
node dist/cli/main.js init
node dist/cli/main.js doctor
node dist/cli/main.js config show
node dist/cli/main.js index
node dist/cli/main.js context "the task I plan to work on"
node dist/cli/main.js sandbox status
node dist/cli/main.js sandbox self-test
node dist/cli/main.js memory list
node dist/cli/main.js pilot "Compare options for a safe migration" --option "Keep current design" --option "Migrate gradually"
```

The `sandbox self-test` runs only a fixed command in a synthetic temporary workspace on Linux. It checks namespace setup, read-only system paths, sensitive-file exclusion, blocked access to a live host localhost TCP listener, outside-workspace write restrictions and disposal of guest writes. It explicitly reports `productionReady: false`.

## Explicit provider request

`forge model test` is config-only and network-silent by default. To send a request, use explicit consent flags and provide a key through the configured environment variable:

```bash
OPENAI_API_KEY=... node dist/cli/main.js model test --live --approve-context-sharing
```

Decision Arena live mode uses `forge pilot "decision description" --option "Option A" --option "Option B" --live --approve-context-sharing`. It uses `FORGE_BASE_URL` to override the configured provider endpoint when needed. A live call sends the approved decision/options to the configured service and may incur charges. Do not paste credentials into task descriptions or committed config. Provider-side retention is governed by the selected provider; Forge cannot promise zero provider retention.

## Local memory and Decision Arena

`forge memory propose` prints the proposed structured record and requires a confirmation flag in non-interactive use. Global and project notes are stored separately beneath a local vault (default `~/.forge/memory`, override with `FORGE_MEMORY_DIR`). The JSON index is a cache; Markdown is source of truth. Imports reject cross-project project-bound notes. Secret detection is heuristic, so do not store credentials.

`forge pilot` offline mode does not claim web research or fabricate numeric rankings. Live mode requires both consent flags, sends only the decision/options through the configured provider registry, and reports that one model generates the named perspectives. Provider billing and retention policies may apply. Memory is not attached to pilot prompts.

## Safety boundaries

- No telemetry is sent by Forge by default.
- File list/read/search is workspace-scoped and read-only; writes go through validated patch preview, approval and checkpoints.
- Coder output is a proposal, not an instruction to the filesystem. Project files and model output are untrusted.
- General command execution, build/test execution and browser automation remain blocked until a production-qualified sandbox is integrated and verified. No host-shell fallback exists.
- Current Linux prototype does **not** apply Landlock or seccomp-bpf, lacks an independently reviewed security boundary, has no macOS/Windows execution driver, and omits `/proc` in the present restricted-kernel environment. It is not safe to classify it as production isolation.
- The repository index is heuristic—not a complete AST/LSP or semantic dependency graph. Agent roles are currently bounded sequential calls rather than independently sandboxed parallel agents.
- No live model-backed coding task, hosted multi-OS CI run, independent penetration test, matched competitor benchmark or 20–30 user study has been completed.

## Release and continuity

This version is a private development preview. `package-lock.json`, a clean locked-toolchain install, complete dependency/license/SBOM review, hosted CI results, platform-specific safe execution drivers, integration-level browser E2E, live model evidence, external security review and customer validation are still release gates. `docs/STATUS.md`, `docs/VERIFICATION_REPORT_2026-10-24.md`, and `docs/MEMORY_DECISION_MERGE_REPORT_2026-10-24.md` are the canonical current reports.
