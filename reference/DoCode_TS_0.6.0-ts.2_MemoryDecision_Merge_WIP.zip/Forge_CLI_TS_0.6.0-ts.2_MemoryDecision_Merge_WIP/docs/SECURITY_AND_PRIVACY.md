# Security and privacy contract

- Forge-owned telemetry is disabled; M1 has no background network activity.
- `init`, `doctor`, `config show`, file commands and audit inspection do not call a model. A local audit file is written by state-changing or inspected commands; no source content is logged.
- Credentials are read only from a provider-allowlisted environment variable (`model.api_key_env`) for the live diagnostic call; unrelated variables such as cloud/account secrets are rejected by config validation. They are never serialized into config or audit. Environment values are not printed.
- A live model call requires `--live --approve-context-sharing`; it sends a short fixed diagnostic prompt and does not attach repository files. Provider billing, retention and processing policies still apply.
- `privacy.mode = "local-only"` blocks remote endpoint use in the live-test command, but is not a host firewall or proof of network isolation.
- Safe files deny known credential paths and `.forge`; redaction covers common credential patterns only and can miss novel/encoded secrets.
- Local audit files can reveal a project has been used and contain path-free event summaries. They are user-owned local records, not signed forensic evidence.
- Cross-project memory import, tool credential inheritance, telemetry and automatic upload are not implemented.
