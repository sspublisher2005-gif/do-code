# Dependency policy for M1 and future adapters

## Actual worktree dependencies

- Runtime dependencies: none. Current M1 uses Node built-ins for CLI argument parsing, fetch, filesystem operations, crypto, path handling and TOML-subset parsing.
- Development dependencies in `package.json`: `typescript` and `@types/node`.
- Tests use Node's built-in `node:test` runner to avoid adding a test framework to the M1 runtime path.

The current worktree was typechecked using the environment's global TypeScript 5.8.3 and global Node type declarations. Registry connectivity timed out, therefore dependency versions are **not resolved by a committed lockfile**. `npm ci` and clean-room installation are not release-qualified yet.

## Planned additions after registry/lockfile is available

| Package | Purpose | Acceptance before adoption |
|---|---|---|
| `smol-toml` | Full TOML parser/serializer | Compatibility tests for strict known schema; reject unknown config keys after parse |
| `zod` | Runtime schema validation | Boundary schemas for provider/tool/persistence inputs and malformed payload tests |
| `commander` | CLI parser/help | Only if it materially improves parser consistency without widening attack surface unnecessarily |
| `ignore` | `.gitignore` semantics | Tests for nested ignore rules and deterministic traversal |
| `openai` | Official OpenAI SDK if direct SDK path is useful | License, lockfile, request/usage/timeout/redirect tests; keep OpenAI-compatible server support |
| `@anthropic-ai/sdk` | Anthropic adapter | Contract tests and license/lockfile review |
| `@google/genai` | Google adapter | Contract tests and license/lockfile review |
| `@playwright/test` | Browser E2E | Only the E2E job installs browser binaries deliberately; browser trace/artifact policy must pass |

Use exact lockfile-resolved versions, audit transitive deps, enumerate licenses, create SBOM, verify package provenance/checksums and clean-room-install the packed artifact. A clean `npm audit` is not proof of source-code security or sandbox isolation.
