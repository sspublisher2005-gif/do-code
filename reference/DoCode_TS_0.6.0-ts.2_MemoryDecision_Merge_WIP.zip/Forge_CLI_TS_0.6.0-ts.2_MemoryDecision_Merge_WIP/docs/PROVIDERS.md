# Provider integration

## M1 implemented

One OpenAI-compatible chat-completions transport uses Node's built-in fetch. It validates base URL schemes/userinfo/query/fragment, allows HTTP only on loopback, bounds prompts/output/timeout, rejects redirects, avoids echoing response bodies on errors, normalizes provider-reported token counts, and leaves cost unknown unless a specifically USD-denominated field is reported. Tests use an in-process HTTP server; they do not hit a real provider.

## Target adapter contract

All providers implement `ModelProvider` (`generate`, `healthCheck`) and use `ModelRequest`/`ModelResponse` from `core/types.ts`. `healthCheck()` is network-silent by default. To probe a real endpoint, a caller must explicitly pass `{ networkConsent: true }`; call sites should obtain user consent rather than infer it from project config.

- OpenAI-compatible API; Ollama can share the interface through an explicit local endpoint, but its local-only configuration is not a network firewall.
- Anthropic native messages API.
- Google Gen AI native generate-content API.
- Ollama/local model adapter.

Each adapter must normalize cancellation, timeout, HTTP/rate-limit/transient errors, usage and request IDs. Retries, if enabled, must be capped by total elapsed time and token/cost budgets. Authentication/config errors are never retried. API keys are environment/credential-store inputs only; the M1 config allowlists provider-specific variable names and rejects arbitrary names. Provider prompts and responses must be treated as untrusted.

Anthropic, Google and dedicated Ollama adapters, retry budget layer, native structured-output contract and live provider task have not yet been implemented/tested.
