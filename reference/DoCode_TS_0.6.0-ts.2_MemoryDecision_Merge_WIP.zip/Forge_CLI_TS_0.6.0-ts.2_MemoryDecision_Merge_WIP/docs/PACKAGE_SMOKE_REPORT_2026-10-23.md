# Forge CLI tarball smoke report — 2026-10-23

## Result

**PASS — local package usability smoke only. Not a production release certification.**

Package: `forge-coding-harness@0.6.0-ts.1`

## Procedure

1. Ran `npm run check:release` on the worktree: typecheck, clean build, tests, and structural release check.
2. Created the tarball with `npm pack`.
3. Created a new temporary consumer project with a minimal `package.json`.
4. Installed the tarball using `npm install --offline`, without relying on a registry lookup.
5. Ran the installed CLI through the npm-created symlink.

## CLI actions observed

- `forge --version` — reports `0.6.0-ts.1`.
- `forge --help` — prints supported command help.
- `forge init` — creates config and `FORGE.md`, and reports no network use.
- `forge doctor` — runs local diagnostics.
- `forge config show` — reads validated configuration.
- `forge files list` — lists allowed workspace files.
- `forge audit --tail 10` — reads local audit events.
- `forge sandbox status` — reports the sandbox capability state and limitations.
- `forge sandbox self-test` — passes the fixed Linux namespace fixture and explicitly reports `productionReady=false`.

## Boundaries

- The tarball installs and runs offline because the runtime code currently uses Node built-ins only.
- The source development toolchain could not be installed from a committed lockfile; `package-lock.json` is absent because registry access failed in the implementation environment.
- The environment's global TypeScript 5.8.3 compiler and global Node type declarations were used for the worktree checks.
- This test does not establish macOS/Windows support, real provider-backed coding quality, hosted CI, a source/dependency SBOM, a full supply-chain audit, an independent security review, or production-safe command execution.
- Linux sandbox self-test is limited to its fixed disposable fixture. The production command/test execution resolver remains disabled until Landlock/seccomp-bpf (or a reviewed equivalent), adversarial validation and external review pass.

See `VERIFICATION_REPORT_2026-10-23.md` and `SANDBOX_POLICY.md` for remaining release blockers.
