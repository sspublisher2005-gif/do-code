# Local Learning Memory — v0.1 scope

## Persist decisions, not thoughts

Forge stores only a structured proposal that the user has reviewed and confirmed. The note types are `solution`, `decision`, `research`, `user_preference`, `project`, `failure`, and `workflow`. Raw hidden reasoning and unreviewed chain-of-thought are not a memory type.

A note records a problem, decision/solution, reason, rejected options, limitations, evidence/source references, confidence, created date, last-verified date, status, and scope. Solution, research, failure, and workflow notes require at least one evidence reference. A preference is not captured automatically; saving it requires explicit confirmation. There is no automatic preference-repetition learner yet.

## Storage layout

```text
<configured-vault>/
├── global/
│   ├── index.json
│   └── notes/<uuid>.md
└── projects/<sha256-project-id>/
    ├── index.json
    └── notes/<uuid>.md
```

Default vault: `~/.forge/memory/`. `FORGE_MEMORY_DIR` can explicitly configure a directory, including an Obsidian vault. Markdown notes are authoritative and have Obsidian-compatible frontmatter. Each `index.json` is a cache that can be rebuilt; it is not an authentication mechanism.

## Confirmation and privacy

- Proposal preview precedes any write. In a non-interactive terminal, `--confirm` is required.
- Memory notes are not passed to model-provider requests. `forge pilot` sends only its prompt/options when live mode is explicitly approved.
- The note writer rejects several common credential formats, but detection is heuristic; never put secrets into memory.
- Global and project memories have separate storage. The import operation prevalidates project binding for the entire bundle before writes, and project notes from another project are rejected.
- `verify` checks schema and stored index hash agreement, not truth. The index can be rebuilt only after review. Hashes are not signed or tamper-proof against someone who can modify both note and index.

## Commands

- `forge memory propose ...`: show a proposed structured lesson, then ask or require `--confirm`.
- `forge memory list [--scope global|project|all]`
- `forge memory search <query> [--scope global|project|all]`
- `forge memory show <uuid>`
- `forge memory edit <uuid>`: opens `$VISUAL`/`$EDITOR` in interactive terminals if it is a single executable path; otherwise prints the note path for manual editing.
- `forge memory forget <uuid> --confirm`
- `forge memory verify <uuid>`
- `forge memory reindex --confirm [--scope global|project|all]`
- `forge memory export <new-file.json> [--scope global|project|all]`
- `forge memory import <file.json> --confirm`
- `forge memory open`: displays the local vault path, does not launch an app.
- `forge memory reset --confirm [--scope global|project|all]`

## Not implemented yet

No automatic memory extraction from successful missions, no lesson promotion from model transcripts, no vector or semantic search, no scheduled web revalidation, and no automatic injection into prompts. These require the coding task loop plus a per-mission consent policy. Search and storage are deterministic local operations today.
