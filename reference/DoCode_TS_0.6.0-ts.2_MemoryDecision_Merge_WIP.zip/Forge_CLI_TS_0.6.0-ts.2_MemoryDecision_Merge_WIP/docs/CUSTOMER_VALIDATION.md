# Customer validation and product expansion gates

Engineering safety must reach a usable candidate before asking customers to rely on code changes. Do not treat social likes, surveys alone, or free signups as proof of paid demand.

## User validation cohort

Recruit 20–30 developers/students/indie builders across small repositories and mixed experience levels. Observe setup without coaching, then test a real contained coding task and the verification report. Separate interview statements from observed behavior.

Measure first-run completion, time to first useful task, task success, false success claims, time required to review a patch, willingness to use the tool on a real repo, reasons for rejection, frequency, alternatives used, and explicit willingness-to-pay at named price points. Do not upload private repositories without separate consent.

## Expansion decisions

Do not prioritize MCP/extensions, full parallel agents, broad web/social research, cloud synchronization, account features, or dashboards until the core CLI shows repeat use. Expand only where user evidence demonstrates a bottleneck and a new security boundary is justified.

Candidate gate: no open critical/high security failures; clean install and supported-platform CI; at least 90% task evidence completeness on held-out fixtures; false completion rate measured; onboarding tested with new users; 20–30 user validation recorded; explicit product owner decision documented. These are proposed acceptance targets, not results already achieved.
