# Threat model — M1

## Assets

Source code, `.forge/` audit/project state, provider credentials in process environment, local user files, model context, proposed changes and integrity of completion reports.

## Trust boundaries

Untrusted inputs include user task text, repository files, `FORGE.md`, config text before validation, model responses, provider error payloads, test output, Internet results, and any future plugin/subagent response. Filesystem writes, process launch, network requests, and browser actions are privileged side effects.

## Threats and current controls

- **Path traversal / symlink reads:** root-relative path rules, component `lstat`, realpath containment check, final-component `O_NOFOLLOW` where supported, sensitive-path denials, special-file rejection.
- **Credential leakage in logs:** environment-variable key lookup, redaction before audit serialization, no raw provider error bodies, no prompt/source attached to M1 model-test request.
- **Prompt injection:** M1 exposes no model-callable arbitrary tools and no command runner. Prompt-injection scanning is not treated as containment.
- **Untrusted commands escaping:** not mitigated by a sandbox in M1; commands are not available at all and sandbox resolver fails closed.
- **False completion:** deterministic completion-gate helper requires required checks/criteria evidence and review; full mission/evidence store integration remains M2.
- **Cost surprises:** live provider call requires both `--live` and `--approve-context-sharing`; a minimal diagnostic prompt only; unknown cost stays unknown.
- **Audit tampering / cross-process sequencing:** local audit is an append-oriented log and is not signed. Cross-process locks and tamper-evident integrity are not implemented in M1.
- **TOCTOU/hardlink bypass:** hardlink files are rejected, symlinks are rejected and final file is opened with no-follow where supported. Parent-path swap resistance is incomplete; do not expose writes/commands based on this check alone.

## Residual risks

M1 path checking is a defense-in-depth helper, not a security boundary against a hostile same-user process racing filesystem operations. Redaction is heuristic. There is no proven OS sandbox, no secure mission persistence/lock protocol, no extension/MCP runtime, and no independent penetration test. Do not run untrusted commands through Forge or claim the tool is secure/production-ready.
