# Forge CLI TypeScript Worktree — Status

**Status date:** 2026-10-24  
**Development version:** `0.6.0-ts.2`  
**Release state:** Development preview; not production-qualified.

## Version/history discipline

- `reference/continuation-pack/` and `reference/v0.4.4/` preserve the recovered continuation archive and JavaScript v0.4.4 reference release.
- Other historical versions live in the master continuation archive; historical test counts do not transfer to this TypeScript worktree.
- `0.6.0-ts.2` is a separate TypeScript development stream, not the legacy JavaScript `0.6.0` line.
- Never publish or call this production-ready until the remaining acceptance gates have attached evidence.

## Current TypeScript implementation

| Area | Current status | Evidence and limits |
|---|---|---|
| CLI | Implemented development interface | Help/version/init/doctor/config/model test/files/index/context/agents/plan/run/mission/apply/verify/resume/undo/freeze/unfreeze/sandbox status/self-test, memory, and pilot. Some commands are intentionally blocked where runtime gates are missing. |
| Strict config | Implemented supported TOML subset | Known keys and value bounds are validated, unsafe URL/key-source configuration is rejected, telemetry stays off. It is not a full general TOML implementation. |
| Canonical contracts | Implemented | Typed Mission, Step, AgentMessage, ToolCall, SafetyDecision, EvidenceRef, VerificationResult, provider and sandbox contracts. Runtime boundaries are schema/policy validated. |
| Providers | Implemented adapter layer | OpenAI-compatible HTTP adapter, direct Anthropic adapter and Google GenAI adapter with mock contract tests. Ollama can be addressed through its OpenAI-compatible endpoint. No live remote/local model-backed coding run is recorded. |
| Repository context | Implemented heuristic first pass | Ignore-aware walker, bounded index, heuristic symbol and import extraction, dependency hints, project-bound index, context pack with secret exclusions and byte budget. Not AST/LSP-complete; large files are omitted rather than truncated. |
| Workflow/agents | Bounded model-role workflow | Orchestrator/Researcher/Architect/Coder/Tester/Reviewer/Security/DevOps roles have constrained prompt/output handling. Roles are sequential model calls, not independently isolated parallel agents. |
| Patch apply/undo | Implemented with explicit approval | Hash-bound context, patch preview, explicit apply approval, checkpoints, conflict-aware undo, freeze guard, failed-apply state correction. No autonomous edit loop. |
| Mission persistence | Implemented first version | Atomic checksummed project-bound state, legal transitions, mission locks, stale local PID recovery, advisory/blocked steps and conservative resume. Needs longer crash/race/power-loss stress tests. |
| Evidence store/completion | Implemented first version | Content-addressed evidence with SHA-256 validation, private local storage, metadata/text redaction, deterministic gate that blocks missing/failed required evidence. Evidence does not itself prove an external system was safe. |
| Audit | Implemented | Local JSONL, redaction before persistence, bounded event/log reads, concurrency-safe event sequence tested across several Node processes. Not cryptographically signed or tamper-evident against a local attacker with write access. |
| Linux isolation prototype | Tested, not production-qualified | Disposable snapshot, unshare user/mount/PID/network/IPC/UTS namespaces, chroot, read-only system binds, private tmpfs masks, secret-file filtering, clean env, setpriv no-new-privileges/capability dropping, host localhost network denial, bounded output and timeout cleanup. `/proc` is deliberately not mounted on this kernel. **No Landlock or seccomp-bpf filter; no independent review.** Not registered for coding/test execution. |
| macOS/Windows sandbox | Not implemented | Must remain blocked, no shell fallback. macOS Seatbelt and a separately reviewed Windows strategy are still required. |
| Container image trust | Not implemented | No enforced digest/signature/provenance, image SBOM, vulnerability or license policy. |
| Browser QA | Not production-integrated | System Chromium/Python Playwright exist in the implementation environment, but Forge does not yet run its live HTTP/Playwright test workflow end-to-end with sandbox evidence. |
| Install/reproducibility | Tarball smoke PASS; lockfile gate BLOCKED | `npm pack` succeeded and the tarball was installed offline into a fresh temporary project. `forge --version`, `--help`, `init`, `doctor`, `config show`, `files list`, `audit`, `sandbox status`, and the fixed `sandbox self-test` ran. No `package-lock.json` could be generated because registry access was unavailable. Global TypeScript 5.8.3 and globally available Node typings were used for checks; this is not a lockfile-based reproducible source install. |
| CI/supply chain | Workflow exists, evidence incomplete | CI matrix and release scripts exist; no hosted Linux/macOS/Windows CI run evidence, full lockfile audit, SBOM, licensing inventory or independent source audit was retrieved in this run. |
| Real-model quality | Not verified | Automated provider tests use local fixtures. No real provider credentials or live model task were used. |
| Competitive benchmark/user validation | Not done | No matched, controlled benchmark against Codex/Claude Code, no 20–30 user study and no product-market-fit claim. |

## Inherited base-branch verification — 2026-10-23 (historical ts.1 snapshot)

- `npm test`: **74 passed, 0 failed, 0 skipped**. This includes TypeScript typecheck, clean build, unit/integration/security tests, namespace security tests and CLI sandbox self-test.
- Linux namespace negative tests executed against the actual kernel: writes stay in the disposable copy; system bind mounts are read-only; private credential fixture files are omitted/masked; a live host localhost TCP listener is unreachable from the network namespace; timed-out tasks are killed and the original fixture remains unchanged.
- `forge sandbox self-test`: PASS on this Linux runtime for its fixed disposable fixture. The command emits `productionReady: false` and explicitly reports Landlock/seccomp as false.
- `npm pack` and a fresh offline tarball-install smoke test PASS for this exact updated worktree. A separate report is saved in `docs/PACKAGE_SMOKE_REPORT_2026-10-23.md`. This validates package usability, not reproducible installation from a committed lockfile.
- `npm ci`, registry dependency audit, clean install from a committed lockfile, hosted CI, macOS and Windows execution, live model tasks and independent security review remain unverified.

## Release decision

**Development progress is real; production completion is not.** Forge has a working local CLI, project memory/config, provider adapters, repository context, bounded role workflow, persistent mission/evidence records, approvals, audit, patch apply/undo, and a Linux namespace prototype. Production command execution remains blocked until Landlock/seccomp-bpf or an independently verified equivalent, platform-specific validation, and security review pass. The overall project should not be marked 100% while these gates are open.


## Memory / Decision Arena merge status (0.6.0-ts.2 WIP)

The previous 0.5.0 Memory/Decision Arena branch has been selectively merged into this new worktree. `forge memory` and `forge pilot` are now connected to the command router and current provider registry. Memory is local by default and does not feed model prompts. Saving a proposed note requires explicit confirmation. Global and current-project notes use separate directories; project notes are bound to a project identity; imports prevalidate scope; common secret-shaped strings are rejected; integrity checks compare note/index hashes. Successful mutations/verification are reflected in local audit events without logging note contents. Decision Arena has a deterministic trigger and an offline brief that refuses to fabricate a score/ranking. Live requests require explicit `--live --approve-context-sharing`, enforce local-only mode against the configured endpoint origin, and send only the decision/options. The saved perspective sections are one model response, not independent human experts or isolated agents.

## 0.6.0-ts.2 merge verification — 2026-10-24

- `npm run check:release`: PASS — typecheck, build, 92 tests, structural packaging check.
- New tests include the prior memory unit security/integrity suite, confirmation-required CLI flows, import/export/reset flow, offline trigger behavior, live-pilot no-repository/no-memory payload checks using a local HTTP fixture, local-only remote request denial, and audit non-disclosure.
- No external provider request was made. The HTTP fixture is local; it proves only what was captured in that test.
- Package-lock, `npm ci`, hosted CI, SBOM/license audit, macOS/Windows isolation and production Linux sandbox gates remain open.
