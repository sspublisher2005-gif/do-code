# Release process — blocked until gates pass

1. Commit resolved dependency lockfile; verify a clean `npm ci --ignore-scripts` install under Node 22.12+.
2. Run typecheck, build, all tests, syntax checks and CLI smoke on Linux/macOS/Windows.
3. Run `npm audit --audit-level=high`, generate SBOM, enumerate transitive licenses, check package contents/paths, and record artifact SHA-256. Review policy and exceptions.
4. `npm pack` and install the tarball into a clean temporary directory; call the installed CLI help/version/init/doctor commands.
5. Collect hosted CI output plus supported-platform sandbox evidence; unsupported platform must fail closed.
6. Run at least one approved real model-backed coding task and one local-model task with patch/test/evidence verification. Store proof artifacts with secrets removed.
7. Complete independent sandbox/security review, recovery and privacy isolation gates. No unresolved critical/high issue can be silently dismissed.
8. Validate onboarding with new users and customer demand separately from engineering checks.
9. Tag and publish only after the owner explicitly releases the candidate. Do not publish this private development worktree as v1.0.0.

Current blocked item: `package-lock.json` has not been generated because npm registry requests timed out in the recovery environment. Never create fake integrity fields or claim a clean-room install without an actual resolved lock.
