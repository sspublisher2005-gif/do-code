# Evidence and truthful completion

A model message is not verification evidence. `VerificationResult.completionAllowed` must be computed from runtime checks, evidence hashes and policy rather than set by a model or role label.

## Required evidence kinds

Test/typecheck/lint logs, patch artifact, changed-file snapshots, review report, security report, browser report and screenshots where relevant, manual attestation only for checks that cannot be automated. Each persisted artifact will carry mission/step provenance, SHA-256, size/media type, producer, timestamp and a safe private URI.

## Completion requirements

A mission may be `completed` only when:

- every required acceptance criterion has at least one linked, verified evidence item;
- every required test/typecheck/lint/browser/security check passes where applicable;
- reviewer verdict passes and is linked to the exact patch hash;
- no unresolved blocking security finding exists;
- output artifacts and repository state match the verified run;
- the mission state transition is legal and persisted atomically.

Missing evidence means `incomplete` or `needs_review`, failed required check or blocking security warning means `failed`. A tool exception, missing provider usage, skipped required test or incomplete browser check cannot be converted into success by prose.

`src/verification/completion-gate.ts` implements a small deterministic helper and has tests. The mission persistence/evidence store and full integration are not shipped in M1.
