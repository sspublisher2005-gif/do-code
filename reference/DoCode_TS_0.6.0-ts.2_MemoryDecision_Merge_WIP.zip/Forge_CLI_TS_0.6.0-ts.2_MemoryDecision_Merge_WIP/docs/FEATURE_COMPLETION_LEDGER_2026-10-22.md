# Forge CLI — Feature Completion Ledger

**As of:** 2026-10-22, local worktree run  
**Rule:** No aggregate completion percentage is reported. A feature is marked **PASS** only for the bounded behavior covered by named passing tests. Passing a component test does not prove production readiness, market demand, security against all attacks, or superiority to competitors.

## Verification evidence recorded in this worktree

| Evidence item | Result | Limits |
|---|---|---|
| `npm test` | **PASS — 75 tests, 0 failures, 0 skipped** | Runs strict typecheck, build and Node test suite with local/global compiler environment. Not a lockfile-based clean dependency install. |
| TypeScript typecheck | **PASS** | The available global TypeScript 5.8.3 compiler and locally available Node declarations were used. The package declares a newer compiler range; the exact declared toolchain was not installed from a lockfile here. |
| TypeScript build | **PASS** | Builds current `src/` into `dist/`. |
| Previous M2 source archive integrity | **PASS** | `unzip -t` passed for the prior M2 archive before this feature increment. |
| Current source ZIP integrity | **PASS after final packaging** | `unzip -t` passed for the freshly generated current ZIP. |
| npm package tarball | **PASS** | `npm pack` produced `forge-coding-harness@0.5.0` with the new Memory and Pilot commands in the packaged `dist/` tree. This is still a development artifact. |
| Clean-room package install and smoke | **PASS for tested command paths** | Fresh temporary project; `npm install --offline --ignore-scripts` from exact final tarball, then version/help/init/doctor/config/files/audit/mission/memory proposal confirmation/search/show/verify/pilot smoke. See `verification/2026-10-22/clean-room-smoke.txt`. |
| Lockfile / `npm ci` | **BLOCKED** | No committed `package-lock.json`; registry resolution did not complete in the available setup. |
| Hosted Linux/macOS/Windows CI | **NOT VERIFIED** | Workflow is configured, but no hosted run evidence is attached to this worktree check. |
| Real external model-backed coding run | **NOT RUN** | No live model request was made by the test suite. |
| Real sandbox isolation tests | **NOT IMPLEMENTED** | Sandbox resolver fails closed; no command execution is enabled. |
| External security review / customer study / matched benchmark | **NOT RUN** | No claim of independent review, product-market fit or competitor superiority. |

## Feature ledger

| Requirement / feature | Status | Passing-test evidence | What the tests actually establish / remaining gate |
|---|---|---|---|
| CLI help, version and symlink entrypoint | **PASS (bounded)** | Integration: help/version deterministic; npm-style symlink entrypoint | CLI starts in tested Linux environment. No Windows/macOS hosted result yet. |
| `forge init` and repeat-safe local setup | **PASS (bounded)** | Integration: init local-only; existing files are preserved on repeat | Does not establish complete onboarding quality with users. |
| Strict TOML subset and secret-env allowlist | **PASS (bounded)** | Unit: defaults, valid config, unknown fields, unsafe URL, missing/symlink config, environment allowlist | This is a documented subset, not full TOML conformance or a credentials vault. |
| OpenAI-compatible provider adapter | **PASS with local fixture** | Integration: response/usage normalization, unknown-cost semantics, redacted provider errors, timeout/size and URL guards | No live provider or real coding task was run; direct Anthropic/Google adapters are absent. Ollama uses compatible endpoints only. |
| Safe workspace list/read/search | **PASS for tested cases** | Unit/security: traversal, secret paths, symlink/special/binary/size restrictions; literal search | Read-only foundation only. Race resistance and every OS-specific path edge are not proven. |
| Write preview | **PASS as non-mutating preview** | Unit: workspace hash unchanged and mutation flag false | Actual writes, approved patch application, checkpoints and undo are not shipped. |
| Local JSONL audit and redaction | **PASS for tested cases** | Unit: JSONL sequence, common secret redaction, corrupt tail behavior, event size cap | Not cryptographically tamper-proof and not proven to have multi-process sequence serialization. |
| Mission state persistence | **PASS for tested storage operations** | Unit/integration: schema/checksum, canonical project binding, transition validation, symlink/corrupt state, stale/live locks, concurrent cancellation | Not a full resumable agent run. Crash injection across all phases and partial-edit rollback remain open. |
| Evidence artifact store | **PASS for byte/manifest integrity cases** | Unit/integration: stored hash and manifest, tamper detection, project/mission attachment, size/symlink guards | Integrity is not substantive correctness proof; no end-to-end coding evidence flow is connected. |
| Evidence-gated completion rule | **PASS as an isolated deterministic gate** | Unit: failed/missing checks and blocking security warnings prevent completion | Mission execution is absent, so this gate does not yet determine the result of a real coding run. |
| Local Learning Memory — Markdown notes + JSON index | **PASS for core store paths** | Unit: Obsidian-style frontmatter, JSON index, global/project separation, keyword ranking, stale-index detection/reindex, schema failures, vault symlink rejection | No embeddings, automatic cross-project import, model memory retrieval, or automatic learning loop. The JSON index is a cache, not tamper-proof authenticity. |
| Memory proposal confirmation | **PASS for tested CLI path** | Integration: proposal shown but not saved by default in noninteractive use; confirmed note can be searched, verified, exported and forgotten | TTY editor interaction and every export/import/reset error path are not all covered yet. Secret redaction is heuristic and cannot guarantee removal of every secret. |
| User preferences are saved only after confirmation | **PASS for the tested write path** | All proposal writes require interactive yes or explicit `--confirm`; there is no automatic preference capture | Repetition detection is not implemented; repeated preferences still require an explicit confirmed proposal. |
| Decision Arena trigger policy | **PASS as pure policy** | Unit: simple task bypasses, explicit compare/high risk/high cost/two prior failures/security/privacy/financial/production/strategic signals trigger | Automatic detection inside `forge run` is not wired because a run/agent execution loop is not shipped. `forge pilot` is explicit. |
| Offline `forge pilot` brief | **PASS as honest template** | Integration: no model/research, no fabricated rankings, trigger rationale surfaced | It does not produce evidence-ranked options offline; user or an approved model must supply analysis. |
| Live `forge pilot` brief | **Consent guard implemented; live result not tested** | Integration: live use without context-sharing approval is blocked | No external model request was sent. Approved mode only sends decision text and user-supplied options; it attaches no repo or memory and does not browse the web. |
| Optimist/Skeptic/Pragmatist review names | **PARTIAL** | Live prompt defines these as perspectives and discloses one model is not independent humans | They are prompt sections, not separate agents or independent reviews. No model-backed output quality validation. |
| Model failure escalation policy | **PASS as policy helper** | Unit: retry once, choose configured free alternative, then local, ask before paid, or stop/rollback | It is not connected to a running coder loop, because no live coding loop exists. No free-provider quota integration. |
| Memory privacy / no telemetry | **PASS for memory command path** | Source path has no provider client; CLI tests use offline mode and no provider call | No global network monitor ran. Does not prove every future tool route will always obey this rule; regression tests are required as integrations are added. |
| Real sandbox security | **NOT IMPLEMENTED** | No real sandbox security test passed | Requires enforced native/container driver plus real negative tests for network, filesystem, secrets, limits, cancellation and cleanup. |
| Sandbox image trust / provenance / SBOM | **NOT IMPLEMENTED** | No acceptance test/report | Needs digest/signature policy, image scanning, SBOM and release-blocking rules. |
| True crash-safe resume / transactional rollback | **PARTIAL** | Mission store and stale-lock tests pass | No exact step/transcript restore; no phase-by-phase crash injection; safe conflict-aware undo not implemented. |
| Real coding-agent execution | **NOT IMPLEMENTED** | No live task result | No coder loop, actual patch application, sandboxed test runner or live model coding evidence. |
| End-to-end truthfulness on completed coding tasks | **PARTIAL** | Completion-gate unit tests prevent several false-success states | Not connected to executed real tasks, so there is no complete-to-test-run proof. |
| Cross-platform Linux/macOS/Windows | **NOT VERIFIED** | Local typecheck/tests only | Need hosted OS results including path, permissions, process cancellation and sandbox-specific tests. |
| Browser E2E with Playwright/Chromium | **NOT IMPLEMENTED in TypeScript worktree** | No current end-to-end browser acceptance test | Need served sample app, desktop/mobile journey, screenshots/traces, console/network assertions and a seeded-fault test. |
| Reproducible release and clean-room install | **PARTIAL** | Prior tarball smoke passed; this increment is building a new tarball | The newest archive must pass clean-install smoke; lockfile and `npm ci` remain blocked. |
| Dependency/supply-chain security and licensing | **NOT VERIFIED** | No lockfile audit/SBOM/license inventory from this run | Must generate lockfile, audit, inventory licenses, produce SBOM/checksums/provenance, inspect notices and retain results. |
| Matched competitor benchmark | **NOT RUN** | No matched benchmark data | Use same tasks/models/budgets/tool access and publish source patches, failures, costs and latency. Do not claim superiority. |
| Onboarding usability | **PARTIAL** | CLI help, doctor and error pathways have automated tests | No observed beginner/pro usability study. |
| Customer validation, 20–30 users | **NOT RUN** | No interviews or observed tests | Required evidence includes task success, help needed, repeat usage and willingness-to-pay notes. |
| Product expansion: more agents, providers, remote MCP/ACP, team/cloud/GUI | **DEFERRED** | Explicitly excluded from current milestone | Reconsider after safe, verifiable local coding and real-user value are demonstrated. |

## Interpretation rules

- **PASS (bounded)** means the named deterministic behavior passed the cited local tests; it does not certify an entire category.
- **PARTIAL** means some code/tests exist but the full acceptance gate has not passed.
- **NOT IMPLEMENTED / NOT RUN / NOT VERIFIED** must not be converted into completion credit.
- A module or policy helper that is not connected to a real execution workflow must be described as a helper, not an active product capability.
- No aggregate completion percentage is reported in this ledger. The next meaningful progress update is a change in a specific gate supported by new test artifacts.
