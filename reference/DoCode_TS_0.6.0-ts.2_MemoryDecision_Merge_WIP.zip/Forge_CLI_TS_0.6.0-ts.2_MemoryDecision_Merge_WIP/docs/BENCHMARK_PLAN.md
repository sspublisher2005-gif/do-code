# Controlled coding-agent benchmark plan

No superiority claim exists. Benchmark only after sandbox and evidence gates allow fair, safe execution.

- Compare Forge against Claude Code and Codex CLI on a fixed set of 30–50 held-out tasks, later expand with repeated seeds.
- Fix repository commit, model/version, available tools, context budget, network policy, execution limits, test suite and cost ceiling per task; record any unavoidable difference.
- Include small/medium repo changes, cross-file refactors, bug fixes, test generation, browser UI corrections, security-sensitive fixes, incomplete specifications, and malicious prompt-injection fixtures.
- Primary metrics: task success by tests, acceptance-criterion coverage, regression rate, independent human patch grade, security policy violations, evidence completeness, rollback correctness and context retrieval precision.
- Secondary metrics: wall time, model/tool attempts, provider-reported tokens/cost, context preparation overhead, repair loops and operator interventions.
- Repeat each model/task enough to estimate variance. Keep failed and timed-out tasks in denominators. Publish raw sanitized run manifests and evaluation rubric.
- Review anonymized patches blind to tool identity. Do not compare on a few cherry-picked demos; do not equate more agent roles with better outcomes.
