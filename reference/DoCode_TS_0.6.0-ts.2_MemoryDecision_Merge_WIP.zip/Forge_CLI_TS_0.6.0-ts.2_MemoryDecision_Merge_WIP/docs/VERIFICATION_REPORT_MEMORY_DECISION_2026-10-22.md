# Forge CLI v0.5.0 — Memory and Decision Arena Increment Verification

**Date:** 2026-10-22  
**Artifact:** TypeScript development worktree, package `forge-coding-harness@0.5.0`  
**Verdict:** Local command/package checks pass for the bounded features listed here. Forge remains a development preview; the report does not certify production readiness.

## Executed checks

| Check | Result | Evidence and limitation |
|---|---|---|
| `npm test` | **PASS — 75 tests, 0 failed, 0 skipped** | Runs strict TypeScript typecheck, build and Node unit/integration/security tests. Uses available global TypeScript 5.8.3 plus environment-provided Node declarations; not a lockfile-pinned toolchain. |
| `npm run check:release` | **PASS** | Same 75-test suite plus structural package file check; not a security audit. |
| `npm pack` | **PASS** | Generated `forge-coding-harness-0.5.0.tgz`, with 147 packaged files at this build. Development artifact only; not published to npm. |
| Offline clean-room install | **PASS** | `npm install --offline --ignore-scripts` of the tarball into a fresh temporary project. |
| Installed CLI smoke | **PASS for tested commands** | Version/help/init/doctor/config show/files list/audit/mission create/memory proposal+search+verify/offline pilot. The exact-tarball smoke summary is included in `verification/2026-10-22/clean-room-smoke.txt`; detailed command outputs are provided alongside it. |
| Memory confirmation semantics | **PASS for tested paths** | An unconfirmed proposal is displayed but not saved; a saved note records confirmation; the storage API refuses `confirmed: false`. Notes are Markdown; index consistency is checked. |
| Memory privacy/scope | **PASS for tested paths** | Tests cover global/project segregation, vault-symlink rejection, common-secret pattern rejection, stale-index detection and project-bound import rejection before writes. Common-secret detection remains heuristic. |
| Decision trigger policy | **PASS as a deterministic helper** | Unit tests cover explicit comparison, high risk/cost, multiple alternatives, prior failures and security/privacy/financial/production/strategic signals. Not automatically wired into a coding run loop. |
| Live pilot consent/data boundary | **PASS against local HTTP fixture only** | A fake local endpoint receives the explicitly approved decision text and options. Test asserts repository-source and local-memory sentinel strings are not in the request. No external provider was contacted. |
| Model fallback policy | **PASS as a pure policy helper** | Tests cover retry-once, alternative free model, local model, ask-before-paid and stop/rollback. Not connected to a live coder loop. |
| Current source ZIP integrity | **PASS** | `unzip -t` performed on the generated source ZIP. This checks archive integrity, not source correctness. |
| `package-lock.json` / `npm ci` | **BLOCKED** | No lockfile was fabricated because registry resolution was not available during the work. |
| Real model-backed coding run | **NOT RUN** | No real external coding-task request or patch was executed. |
| Real OS sandbox security matrix | **NOT IMPLEMENTED** | Sandbox resolver remains fail-closed; no shell/command execution path is enabled. |
| Hosted CI, SBOM, provenance and license audit | **NOT VERIFIED / NOT RUN** | Workflow exists; no hosted run, SBOM, provenance report, or full license inventory is attached. |
| Browser E2E / competitor benchmark / customer validation | **NOT RUN** | No Playwright end-to-end fixture run, matched competitor benchmark, independent review, or user interview series in this increment. |

## Behavior added and tested

### Local Learning Memory

- Added Obsidian-compatible Markdown notes with validated frontmatter and a rebuildable JSON index.
- Added global and current-project scopes using separate storage paths.
- Added keyword search with title weighting.
- Added user-visible proposal preview; unconfirmed draft is marked `userConfirmed: false` and cannot be saved by the storage API without explicit confirmation.
- Added show, list, noninteractive edit-path display / interactive editor support, forget, integrity verify, reindex, export, import, open-path and reset commands.
- Import requires confirmation, regenerates IDs, prevalidates all project bindings before any writes, and refuses cross-project note import.
- Core validates the same common secret-pattern heuristic as the CLI.
- Memory notes are not automatically injected into providers. The live Decision Arena path intentionally sends only the decision statement and supplied options.

Limitations: heuristic secret detection cannot guarantee that all secrets are absent; checksums are not signatures; note factual freshness is not automatically checked; automatic memory extraction from coding missions is not implemented because the coding loop is not implemented.

### Decision Arena Lite

- Added deterministic trigger policy and tests for the threshold signals.
- Added offline `forge pilot` output that never invents scores/ranks or claims research it did not perform.
- Added optional live brief only after both explicit flags are passed.
- Model prompt describes Optimist/Skeptic/Pragmatist as structured perspectives generated by one model, not independent humans or separate agent calls.
- The current CLI does not perform web research, auto-accept a recommendation, or save decisions without a separate confirmed memory proposal.

### Model failure escape hatch

- Added/tested a pure policy helper to retry once, choose an untried configured free model, then a local model, then ask before paid use only if budget permits, otherwise stop/rollback.
- No automatic model switching happens in a real coding loop yet; the loop itself is not shipped.

## Release decision

**Keep as a development preview.** The bounded code paths above are implemented and tested. Do not claim the full product is complete, secure against untrusted command execution, better than Claude Code/Codex/OpenCode, or ready for an unrestricted public launch. The blocking gates remain a real sandbox with adversarial proof, crash-safe step recovery, live model-backed code task, lockfile/hosted CI and supply-chain qualification, and external validation.

Use `docs/FEATURE_COMPLETION_LEDGER_2026-10-22.md` as the authoritative per-feature status record. No single overall completion percentage is used.
