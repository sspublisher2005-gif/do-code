# Recovery and rollback roadmap

The recovered v0.4.4 JS ZIP and npm tarball are preserved unchanged in `reference/v0.4.4/`. Their historical test evidence applies only to that artifact.

M2 will add a versioned mission store, atomic JSON persistence, root identity, SHA-256 integrity, stale-lock detection, bounded lock lease/recovery, and conservative resume that never silently replays a write step. A crash at any mission transition must leave either the prior valid state or an explicitly interrupted state.

Rollback/checkpoints must record before/after hashes. Undo is permitted only when current file hashes match the recorded post-write state. If the user changed a file after the checkpoint, rollback must refuse and explain the conflict; it must never overwrite newer work.

Audit JSONL in M1 is useful for operational inspection but is not cryptographically signed, tamper-proof, or coordinated with other Forge processes. No checkpoint restore command ships yet.
