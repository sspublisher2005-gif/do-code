# Decision Arena Lite — v0.1 scope

## Trigger policy

The deterministic trigger helper returns `shouldRun=true` for an explicit request/comparison, high risk, estimated cost at/above the configured threshold (default USD 5), two or more prior failures, multiple plausible approaches, high uncertainty, or known security/privacy/financial/production/strategic impact. A simple task does not trigger the arena. The function is unit-tested but is not wired into a task runner because `forge run` is not implemented.

## Current commands

`forge pilot "decision"` is an explicit entry point. Offline mode shows the task, supplied options, trigger reasons, and comparison criteria but refuses to fabricate scores or ranking without evidence. Live mode requires `--live --approve-context-sharing`; it sends only the decision and user-provided candidate options to the configured OpenAI-compatible/Ollama endpoint. Repo contents, global memory and project memory are not attached; no web browsing is performed.

The prompted report asks for goal, provided facts, assumptions/unknowns, 2–4 options, Optimist/Skeptic/Pragmatist perspectives, errors in user framing, weaknesses in the model recommendation, qualitative comparison, ranked options only with justified basis, risks, what changes/doesn't, what-if analysis, approvals, and user choices. The CLI explicitly discloses that all sections come from a single model call—not independent human experts or three independent model runs. Live quality has not yet been validated because no external request was made in this test run.

## Required behavior later

- Connect this trigger to a safe mission planner, without running it for trivial tasks.
- Retrieve relevant local memory for comparison without sending it to a provider; explicit, scoped consent is required before any excerpt could be transmitted.
- Add approved official-doc/web research with timestamps, citations, source quality, and a strict rule not to claim research if it did not happen.
- Save only a user-confirmed final decision using `forge memory propose --type decision ...`.
- Add tests for contradictory sources, stale claims, model hallucinated citations, cost limits, refusal to auto-accept recommendations, and provider failure.
