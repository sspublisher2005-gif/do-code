# Memory / Decision Arena merge report — 0.6.0-ts.2

Date: 2026-10-24
Parent source: saved TypeScript branch `0.6.0-ts.1` source archive (`Forge_CLI_TS_0.6.0-ts.1_Source_Updated.zip`).
Feature source: saved `Forge_CLI_v0.5.0_Memory_Decision_WIP.zip`.
Status: development WIP; the parent source and feature branch are preserved separately.

## Merged modules

- `src/memory/types.ts`: explicit note/proposal/draft types, scopes, confidence and status.
- `src/memory/markdown-store.ts`: local Obsidian-compatible Markdown files, global/current-project scope, SHA-256 index, schema validation, secret heuristics, verification, search, reindex, confirmed import/export/reset, edit, symlink checks and atomic create/replacement.
- `src/decisions/trigger.ts`: deterministic trigger rule for explicit comparison, risk, cost threshold, repeated failures, alternatives, uncertainty and security/privacy/financial/production/strategic impact.
- `src/cli/commands/memory.ts`: list/search/show/propose/edit/forget/verify/reindex/export/import/open/reset with confirmation for writes/destructive operations; audit records do not include note contents.
- `src/cli/commands/pilot.ts`: offline Decision Arena brief and opt-in live brief routed through the active provider registry instead of hardcoding OpenAI-compatible/OpenAI+Ollama only.
- CLI router and help updated to `0.6.0-ts.2`.
- Focused local-memory and Decision Arena documentation ported into `docs/LOCAL_MEMORY.md` and `docs/DECISION_ARENA.md`.

## Security/product invariants retained

- Non-interactive memory proposals are never persisted unless `--confirm` is present.
- Project-scoped notes must match the current canonical project ID; cross-project project-memory imports are rejected after prevalidating all entries.
- Memory is not automatically sent to providers or injected into context packs. The live pilot transmits only decision text/options and disclosed risk signals, after `--live --approve-context-sharing`.
- `privacy.mode = "local-only"` blocks remote pilot requests before the network call. Obvious credential-shaped decision/option strings are rejected before any live request.
- Offline pilot mode does not generate numeric scores or rank alternatives without evidence.
- All named decision perspectives are written by one model response; they are not represented as independent humans or independent agents.
- Memory note proposal/save, forget, verify, edit, reindex, export, import and reset create local audit summaries that do not contain note body/query text. Audit failure after a completed memory operation emits a warning instead of falsely reporting the memory mutation as rolled back.

## Verification

`npm run check:release` passed with **92 tests, 0 failures, 0 skips** in the local Node 22.16 environment. An `npm pack` tarball was installed offline into a fresh temporary consumer; installed CLI version/help/init/doctor/memory list/offline pilot/sandbox status smoke passed. The suite uses a local HTTP fixture for the opt-in live pilot test; no real API request or model charge was performed. The release script is structural, not a hosted CI/security certification.

## Known remaining caveats

- `package-lock.json` is still missing; dependency/version resolution and `npm ci` have not been qualified in a network-enabled clean environment.
- No cross-process lock is implemented for the whole memory-vault mutation/index rebuild. Atomic note creation and index replacement reduce risks, but concurrent writers may still race index updates. Add a vault-wide lock and multi-process race tests before promoting memory beyond preview.
- The memory secret filter is heuristic, not a guarantee. Do not put credentials or sensitive personal data into memory.
- Memory import prevalidates scope and schema, but the series of note writes is not a transaction over the whole import; disk failure mid-import may leave a partial set. This should be improved with staged import/rollback before declaring bulk import strongly atomic.
- No automatic memory extraction, auto-injection, semantic/vector search or stale-claim web revalidation is implemented.
- Decision trigger helper is available, but it is not automatically wired into the planner/run loop.
- General build/test/shell execution remains blocked behind production sandbox qualification. Linux namespace prototype still has `productionReady=false`, lacks Landlock/seccomp-bpf, has not undergone independent security review; macOS/Windows sandbox drivers are not implemented.
