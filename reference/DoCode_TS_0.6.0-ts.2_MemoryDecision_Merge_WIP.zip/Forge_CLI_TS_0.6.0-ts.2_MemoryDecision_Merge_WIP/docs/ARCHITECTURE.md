# Architecture and trust boundaries

## M1 implemented path

`CLI -> config validation -> policy/path checks -> read-only file tools or explicit model adapter -> redacted local audit`

- `core/types.ts` owns canonical public interfaces.
- `core/mission-state.ts` owns the legal transition table; callers cannot skip it by supplying model text.
- `safety/policy-engine.ts` is deterministic and denies writes, process tools, credential access, network tools and destructive actions in M1.
- `tools/safe-files.ts` is the only implemented workspace content interface. It is bounded and read-only.
- `providers/openai-compatible.ts` uses built-in `fetch`; no provider SDK is needed in the M1 runtime path.
- `audit/jsonl.ts` stores bounded local event summaries. It is not cryptographically tamper-proof and does not store full prompts or code excerpts by default.
- `sandbox/resolver.ts` always fails closed because no verified sandbox driver exists in this worktree.

## Target coding workflow (not yet shipped)

1. Validate a mission and its acceptance criteria.
2. Build a bounded task context pack using safe repository walk/index rules.
3. Orchestrator creates versioned steps and role-scoped requests.
4. Researcher and Architect propose findings/plan; Coder returns a patch proposal, not a direct file write.
5. Safety broker validates all tool calls and obtains user approval where permitted.
6. An actual sandbox driver executes approved tests in an isolated workspace.
7. Tester, Reviewer and Security Agent return structured assessments.
8. Evidence store hashes test logs, patch, browser report and required review/security outputs.
9. Deterministic completion gate blocks `completed` unless every required criterion has verified evidence and no required check failed or remains unknown.

Role names are organizational boundaries, not security isolation. Only deterministic runtime policy can grant capability.
