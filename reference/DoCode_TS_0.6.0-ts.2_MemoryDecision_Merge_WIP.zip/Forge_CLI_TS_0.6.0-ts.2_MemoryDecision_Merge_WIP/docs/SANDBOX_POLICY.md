# Sandbox policy and driver status

## Execution policy

General coding/test command execution remains disabled through Forge. `resolveSandboxDriver()` must fail closed and must never fall back to the host shell. `forge sandbox self-test` is the only CLI path that runs a command in the experimental Linux namespace driver; it uses a fixed script and temporary synthetic fixture only. It cannot run user-supplied commands and is not wired into `forge run`, `forge verify`, or the agent tool registry.

## Tested Linux namespace prototype (not production-ready)

`src/sandbox/linux/namespace-driver.ts` is a local prototype tested on the current Linux runtime. It uses:

- unprivileged user, mount, PID, network, IPC and UTS namespaces;
- a chroot made from read-only system directory binds plus empty/private tmpfs masks;
- a disposable copy of the project, with `.git`, `.forge`, env files, credential-named files, home/cloud/SSH config and secret-looking text omitted;
- workspace-only persistent writes inside the disposable copy; `/tmp` is ephemeral;
- a clean environment, `setpriv --no-new-privs`, dropped capability sets, timeout/process-group termination, `prlimit`, bounded stdout/stderr and cleanup;
- default deny-all networking; allowlist networking is not supported by this prototype.

Local negative tests currently prove that the disposable workspace can be written without changing the original project, host system paths are read-only, sensitive fixture files are omitted, a connection to a live host localhost TCP listener fails from the child network namespace, outside-workspace writes are blocked by read-only masks, and timeout cleanup works.

Known limitations:

- **Landlock is not applied.** The current runtime returns `ENOSYS` for the Landlock ruleset-version syscall; this prototype must not pretend otherwise.
- **seccomp-bpf is not applied.** Dangerous syscalls are not independently filtered by a syscall policy.
- `/proc` cannot safely be mounted in the current unprivileged namespace environment; it remains absent. Some tools/runtimes expect it.
- No cgroup CPU/memory isolation is available; `prlimit` enforces per-process limits such as CPU time, address space, process count and file size, not a whole-tree aggregate RSS ceiling.
- Snapshot copying has a larger race window than openat/descriptor-pinned traversal; do not treat it as a complete defence against a hostile process concurrently mutating the source tree.
- No independent penetration test or hostile workload benchmark has been run.

For these reasons capabilities report `landlock: false`, `seccompBpf: false`, and `productionReady: false`. The production resolver must not select this prototype for untrusted command execution.

## Required production drivers

- **Linux/WSL2:** prefer Bubblewrap namespaces with disposable workspace, Landlock and seccomp-bpf where supported, deny-all egress, resource limits, process-tree cancellation and cleanup. Fail closed if any security primitive fails its runtime probe.
- **macOS:** Seatbelt profile with minimum required file/process/network capabilities and negative tests; fail closed when the correct policy API is not available.
- **Windows:** no native driver is enabled until an independently reviewed implementation exists; no direct PowerShell/CMD execution fallback.
- **Optional containers:** Docker/Podman only for dependency installs/unknown scripts after immutable image digest, signature/provenance, SBOM, vulnerability and license checks. Use non-root identities, read-only rootfs, restricted mounts, denied network unless separately approved, dropped capabilities, limits and cleanup.
- **Optional strong isolation:** Firecracker on Linux/KVM or gVisor when supported and justified by the threat model.

## Image trust/provenance

Pin images by immutable digest; reject mutable tags; verify registry, signature and provenance; create/verify SBOMs; enforce vulnerability/license policy; store image digest and runtime identity in mission evidence. Any mismatch, unavailable capability or cleanup error blocks completion.

This policy is intentionally stricter than the current prototype. Documentation is not proof of implementation or security.
