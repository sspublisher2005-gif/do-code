# Forge CLI — Continuation Context

**Checkpoint date:** 2026-10-21  
**Current reference release:** Forge Unified v0.4.4  
**Use this file as the handoff anchor for the next Forge-only session.**

## Scope and isolation

This context is only for Forge. Do not import Settlewise, PS TRI, games, or any other project into Forge unless the user explicitly authorizes that cross-project import. Keep Forge files, history, audit logs, memory and plans project-bound. No cross-project automatic search or memory merge.

## Latest recovered artifacts

- `baseline/Forge_Unified_v0.4.4.zip` — latest unified source/documentation archive recovered from the library.
- `baseline/forge-coding-harness-0.4.4.tgz` — npm package tarball for `forge-coding-harness@0.4.4`.
- `baseline/Forge_Unified_v0.4.4.sha256` — supplied SHA-256 file; hashes were independently recomputed and match.
- `verification/RELEASE_VERIFICATION_2026-10-21_v0.4.4.md` — original release-verification report.
- `verification/REMAINING_WORK_AND_ACCEPTANCE_GATES_2026-10-21.md` — open acceptance gates.
- `verification/forge-v0.4.4-check-release.log`, `forge-v0.4.4-browser-smoke.log`, and `forge-v0.4.4-zip-extract-validation.log` — original supporting artifacts.
- `history/forge-project-history-handoff.md` and `history/MASTER_HANDOFF_REPORT(1).docx` — historic handoff material; useful for lineage, but older architecture/state statements must not override v0.4.4 evidence.
- `planning/TYPESCRIPT_MVP_IMPLEMENTATION_PLAN.md` — target architecture, layout, contracts, dependency plan, build order, test plan and first-milestone acceptance criteria.
- `verification/independent-local-rerun/` — test/check/CLI outputs produced during this recovery in the current environment.

## Current reference artifact verification performed in this recovery

Environment: Node.js `v22.16.0`, npm `10.9.2`, Linux container.

- ZIP path entries inspected: 179; no absolute or `..` traversal entries found.
- ZIP hash: `a8ee95139d6f7e703d4ef3d4b7c3f7a174906736c9c7774a229438b73209572d` — matches supplied checksum.
- npm tarball hash: `b6697318ac7b3b4c6f0a662b0fe91a15ead0ea95a10b06d473ffa10e4fd51852` — matches supplied checksum.
- `npm test`: **129 passed, 0 failed, 0 skipped**.
- `npm run check`: **32 JavaScript files syntax-checked successfully**.
- `node bin/forge.js --version`: **0.4.4**.
- `node bin/forge.js --help`: exit code 0; CLI help printed.

These are local package/source checks only. They do not prove production security or end-to-end model-backed code quality.

## Target architecture — locked decisions from the user

- TypeScript + Node.js, strict mode; provider-agnostic model adapters for OpenAI-compatible APIs, Anthropic, Google, and Ollama/local.
- Repo-aware context engine: repository map, symbol index, dependency graph, task context packs, bounded context and deterministic local exclusion rules.
- Roles: Orchestrator, Researcher, Architect, Coder, Tester, Reviewer, Security Agent and DevOps Agent. Names/prompts do not create security boundaries; all side effects must route through one runtime policy broker.
- Evidence-gated completion: a mission cannot be `completed` without passing verification and review gates and linked evidence.
- Local audit log, token/cost meter with unknown values honestly unknown, checkpoint/undo, dry-run, no telemetry by default.
- Project-local `FORGE.md`; user-selected `forge.config.toml`; explicit project identity and privacy boundaries.
- Default execution boundary: native OS sandbox — macOS Seatbelt; Linux/WSL2 Bubblewrap + Landlock + seccomp-bpf. Optional Docker/Podman for dependency installs and unknown scripts. Optional Firecracker on Linux/KVM and gVisor where appropriate. Unsupported platform or unavailable isolation must fail closed; never silently fall back to executing untrusted code on the host.
- Deny-by-default network; workspace-only writes; secret redaction; resource/timeout limits; controlled process-tree cancellation; cleanup.

## Confirmed mismatch between v0.4.4 and the locked target

| Area | v0.4.4 recovered implementation | Target / next action |
|---|---|---|
| Language | 41 JavaScript source/test/script files; zero TypeScript files in the unified ZIP | Create a strict TypeScript implementation path; preserve v0.4.4 as a reference archive, not the target truth. |
| Config | `forge.config.json` | Migrate to validated `forge.config.toml`; define migration/compatibility rules explicitly. |
| Model access | Existing `src/llm.js` supports OpenCode CLI and direct OpenRouter paths | Introduce a typed `ModelProvider` contract and first-class OpenAI-compatible, Anthropic, Google, Ollama adapters, contract tests and usage normalization. |
| Sandbox default | Optional Docker/Podman disposable-copy execution; tests fail closed if runtime missing. Ordinary approved commands can still execute on host. Windows sandbox unavailable. | Native OS sandbox must be the default for risky/untrusted commands. Host execution only for narrow, explicit, low-risk operations; fail closed if no enforced boundary. |
| Repository context | Deterministic file index and approximate import graph; useful but heuristic | Explicit repo map, symbol index, dependency graph and bounded task context pack contracts, measured by retrieval tests. |
| Multi-agent | Planner/coder/reviewer flow plus bounded optional read-only specialists | Make all agent/tool messages typed; privilege enforcement remains in Forge runtime, not agent prompts. |
| Completion gate | Tests/review/security/browser outcomes gate completion, with known remaining heuristic gaps | Versioned acceptance contract linking every criterion to verified evidence; missing evidence means incomplete. |
| Evidence of production readiness | No real Docker/Podman isolation/escape run, live-provider task, hosted CI result, trusted image SBOM/provenance run, independent security review or customer validation | Keep these explicitly blocked until the evidence exists. |

## Recovery decision

Do **not** overwrite the v0.4.4 artifact in place. Start the spec-aligned TypeScript MVP in a separate directory/branch. Extract current behaviors as contract references, then implement, test and migrate deliberately. Do not claim parity merely because equivalent filenames exist.

## Immediate next steps

1. Create the TypeScript repository skeleton in the layout defined in `planning/TYPESCRIPT_MVP_IMPLEMENTATION_PLAN.md`.
2. Commit strict TS config, package scripts, lockfile and `Mission`, `Step`, `AgentMessage`, `ToolCall`, `SafetyDecision`, `EvidenceRef`, `VerificationResult` contracts.
3. Implement Milestone M1: CLI + TOML config + provider interface/one mockable adapter + safe workspace file tools + redacted append-only audit log.
4. Make all tests pass from a clean install. Keep arbitrary shell tools, autonomous patch application and “completed” status disabled until policy and evidence gates are implemented.
5. Follow with mission persistence, repo context packs, verification gate, then sandbox drivers and adversarial security tests.

## Release rule

A package being built, a local test suite passing, a live-provider task passing, an OS sandbox being effective, an external security review passing, cross-platform CI passing and product-market validation are distinct claims. Report each separately. Never claim “production-ready”, “fully secure”, “better than Codex/Claude Code”, or “100% complete” without appropriate evidence.
