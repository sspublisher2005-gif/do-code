# Test strategy

## M1 tests implemented in this worktree

- Unit: config defaults/parser/schema/unknown keys/unsafe endpoints; mission and step transitions; path normalization and symlink rejection; bounded file tools; audit redaction/JSONL/corrupt lines; default-deny policy; completion helper.
- Integration: CLI help/version/init/idempotency; offline model-test behavior and consent gate; OpenAI-compatible adapter against a local fixture server; HTTP error-body secrecy; dry-run write preview hash preservation.
- Security: traversal/outside-workspace sentinel, symlink alias, credential path and binary file denial, remote HTTP/userinfo/query/endpoint URL rejection, recursive secret redaction, M1 write/process denial.

## Must be added before relevant feature gates

- Symlink swap/TOCTOU and hardlink tests across supported OSes.
- Malformed provider output, timeout/cancellation, 429/5xx budgets, cost unknown semantics and context size caps.
- Cross-process append/lock sequencing, corrupted mission store, partial writes, stale PID/lock and concurrent resume.
- Model-injected patch validation, hostile repository prompt instructions, secret sentinel isolation, no ambient provider credentials in child process.
- Sandbox negative tests: blocked network, host-home/outside-workspace sentinels, limits, cancellation/process-tree kill and cleanup; container digest/provenance/SBOM mismatch.
- Real HTTP-served Playwright fixture with desktop/mobile interactions, console/page/network failures, screenshots/traces, seeded UI regression and sandbox-backed exact app hash.
- Windows/macOS/Linux package, path, signal, permissions and process-tree CI; clean-room tarball install and artifact checksums.

Tests must distinguish a unit mock, local HTTP fixture, real provider call, real sandbox run, hosted CI and external security review. They are different evidence classes.
