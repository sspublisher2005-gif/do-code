# Forge v0.5.0 TypeScript MVP — Verification Report

Date: 2026-10-22

## Executed checks

| Check | Result | Scope |
|---|---|---|
| TypeScript typecheck | PASS | Environment's globally installed TypeScript 5.8.3 and Node declarations; exact lockfile compiler not verified |
| TypeScript build | PASS | Generates `dist/` from strict TS config |
| Unit, integration, and security test suite | PASS — 36 / 36 | Deterministic local tests and local HTTP fixture; not a live model call |
| Structural release check | PASS | Required package files and CLI shebang/entry hash only |
| `npm pack` | PASS | `forge-coding-harness@0.5.0` archive built locally (111 files, about 65.7 kB compressed in the final pack) |
| Clean-room tarball install | PASS | Installed offline in a fresh temp project; CLI version, help, init, and doctor tested |
| npm-style symlink entrypoint | PASS | Regression test verifies CLI invokes through a symlink |
| Dependency lock / reproducible `npm ci` | BLOCKED | Registry connection timed out while resolving dev dependencies; no lockfile was generated |
| Live model-backed coding task | NOT RUN | No live network call or external model spend was made |
| OS sandbox adversarial suite | NOT IMPLEMENTED | No sandbox driver is enabled; current resolver fails closed |
| Hosted Linux/macOS/Windows CI | NOT VERIFIED | Workflow exists; no hosted result available |
| SBOM/provenance/license audit | NOT RUN | Release gate remains open |

## Notable fixes found while testing

1. An npm-installed symlink could bypass the CLI's direct-entrypoint check, so the CLI printed nothing despite a zero exit code. The entrypoint now resolves real paths, with a regression test.
2. The provider response parser now has a 2 MiB body cap.
3. A provider field named `cost` is not assumed to mean USD. Cost stays unknown unless `cost_usd` is present and valid.
4. `healthCheck()` does not send a request unless the caller explicitly passes `networkConsent: true`.
5. Audit events are capped at 16 KiB before append, and audit file permissions are tightened to owner read/write where supported.
6. Config rejects arbitrary environment variables as API-key sources and the live-test output names the configured endpoint origin before sending its diagnostic prompt.

## Release decision

**Development preview only. Not production-ready.** M1 is not complete until the lockfile/clean install and related release checks are repeatable. Do not use this build to execute untrusted code: arbitrary shell execution and OS sandbox execution are intentionally absent.
