# Forge project continuity — 2026-10-24

## Current branch / progress

- Active development worktree in this bundle: `0.6.0-ts.2` (TypeScript).
- Parent source: `0.6.0-ts.1` from the October 23 update.
- Selectively merged feature branch: `0.5.0` Memory/Decision WIP.
- Frozen JS/reference builds (including v0.4.5, v0.4.4 and historical v0.6.0) remain separate and must not be conflated by version number alone.
- Overall product completion estimate remains approximately **55% provisional** from the saved October 23 project-state report. Do not rebase to 25%, which was the M1-only scope error. The percentage is not a verified quality score; update it only after a consistent whole-project review.

## Verified in the 0.6.0-ts.2 worktree

- `npm run check:release`: 92 tests passed, zero failed, zero skipped; structural release check passed.
- `npm pack` generated `forge-coding-harness-0.6.0-ts.2.tgz`; it installed with `npm install --offline --ignore-scripts` into a fresh temporary consumer. Installed CLI version/help/init/doctor/memory list/offline pilot/sandbox status succeeded.
- Local HTTP fixture tests verified that the explicitly approved Decision Arena request does not include project files or memory. Obvious credential-shaped decision text is blocked before the request. No live model call was performed.
- The package and source zip are development WIP only; `package-lock.json` is absent and clean `npm ci` remains unverified.

## Preserved branches

- `0.6.0-ts.1`: unchanged previous active TypeScript code branch.
- `0.5.0` Memory/Decision WIP: preserved separately in the historical feature branch.
- `0.5.0` M2 mission persistence WIP and plan: preserved separately.
- Historical JavaScript v0.4.5 and v0.4.4 reference releases remain available in the master transfer archive.

## Next blockers

1. Resolve dependency versions and commit a real lockfile in a network-enabled environment; run `npm ci`, build, tests and tarball tests from that locked setup.
2. Add a vault-wide cross-process lock to Memory and transactional/staged bulk import. Test concurrent writers, partial import failure, interrupted indexing and malicious filesystem races.
3. Integrate Decision Arena's deterministic trigger into the actual planner only after policy tests; do not auto-send or auto-accept.
4. Production sandbox: Linux Landlock/seccomp-bpf or independently reviewed equivalent; macOS Seatbelt and Windows support; adversarial network/host-file/resource/cancellation/cleanup tests. Until then general build/test/shell execution must remain blocked.
5. Hosted CI, SBOM, licenses, package provenance/checksums, live model-backed coding task, integrated Playwright E2E, independent security review, controlled benchmark and 20–30 customer validation.
