import { constants } from "node:fs";
import { lstat, open, readdir, realpath } from "node:fs/promises";
import { join, relative, sep } from "node:path";
import { ForgeError } from "../core/errors.js";
import { noFollowFlag, resolveExistingPath, shouldSkipDirectory, validateRelativePath } from "../safety/path-policy.js";

export interface FileToolLimits {
  maxReadBytes: number;
  maxFiles: number;
  maxSearchMatches: number;
}
export interface ListedFile {
  path: string;
  kind: "file" | "directory";
  sizeBytes: number;
}
export interface SearchMatch {
  path: string;
  line: number;
  text: string;
}
const DEFAULT_LIMITS: FileToolLimits = { maxReadBytes: 256 * 1024, maxFiles: 1000, maxSearchMatches: 200 };
const BINARY_EXTENSIONS = new Set([".png", ".jpg", ".jpeg", ".gif", ".webp", ".ico", ".pdf", ".zip", ".gz", ".tgz", ".7z", ".exe", ".dll", ".so", ".dylib", ".class", ".jar", ".woff", ".woff2", ".ttf", ".otf", ".mp4", ".mov", ".mp3", ".wav", ".sqlite", ".db"]);

export class SafeFileTools {
  readonly #root: string;
  readonly #limits: FileToolLimits;

  private constructor(root: string, limits: FileToolLimits) {
    this.#root = root;
    this.#limits = limits;
  }

  static async create(root: string, limits: Partial<FileToolLimits> = {}): Promise<SafeFileTools> {
    const canonicalRoot = await realpath(root);
    const info = await lstat(canonicalRoot);
    if (!info.isDirectory()) throw new ForgeError("WORKSPACE_INVALID", "Workspace root must be a directory.");
    const merged = { ...DEFAULT_LIMITS, ...limits };
    for (const [name, value] of Object.entries(merged)) {
      if (!Number.isSafeInteger(value) || value < 1) throw new ForgeError("FILE_LIMIT_INVALID", `File-tool limit ${name} must be a positive safe integer.`);
    }
    return new SafeFileTools(canonicalRoot, merged);
  }

  async list(requestedPath = ".", recursive = true): Promise<ListedFile[]> {
    const start = await resolveExistingPath(this.#root, requestedPath, "directory");
    const results: ListedFile[] = [];
    const queue: Array<{ absolute: string; relative: string }> = [{ absolute: start.absolutePath, relative: start.relativePath }];
    while (queue.length > 0) {
      const current = queue.shift();
      if (!current) break;
      let names: string[];
      try { names = (await readdir(current.absolute)).sort((a: string, b: string) => a.localeCompare(b, "en")); }
      catch { continue; }
      for (const name of names) {
        if (shouldSkipDirectory(name)) continue;
        const childRelative = current.relative === "." ? name : `${current.relative}${sep}${name}`;
        // The path policy excludes secret names, including .env variants.
        let child;
        try { child = await resolveExistingPath(this.#root, childRelative, "any"); }
        catch (error) {
          if (error instanceof ForgeError && ["PATH_SYMLINK_DENIED", "PATH_SENSITIVE_DENIED", "PATH_SPECIAL_FILE_DENIED", "PATH_PRIVATE_DIRECTORY"].includes(error.code)) continue;
          continue;
        }
        if (child.stat.isDirectory()) {
          results.push({ path: child.relativePath, kind: "directory", sizeBytes: 0 });
          if (recursive) queue.push({ absolute: child.absolutePath, relative: child.relativePath });
        } else if (child.stat.isFile()) {
          results.push({ path: child.relativePath, kind: "file", sizeBytes: Number(child.stat.size) });
        }
        if (results.length >= this.#limits.maxFiles) return results;
      }
    }
    return results;
  }

  async read(requestedPath: string): Promise<string> {
    const safe = await resolveExistingPath(this.#root, requestedPath, "file");
    if (safe.stat.size > this.#limits.maxReadBytes) {
      throw new ForgeError("FILE_TOO_LARGE", `File exceeds the ${this.#limits.maxReadBytes}-byte read limit.`);
    }
    const extension = requestedPath.toLowerCase().slice(requestedPath.lastIndexOf("."));
    if (BINARY_EXTENSIONS.has(extension)) {
      throw new ForgeError("FILE_BINARY_DENIED", "Binary files are not rendered by text file tools.");
    }
    const handle = await open(safe.absolutePath, constants.O_RDONLY | noFollowFlag());
    try {
      const stat = await handle.stat();
      if (!stat.isFile() || stat.size > this.#limits.maxReadBytes) throw new ForgeError("FILE_CHANGED", "File changed during validation; refusing to read it.");
      const buffer = await handle.readFile();
      if (buffer.includes(0)) throw new ForgeError("FILE_BINARY_DENIED", "Binary files are not rendered by text file tools.");
      try { return new TextDecoder("utf-8", { fatal: true }).decode(buffer); }
      catch { throw new ForgeError("FILE_ENCODING_DENIED", "File is not valid UTF-8 text."); }
    } finally {
      await handle.close();
    }
  }

  async search(query: string, requestedPath = "."): Promise<SearchMatch[]> {
    if (query.length === 0) throw new ForgeError("SEARCH_EMPTY", "Search query must not be empty.");
    if (query.length > 500) throw new ForgeError("SEARCH_TOO_LONG", "Search query exceeds 500 characters.");
    const base = await resolveExistingPath(this.#root, requestedPath, "directory");
    const files = await this.list(base.relativePath, true);
    const matches: SearchMatch[] = [];
    for (const entry of files) {
      if (entry.kind !== "file" || BINARY_EXTENSIONS.has(entry.path.toLowerCase().slice(entry.path.lastIndexOf(".")))) continue;
      try {
        const text = await this.read(entry.path);
        const lines = text.split(/\r?\n/);
        for (let i = 0; i < lines.length; i += 1) {
          const line = lines[i] ?? "";
          if (line.includes(query)) {
            matches.push({ path: entry.path, line: i + 1, text: line.slice(0, 500) });
            if (matches.length >= this.#limits.maxSearchMatches) return matches;
          }
        }
      } catch {
        // Unreadable, denied, binary, or over-limit files are skipped; none is opened with write access.
      }
    }
    return matches;
  }

  /** M1 shows preview-only proposed writes; it never mutates repository files. */
  writePreview(requestedPath: string, contents: string): { path: string; bytes: number; preview: string; mutationPerformed: false } {
    const normalized = validateRelativePath(requestedPath);
    if (normalized === ".") throw new ForgeError("WRITE_PATH_INVALID", "A regular workspace file path is required.");
    if (Buffer.byteLength(contents, "utf8") > this.#limits.maxReadBytes) throw new ForgeError("WRITE_PREVIEW_TOO_LARGE", "Proposed contents exceed the configured preview size limit.");
    return { path: normalized, bytes: Buffer.byteLength(contents, "utf8"), preview: contents.slice(0, 4000), mutationPerformed: false };
  }
}
