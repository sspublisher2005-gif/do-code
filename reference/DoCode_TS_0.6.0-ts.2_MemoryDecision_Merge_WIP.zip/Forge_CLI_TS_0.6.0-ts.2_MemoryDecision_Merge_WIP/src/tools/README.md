# Tools and policy boundary

M1 tool surface: bounded file list/read/literal search and a non-mutating write preview. All proposed model tool arguments must be treated as `unknown` and validated before policy evaluation. Planned tools include patch preview, Git read-only metadata and sandbox-bound verification commands. No model/tool gets raw filesystem/process/network/browser capability.
