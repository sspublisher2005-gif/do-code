import { constants as fsConstants } from "node:fs";
import { chmod, copyFile, lstat, mkdir, open, readFile, realpath, rename, readdir, unlink, writeFile } from "node:fs/promises";
import { createHash, randomUUID } from "node:crypto";
import { dirname, join, relative, sep } from "node:path";
import { ForgeError } from "../core/errors.js";
import { ensureProjectHome } from "../privacy/project-home.js";
import { resolveExistingPath, validateRelativePath } from "../safety/path-policy.js";
import { appendAudit } from "../audit/jsonl.js";
import { assertWorkspaceNotFrozen } from "../safety/freeze.js";
import { redactString } from "../safety/secret-redaction.js";

export interface ProposedFileChange { path: string; expectedSha256: string; newContent: string; reason: string }
export interface ProposedPatch { schemaVersion: 1; id: string; missionId: string; createdAt: string; files: ProposedFileChange[]; source: "model_proposal" }
interface CheckpointFile { path: string; beforeContent: string; beforeSha256: string; afterSha256: string; mode: number }
interface Checkpoint { schemaVersion: 1; id: string; missionId: string; root: string; createdAt: string; files: CheckpointFile[] }

const MAX_PATCH_BYTES = 2 * 1024 * 1024;
const MAX_PATCH_FILES = 50;

export function parseModelPatch(text: string, missionId: string, allowedFiles: Map<string, { sha256: string; content: string }>): ProposedPatch {
  if (Buffer.byteLength(text, "utf8") > MAX_PATCH_BYTES) throw new ForgeError("PATCH_TOO_LARGE", "Model patch proposal exceeds the 2 MiB limit.");
  const trimmed = text.trim().replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/, "");
  let parsed: unknown;
  try { parsed = JSON.parse(trimmed) as unknown; } catch { throw new ForgeError("PATCH_FORMAT_INVALID", "Coder output must be a JSON object containing a files array; no changes were written."); }
  if (!isRecord(parsed) || !Array.isArray(parsed.files) || parsed.files.length < 1 || parsed.files.length > MAX_PATCH_FILES) throw new ForgeError("PATCH_FORMAT_INVALID", `Patch must contain 1–${MAX_PATCH_FILES} file changes.`);
  const changes: ProposedFileChange[] = []; const seen = new Set<string>(); let total = 0;
  for (const raw of parsed.files) {
    if (!isRecord(raw) || typeof raw.path !== "string" || typeof raw.content !== "string") throw new ForgeError("PATCH_FORMAT_INVALID", "Every patch file needs a path and complete new content string.");
    const path = validateRelativePath(raw.path).replace(/\\/g, "/");
    if (path === "." || seen.has(path)) throw new ForgeError("PATCH_PATH_INVALID", "Patch paths must be unique workspace-relative file paths.");
    const prior = allowedFiles.get(path);
    if (!prior) throw new ForgeError("PATCH_OUTSIDE_CONTEXT", `Coder proposed '${path}', which was not included in the task context. No changes were written.`);
    if (Buffer.byteLength(raw.content, "utf8") > 512 * 1024) throw new ForgeError("PATCH_FILE_TOO_LARGE", `Proposed contents for '${path}' exceed 512 KiB.`);
    if (raw.content.includes("\0")) throw new ForgeError("PATCH_BINARY_DENIED", "Binary file edits are not supported.");
    if (redactString(raw.content) !== raw.content) throw new ForgeError("PATCH_SECRET_SUSPECTED", `Patch content for '${path}' resembles a credential. Remove secrets before proposing a patch.`);
    const newContent = raw.content;
    total += Buffer.byteLength(newContent, "utf8"); if (total > MAX_PATCH_BYTES) throw new ForgeError("PATCH_TOO_LARGE", "Total proposed patch exceeds the 2 MiB limit.");
    const reason = typeof raw.reason === "string" ? raw.reason.slice(0, 1000) : "No rationale provided by coder.";
    if (redactString(reason) !== reason) throw new ForgeError("PATCH_SECRET_SUSPECTED", `Patch rationale for '${path}' resembles a credential. Remove secrets before proposing a patch.`);
    changes.push({ path, expectedSha256: prior.sha256, newContent, reason });
    seen.add(path);
  }
  return { schemaVersion: 1, id: randomUUID(), missionId, createdAt: new Date().toISOString(), files: changes, source: "model_proposal" };
}

export async function previewPatch(root: string, patch: ProposedPatch): Promise<string> {
  const canonicalRoot = await realpath(root); const blocks: string[] = [`Patch ${patch.id}`, `Mission: ${patch.missionId}`, `Files: ${patch.files.length}`, "NO FILES HAVE BEEN MODIFIED."];
  for (const change of patch.files) {
    const safe = await resolveExistingPath(canonicalRoot, change.path, "file");
    const current = await readNoFollow(safe.absolutePath);
    const actual = hash(current.content);
    blocks.push(`\n--- ${change.path} ---\nExpected current SHA-256: ${change.expectedSha256}\nActual current SHA-256:   ${actual}\nReason: ${change.reason}\nProposed bytes: ${Buffer.byteLength(change.newContent, "utf8")}`);
    if (actual !== change.expectedSha256) blocks.push("CONFLICT: current file differs from the version used to create this proposal.");
    else blocks.push("PRECONDITION: matches context snapshot.");
    blocks.push("--- proposed content preview (first 40 lines) ---\n" + change.newContent.split(/\r?\n/).slice(0, 40).join("\n"));
  }
  return blocks.join("\n");
}

export async function applyPatch(root: string, patch: ProposedPatch, approval: boolean): Promise<{ checkpointId: string; changedPaths: string[]; bytesWritten: number }> {
  await assertWorkspaceNotFrozen(root, "patch application");
  if (!approval) throw new ForgeError("PATCH_APPROVAL_REQUIRED", "Patch application requires explicit --approve. Run without it to preview; no files were written.");
  const canonicalRoot = await realpath(root); const { home } = await ensureProjectHome(canonicalRoot);
  const validated: Array<{ change: ProposedFileChange; absolute: string; before: string; beforeHash: string; mode: number }> = [];
  for (const change of patch.files) {
    const safe = await resolveExistingPath(canonicalRoot, change.path, "file");
    const current = await readNoFollow(safe.absolutePath);
    const actual = hash(current.content);
    if (actual !== change.expectedSha256) throw new ForgeError("PATCH_CONFLICT", `File '${change.path}' changed since the proposal was created. Refusing to overwrite it.`);
    if (change.newContent === current.content) continue;
    validated.push({ change, absolute: safe.absolutePath, before: current.content, beforeHash: actual, mode: current.mode });
  }
  if (!validated.length) throw new ForgeError("PATCH_NO_CHANGES", "Patch contains no changes to apply.");
  const checkpointId = randomUUID();
  const checkpoint: Checkpoint = {
    schemaVersion: 1, id: checkpointId, missionId: patch.missionId, root: canonicalRoot, createdAt: new Date().toISOString(),
    files: validated.map(({ change, before, beforeHash, mode }) => ({ path: change.path, beforeContent: before, beforeSha256: beforeHash, afterSha256: hash(change.newContent), mode })),
  };
  const checkpointDir = join(home, "checkpoints", patch.missionId);
  await ensureSafeDir(join(home, "checkpoints")); await ensureSafeDir(checkpointDir);
  await atomicPrivateJson(join(checkpointDir, `${checkpointId}.json`), checkpoint);
  const applied: typeof validated = [];
  try {
    for (const entry of validated) {
      await atomicReplace(canonicalRoot, entry.change.path, entry.change.expectedSha256, entry.change.newContent, entry.mode);
      applied.push(entry);
    }
  } catch (error) {
    // Best-effort rollback only when current bytes still equal the patch output. Preserve later edits.
    for (const entry of [...applied].reverse()) {
      try { await atomicReplace(canonicalRoot, entry.change.path, hash(entry.change.newContent), entry.before, entry.mode); }
      catch { /* checkpoint is preserved for manual recovery; do not overwrite divergent files */ }
    }
    await appendAudit(canonicalRoot, { event: "patch.apply_failure", outcome: "failed", missionId: patch.missionId, details: { checkpointId, changedBeforeFailure: applied.length, error: "Patch application failed; rollback attempted only for files still matching proposed hashes." } }).catch(() => undefined);
    throw error;
  }
  const bytesWritten = validated.reduce((sum: number, e) => sum + Buffer.byteLength(e.change.newContent, "utf8"), 0);
  await appendAudit(canonicalRoot, { event: "patch.applied", outcome: "succeeded", missionId: patch.missionId, details: { checkpointId, files: validated.length, bytesWritten, automaticTestsRun: false } });
  return { checkpointId, changedPaths: validated.map((e) => e.change.path), bytesWritten };
}

export async function listCheckpoints(root: string, missionId: string): Promise<string[]> {
  assertUuid(missionId); const { home } = await ensureProjectHome(root); const dir = join(home, "checkpoints", missionId);
  return (await readdir(dir).catch((e: unknown) => { if (hasCode(e, "ENOENT")) return []; throw e; })).filter((n: string) => /^[0-9a-f-]{36}\.json$/i.test(n)).map((n: string) => n.slice(0, -5)).sort();
}

export async function undoCheckpoint(root: string, missionId: string, checkpointId: string, approval: boolean): Promise<{ restoredPaths: string[] }> {
  if (!approval) throw new ForgeError("UNDO_APPROVAL_REQUIRED", "Rollback requires explicit --approve. No files were modified.");
  assertUuid(missionId); assertUuid(checkpointId);
  const canonicalRoot = await realpath(root); const { home } = await ensureProjectHome(canonicalRoot);
  const path = join(home, "checkpoints", missionId, `${checkpointId}.json`);
  const info = await lstat(path).catch((e: unknown) => { if (hasCode(e, "ENOENT")) throw new ForgeError("CHECKPOINT_NOT_FOUND", "Checkpoint does not exist for this mission."); throw e; });
  if (!info.isFile() || info.isSymbolicLink() || info.size > MAX_PATCH_BYTES * 3) throw new ForgeError("CHECKPOINT_UNSAFE", "Checkpoint is unsafe or too large.");
  let cp: Checkpoint; try { cp = JSON.parse(await readFile(path, "utf8")) as Checkpoint; } catch { throw new ForgeError("CHECKPOINT_CORRUPT", "Checkpoint JSON is corrupt; no restore was attempted."); }
  if (!cp || cp.schemaVersion !== 1 || cp.id !== checkpointId || cp.missionId !== missionId || cp.root !== canonicalRoot || !Array.isArray(cp.files) || cp.files.length < 1 || cp.files.length > MAX_PATCH_FILES) throw new ForgeError("CHECKPOINT_CORRUPT", "Checkpoint identity/schema validation failed; no restore was attempted.");
  // Validate all hashes before restoring any file.
  const currentFiles: Array<{ cpFile: CheckpointFile; absolute: string }> = [];
  for (const file of cp.files) {
    const safe = await resolveExistingPath(canonicalRoot, file.path, "file"); const current = await readNoFollow(safe.absolutePath);
    if (hash(current.content) !== file.afterSha256) throw new ForgeError("UNDO_CONFLICT", `File '${file.path}' changed since the checkpoint. Nothing was restored.`);
    if (hash(file.beforeContent) !== file.beforeSha256) throw new ForgeError("CHECKPOINT_INTEGRITY", `Checkpoint content hash failed for '${file.path}'.`);
    currentFiles.push({ cpFile: file, absolute: safe.absolutePath });
  }
  const restored: string[] = [];
  for (const { cpFile } of currentFiles) {
    await atomicReplace(canonicalRoot, cpFile.path, cpFile.afterSha256, cpFile.beforeContent, cpFile.mode); restored.push(cpFile.path);
  }
  await appendAudit(canonicalRoot, { event: "patch.undo", outcome: "succeeded", missionId, details: { checkpointId, restoredFiles: restored.length } });
  return { restoredPaths: restored };
}

async function atomicReplace(root: string, path: string, expectedHash: string, nextContent: string, mode: number): Promise<void> {
  const safe = await resolveExistingPath(root, path, "file");
  const before = await readNoFollow(safe.absolutePath);
  if (hash(before.content) !== expectedHash) throw new ForgeError("PATCH_CONFLICT", `File '${path}' no longer matches the expected hash; refusing to overwrite it.`);
  const parent = dirname(safe.absolutePath); const canonicalParent = await realpath(parent);
  if (canonicalParent !== parent) throw new ForgeError("PATCH_PARENT_CHANGED", `Parent path for '${path}' changed during validation.`);
  const temp = join(parent, `.forge-tmp-${randomUUID()}`); const h = await open(temp, fsConstants.O_CREAT | fsConstants.O_EXCL | fsConstants.O_WRONLY | (fsConstants.O_NOFOLLOW ?? 0), 0o600);
  try { await h.writeFile(nextContent, "utf8"); await h.chmod(mode & 0o777); await h.sync(); } finally { await h.close(); }
  try {
    const latest = await resolveExistingPath(root, path, "file");
    if (latest.absolutePath !== safe.absolutePath || hash((await readNoFollow(latest.absolutePath)).content) !== expectedHash) throw new ForgeError("PATCH_RACE_DETECTED", `File '${path}' changed during the write window; refusing to replace it.`);
    await rename(temp, safe.absolutePath);
  } catch (error) { await unlink(temp).catch(() => undefined); throw error; }
}
async function readNoFollow(path: string): Promise<{ content: string; mode: number }> {
  const handle = await open(path, fsConstants.O_RDONLY | (fsConstants.O_NOFOLLOW ?? 0));
  try { const stat = await handle.stat(); if (!stat.isFile() || stat.size > MAX_PATCH_BYTES) throw new ForgeError("PATCH_FILE_UNSAFE", "Patch target is not a bounded regular file."); const b = await handle.readFile(); if (b.includes(0)) throw new ForgeError("PATCH_BINARY_DENIED", "Binary patch targets are not supported."); let content: string; try { content = new TextDecoder("utf-8", { fatal: true }).decode(b); } catch { throw new ForgeError("PATCH_ENCODING_DENIED", "Patch target is not UTF-8 text."); } return { content, mode: stat.mode & 0o777 }; } finally { await handle.close(); }
}
async function ensureSafeDir(path: string): Promise<void> { try { await mkdir(path, { mode: 0o700 }); } catch (e) { if (!hasCode(e, "EEXIST")) throw e; } const info = await lstat(path); if (!info.isDirectory() || info.isSymbolicLink()) throw new ForgeError("CHECKPOINT_PATH_UNSAFE", "Checkpoint path must be a real directory."); await chmod(path, 0o700).catch(() => undefined); }
async function atomicPrivateJson(path: string, value: unknown): Promise<void> { const temp = `${path}.${randomUUID()}.tmp`; const h = await open(temp, fsConstants.O_CREAT | fsConstants.O_EXCL | fsConstants.O_WRONLY, 0o600); try { await h.writeFile(`${JSON.stringify(value)}\n`, "utf8"); await h.sync(); } finally { await h.close(); } try { await rename(temp, path); } catch (e) { await unlink(temp).catch(() => undefined); throw e; } }
function hash(content: string): string { return createHash("sha256").update(content, "utf8").digest("hex"); }
function isRecord(v: unknown): v is Record<string, unknown> { return !!v && typeof v === "object" && !Array.isArray(v); }
function assertUuid(id: string): void { if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(id)) throw new ForgeError("PATCH_ID_INVALID", "Expected a Forge-generated UUID."); }
function hasCode(error: unknown, code: string): boolean { return error !== null && typeof error === "object" && "code" in error && error.code === code; }
