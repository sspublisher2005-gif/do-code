# Repository context engine — planned for M3

Separate modules are planned for a no-follow repository walker, `.gitignore`-compatible exclusions, repository map, symbol index, dependency graph, and task context pack. A context pack must contain only allowlisted source excerpts and metadata: included file paths/reasons/hash, char/token budget, excluded candidates and omission reason. Secrets, binaries, symlinks, private state, generated output and oversized files must never enter model context. Nothing here is implemented by the M1 safe file commands.
