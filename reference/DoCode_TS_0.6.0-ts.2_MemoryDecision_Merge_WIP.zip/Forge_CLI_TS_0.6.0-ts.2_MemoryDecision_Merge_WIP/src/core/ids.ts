import { createHash, randomUUID } from "node:crypto";
import { realpath } from "node:fs/promises";

export function newId(): string {
  return randomUUID();
}

export async function projectIdFor(root: string): Promise<string> {
  const canonical = await realpath(root);
  return createHash("sha256").update(canonical, "utf8").digest("hex").slice(0, 24);
}
