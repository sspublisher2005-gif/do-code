export type ISODateTime = string;
export type Id = string;

export type MissionStatus =
  | "draft" | "awaiting_approval" | "ready" | "running" | "verifying"
  | "needs_review" | "completed" | "failed" | "cancelled" | "interrupted";
export type StepStatus =
  | "pending" | "ready" | "running" | "awaiting_approval" | "passed"
  | "failed" | "blocked" | "skipped" | "interrupted";
export type AgentRole =
  | "orchestrator" | "researcher" | "architect" | "coder"
  | "tester" | "reviewer" | "security" | "devops";
export type Capability =
  | "model" | "read_workspace" | "write_workspace" | "sandbox_command"
  | "browser" | "network_research";
export type VerificationKind =
  | "test" | "typecheck" | "lint" | "browser" | "review" | "security" | "manual";

export interface AcceptanceCriterion {
  id: Id;
  description: string;
  required: boolean;
  verificationKinds: VerificationKind[];
}

export interface Mission {
  schemaVersion: 1;
  id: Id;
  projectId: Id;
  repoRoot: string;
  objective: string;
  status: MissionStatus;
  createdAt: ISODateTime;
  updatedAt: ISODateTime;
  steps: Step[];
  acceptanceCriteria: AcceptanceCriterion[];
  maxCostUsd?: number;
  maxDurationMs: number;
  dryRun: boolean;
  approvedCapabilities: Capability[];
  evidenceIds: Id[];
}

export type StepKind = "research" | "plan" | "implement" | "test" | "review" | "security" | "devops";
export interface Step {
  id: Id;
  missionId: Id;
  ordinal: number;
  kind: StepKind;
  assignedRole: AgentRole;
  status: StepStatus;
  dependsOn: Id[];
  attempt: number;
  inputEvidenceIds: Id[];
  outputEvidenceIds: Id[];
  toolCallIds: Id[];
  createdAt: ISODateTime;
  startedAt?: ISODateTime;
  finishedAt?: ISODateTime;
  failureCode?: string;
}

export interface TokenUsage {
  inputTokens?: number;
  outputTokens?: number;
  cachedInputTokens?: number;
  costUsd?: number;
  costKnown: boolean;
  source: "provider_reported" | "estimated" | "unknown";
}

export interface AgentMessage {
  id: Id;
  missionId: Id;
  stepId?: Id;
  role: AgentRole | "user" | "system" | "tool";
  senderId: string;
  recipientId?: string;
  content: string;
  toolCallIds: Id[];
  evidenceIds: Id[];
  createdAt: ISODateTime;
  provider?: string;
  model?: string;
  usage?: TokenUsage;
  redacted: boolean;
}

export type ToolRisk = "read_only" | "workspace_write" | "process" | "network" | "credentials" | "destructive";
export type ToolCallStatus =
  | "requested" | "denied" | "awaiting_approval" | "approved" | "running"
  | "succeeded" | "failed" | "cancelled";
export interface ToolCall {
  id: Id;
  missionId: Id;
  stepId: Id;
  toolName: string;
  input: unknown;
  risk: ToolRisk;
  requestedCapabilities: string[];
  status: ToolCallStatus;
  safetyDecisionId?: Id;
  createdAt: ISODateTime;
  startedAt?: ISODateTime;
  finishedAt?: ISODateTime;
  outputEvidenceIds: Id[];
  errorCode?: string;
}

export type SafetyOutcome = "allow" | "deny" | "needs_approval";
export interface SafetyDecision {
  id: Id;
  missionId: Id;
  toolCallId?: Id;
  outcome: SafetyOutcome;
  policyVersion: string;
  ruleIds: string[];
  resource: string;
  rationale: string;
  decidedAt: ISODateTime;
  expiresAt?: ISODateTime;
  operatorId?: string;
}

export type EvidenceKind =
  | "test_log" | "typecheck_log" | "lint_log" | "patch" | "file_snapshot"
  | "browser_report" | "screenshot" | "review_report" | "security_report"
  | "manual_attestation" | "model_response" | "audit_event";
export interface EvidenceRef {
  id: Id;
  missionId: Id;
  stepId?: Id;
  kind: EvidenceKind;
  uri: string;
  sha256: string;
  createdAt: ISODateTime;
  producedBy: string;
  verified: boolean;
  mediaType?: string;
  byteLength?: number;
  metadata: Record<string, string | number | boolean | null>;
}

export type VerificationStatus = "passed" | "failed" | "incomplete" | "skipped";
export interface VerificationCheck {
  id: Id;
  name: string;
  status: VerificationStatus;
  required: boolean;
  exitCode?: number;
  durationMs?: number;
  evidenceIds: Id[];
  details?: string;
}
export interface VerificationResult {
  id: Id;
  missionId: Id;
  status: VerificationStatus;
  startedAt: ISODateTime;
  finishedAt: ISODateTime;
  checks: VerificationCheck[];
  unresolvedWarnings: string[];
  completionAllowed: boolean;
  policyVersion: string;
}

export type ProviderId = "openai-compatible" | "anthropic" | "google" | "ollama";
export interface ModelRequest {
  model: string;
  role: AgentRole;
  system: string;
  messages: Array<{ role: "user" | "assistant"; content: string }>;
  responseSchema?: Record<string, unknown>;
  maxOutputTokens: number;
  timeoutMs: number;
  signal?: AbortSignal;
}
export interface ModelResponse {
  text: string;
  provider: ProviderId;
  model: string;
  usage: TokenUsage;
  requestId?: string;
  durationMs: number;
}
export interface ModelProvider {
  readonly id: ProviderId;
  generate(request: ModelRequest): Promise<ModelResponse>;
  healthCheck(options?: { networkConsent?: boolean; signal?: AbortSignal }): Promise<{ ok: boolean; detail: string }>;
}
