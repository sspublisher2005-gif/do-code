import { ForgeError } from "./errors.js";
import type { MissionStatus, StepStatus } from "./types.js";

const missionTransitions: Readonly<Record<MissionStatus, readonly MissionStatus[]>> = {
  draft: ["awaiting_approval", "ready", "cancelled"],
  awaiting_approval: ["ready", "cancelled", "needs_review"],
  ready: ["running", "cancelled", "needs_review"],
  running: ["verifying", "failed", "cancelled", "interrupted", "needs_review"],
  verifying: ["completed", "failed", "needs_review", "interrupted"],
  needs_review: ["ready", "cancelled", "failed"],
  completed: [],
  failed: ["ready", "cancelled"],
  cancelled: [],
  interrupted: ["needs_review", "ready", "cancelled"],
};

const stepTransitions: Readonly<Record<StepStatus, readonly StepStatus[]>> = {
  pending: ["ready", "blocked", "skipped"],
  ready: ["running", "awaiting_approval", "blocked", "skipped"],
  running: ["passed", "failed", "blocked", "interrupted", "awaiting_approval"],
  awaiting_approval: ["ready", "blocked", "skipped"],
  passed: [],
  failed: ["ready", "skipped"],
  blocked: ["ready", "skipped"],
  skipped: [],
  interrupted: ["ready", "blocked"],
};

export function assertMissionTransition(from: MissionStatus, to: MissionStatus): void {
  if (!missionTransitions[from].includes(to)) {
    throw new ForgeError("INVALID_MISSION_TRANSITION", `Mission transition ${from} -> ${to} is not allowed.`);
  }
}

export function assertStepTransition(from: StepStatus, to: StepStatus): void {
  if (!stepTransitions[from].includes(to)) {
    throw new ForgeError("INVALID_STEP_TRANSITION", `Step transition ${from} -> ${to} is not allowed.`);
  }
}
