export class ForgeError extends Error {
  readonly code: string;
  readonly safeDetails?: Record<string, string | number | boolean | null>;

  constructor(code: string, message: string, safeDetails?: Record<string, string | number | boolean | null>) {
    super(message);
    this.name = "ForgeError";
    this.code = code;
    if (safeDetails !== undefined) this.safeDetails = safeDetails;
  }
}

export function errorCode(error: unknown): string {
  return error instanceof ForgeError ? error.code : "UNEXPECTED_ERROR";
}

export function safeErrorMessage(error: unknown): string {
  if (error instanceof ForgeError) return error.message;
  if (error instanceof Error) return "Unexpected error. Details were not printed to avoid leaking secrets.";
  return "Unknown error.";
}
