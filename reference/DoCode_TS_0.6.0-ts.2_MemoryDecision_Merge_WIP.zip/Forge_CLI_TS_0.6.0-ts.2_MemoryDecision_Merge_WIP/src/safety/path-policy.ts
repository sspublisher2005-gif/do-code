import { constants } from "node:fs";
import { lstat, realpath } from "node:fs/promises";
import { isAbsolute, join, relative, sep } from "node:path";
import { ForgeError } from "../core/errors.js";

const DENIED_SEGMENTS = new Set([
  ".git", ".forge", ".ssh", ".aws", ".azure", ".gnupg", ".kube", ".npmrc", ".netrc", ".pypirc",
  "credentials", "credentials.json", "secrets.json", "id_rsa", "id_ed25519", "id_ecdsa", "id_dsa",
  "known_hosts", "login data", "cookies", "cookies.sqlite", "key4.db", "logins.json",
]);
const SKIP_DIRECTORIES = new Set([
  ".git", ".forge", "node_modules", "dist", "coverage", "vendor", ".next", ".nuxt", ".venv",
  "venv", "__pycache__", ".pytest_cache", ".mypy_cache", "target", "build",
]);

export interface SafePath {
  root: string;
  absolutePath: string;
  relativePath: string;
  stat: Awaited<ReturnType<typeof lstat>>;
}

export function isDeniedSensitivePath(relativePath: string): boolean {
  const segments = relativePath.split(/[\\/]+/).filter(Boolean).map((part) => part.toLowerCase());
  return segments.some((segment) => {
    if (DENIED_SEGMENTS.has(segment)) return true;
    if (segment === ".env" || segment.startsWith(".env.")) return true;
    if (/^id_(?:rsa|ed25519|ecdsa|dsa)(?:\.pub)?$/.test(segment)) return true;
    if (/^(?:token|secret|credentials?)(?:\.[a-z0-9_-]+)?$/i.test(segment)) return true;
    return false;
  });
}

export function shouldSkipDirectory(name: string): boolean {
  return SKIP_DIRECTORIES.has(name.toLowerCase());
}

export function validateRelativePath(requestedPath: string): string {
  if (requestedPath.includes("\0")) throw new ForgeError("PATH_INVALID", "Path contains a NUL byte.");
  if (isAbsolute(requestedPath) || /^[A-Za-z]:[\\/]/.test(requestedPath) || requestedPath.startsWith("\\\\")) {
    throw new ForgeError("PATH_ABSOLUTE_DENIED", "Use a workspace-relative path; absolute paths are not allowed.");
  }
  const segments = requestedPath.split(/[\\/]+/).filter((part) => part.length > 0 && part !== ".");
  if (segments.some((part) => part === "..")) throw new ForgeError("PATH_TRAVERSAL_DENIED", "Parent-directory traversal is not allowed.");
  if (segments.length === 0) return ".";
  const normalized = segments.join(sep);
  if (isDeniedSensitivePath(normalized)) throw new ForgeError("PATH_SENSITIVE_DENIED", "Access to credential or private-state paths is denied.");
  return normalized;
}

export async function resolveExistingPath(rootInput: string, requestedPath: string, expected: "file" | "directory" | "any" = "any"): Promise<SafePath> {
  const root = await realpath(rootInput);
  const normalized = validateRelativePath(requestedPath);
  let current = root;
  const segments = normalized === "." ? [] : normalized.split(sep);
  let info = await lstat(root);
  for (let index = 0; index < segments.length; index += 1) {
    const segment = segments[index];
    if (!segment) continue;
    if (isDeniedSensitivePath(segment)) throw new ForgeError("PATH_SENSITIVE_DENIED", "Access to credential or private-state paths is denied.");
    current = join(current, segment);
    try {
      info = await lstat(current);
    } catch (error) {
      if (isNotFound(error)) throw new ForgeError("PATH_NOT_FOUND", "Requested workspace path does not exist.");
      throw error;
    }
    if (info.isSymbolicLink()) throw new ForgeError("PATH_SYMLINK_DENIED", "Symlink paths are not followed by Forge file tools.");
    const isFinal = index === segments.length - 1;
    if (!isFinal && !info.isDirectory()) throw new ForgeError("PATH_NOT_DIRECTORY", "A parent path component is not a directory.");
    if (!isFinal && shouldSkipDirectory(segment)) throw new ForgeError("PATH_PRIVATE_DIRECTORY", "Access to a private or generated directory is denied.");
  }
  if (info.isSymbolicLink()) throw new ForgeError("PATH_SYMLINK_DENIED", "Symlink paths are not followed by Forge file tools.");
  if (!(info.isFile() || info.isDirectory())) throw new ForgeError("PATH_SPECIAL_FILE_DENIED", "Special files are not supported.");
  if (info.isFile() && Number(info.nlink) > 1) throw new ForgeError("PATH_HARDLINK_DENIED", "Files with multiple hard links are denied by the M1 path policy.");
  if (expected === "file" && !info.isFile()) throw new ForgeError("PATH_NOT_FILE", "Requested path is not a regular file.");
  if (expected === "directory" && !info.isDirectory()) throw new ForgeError("PATH_NOT_DIRECTORY", "Requested path is not a directory.");
  const actual = await realpath(current);
  const rel = relative(root, actual);
  if (rel === ".." || rel.startsWith(`..${sep}`) || isAbsolute(rel)) throw new ForgeError("PATH_ESCAPE_DENIED", "Resolved path escapes the workspace root.");
  const relativePath = rel === "" ? "." : rel;
  if (relativePath !== "." && isDeniedSensitivePath(relativePath)) throw new ForgeError("PATH_SENSITIVE_DENIED", "Access to credential or private-state paths is denied.");
  return { root, absolutePath: actual, relativePath, stat: info };
}

export function noFollowFlag(): number {
  return constants.O_NOFOLLOW ?? 0;
}

function isNotFound(error: unknown): boolean {
  return error !== null && typeof error === "object" && "code" in error && error.code === "ENOENT";
}
