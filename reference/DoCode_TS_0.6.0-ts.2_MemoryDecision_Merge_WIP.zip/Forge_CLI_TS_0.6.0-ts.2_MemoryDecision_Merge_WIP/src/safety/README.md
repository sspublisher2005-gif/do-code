# Safety module

`path-policy.ts` provides bounded relative-path checks and rejects sensitive files, symlinks and hard-linked files. `secret-redaction.ts` redacts common credential patterns. `policy-engine.ts` allows only explicitly approved read-only workspace capabilities and denies writes/process/network/credential/destructive risk in M1. These controls are not a substitute for OS isolation or a protection against every parent-path TOCTOU race.
