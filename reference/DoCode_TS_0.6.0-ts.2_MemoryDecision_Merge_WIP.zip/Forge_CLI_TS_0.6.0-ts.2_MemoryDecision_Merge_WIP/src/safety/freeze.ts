import { constants as fsConstants } from "node:fs";
import { chmod, lstat, mkdir, open, readFile, rename, unlink } from "node:fs/promises";
import { randomUUID } from "node:crypto";
import { join } from "node:path";
import { ForgeError } from "../core/errors.js";
import { ensureProjectHome } from "../privacy/project-home.js";
import { appendAudit } from "../audit/jsonl.js";
import { redactString } from "./secret-redaction.js";

const FILE = "FROZEN.json";
const MAX_REASON = 2_000;
interface FreezeRecord { schemaVersion: 1; frozenAt: string; reason: string; projectRoot: string }

/** Workspace kill switch for Forge-initiated remote model calls and proposed patch application. */
export async function freezeWorkspace(rootInput: string, reasonInput = "Manual operator freeze"): Promise<FreezeRecord> {
  const { root, home } = await ensureProjectHome(rootInput);
  const reason = redactString(reasonInput).trim().slice(0, MAX_REASON) || "Manual operator freeze";
  const record: FreezeRecord = { schemaVersion: 1, frozenAt: new Date().toISOString(), reason, projectRoot: root };
  const target = join(home, FILE);
  const temp = join(home, `.${FILE}.${randomUUID()}.tmp`);
  const h = await open(temp, fsConstants.O_CREAT | fsConstants.O_EXCL | fsConstants.O_WRONLY | (fsConstants.O_NOFOLLOW ?? 0), 0o600);
  try { await h.writeFile(`${JSON.stringify(record)}\n`, "utf8"); await h.sync(); } finally { await h.close(); }
  try {
    // rename is atomic on the same filesystem; freezing intentionally replaces an existing valid freeze record.
    const current = await lstat(target).catch((e: unknown) => { if (hasCode(e, "ENOENT")) return undefined; throw e; });
    if (current && (current.isSymbolicLink() || !current.isFile() || current.size > 8192)) throw new ForgeError("FREEZE_STATE_UNSAFE", "Freeze state is unsafe; refusing to replace it.");
    await rename(temp, target); await chmod(target, 0o600).catch(() => undefined);
  } catch (e) { await unlink(temp).catch(() => undefined); throw e; }
  await appendAudit(root, { event: "workspace.freeze", outcome: "denied", details: { reason, frozenAt: record.frozenAt } });
  return record;
}

export async function readFreezeState(rootInput: string): Promise<FreezeRecord | undefined> {
  const { root, home } = await ensureProjectHome(rootInput);
  const target = join(home, FILE);
  let info;
  try { info = await lstat(target); } catch (e) { if (hasCode(e, "ENOENT")) return undefined; throw e; }
  if (info.isSymbolicLink() || !info.isFile() || info.size > 8192) throw new ForgeError("FREEZE_STATE_UNSAFE", "Freeze state is not a bounded regular file; refusing safety-sensitive operations.");
  let value: unknown;
  try { value = JSON.parse(await readFile(target, "utf8")) as unknown; }
  catch { throw new ForgeError("FREEZE_STATE_CORRUPT", "Freeze state is corrupt; safety-sensitive operations remain blocked until it is inspected manually."); }
  if (!isFreezeRecord(value) || value.projectRoot !== root) throw new ForgeError("FREEZE_STATE_CORRUPT", "Freeze record schema or project binding is invalid; safety-sensitive operations remain blocked.");
  return value;
}

export async function assertWorkspaceNotFrozen(root: string, action: string): Promise<void> {
  const record = await readFreezeState(root);
  if (record) throw new ForgeError("WORKSPACE_FROZEN", `Forge workspace is frozen (${record.reason}). Blocked action: ${action}. Run 'forge unfreeze --approve' after manually reviewing the workspace.`);
}

export async function unfreezeWorkspace(rootInput: string, approved: boolean): Promise<void> {
  if (!approved) throw new ForgeError("UNFREEZE_APPROVAL_REQUIRED", "Unfreezing requires the explicit --approve option after reviewing the workspace.");
  const { root, home } = await ensureProjectHome(rootInput);
  const target = join(home, FILE); const record = await readFreezeState(root);
  if (!record) throw new ForgeError("WORKSPACE_NOT_FROZEN", "This workspace is not frozen.");
  // Identity/type check immediately before unlink; never follow a symlink.
  const info = await lstat(target);
  if (info.isSymbolicLink() || !info.isFile() || info.size > 8192) throw new ForgeError("FREEZE_STATE_UNSAFE", "Freeze state changed or became unsafe; refusing to remove it.");
  const again = await readFreezeState(root);
  if (!again || again.frozenAt !== record.frozenAt || again.projectRoot !== root) throw new ForgeError("FREEZE_STATE_CHANGED", "Freeze state changed during approval; refusing to remove it.");
  await unlink(target);
  await appendAudit(root, { event: "workspace.unfreeze", outcome: "allowed", details: { previousFrozenAt: record.frozenAt, reason: record.reason } });
}
function isFreezeRecord(v: unknown): v is FreezeRecord {
  return !!v && typeof v === "object" && (v as FreezeRecord).schemaVersion === 1 && typeof (v as FreezeRecord).frozenAt === "string" && typeof (v as FreezeRecord).reason === "string" && typeof (v as FreezeRecord).projectRoot === "string";
}
function hasCode(error: unknown, code: string): boolean { return error !== null && typeof error === "object" && "code" in error && error.code === code; }
