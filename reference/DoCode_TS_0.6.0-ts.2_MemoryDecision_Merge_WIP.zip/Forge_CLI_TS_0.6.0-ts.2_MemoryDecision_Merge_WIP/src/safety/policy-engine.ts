import { newId } from "../core/ids.js";
import type { SafetyDecision, ToolCall, Capability } from "../core/types.js";
import { ForgeError } from "../core/errors.js";

export const POLICY_VERSION = "forge-m1-2026-10-22";

/** Deterministic policy broker. Agent text and approval-looking model output are never inputs to authorization. */
export function decideToolCall(input: {
  toolCall: ToolCall;
  approvedCapabilities: Capability[];
  now?: Date;
}): SafetyDecision {
  const { toolCall, approvedCapabilities } = input;
  const decidedAt = (input.now ?? new Date()).toISOString();
  const requested = new Set(toolCall.requestedCapabilities);
  let outcome: SafetyDecision["outcome"] = "deny";
  let ruleIds: string[] = [];
  let rationale = "Tool call denied by the default-deny policy.";

  if (toolCall.risk === "read_only" && requested.size > 0 && [...requested].every((capability) => capability === "read_workspace" && approvedCapabilities.includes("read_workspace"))) {
    outcome = "allow";
    ruleIds = ["READ_ONLY_WORKSPACE_SCOPE"];
    rationale = "Read-only workspace capability is explicitly approved and is routed through bounded safe-file tools.";
  } else if (toolCall.risk === "workspace_write") {
    ruleIds = ["M1_WRITE_TOOLS_DISABLED"];
    rationale = "Workspace writes are disabled in M1; a model request or generic approval flag cannot enable them.";
  } else if (toolCall.risk === "process") {
    ruleIds = ["M1_PROCESS_TOOLS_DISABLED", "SANDBOX_REQUIRED"];
    rationale = "Process execution is disabled until a verified sandbox driver and command policy are implemented.";
  } else if (toolCall.risk === "network") {
    ruleIds = ["NETWORK_DEFAULT_DENY"];
    rationale = "Network tools are disabled unless a tool-specific egress policy and explicit consent exist.";
  } else if (toolCall.risk === "credentials") {
    ruleIds = ["CREDENTIAL_ACCESS_DENIED"];
    rationale = "Agent tools are never granted direct credential access.";
  } else if (toolCall.risk === "destructive") {
    ruleIds = ["DESTRUCTIVE_ACTION_DENIED"];
    rationale = "Destructive actions are not available in M1.";
  } else {
    ruleIds = ["CAPABILITY_NOT_APPROVED"];
    rationale = "The requested capability is not explicitly approved for this mission.";
  }

  if (!toolCall.toolName.trim() || !toolCall.missionId.trim() || !toolCall.stepId.trim()) throw new ForgeError("POLICY_INPUT_INVALID", "Safety policy requires a tool name, mission ID, and step ID.");
  return {
    id: newId(),
    missionId: toolCall.missionId,
    toolCallId: toolCall.id,
    outcome,
    policyVersion: POLICY_VERSION,
    ruleIds,
    resource: toolCall.toolName.slice(0, 128),
    rationale,
    decidedAt,
  };
}
