const REDACTIONS: Array<{ pattern: RegExp; replacement: string }> = [
  { pattern: /\b(sk-[A-Za-z0-9_-]{12,})\b/g, replacement: "[REDACTED_OPENAI_KEY]" },
  { pattern: /\b(AIza[0-9A-Za-z_-]{20,})\b/g, replacement: "[REDACTED_GOOGLE_KEY]" },
  { pattern: /\b(gh[pousr]_[A-Za-z0-9]{20,})\b/g, replacement: "[REDACTED_GITHUB_TOKEN]" },
  { pattern: /\b(xox[baprs]-[A-Za-z0-9-]{10,})\b/g, replacement: "[REDACTED_SLACK_TOKEN]" },
  { pattern: /\b(Bearer\s+)[A-Za-z0-9._~+\/-]+=*/gi, replacement: "$1[REDACTED]" },
  { pattern: /((?:api[_-]?key|access[_-]?token|refresh[_-]?token|password|client[_-]?secret)\s*[:=]\s*)([^\s,;]+)/gi, replacement: "$1[REDACTED]" },
  { pattern: /-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----[\s\S]*?-----END (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----/g, replacement: "[REDACTED_PRIVATE_KEY]" },
];

export function redactString(input: string): string {
  let output = input;
  for (const entry of REDACTIONS) output = output.replace(entry.pattern, entry.replacement);
  return output;
}

export function redactValue<T>(input: T): T {
  if (typeof input === "string") return redactString(input) as T;
  if (Array.isArray(input)) return input.map((item) => redactValue(item)) as T;
  if (input !== null && typeof input === "object") {
    const result: Record<string, unknown> = {};
    for (const [key, value] of Object.entries(input as Record<string, unknown>)) {
      if (/^(?:api[-_]?key|password|secret|token|authorization|cookie)$/i.test(key)) result[key] = "[REDACTED]";
      else result[key] = redactValue(value);
    }
    return result as T;
  }
  return input;
}
