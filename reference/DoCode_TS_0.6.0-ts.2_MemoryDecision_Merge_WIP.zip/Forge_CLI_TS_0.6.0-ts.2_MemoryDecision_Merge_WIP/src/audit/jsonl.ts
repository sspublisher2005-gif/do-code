import { constants } from "node:fs";
import { lstat, open, readFile, unlink } from "node:fs/promises";
import { join } from "node:path";
import { hostname } from "node:os";
import { randomUUID } from "node:crypto";
import { newId, projectIdFor } from "../core/ids.js";
import { ForgeError } from "../core/errors.js";
import { redactValue } from "../safety/secret-redaction.js";
import { ensureProjectHome } from "../privacy/project-home.js";

export interface AuditEventInput {
  event: string;
  outcome: "started" | "allowed" | "denied" | "succeeded" | "failed" | "info";
  missionId?: string;
  stepId?: string;
  decisionId?: string;
  resultId?: string;
  details?: Record<string, string | number | boolean | null>;
}
export interface AuditEvent {
  schemaVersion: 1;
  id: string;
  sequence: number;
  at: string;
  projectId: string;
  event: string;
  outcome: AuditEventInput["outcome"];
  missionId?: string;
  stepId?: string;
  decisionId?: string;
  resultId?: string;
  details: Record<string, string | number | boolean | null>;
}
const MAX_LOG_BYTES = 10 * 1024 * 1024;
const MAX_EVENT_BYTES = 16 * 1024;
const AUDIT_LOCK_STALE_MS = 30_000;
const AUDIT_LOCK_WAIT_MS = 5_000;
const auditQueues = new Map<string, Promise<void>>();

export async function appendAudit(rootInput: string, input: AuditEventInput): Promise<AuditEvent> {
  const { root, home } = await ensureProjectHome(rootInput);
  const logPath = join(home, "audit.jsonl");
  try {
    const info = await lstat(logPath);
    if (info.isSymbolicLink() || !info.isFile()) throw new ForgeError("AUDIT_UNSAFE_FILE", "Audit log must be a regular file; refusing to append.");
    if (info.size > MAX_LOG_BYTES) throw new ForgeError("AUDIT_LOG_TOO_LARGE", "Audit log exceeded its read/write limit; rotate it manually after backup.");
  } catch (error) {
    if (!isNotFound(error)) throw error;
  }

  const previous = auditQueues.get(logPath) ?? Promise.resolve();
  let resolveQueue!: () => void;
  const current = new Promise<void>((resolve) => { resolveQueue = resolve; });
  const queued = previous.then(() => current);
  auditQueues.set(logPath, queued);
  await previous;
  let releaseLock: (() => Promise<void>) | undefined;
  try {
    releaseLock = await acquireAuditLock(join(home, "audit.lock"), root);
    const sequence = await nextSequence(logPath);
    const safeDetails = redactValue(input.details ?? {}) as Record<string, string | number | boolean | null>;
    const event: AuditEvent = {
      schemaVersion: 1,
      id: newId(),
      sequence,
      at: new Date().toISOString(),
      projectId: await projectIdFor(root),
      event: redactValue(input.event),
      outcome: input.outcome,
      details: safeDetails,
    };
    if (input.missionId !== undefined) event.missionId = input.missionId;
    if (input.stepId !== undefined) event.stepId = input.stepId;
    if (input.decisionId !== undefined) event.decisionId = input.decisionId;
    if (input.resultId !== undefined) event.resultId = input.resultId;
    const flags = constants.O_CREAT | constants.O_APPEND | constants.O_WRONLY | (constants.O_NOFOLLOW ?? 0);
    const serialized = `${JSON.stringify(event)}\n`;
    if (Buffer.byteLength(serialized, "utf8") > MAX_EVENT_BYTES) {
      throw new ForgeError("AUDIT_EVENT_TOO_LARGE", "Audit event exceeds the 16 KiB per-event limit; reduce its details and retry.");
    }
    const handle = await open(logPath, flags, 0o600);
    try {
      const info = await handle.stat();
      if (!info.isFile() || info.size > MAX_LOG_BYTES) throw new ForgeError("AUDIT_FILE_CHANGED", "Audit log changed during append; refusing to write.");
      await handle.chmod(0o600);
      await handle.writeFile(serialized, "utf8");
      await handle.sync();
    } finally {
      await handle.close();
    }
    return event;
  } finally {
    if (releaseLock) await releaseLock().catch(() => undefined);
    resolveQueue();
    if (auditQueues.get(logPath) === queued) auditQueues.delete(logPath);
  }
}

export async function readAuditTail(rootInput: string, requestedCount: number): Promise<{ events: AuditEvent[]; corruptLines: number; truncated: boolean }> {
  if (!Number.isSafeInteger(requestedCount) || requestedCount < 1 || requestedCount > 1000) throw new ForgeError("AUDIT_TAIL_INVALID", "Audit tail count must be between 1 and 1000.");
  const { home } = await ensureProjectHome(rootInput);
  const logPath = join(home, "audit.jsonl");
  let bytes: Buffer;
  try {
    const info = await lstat(logPath);
    if (info.isSymbolicLink() || !info.isFile()) throw new ForgeError("AUDIT_UNSAFE_FILE", "Audit log must be a regular file.");
    const handle = await open(logPath, constants.O_RDONLY | (constants.O_NOFOLLOW ?? 0));
    try {
      const stat = await handle.stat();
      const start = Math.max(0, stat.size - MAX_LOG_BYTES);
      bytes = Buffer.alloc(stat.size - start);
      await handle.read(bytes, 0, bytes.length, start);
      const truncated = start > 0;
      const lines = bytes.toString("utf8").split(/\r?\n/).filter((line) => line.length > 0);
      const events: AuditEvent[] = [];
      let corruptLines = 0;
      for (const line of lines.slice(-Math.max(requestedCount * 4, requestedCount))) {
        try {
          const parsed: unknown = JSON.parse(line);
          if (isAuditEvent(parsed)) events.push(parsed);
          else corruptLines += 1;
        } catch { corruptLines += 1; }
      }
      return { events: events.slice(-requestedCount), corruptLines, truncated };
    } finally { await handle.close(); }
  } catch (error) {
    if (isNotFound(error)) return { events: [], corruptLines: 0, truncated: false };
    throw error;
  }
}

function isAuditEvent(value: unknown): value is AuditEvent {
  if (!value || typeof value !== "object") return false;
  const x = value as Record<string, unknown>;
  return x.schemaVersion === 1 && typeof x.id === "string" && typeof x.sequence === "number" && typeof x.at === "string" && typeof x.projectId === "string" && typeof x.event === "string" && typeof x.outcome === "string" && x.details !== null && typeof x.details === "object";
}

interface AuditLockRecord { token: string; pid: number; host: string; root: string; createdAt: string }

async function acquireAuditLock(lockPath: string, root: string): Promise<() => Promise<void>> {
  const token = randomUUID();
  const record: AuditLockRecord = { token, pid: process.pid, host: hostname(), root, createdAt: new Date().toISOString() };
  const payload = JSON.stringify(record);
  const deadline = Date.now() + AUDIT_LOCK_WAIT_MS;
  while (Date.now() < deadline) {
    try {
      const handle = await open(lockPath, constants.O_CREAT | constants.O_EXCL | constants.O_WRONLY | (constants.O_NOFOLLOW ?? 0), 0o600);
      try { await handle.writeFile(payload, "utf8"); await handle.sync(); } catch (error) { await handle.close().catch(() => undefined); await unlinkOwnedLock(lockPath, token).catch(() => undefined); throw error; }
      await handle.close();
      return async () => { await unlinkOwnedLock(lockPath, token); };
    } catch (error) {
      if (!isCode(error, "EEXIST")) throw error;
      await recoverStaleAuditLock(lockPath, root);
      await new Promise((resolve) => setTimeout(resolve, 20));
    }
  }
  throw new ForgeError("AUDIT_LOCKED", "Audit log is locked by another process. The event was not written; retry after inspecting the workspace lock state.");
}

async function recoverStaleAuditLock(path: string, root: string): Promise<void> {
  let before: Awaited<ReturnType<typeof lstat>>;
  let raw: string;
  try { before = await lstat(path); raw = await readFile(path, "utf8"); }
  catch (error) { if (isNotFound(error)) return; throw error; }
  if (before.isSymbolicLink() || !before.isFile() || before.size > 4096) throw new ForgeError("AUDIT_LOCK_UNSAFE", "Audit lock is not a bounded regular file; refusing recovery.");
  let record: AuditLockRecord;
  try { record = JSON.parse(raw) as AuditLockRecord; } catch {
    // A concurrent process may be observing the tiny create-before-write window. Wait while new;
    // remove only an unchanged, stale incomplete lock left by a dead process.
    if (Date.now() - before.mtimeMs < AUDIT_LOCK_STALE_MS) return;
    const again = await readFile(path, "utf8").catch((e: unknown) => { if (isNotFound(e)) return undefined; throw e; });
    const now = await lstat(path).catch((e: unknown) => { if (isNotFound(e)) return undefined; throw e; });
    if (again === raw && now && !now.isSymbolicLink() && now.isFile() && now.ino === before.ino && Date.now() - now.mtimeMs >= AUDIT_LOCK_STALE_MS) {
      await unlink(path).catch((e: unknown) => { if (!isNotFound(e)) throw e; });
      return;
    }
    throw new ForgeError("AUDIT_LOCK_CORRUPT", "Audit lock is corrupt; refusing automatic removal.");
  }
  if (!record || record.host !== hostname() || record.root !== root || !Number.isInteger(record.pid) || typeof record.createdAt !== "string") return;
  const age = Date.now() - Date.parse(record.createdAt);
  if (!Number.isFinite(age) || age < AUDIT_LOCK_STALE_MS || isPidAlive(record.pid)) return;
  try {
    const again = await readFile(path, "utf8");
    const now = await lstat(path);
    if (!now.isSymbolicLink() && now.isFile() && again === raw && now.ino === before.ino) await unlink(path);
  } catch (error) { if (!isNotFound(error)) throw error; }
}

async function unlinkOwnedLock(path: string, token: string): Promise<void> {
  try {
    const info = await lstat(path);
    if (info.isSymbolicLink() || !info.isFile() || info.size > 4096) return;
    const record = JSON.parse(await readFile(path, "utf8")) as Partial<AuditLockRecord>;
    if (record.token === token && record.pid === process.pid) await unlink(path);
  } catch (error) { if (!isNotFound(error)) throw error; }
}

function isPidAlive(pid: number): boolean {
  try { process.kill(pid, 0); return true; }
  catch (error) { if (isCode(error, "ESRCH")) return false; return true; }
}
function isCode(error: unknown, code: string): boolean { return error !== null && typeof error === "object" && "code" in error && error.code === code; }

async function nextSequence(path: string): Promise<number> {
  try {
    const stat = await lstat(path);
    if (stat.isSymbolicLink() || !stat.isFile()) throw new ForgeError("AUDIT_UNSAFE_FILE", "Audit log must be a regular file.");
    const handle = await open(path, constants.O_RDONLY | (constants.O_NOFOLLOW ?? 0));
    try {
      const info = await handle.stat();
      const start = Math.max(0, info.size - Math.min(MAX_LOG_BYTES, 1024 * 1024));
      const buffer = Buffer.alloc(info.size - start);
      await handle.read(buffer, 0, buffer.length, start);
      const lines = buffer.toString("utf8").trimEnd().split(/\r?\n/);
      for (let i = lines.length - 1; i >= 0; i -= 1) {
        try {
          const parsed: unknown = JSON.parse(lines[i] ?? "");
          if (isAuditEvent(parsed)) return parsed.sequence + 1;
        } catch { /* tolerate a corrupt trailing record, but never use it as sequence source */ }
      }
      return 1;
    } finally { await handle.close(); }
  } catch (error) {
    if (isNotFound(error)) return 1;
    throw error;
  }
}

function isNotFound(error: unknown): boolean {
  return error !== null && typeof error === "object" && "code" in error && error.code === "ENOENT";
}
