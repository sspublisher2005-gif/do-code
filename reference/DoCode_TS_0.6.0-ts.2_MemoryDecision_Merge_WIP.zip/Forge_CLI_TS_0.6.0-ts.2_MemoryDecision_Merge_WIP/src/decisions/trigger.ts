export type DecisionRisk = "low" | "medium" | "high";
export interface DecisionSignals {
  explicitRequest?: boolean;
  comparisonRequested?: boolean;
  risk?: DecisionRisk;
  estimatedCostUsd?: number;
  costThresholdUsd?: number;
  priorFailures?: number;
  architectureAlternatives?: number;
  securitySensitive?: boolean;
  privacySensitive?: boolean;
  financialImpact?: boolean;
  productionImpact?: boolean;
  strategicImportance?: boolean;
  uncertainty?: DecisionRisk;
}
export interface DecisionTriggerResult {
  shouldRun: boolean;
  reasons: string[];
  reasonCode: string;
}

/** Deterministic trigger policy. It does not make decisions or claim a research result. */
export function shouldTriggerDecisionArena(signals: DecisionSignals): DecisionTriggerResult {
  const reasons: string[] = [];
  if (signals.explicitRequest) reasons.push("the user explicitly requested a comparison or pilot review");
  if (signals.comparisonRequested) reasons.push("the task asks to compare alternatives");
  if (signals.risk === "high") reasons.push("the decision has high stated risk");
  const threshold = Number.isFinite(signals.costThresholdUsd) && (signals.costThresholdUsd ?? 0) >= 0 ? signals.costThresholdUsd! : 5;
  if (Number.isFinite(signals.estimatedCostUsd) && (signals.estimatedCostUsd ?? 0) >= threshold) reasons.push(`estimated cost reaches the configured threshold ($${threshold.toFixed(2)})`);
  if ((signals.priorFailures ?? 0) >= 2) reasons.push("at least two prior attempts failed");
  if ((signals.architectureAlternatives ?? 0) >= 2) reasons.push("multiple plausible architectures or approaches are present");
  if (signals.securitySensitive) reasons.push("the decision affects security");
  if (signals.privacySensitive) reasons.push("the decision affects privacy");
  if (signals.financialImpact) reasons.push("the decision affects money or commercial commitments");
  if (signals.productionImpact) reasons.push("the decision affects production or release safety");
  if (signals.strategicImportance) reasons.push("the decision is strategically important");
  if (signals.uncertainty === "high") reasons.push("material uncertainty remains high");
  return { shouldRun: reasons.length > 0, reasons, reasonCode: reasons.length ? "DECISION_ARENA_TRIGGERED" : "SIMPLE_TASK_NO_ARENA" };
}
