export type SandboxPlatform = "linux" | "macos" | "windows";
export type NetworkPolicy = "deny_all" | "allowlist";

export interface SandboxLimits {
  timeoutMs: number;
  memoryBytes: number;
  cpuQuotaPercent: number;
  maxProcesses: number;
  maxOutputBytes: number;
}

export interface SandboxRunRequest {
  /** Absolute executable and argv are separately specified; shell strings are forbidden. */
  executable: string;
  argv: string[];
  workspaceRoot: string;
  writablePaths: string[];
  environment: Record<string, string>;
  network: NetworkPolicy;
  networkAllowlist?: string[];
  limits: SandboxLimits;
  signal?: AbortSignal;
}

export interface SandboxRunResult {
  runId: string;
  exitCode: number | null;
  stdout: string;
  stderr: string;
  durationMs: number;
  cancelled: boolean;
  evidencePath?: string;
}

export interface SandboxCapabilities {
  platform: SandboxPlatform;
  filesystemIsolation: boolean;
  networkIsolation: boolean;
  credentialIsolation: boolean;
  resourceLimits: boolean;
  processTreeCancellation: boolean;
  driverVersion: string;
  verifiedByTestIds: string[];
  /** False until syscall filtering and independent review are implemented. */
  landlock: boolean;
  seccompBpf: boolean;
  productionReady: boolean;
}

export interface SandboxDriver {
  readonly id: string;
  probe(): Promise<SandboxCapabilities>;
  run(request: SandboxRunRequest): Promise<SandboxRunResult>;
  cleanup(runId: string): Promise<void>;
}
