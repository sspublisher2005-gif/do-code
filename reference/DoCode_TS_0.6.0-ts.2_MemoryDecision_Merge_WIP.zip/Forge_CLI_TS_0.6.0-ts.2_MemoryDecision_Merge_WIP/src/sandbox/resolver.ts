import { ForgeError } from "../core/errors.js";
import type { SandboxDriver } from "./driver.js";

/** M1 intentionally has no executable sandbox driver. Never fall back to host shell execution. */
export async function resolveSandboxDriver(): Promise<SandboxDriver> {
  throw new ForgeError("SANDBOX_NOT_IMPLEMENTED", "No verified sandbox driver is available in this M1 build. Untrusted commands are blocked; no host-execution fallback is permitted.");
}
