import { spawn, type ChildProcess } from "node:child_process";
import { constants as fsConstants } from "node:fs";
import { randomUUID } from "node:crypto";
import { access, chmod, lstat, mkdir, mkdtemp, open, readdir, readFile, realpath, rm, stat, writeFile } from "node:fs/promises";
import { delimiter, extname, join, sep } from "node:path";
import { tmpdir } from "node:os";
import { ForgeError } from "../../core/errors.js";
import type { SandboxCapabilities, SandboxDriver, SandboxRunRequest, SandboxRunResult } from "../driver.js";
import { redactString } from "../../safety/secret-redaction.js";

const SNAPSHOT_MAX_FILES = 30_000;
const SNAPSHOT_MAX_BYTES = 700 * 1024 * 1024;
const SNAPSHOT_MAX_FILE_BYTES = 64 * 1024 * 1024;
const PROTECTED_NAMES = /^(?:\.env(?:\..*)?|\.npmrc|\.netrc|\.pypirc|credentials(?:\.json)?|secrets?(?:\.json)?|id_(?:rsa|dsa|ecdsa|ed25519)|known_hosts|authorized_keys|.*\.(?:pem|p12|pfx|key|kdbx))$/i;
const EXCLUDED_DIRS = new Set([".git", ".forge", ".ssh", ".aws", ".azure", ".gnupg", ".config", "AppData", "Credentials"]);
const MAX_ARGS = 256;
const MAX_ARG_BYTES = 16 * 1024;
const SAFE_ENVIRONMENT_KEYS = new Set(["NODE_ENV", "TZ", "TERM", "NO_COLOR", "FORCE_COLOR", "FORGE_TEST_MODE"]);
const NAMESPACE_SCRIPT = String.raw`
set -eu
r=$1; workspace=$2; empty_shadow=$3; mount_bin=$4; chroot_bin=$5; setpriv_bin=$6; env_bin=$7
shift 7
"$mount_bin" --make-rprivate /
for d in usr bin sbin lib lib64 etc; do
  if [ -e "/$d" ]; then
    "$mount_bin" --bind "/$d" "$r/$d"
    "$mount_bin" -o remount,ro,bind "$r/$d"
  fi
done
# These are fresh, ephemeral filesystems; they mask host home directories, sockets, logs, package caches and hardware metadata.
for d in root home run mnt media opt srv var sys; do
  if [ -d "$r/$d" ]; then
    "$mount_bin" -t tmpfs -o size=64m tmpfs "$r/$d"
    # These directories are empty, private masks. They must not become alternate write locations.
    "$mount_bin" -o remount,ro "$r/$d"
  fi
done
"$mount_bin" -t tmpfs -o size=128m tmpfs "$r/tmp"
"$mount_bin" --bind "$workspace" "$r/workspace"
"$mount_bin" -o remount,rw,bind "$r/workspace"
for d in etc/ssh etc/ssl/private etc/sudoers.d etc/NetworkManager/system-connections etc/openvpn etc/wireguard etc/kubernetes; do
  if [ -d "$r/$d" ]; then "$mount_bin" -t tmpfs -o size=1m tmpfs "$r/$d"; fi
done
if [ -f "$r/etc/shadow" ]; then
  "$mount_bin" --bind "$empty_shadow" "$r/etc/shadow"
  "$mount_bin" -o remount,ro,bind "$r/etc/shadow"
fi
if [ -f "$r/etc/gshadow" ]; then
  "$mount_bin" --bind "$empty_shadow" "$r/etc/gshadow"
  "$mount_bin" -o remount,ro,bind "$r/etc/gshadow"
fi
"$mount_bin" -t tmpfs -o size=8m tmpfs "$r/dev"
for d in null zero urandom; do
  : > "$r/dev/$d"
  "$mount_bin" --bind "/dev/$d" "$r/dev/$d"
  "$mount_bin" -o remount,ro,bind "$r/dev/$d"
done
# /proc is deliberately not mounted: some restricted kernels reject safe procfs mounts in user namespaces.
# Missing /proc features are a documented compatibility limitation, not a reason to expose host /proc.
# GNU chroot resets cwd to /, so an inner shell must change into the mounted workspace
# after chroot. Do not preserve any host cwd reference across the chroot boundary.
"$chroot_bin" "$r" /bin/sh -eu -c 'cd /workspace && exec "$@"' forge-inner \
  "$setpriv_bin" --no-new-privs --bounding-set=-all --inh-caps=-all --ambient-caps=-all \
  "$env_bin" -i PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin HOME=/root TMPDIR=/tmp LANG=C.UTF-8 LC_ALL=C.UTF-8 CI=1 FORGE_SANDBOX=1 "$@"
`;

interface ToolPaths { unshare: string; mount: string; chroot: string; setpriv: string; prlimit: string; env: string; shell: string }
interface SnapshotStats { files: number; bytes: number; excluded: number }

/**
 * Linux user/mount/PID/network namespace sandbox prototype. It deliberately reports
 * productionReady=false because this implementation does not yet enforce Landlock or
 * a seccomp-bpf profile and has not had independent security review.
 * The production resolver must not select it until those gates are completed.
 */
export class LinuxNamespacePrototypeDriver implements SandboxDriver {
  readonly id = "linux-userns-chroot-prototype";
  readonly #active = new Map<string, { child?: ChildProcess; tempDir: string }>();
  readonly #toolPaths: ToolPaths | undefined;

  private constructor(paths: ToolPaths | undefined) { this.#toolPaths = paths; }

  static async create(): Promise<LinuxNamespacePrototypeDriver> {
    if (process.platform !== "linux") return new LinuxNamespacePrototypeDriver(undefined);
    const names = ["unshare", "mount", "chroot", "setpriv", "prlimit", "env", "sh"] as const;
    const found: Partial<ToolPaths> = {};
    for (const name of names) {
      const path = await findExecutable(name);
      if (path) {
        const key = name === "sh" ? "shell" : name;
        (found as Record<string, string>)[key] = path;
      }
    }
    const required = ["unshare", "mount", "chroot", "setpriv", "prlimit", "env", "shell"] as const;
    return new LinuxNamespacePrototypeDriver(required.every((name) => found[name]) ? found as ToolPaths : undefined);
  }

  async probe(): Promise<SandboxCapabilities> {
    const toolsAvailable = process.platform === "linux" && this.#toolPaths !== undefined;
    let namespaceSetup = false;
    if (toolsAvailable && this.#toolPaths) {
      namespaceSetup = await probeNamespacePrimitives(this.#toolPaths).catch(() => false);
    }
    return {
      platform: "linux",
      filesystemIsolation: toolsAvailable && namespaceSetup,
      networkIsolation: toolsAvailable && namespaceSetup,
      credentialIsolation: toolsAvailable && namespaceSetup,
      resourceLimits: toolsAvailable && namespaceSetup,
      processTreeCancellation: toolsAvailable && namespaceSetup,
      driverVersion: "prototype-1",
      verifiedByTestIds: ["linux-ns-readonly-root", "linux-ns-network-denial", "linux-ns-credential-mask", "linux-ns-host-write-isolation", "linux-ns-timeout-cleanup"],
      landlock: false,
      seccompBpf: false,
      productionReady: false,
    };
  }

  async run(request: SandboxRunRequest): Promise<SandboxRunResult> {
    if (process.platform !== "linux" || !this.#toolPaths) throw new ForgeError("SANDBOX_UNAVAILABLE", "Linux namespace sandbox prerequisites are unavailable. No command was executed.");
    if (request.network !== "deny_all") throw new ForgeError("SANDBOX_NETWORK_POLICY_UNSUPPORTED", "This prototype supports deny-all network policy only. No command was executed.");
    if (Object.keys(request.environment ?? {}).some((key) => !SAFE_ENVIRONMENT_KEYS.has(key))) throw new ForgeError("SANDBOX_ENVIRONMENT_DENIED", "Only non-secret runtime display/test environment variables are permitted. No command was executed.");
    if (request.limits.cpuQuotaPercent !== 100) throw new ForgeError("SANDBOX_CPU_QUOTA_UNSUPPORTED", "The prototype enforces CPU time limits but not cgroup CPU percentage quotas; use cpuQuotaPercent=100 or wait for cgroup support. No command was executed.");
    validateLimits(request);
    validateCommand(request.executable, request.argv);
    if (request.signal?.aborted) return { runId: cryptoRandomId(), exitCode: null, stdout: "", stderr: "Cancelled before start.", durationMs: 0, cancelled: true };
    const workspaceRoot = await realpath(request.workspaceRoot);
    const rootInfo = await lstat(workspaceRoot);
    if (!rootInfo.isDirectory() || rootInfo.isSymbolicLink()) throw new ForgeError("SANDBOX_WORKSPACE_INVALID", "Sandbox workspace must be a real directory.");

    const runId = cryptoRandomId();
    const tempDir = await mkdtemp(join(tmpdir(), "forge-ns-sandbox-"));
    await chmod(tempDir, 0o700);
    this.#active.set(runId, { tempDir });
    const rootfs = join(tempDir, "rootfs");
    const workspaceCopy = join(tempDir, "workspace");
    await createRootLayout(rootfs);
    const snapshotStats = await copyWorkspace(workspaceRoot, workspaceCopy);
    // Prevent the chroot's top-level unmounted directories from becoming writable by sandbox UID 0.
    await chmod(rootfs, 0o555);
    const shadowFile = join(tempDir, "empty-shadow");
    await writeFile(shadowFile, "", { mode: 0o444, flag: "wx" });
    const paths = this.#toolPaths;
    const timeoutMs = Math.min(request.limits.timeoutMs, 30 * 60_000);
    const cpuSeconds = Math.max(1, Math.ceil(timeoutMs / 1000));
    const argv = [
      `--cpu=${cpuSeconds}:${cpuSeconds}`,
      `--as=${request.limits.memoryBytes}:${request.limits.memoryBytes}`,
      `--nproc=${Math.min(request.limits.maxProcesses, 1024)}:${Math.min(request.limits.maxProcesses, 1024)}`,
      `--fsize=${Math.max(1024, request.limits.maxOutputBytes)}:${Math.max(1024, request.limits.maxOutputBytes)}`,
      "--nofile=256:256", "--", paths.unshare,
      "--user", "--map-root-user", "--mount", "--pid", "--fork", "--net", "--ipc", "--uts", "--kill-child",
      paths.shell, "-eu", "-c", NAMESPACE_SCRIPT, "forge-ns",
      rootfs, workspaceCopy, shadowFile, paths.mount, paths.chroot, paths.setpriv, paths.env,
      ...Object.entries(request.environment ?? {}).map(([key, value]) => `${key}=${value}`),
      request.executable, ...request.argv,
    ];
    const startedAt = Date.now();
    let cancelled = false;
    let timedOut = false;
    let outputExceeded = false;
    let child: ChildProcess | undefined;
    let timeout: ReturnType<typeof setTimeout> | undefined;
    let stdoutBytes = 0; let stderrBytes = 0;
    const stdout: Buffer[] = []; const stderr: Buffer[] = [];
    const maxOutput = Math.max(1024, Math.min(request.limits.maxOutputBytes, 4 * 1024 * 1024));
    const terminate = (): void => {
      if (!child || child.pid == null) return;
      try { process.kill(-child.pid, "SIGTERM"); } catch { child.kill("SIGTERM"); }
      const timeoutHandle = setTimeout(() => {
        if (child && child.exitCode === null && child.signalCode === null && child.pid != null) {
          try { process.kill(-child.pid, "SIGKILL"); } catch { child.kill("SIGKILL"); }
        }
      }, 250);
      (timeoutHandle as any).unref?.();
    };
    const appendOutput = (target: Buffer[], chunk: Buffer, isStdout: boolean): void => {
      const total = stdoutBytes + stderrBytes;
      const allowed = Math.max(0, maxOutput - total);
      if (chunk.length > allowed) outputExceeded = true;
      const kept = chunk.subarray(0, allowed);
      if (kept.length) target.push(kept);
      if (isStdout) stdoutBytes += kept.length; else stderrBytes += kept.length;
      if (outputExceeded) { cancelled = true; terminate(); }
    };

    try {
      const runPromise = new Promise<{ exitCode: number | null; signal: NodeJS.Signals | null }>((resolvePromise, rejectPromise) => {
        child = spawn(paths.prlimit, argv, { cwd: workspaceRoot, env: {}, stdio: ["ignore", "pipe", "pipe"], detached: true });
        const active = this.#active.get(runId); if (active) active.child = child;
        child.stdout?.on("data", (chunk: Buffer) => appendOutput(stdout, Buffer.from(chunk), true));
        child.stderr?.on("data", (chunk: Buffer) => appendOutput(stderr, Buffer.from(chunk), false));
        child.once("error", rejectPromise);
        child.once("close", (code, signal) => resolvePromise({ exitCode: code, signal }));
      });
      const abort = (): void => { cancelled = true; terminate(); };
      request.signal?.addEventListener("abort", abort, { once: true });
      timeout = setTimeout(() => { timedOut = true; cancelled = true; terminate(); }, timeoutMs);
      const result = await runPromise;
      request.signal?.removeEventListener("abort", abort);
      return {
        runId,
        exitCode: result.exitCode,
        stdout: redactString(Buffer.concat(stdout).toString("utf8")),
        stderr: [redactString(Buffer.concat(stderr).toString("utf8")), snapshotStats.excluded ? `[Forge sandbox: ${snapshotStats.excluded} sensitive/out-of-root/symlink entries excluded from disposable workspace snapshot.]` : "", outputExceeded ? "[Forge sandbox: output limit exceeded; process terminated.]" : "", timedOut ? "[Forge sandbox: time limit exceeded; process terminated.]" : ""].filter(Boolean).join("\n"),
        durationMs: Date.now() - startedAt,
        cancelled: cancelled || timedOut || result.signal !== null,
      };
    } finally {
      if (timeout) clearTimeout(timeout);
      await rm(tempDir, { recursive: true, force: true }).catch(async () => {
        await makeWritableForCleanup(tempDir).catch(() => undefined);
        await rm(tempDir, { recursive: true, force: true }).catch(() => undefined);
      });
      this.#active.delete(runId);
    }
  }

  async cleanup(runId: string): Promise<void> {
    const active = this.#active.get(runId);
    if (!active) return;
    const child = active.child;
    const pid = child?.pid;
    if (pid != null) {
      try { process.kill(-pid, "SIGKILL"); } catch { child?.kill("SIGKILL"); }
    }
    await makeWritableForCleanup(active.tempDir).catch(() => undefined);
    await rm(active.tempDir, { recursive: true, force: true });
    this.#active.delete(runId);
  }
}

export async function createLinuxNamespacePrototypeDriver(): Promise<SandboxDriver> {
  return LinuxNamespacePrototypeDriver.create();
}

async function probeNamespacePrimitives(paths: ToolPaths): Promise<boolean> {
  const script = 'set -eu; mount --make-rprivate /; mount -t tmpfs -o size=1m tmpfs /tmp; test -w /tmp';
  return await new Promise<boolean>((resolvePromise) => {
    const child = spawn(paths.unshare, ["--user", "--map-root-user", "--mount", "--net", paths.shell, "-eu", "-c", script], { stdio: "ignore", timeout: 2500, env: {} });
    child.once("error", () => resolvePromise(false));
    child.once("close", (code) => resolvePromise(code === 0));
  });
}

async function createRootLayout(rootfs: string): Promise<void> {
  const dirs = ["usr", "bin", "sbin", "lib", "lib64", "etc", "dev", "proc", "sys", "tmp", "root", "home", "run", "mnt", "media", "opt", "srv", "var", "workspace"];
  await mkdir(rootfs, { recursive: true, mode: 0o700 });
  for (const name of dirs) await mkdir(join(rootfs, name), { recursive: true, mode: 0o555 });
  await chmod(rootfs, 0o555);
}

async function copyWorkspace(root: string, target: string): Promise<SnapshotStats> {
  await mkdir(target, { recursive: true, mode: 0o700 });
  const realRoot = await realpath(root); const rootPrefix = realRoot.endsWith(sep) ? realRoot : `${realRoot}${sep}`;
  const visited = new Set<string>(); const stats: SnapshotStats = { files: 0, bytes: 0, excluded: 0 };
  async function walk(sourceDir: string, targetDir: string, relativeDir: string): Promise<void> {
    const dirNames = await readdir(sourceDir, { withFileTypes: true });
    for (const entry of dirNames) {
      const name = entry.name;
      const rel = relativeDir ? `${relativeDir}/${name}` : name;
      if (excludedName(name, entry.isDirectory())) { stats.excluded += 1; continue; }
      const sourcePath = join(sourceDir, name); const destPath = join(targetDir, name);
      let canonical: string;
      try { canonical = await realpath(sourcePath); } catch { stats.excluded += 1; continue; }
      if (canonical !== realRoot && !canonical.startsWith(rootPrefix)) { stats.excluded += 1; continue; }
      let info;
      try { info = await lstat(sourcePath); } catch { stats.excluded += 1; continue; }
      if (info.isSymbolicLink()) {
        // Dereference only links fully contained by this workspace. No links escape into host state.
        try { info = await stat(canonical); } catch { stats.excluded += 1; continue; }
      }
      if (info.isDirectory()) {
        if (visited.has(canonical)) { stats.excluded += 1; continue; }
        visited.add(canonical);
        await mkdir(destPath, { recursive: true, mode: 0o700 });
        await walk(canonical, destPath, rel);
        await chmod(destPath, 0o700);
      } else if (info.isFile()) {
        if (info.size > SNAPSHOT_MAX_FILE_BYTES || stats.files >= SNAPSHOT_MAX_FILES || stats.bytes + info.size > SNAPSHOT_MAX_BYTES) throw new ForgeError("SANDBOX_SNAPSHOT_LIMIT", "Workspace snapshot exceeded file-count or byte limits. No command ran.");
        let content: Buffer;
        try { content = await readFile(canonical); } catch { stats.excluded += 1; continue; }
        const ext = extname(name).toLowerCase();
        if (looksTexty(ext) && redactString(content.toString("utf8")) !== content.toString("utf8")) { stats.excluded += 1; continue; }
        await writeFile(destPath, content, { flag: "wx", mode: info.mode & 0o111 ? 0o700 : 0o600 });
        stats.files += 1; stats.bytes += content.length;
      } else stats.excluded += 1;
    }
  }
  await walk(realRoot, target, "");
  return stats;
}

function excludedName(name: string, directory: boolean): boolean {
  if (directory) return EXCLUDED_DIRS.has(name) || name === "node_modules/.cache";
  return PROTECTED_NAMES.test(name) || /^\.env(?:\.|$)/i.test(name) || /(?:secret|credential|token|private[-_.]?key)/i.test(name) || name.toLowerCase() === ".npmrc";
}
function looksTexty(ext: string): boolean { return [".ts", ".tsx", ".js", ".jsx", ".mjs", ".cjs", ".json", ".md", ".txt", ".yml", ".yaml", ".toml", ".ini", ".cfg", ".conf", ".xml", ".html", ".css", ".scss", ".py", ".sh", ".bash", ".sql", ".env.example", ""].includes(ext); }
function validateCommand(executable: string, args: string[]): void {
  if (!executable || executable.length > 512 || executable.includes("\0") || executable.startsWith("-") || !/^[A-Za-z0-9_./:@+-]+$/.test(executable)) throw new ForgeError("SANDBOX_COMMAND_INVALID", "Sandbox executable must be a valid command path/name. No command ran.");
  if (args.length > MAX_ARGS || args.some((arg) => typeof arg !== "string" || arg.includes("\0") || Buffer.byteLength(arg, "utf8") > MAX_ARG_BYTES) || args.reduce((sum, arg) => sum + Buffer.byteLength(arg, "utf8"), 0) > 256 * 1024) throw new ForgeError("SANDBOX_ARGUMENTS_INVALID", "Sandbox arguments exceed count/size limits. No command ran.");
}
function validateLimits(request: SandboxRunRequest): void {
  const l = request.limits;
  if (![l.timeoutMs, l.memoryBytes, l.cpuQuotaPercent, l.maxProcesses, l.maxOutputBytes].every(Number.isFinite) || l.timeoutMs < 100 || l.timeoutMs > 30 * 60_000 || l.memoryBytes < 256 * 1024 * 1024 || l.memoryBytes > 8 * 1024 ** 3 || l.maxProcesses < 8 || l.maxProcesses > 1024 || l.maxOutputBytes < 1024 || l.maxOutputBytes > 4 * 1024 * 1024 || l.cpuQuotaPercent < 1 || l.cpuQuotaPercent > 1000) throw new ForgeError("SANDBOX_LIMITS_INVALID", "Sandbox resource limits are invalid or outside supported bounds. No command ran.");
}
async function findExecutable(name: string): Promise<string | undefined> {
  for (const dir of (process.env.PATH ?? "").split(delimiter).filter(Boolean)) {
    const candidate = join(dir, name);
    try { await access(candidate, fsConstants.X_OK); const resolved = await realpath(candidate); const info = await stat(resolved); if (info.isFile()) return resolved; } catch { /* Continue searching PATH. */ }
  }
  return undefined;
}
function cryptoRandomId(): string { return randomUUID(); }
async function makeWritableForCleanup(path: string): Promise<void> {
  await chmod(path, 0o700).catch(() => undefined);
  const children = await readdir(path, { withFileTypes: true }).catch(() => []);
  for (const child of children) {
    const full = join(path, child.name);
    if (child.isDirectory() && !child.isSymbolicLink()) await makeWritableForCleanup(full);
    else await chmod(full, 0o600).catch(() => undefined);
  }
  await chmod(path, 0o700).catch(() => undefined);
}
