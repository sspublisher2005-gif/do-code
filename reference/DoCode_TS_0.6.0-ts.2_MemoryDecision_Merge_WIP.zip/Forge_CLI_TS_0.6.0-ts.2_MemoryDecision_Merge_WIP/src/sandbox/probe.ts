import { constants as fsConstants } from "node:fs";
import { access, lstat, readFile } from "node:fs/promises";
import { delimiter, join } from "node:path";

export interface SandboxProbe {
  schemaVersion: 1;
  platform: NodeJS.Platform;
  arch: string;
  isWsl: boolean;
  candidates: Record<string, { path?: string; executable: boolean }>;
  kernelControls: { landlock: "not_probed" | "unavailable"; seccompBpf: "not_probed" | "unavailable" };
  executionStatus: "blocked";
  reason: string;
}

const CANDIDATES = ["bwrap", "sandbox-exec", "docker", "podman", "firecracker", "runsc"] as const;

/** Diagnostic only: finding an executable does not prove a sandbox is correctly configured or secure. */
export async function probeSandboxEnvironment(env: NodeJS.ProcessEnv = process.env): Promise<SandboxProbe> {
  const candidates: SandboxProbe["candidates"] = {};
  const paths = (env.PATH ?? "").split(delimiter).filter(Boolean);
  for (const executable of CANDIDATES) {
    let found: string | undefined;
    for (const base of paths) {
      const candidate = join(base, executable);
      try {
        const info = await lstat(candidate);
        if (info.isFile() && !info.isSymbolicLink()) { await access(candidate, fsConstants.X_OK); found = candidate; break; }
      } catch { /* Missing or non-executable candidates are diagnostics, not fatal. */ }
    }
    candidates[executable] = found ? { path: found, executable: true } : { executable: false };
  }
  let isWsl = false;
  if (process.platform === "linux") {
    try { isWsl = /microsoft|wsl/i.test(await readFile("/proc/sys/kernel/osrelease", "utf8")); } catch { /* Keep false when proc is unavailable. */ }
  }
  return {
    schemaVersion: 1,
    platform: process.platform,
    arch: process.arch,
    isWsl,
    candidates,
    kernelControls: { landlock: "not_probed", seccompBpf: "not_probed" },
    executionStatus: "blocked",
    reason: "Forge has no implemented and independently verified sandbox driver in this build. Detecting bwrap, sandbox-exec, Docker, Podman, Firecracker or gVisor is not proof of isolation; no host command was run.",
  };
}
