import { constants as fsConstants } from "node:fs";
import { createHash, randomUUID } from "node:crypto";
import { chmod, lstat, mkdir, open, readFile, realpath, rename, unlink } from "node:fs/promises";
import { join } from "node:path";
import { ForgeError } from "../core/errors.js";
import { newId } from "../core/ids.js";
import type { EvidenceKind, EvidenceRef } from "../core/types.js";
import { ensureProjectHome } from "../privacy/project-home.js";
import { redactString } from "../safety/secret-redaction.js";

const MAX_EVIDENCE_BYTES = 10 * 1024 * 1024;
const KINDS = new Set<EvidenceKind>(["test_log", "typecheck_log", "lint_log", "patch", "file_snapshot", "browser_report", "screenshot", "review_report", "security_report", "manual_attestation", "model_response", "audit_event"]);

export class EvidenceStore {
  readonly #root: string; readonly #base: string;
  private constructor(root: string, base: string) { this.#root = root; this.#base = base; }
  static async open(rootInput: string): Promise<EvidenceStore> {
    const { root, home } = await ensureProjectHome(rootInput);
    const base = join(home, "evidence");
    try { await mkdir(base, { mode: 0o700 }); } catch (e) { if (!hasCode(e, "EEXIST")) throw e; }
    const info = await lstat(base); if (!info.isDirectory() || info.isSymbolicLink()) throw new ForgeError("EVIDENCE_STORE_UNSAFE", "Evidence store must be a real directory.");
    return new EvidenceStore(root, base);
  }
  async put(input: { missionId: string; kind: EvidenceKind; content: string | Uint8Array; producedBy: string; stepId?: string; mediaType?: string; metadata?: Record<string, string | number | boolean | null> }): Promise<EvidenceRef> {
    if (!KINDS.has(input.kind)) throw new ForgeError("EVIDENCE_KIND_INVALID", "Evidence kind is not supported.");
    assertUuid(input.missionId);
    // String evidence is sanitized before persistence. Binary artifacts are caller-owned and should be treated as private; this store does not inspect arbitrary binary formats.
    const safeContent = typeof input.content === "string" ? redactString(input.content) : input.content;
    const buffer = typeof safeContent === "string" ? Buffer.from(safeContent, "utf8") : Buffer.from(safeContent);
    if (buffer.byteLength > MAX_EVIDENCE_BYTES) throw new ForgeError("EVIDENCE_TOO_LARGE", "Evidence exceeds the 10 MiB per-artifact limit.");
    const dir = join(this.#base, input.missionId);
    try { await mkdir(dir, { mode: 0o700 }); } catch (e) { if (!hasCode(e, "EEXIST")) throw e; }
    const di = await lstat(dir); if (!di.isDirectory() || di.isSymbolicLink()) throw new ForgeError("EVIDENCE_PATH_UNSAFE", "Mission evidence directory is not a real directory.");
    await chmod(dir, 0o700).catch(() => undefined);
    const id = newId(); const target = join(dir, `${id}.bin`); const temp = join(dir, `${id}.${randomUUID()}.tmp`);
    const handle = await open(temp, fsConstants.O_CREAT | fsConstants.O_EXCL | fsConstants.O_WRONLY, 0o600);
    try { await handle.writeFile(buffer); await handle.sync(); } finally { await handle.close(); }
    try { await rename(temp, target); } catch (e) { await unlink(temp).catch(() => undefined); throw e; }
    const ref: EvidenceRef = {
      id, missionId: input.missionId, kind: input.kind, uri: `.forge/evidence/${input.missionId}/${id}.bin`,
      sha256: createHash("sha256").update(buffer).digest("hex"), createdAt: new Date().toISOString(),
      producedBy: input.producedBy.slice(0, 200), verified: true, byteLength: buffer.byteLength,
      mediaType: input.mediaType ?? (typeof safeContent === "string" ? "text/plain; charset=utf-8" : "application/octet-stream"),
      metadata: boundMetadata(input.metadata ?? {}),
    };
    if (input.stepId !== undefined) ref.stepId = input.stepId;
    const manifestPath = join(dir, `${id}.json`); const manifestTmp = `${manifestPath}.${randomUUID()}.tmp`;
    const manifest = await open(manifestTmp, fsConstants.O_CREAT | fsConstants.O_EXCL | fsConstants.O_WRONLY, 0o600);
    try { await manifest.writeFile(`${JSON.stringify(ref)}\n`, "utf8"); await manifest.sync(); } finally { await manifest.close(); }
    try { await rename(manifestTmp, manifestPath); } catch (e) { await unlink(manifestTmp).catch(() => undefined); throw e; }
    return ref;
  }
  async get(missionId: string, evidenceId: string): Promise<{ ref: EvidenceRef; content: Buffer }> {
    assertUuid(missionId); assertUuid(evidenceId);
    const dir = join(this.#base, missionId); const manifestPath = join(dir, `${evidenceId}.json`); const binaryPath = join(dir, `${evidenceId}.bin`);
    const manifestInfo = await lstat(manifestPath).catch((e: unknown) => { if (hasCode(e, "ENOENT")) throw new ForgeError("EVIDENCE_NOT_FOUND", "Evidence reference not found."); throw e; });
    if (!manifestInfo.isFile() || manifestInfo.isSymbolicLink() || manifestInfo.size > 64 * 1024) throw new ForgeError("EVIDENCE_MANIFEST_UNSAFE", "Evidence manifest is unsafe or too large.");
    let ref: EvidenceRef; try { ref = JSON.parse(await readFile(manifestPath, "utf8")) as EvidenceRef; } catch { throw new ForgeError("EVIDENCE_MANIFEST_CORRUPT", "Evidence manifest is invalid JSON."); }
    if (ref.id !== evidenceId || ref.missionId !== missionId || !KINDS.has(ref.kind) || !/^[a-f0-9]{64}$/.test(ref.sha256)) throw new ForgeError("EVIDENCE_MANIFEST_CORRUPT", "Evidence manifest identity or schema is invalid.");
    const fi = await lstat(binaryPath); if (!fi.isFile() || fi.isSymbolicLink() || fi.size > MAX_EVIDENCE_BYTES) throw new ForgeError("EVIDENCE_BLOB_UNSAFE", "Evidence content file is unsafe or too large.");
    const handle = await open(binaryPath, fsConstants.O_RDONLY | (fsConstants.O_NOFOLLOW ?? 0)); let content: Buffer;
    try { content = await handle.readFile(); } finally { await handle.close(); }
    if (createHash("sha256").update(content).digest("hex") !== ref.sha256 || content.byteLength !== ref.byteLength) throw new ForgeError("EVIDENCE_HASH_MISMATCH", "Evidence content hash/length failed verification.");
    return { ref, content };
  }
  async inspect(missionId: string): Promise<{ refs: EvidenceRef[]; corruptArtifacts: string[] }> {
    assertUuid(missionId); const dir = join(this.#base, missionId); const entries = await (await import("node:fs/promises")).readdir(dir).catch((e: unknown) => { if (hasCode(e, "ENOENT")) return []; throw e; });
    const refs: EvidenceRef[] = []; const corruptArtifacts: string[] = [];
    for (const name of entries.filter((n: string) => /^[0-9a-f-]{36}\.json$/i.test(n))) {
      try { const { ref } = await this.get(missionId, name.slice(0, -5)); refs.push(ref); }
      catch { corruptArtifacts.push(name.slice(0, -5)); }
    }
    return { refs: refs.sort((a, b) => a.createdAt.localeCompare(b.createdAt)), corruptArtifacts: corruptArtifacts.sort() };
  }
  async list(missionId: string): Promise<EvidenceRef[]> {
    return (await this.inspect(missionId)).refs;
  }
}
function assertUuid(id: string): void { if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(id)) throw new ForgeError("EVIDENCE_ID_INVALID", "Expected a Forge-generated UUID."); }
function boundMetadata(m: Record<string, string | number | boolean | null>): Record<string, string | number | boolean | null> {
  const result: Record<string, string | number | boolean | null> = {};
  for (const [key, value] of Object.entries(m).slice(0, 40)) if (/^[a-zA-Z][a-zA-Z0-9_.-]{0,63}$/.test(key) && (value === null || typeof value === "boolean" || typeof value === "number" && Number.isFinite(value) || typeof value === "string" && value.length <= 1000)) result[key] = typeof value === "string" ? redactString(value) : value;
  return result;
}
function hasCode(error: unknown, code: string): boolean { return error !== null && typeof error === "object" && "code" in error && error.code === code; }
