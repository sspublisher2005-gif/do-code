/** Escape terminal control sequences from untrusted repository/model content. */
export function safeTerminalText(value: string): string {
  return value.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F-\u009F\u001B]/g, (char) => {
    const code = char.codePointAt(0) ?? 0;
    return `\\x${code.toString(16).padStart(2, "0")}`;
  });
}
