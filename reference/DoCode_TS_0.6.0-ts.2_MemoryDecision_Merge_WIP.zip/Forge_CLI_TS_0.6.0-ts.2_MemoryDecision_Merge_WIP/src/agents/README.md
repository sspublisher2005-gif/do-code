# Agent roles — planned, not active in M1

Reserved roles: Orchestrator, Researcher, Architect, Coder, Tester, Reviewer, Security Agent, DevOps Agent. They will exchange schema-validated `AgentMessage` records with explicit mission/step IDs and budget ceilings. The Orchestrator alone owns state transitions. Specialist messages do not grant privileges and cannot call privileged APIs. M1 has no agent loop or autonomous code editing.
