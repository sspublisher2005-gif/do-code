import { createHash, randomUUID } from "node:crypto";
import { constants } from "node:fs";
import { homedir } from "node:os";
import { dirname, join, relative, resolve, sep } from "node:path";
import { chmod, lstat, link, mkdir, open, readdir, realpath, rename, unlink } from "node:fs/promises";
import { spawn } from "node:child_process";
import { projectIdFor } from "../core/ids.js";
import { redactString } from "../safety/secret-redaction.js";
import { ForgeError } from "../core/errors.js";
import type { MemoryDraft, MemoryIndex, MemoryIndexEntry, MemoryNote, MemoryProposal, MemoryScope, MemoryScopeFilter, MemoryStatus, MemoryType } from "./types.js";

const MAX_NOTE_BYTES = 256 * 1024;
const MAX_EXPORT_BYTES = 20 * 1024 * 1024;
const VALID_ID = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const MEMORY_TYPES = new Set<MemoryType>(["solution", "decision", "research", "user_preference", "project", "failure", "workflow"]);
const MEMORY_STATUSES = new Set<MemoryStatus>(["active", "outdated", "disputed"]);

export interface LocatedNote { note: MemoryNote; path: string; raw: string; scopeDir: string; }
export interface MemorySearchHit { note: MemoryNote; score: number; }

export function memoryVaultPath(): string {
  const configured = process.env.FORGE_MEMORY_DIR?.trim();
  return configured ? resolve(configured) : join(homedir(), ".forge", "memory");
}

export function sha256Text(value: string | Uint8Array): string {
  return createHash("sha256").update(value).digest("hex");
}

export async function proposeMemory(root: string, proposal: MemoryProposal): Promise<MemoryDraft> {
  validateProposal(proposal);
  const projectId = proposal.scope === "project" ? await projectIdFor(root) : null;
  const now = new Date().toISOString();
  const note: MemoryDraft = {
    schemaVersion: 1,
    id: randomUUID(),
    ...proposal,
    projectId,
    createdAt: now,
    lastVerifiedAt: null,
    status: "active",
    userConfirmed: false,
  };
  validateMemoryDraft(note);
  return note;
}

export async function saveMemoryNote(root: string, candidate: MemoryDraft | MemoryNote, options: { confirmed: boolean }): Promise<LocatedNote> {
  if (options.confirmed !== true) throw new ForgeError("MEMORY_CONFIRM_REQUIRED", "Memory storage requires an explicit user-confirmation result.");
  if (candidate.userConfirmed === false) validateMemoryDraft(candidate); else validateMemoryNote(candidate);
  const note: MemoryNote = { ...candidate, userConfirmed: true };
  validateMemoryNote(note);
  const expectedProjectId = note.scope === "project" ? await projectIdFor(root) : null;
  if (note.projectId !== expectedProjectId) {
    throw new ForgeError("MEMORY_PROJECT_MISMATCH", "Memory scope does not match this project; cross-project memory import is blocked.");
  }
  const { scopeDir, notesDir } = await getScopeDirs(root, note.scope);
  const file = join(notesDir, `${note.id}.md`);
  const raw = renderMarkdown(note);
  await atomicCreate(file, Buffer.from(raw, "utf8"), notesDir);
  await rebuildIndex(scopeDir, notesDir);
  return { note, path: file, raw, scopeDir };
}

export async function listMemoryNotes(root: string, filter: MemoryScopeFilter = "all"): Promise<MemoryNote[]> {
  const locations = await selectedDirs(root, filter, false);
  const notes: MemoryNote[] = [];
  for (const item of locations) {
    for (const found of await readScopeNotes(item.scopeDir, item.notesDir, item.scope, item.projectId)) notes.push(found.note);
  }
  return notes.sort((a, b) => b.createdAt.localeCompare(a.createdAt) || a.id.localeCompare(b.id));
}

export async function searchMemory(root: string, query: string, filter: MemoryScopeFilter = "all"): Promise<MemorySearchHit[]> {
  const terms = tokenize(query);
  if (!terms.length) throw new ForgeError("MEMORY_SEARCH_EMPTY", "Memory search requires at least one searchable word.");
  const notes = await listMemoryNotes(root, filter);
  const hits: MemorySearchHit[] = [];
  for (const note of notes) {
    const title = normalize(note.title);
    const body = normalize([note.problem, note.decision, note.reason, ...note.rejectedOptions, ...note.limitations, ...note.evidence].join(" "));
    let score = 0;
    for (const term of terms) {
      if (title.includes(term)) score += 3;
      if (body.includes(term)) score += 1;
      if (note.type === "user_preference" && (term.includes("prefer") || term.includes("privacy"))) score += 0.25;
    }
    if (score > 0) hits.push({ note, score });
  }
  return hits.sort((a, b) => b.score - a.score || b.note.createdAt.localeCompare(a.note.createdAt)).slice(0, 100);
}

export async function findMemoryNote(root: string, id: string): Promise<LocatedNote> {
  assertId(id);
  const results = await selectedDirs(root, "all", false);
  for (const item of results) {
    const { scopeDir, notesDir, scope, projectId } = item;
    const path = join(notesDir, `${id}.md`);
    try {
      const raw = await readRegularText(path, notesDir, MAX_NOTE_BYTES);
      const note = parseMarkdown(raw);
      if (note.id !== id || note.scope !== scope || note.projectId !== projectId) throw new ForgeError("MEMORY_NOTE_SCOPE_INVALID", "Memory note identity or scope does not match its storage location.");
      return { note, path, raw, scopeDir };
    } catch (error) {
      if (isNotFound(error)) continue;
      throw error;
    }
  }
  throw new ForgeError("MEMORY_NOTE_NOT_FOUND", `Memory note '${id}' was not found in global or current-project memory.`);
}

export async function verifyMemoryNote(root: string, id: string): Promise<{ note: MemoryNote; integrity: "verified"; sha256: string; indexed: boolean }> {
  const located = await findMemoryNote(root, id);
  const digest = sha256Text(located.raw);
  const index = await readIndex(located.scopeDir);
  const entry = index.entries.find((candidate) => candidate.id === id);
  if (!entry) throw new ForgeError("MEMORY_INDEX_ENTRY_MISSING", "Memory note is valid Markdown, but its JSON index entry is missing. Run 'forge memory reindex --confirm' after reviewing the vault.");
  if (entry.filename !== `${id}.md` || entry.sha256 !== digest || entry.scope !== located.note.scope || entry.projectId !== located.note.projectId) {
    throw new ForgeError("MEMORY_INDEX_STALE", "Memory note and JSON index differ. If you intentionally edited the note outside Forge, review it and run 'forge memory reindex --confirm'.");
  }
  return { note: located.note, integrity: "verified", sha256: digest, indexed: true };
}

export async function reindexMemory(root: string, filter: MemoryScopeFilter = "all"): Promise<number> {
  const locations = await selectedDirs(root, filter, true);
  let count = 0;
  for (const item of locations) count += await rebuildIndex(item.scopeDir, item.notesDir, item.scope, item.projectId);
  return count;
}

export async function forgetMemoryNote(root: string, id: string): Promise<void> {
  const located = await findMemoryNote(root, id);
  const info = await lstat(located.path);
  if (info.isSymbolicLink() || !info.isFile()) throw new ForgeError("MEMORY_NOTE_UNSAFE", "Refusing to delete a symbolic link or special file.");
  await unlink(located.path);
  const notesDir = dirname(located.path);
  const scope = located.note.scope;
  const projectId = located.note.projectId;
  await rebuildIndex(located.scopeDir, notesDir, scope, projectId);
}

export async function editMemoryNote(root: string, id: string): Promise<{ path: string; edited: boolean; detail: string }> {
  const located = await findMemoryNote(root, id);
  if (!process.stdin.isTTY || !process.stdout.isTTY) return { path: located.path, edited: false, detail: "Non-interactive terminal; edit the Markdown file directly. Run memory reindex --confirm after an external edit." };
  const editor = (process.env.VISUAL || process.env.EDITOR || (process.platform === "win32" ? "notepad" : "vi")).trim();
  if (!editor || /[\s"'`;$|&<>]/.test(editor)) throw new ForgeError("MEMORY_EDITOR_UNSAFE", "EDITOR/VISUAL must contain only one executable path; arguments and shell expressions are not accepted.");
  const code = await new Promise<number>((resolveCode, reject) => {
    const child = spawn(editor, [located.path], { stdio: "inherit", shell: false, windowsHide: true });
    child.once("error", reject);
    child.once("exit", (status) => resolveCode(status ?? 1));
  });
  if (code !== 0) throw new ForgeError("MEMORY_EDITOR_FAILED", `Editor exited with status ${code}; the index was not changed.`);
  const raw = await readRegularText(located.path, dirname(located.path), MAX_NOTE_BYTES);
  const note = parseMarkdown(raw);
  if (note.id !== id || note.scope !== located.note.scope || note.projectId !== located.note.projectId) throw new ForgeError("MEMORY_EDIT_IDENTITY_CHANGED", "Edited memory metadata changed its ID or scope; refusing to reindex it.");
  await rebuildIndex(located.scopeDir, dirname(located.path), note.scope, note.projectId);
  return { path: located.path, edited: true, detail: "Edited note validated and index refreshed." };
}

export async function exportMemory(root: string, destination: string, filter: MemoryScopeFilter = "all"): Promise<{ path: string; count: number }> {
  const notes = await listMemoryNotes(root, filter);
  const bundle = { schemaVersion: 1, exportedAt: new Date().toISOString(), notes };
  const json = `${JSON.stringify(bundle, null, 2)}\n`;
  if (Buffer.byteLength(json) > MAX_EXPORT_BYTES) throw new ForgeError("MEMORY_EXPORT_TOO_LARGE", "Memory export exceeds the 20 MiB limit.");
  const path = resolve(destination);
  await mkdir(dirname(path), { recursive: true });
  let handle;
  try {
    handle = await open(path, constants.O_CREAT | constants.O_EXCL | constants.O_WRONLY | (constants.O_NOFOLLOW ?? 0), 0o600);
    await handle.writeFile(json, "utf8");
    await handle.sync();
  } catch (error) {
    if (isExists(error)) throw new ForgeError("MEMORY_EXPORT_EXISTS", "Export destination already exists; choose a new path so Forge does not overwrite your files.");
    throw error;
  } finally { await handle?.close().catch(() => undefined); }
  return { path, count: notes.length };
}

export async function importMemory(root: string, sourcePath: string, options: { confirmed: boolean }): Promise<number> {
  if (options.confirmed !== true) throw new ForgeError("MEMORY_CONFIRM_REQUIRED", "Memory import requires explicit user confirmation.");
  const raw = await readRegularText(resolve(sourcePath), dirname(resolve(sourcePath)), MAX_EXPORT_BYTES);
  let parsed: unknown;
  try { parsed = JSON.parse(raw) as unknown; } catch { throw new ForgeError("MEMORY_IMPORT_INVALID", "Memory import must be a valid Forge JSON export."); }
  if (!isRecord(parsed) || parsed.schemaVersion !== 1 || !Array.isArray(parsed.notes) || parsed.notes.length > 10_000) throw new ForgeError("MEMORY_IMPORT_INVALID", "Memory import schema is invalid or exceeds 10,000 notes.");
  const validated: MemoryNote[] = [];
  const currentProjectId = await projectIdFor(root);
  for (const value of parsed.notes) {
    validateMemoryNote(value);
    const note = value as MemoryNote;
    // Validate every entry before writing any entry, so cross-project data cannot cause a partial import.
    const expectedProjectId = note.scope === "project" ? currentProjectId : null;
    if (note.projectId !== expectedProjectId) throw new ForgeError("MEMORY_PROJECT_MISMATCH", "Import contains project memory from a different project; no cross-project import was performed.");
    validated.push(note);
  }
  for (const note of validated) {
    const newNote: MemoryNote = { ...note, id: randomUUID(), createdAt: new Date().toISOString(), lastVerifiedAt: null, userConfirmed: true };
    await saveMemoryNote(root, newNote, { confirmed: true });
  }
  return validated.length;
}

export async function resetMemory(root: string, filter: MemoryScopeFilter): Promise<number> {
  const locations = await selectedDirs(root, filter, false);
  let deleted = 0;
  for (const item of locations) {
    const notes = await readScopeNotes(item.scopeDir, item.notesDir, item.scope, item.projectId);
    for (const found of notes) {
      await unlink(found.path);
      deleted += 1;
    }
    await rebuildIndex(item.scopeDir, item.notesDir, item.scope, item.projectId);
  }
  return deleted;
}

export function renderMarkdown(note: MemoryNote | MemoryDraft): string {
  if (note.userConfirmed === false) validateMemoryDraft(note); else validateMemoryNote(note);
  const fields: Record<string, unknown> = {
    forge_schema_version: note.schemaVersion,
    forge_id: note.id,
    forge_type: note.type,
    forge_title: note.title,
    forge_problem: note.problem,
    forge_decision: note.decision,
    forge_reason: note.reason,
    forge_rejected_options: note.rejectedOptions,
    forge_limitations: note.limitations,
    forge_evidence: note.evidence,
    forge_confidence: note.confidence,
    forge_created_at: note.createdAt,
    forge_last_verified_at: note.lastVerifiedAt,
    forge_status: note.status,
    forge_scope: note.scope,
    forge_project_id: note.projectId,
    forge_user_confirmed: note.userConfirmed,
  };
  const frontMatter = Object.entries(fields).map(([key, value]) => `${key}: ${JSON.stringify(value)}`).join("\n");
  return `---\n${frontMatter}\n---\n\n# ${note.title}\n\n## Problem\n\n${note.problem}\n\n## Decision / solution\n\n${note.decision}\n\n## Reason\n\n${note.reason}\n\n## Rejected options\n\n${note.rejectedOptions.length ? note.rejectedOptions.map((item) => `- ${item}`).join("\n") : "- None recorded"}\n\n## Limitations\n\n${note.limitations.length ? note.limitations.map((item) => `- ${item}`).join("\n") : "- None recorded"}\n\n## Evidence / sources\n\n${note.evidence.length ? note.evidence.map((item) => `- ${item}`).join("\n") : "- None recorded"}\n\n## Verification\n\n- Confidence: ${note.confidence.toFixed(2)}\n- Created: ${note.createdAt}\n- Last verified: ${note.lastVerifiedAt ?? "never"}\n- Status: ${note.status}\n- Scope: ${note.scope}\n- User confirmed: ${note.userConfirmed ? "yes" : "not yet"}\n`;
}

export function parseMarkdown(raw: string): MemoryNote {
  if (Buffer.byteLength(raw) > MAX_NOTE_BYTES) throw new ForgeError("MEMORY_NOTE_TOO_LARGE", "Memory note exceeds the 256 KiB limit.");
  const parts = raw.split(/\r?\n/);
  if (parts[0] !== "---") throw new ForgeError("MEMORY_NOTE_FRONTMATTER_INVALID", "Memory note must begin with YAML frontmatter.");
  const end = parts.findIndex((line, index) => index > 0 && line === "---");
  if (end < 0) throw new ForgeError("MEMORY_NOTE_FRONTMATTER_INVALID", "Memory note frontmatter is not closed.");
  const meta: Record<string, unknown> = Object.create(null) as Record<string, unknown>;
  for (const line of parts.slice(1, end)) {
    const match = /^([a-z_]+): (.+)$/.exec(line);
    if (!match) throw new ForgeError("MEMORY_NOTE_FRONTMATTER_INVALID", "Unsupported or malformed YAML frontmatter line.");
    const key = match[1] ?? "";
    if (Object.hasOwn(meta, key)) throw new ForgeError("MEMORY_NOTE_FRONTMATTER_INVALID", `Duplicate frontmatter key '${key}'.`);
    try { meta[key] = JSON.parse(match[2] ?? "") as unknown; }
    catch { throw new ForgeError("MEMORY_NOTE_FRONTMATTER_INVALID", `Invalid frontmatter value for '${key}'.`); }
  }
  const note: MemoryNote = {
    schemaVersion: meta.forge_schema_version as 1,
    id: meta.forge_id as string,
    type: meta.forge_type as MemoryType,
    title: meta.forge_title as string,
    problem: meta.forge_problem as string,
    decision: meta.forge_decision as string,
    reason: meta.forge_reason as string,
    rejectedOptions: meta.forge_rejected_options as string[],
    limitations: meta.forge_limitations as string[],
    evidence: meta.forge_evidence as string[],
    confidence: meta.forge_confidence as number,
    createdAt: meta.forge_created_at as string,
    lastVerifiedAt: meta.forge_last_verified_at as string | null,
    status: meta.forge_status as MemoryStatus,
    scope: meta.forge_scope as MemoryScope,
    projectId: meta.forge_project_id as string | null,
    userConfirmed: meta.forge_user_confirmed as true,
  };
  validateMemoryNote(note);
  return note;
}

async function getScopeDirs(root: string, scope: MemoryScope): Promise<{ scopeDir: string; notesDir: string; projectId: string | null }> {
  const base = await ensureVaultRoot();
  let scopeDir: string;
  let projectId: string | null = null;
  if (scope === "global") scopeDir = join(base, "global");
  else {
    projectId = await projectIdFor(root);
    scopeDir = join(base, "projects", projectId);
  }
  await ensureDirectory(scopeDir);
  const notesDir = join(scopeDir, "notes");
  await ensureDirectory(notesDir);
  return { scopeDir, notesDir, projectId };
}

async function selectedDirs(root: string, filter: MemoryScopeFilter, create: boolean): Promise<Array<{ scopeDir: string; notesDir: string; scope: MemoryScope; projectId: string | null }>> {
  const selected: MemoryScope[] = filter === "all" ? ["global", "project"] : [filter];
  const results = [] as Array<{ scopeDir: string; notesDir: string; scope: MemoryScope; projectId: string | null }>;
  for (const scope of selected) {
    if (!create && scope === "project") {
      // Resolving project identity still requires a real project, but an absent memory directory is normal.
      const base = await ensureVaultRoot();
      const projectId = await projectIdFor(root);
      const scopeDir = join(base, "projects", projectId);
      const notesDir = join(scopeDir, "notes");
      if (!(await directoryExists(scopeDir))) continue;
      await assertRealDirectory(scopeDir);
      if (await directoryExists(notesDir)) await assertRealDirectory(notesDir);
      results.push({ scopeDir, notesDir, scope, projectId });
    } else if (!create && scope === "global") {
      const base = await ensureVaultRoot();
      const scopeDir = join(base, "global");
      const notesDir = join(scopeDir, "notes");
      if (!(await directoryExists(scopeDir))) continue;
      await assertRealDirectory(scopeDir);
      if (await directoryExists(notesDir)) await assertRealDirectory(notesDir);
      results.push({ scopeDir, notesDir, scope, projectId: null });
    } else {
      const dirs = await getScopeDirs(root, scope);
      results.push({ ...dirs, scope });
    }
  }
  return results;
}

async function readScopeNotes(scopeDir: string, notesDir: string, scope: MemoryScope, projectId: string | null): Promise<LocatedNote[]> {
  try { await assertRealDirectory(scopeDir); await assertRealDirectory(notesDir); }
  catch (error) { if (isNotFound(error)) return []; throw error; }
  let names: string[];
  try { names = await readdir(notesDir); } catch (error) { if (isNotFound(error)) return []; throw error; }
  const out: LocatedNote[] = [];
  for (const name of names.filter((value) => value.endsWith(".md")).sort()) {
    const id = name.slice(0, -3);
    if (!VALID_ID.test(id)) continue;
    const path = join(notesDir, name);
    const raw = await readRegularText(path, notesDir, MAX_NOTE_BYTES);
    const note = parseMarkdown(raw);
    if (note.id !== id || note.scope !== scope || note.projectId !== projectId) throw new ForgeError("MEMORY_NOTE_SCOPE_INVALID", `Memory note '${name}' has inconsistent ID or scope metadata.`);
    out.push({ note, path, raw, scopeDir });
  }
  return out;
}

async function rebuildIndex(scopeDir: string, notesDir: string, scope?: MemoryScope, projectId?: string | null): Promise<number> {
  const resolvedScope = scope ?? (scopeDir.split(/[\\/]/).includes("global") ? "global" : "project");
  const resolvedProjectId = projectId === undefined ? (resolvedScope === "global" ? null : scopeDir.split(/[\\/]/).at(-1) ?? null) : projectId;
  await ensureDirectory(scopeDir);
  await ensureDirectory(notesDir);
  const notes = await readScopeNotes(scopeDir, notesDir, resolvedScope, resolvedProjectId);
  const index: MemoryIndex = {
    schemaVersion: 1,
    entries: notes.map(({ note, raw }) => ({
      id: note.id,
      filename: `${note.id}.md`,
      sha256: sha256Text(raw),
      type: note.type,
      title: note.title,
      scope: note.scope,
      projectId: note.projectId,
      lastIndexedAt: new Date().toISOString(),
    })),
  };
  await atomicReplace(join(scopeDir, "index.json"), Buffer.from(`${JSON.stringify(index, null, 2)}\n`, "utf8"), scopeDir);
  return index.entries.length;
}

async function readIndex(scopeDir: string): Promise<MemoryIndex> {
  const path = join(scopeDir, "index.json");
  const raw = await readRegularText(path, scopeDir, 5 * 1024 * 1024);
  let parsed: unknown;
  try { parsed = JSON.parse(raw) as unknown; } catch { throw new ForgeError("MEMORY_INDEX_CORRUPT", "Memory index is not valid JSON; run 'forge memory reindex --confirm'."); }
  if (!isRecord(parsed) || parsed.schemaVersion !== 1 || !Array.isArray(parsed.entries)) throw new ForgeError("MEMORY_INDEX_CORRUPT", "Memory index schema is invalid; run 'forge memory reindex --confirm'.");
  for (const entry of parsed.entries) {
    if (!isRecord(entry) || typeof entry.id !== "string" || !VALID_ID.test(entry.id) || entry.filename !== `${entry.id}.md` || typeof entry.sha256 !== "string" || !/^[a-f0-9]{64}$/.test(entry.sha256)) {
      throw new ForgeError("MEMORY_INDEX_CORRUPT", "Memory index contains an invalid entry.");
    }
  }
  return parsed as unknown as MemoryIndex;
}

async function ensureVaultRoot(): Promise<string> {
  const configured = process.env.FORGE_MEMORY_DIR?.trim();
  if (configured) {
    const target = resolve(configured);
    await mkdir(target, { recursive: true });
    const info = await lstat(target);
    if (info.isSymbolicLink() || !info.isDirectory()) throw new ForgeError("MEMORY_VAULT_UNSAFE", "Configured memory vault must be a real directory, not a symlink or special file.");
    const canonical = await realpath(target);
    if (process.platform !== "win32") await chmod(canonical, 0o700).catch(() => undefined);
    return canonical;
  }
  const home = await realpath(homedir());
  const forgeHome = join(home, ".forge");
  await ensureDirectory(forgeHome);
  const memoryHome = join(forgeHome, "memory");
  await ensureDirectory(memoryHome);
  return await realpath(memoryHome);
}

async function ensureDirectory(path: string): Promise<void> {
  try { await mkdir(path, { recursive: true, mode: 0o700 }); } catch (error) { if (!isExists(error)) throw error; }
  const info = await lstat(path);
  if (info.isSymbolicLink() || !info.isDirectory()) throw new ForgeError("MEMORY_DIRECTORY_UNSAFE", "Memory directory must not be a symlink or special file.");
  if (process.platform !== "win32") await chmod(path, 0o700).catch(() => undefined);
}

async function assertRealDirectory(path: string): Promise<void> {
  const info = await lstat(path);
  if (info.isSymbolicLink() || !info.isDirectory()) throw new ForgeError("MEMORY_DIRECTORY_UNSAFE", "Memory directory must be a real directory, not a symlink or special file.");
}

async function directoryExists(path: string): Promise<boolean> {
  try { const info = await lstat(path); if (info.isSymbolicLink() || !info.isDirectory()) throw new ForgeError("MEMORY_DIRECTORY_UNSAFE", "Memory directory must not be a symlink or special file."); return true; }
  catch (error) { if (isNotFound(error)) return false; throw error; }
}

async function readRegularText(path: string, parentDir: string, maxBytes: number): Promise<string> {
  const before = await lstat(path);
  if (before.isSymbolicLink() || !before.isFile() || before.size > maxBytes) throw new ForgeError("MEMORY_FILE_UNSAFE", "Memory files must be regular files within the configured size limit.");
  const handle = await open(path, constants.O_RDONLY | (constants.O_NOFOLLOW ?? 0));
  try {
    const current = await handle.stat();
    if (!current.isFile() || current.size > maxBytes) throw new ForgeError("MEMORY_FILE_UNSAFE", "Memory file changed during open or exceeds its size limit.");
    const canonical = await realpath(path);
    const rel = relative(parentDir, canonical);
    if (rel.startsWith(`..${sep}`) || rel === ".." || resolve(parentDir, rel) !== canonical) throw new ForgeError("MEMORY_PATH_ESCAPE", "Memory file resolves outside its expected directory.");
    return await handle.readFile({ encoding: "utf8" });
  } finally { await handle.close(); }
}

async function atomicCreate(path: string, bytes: Uint8Array, dir: string): Promise<void> {
  const temp = join(dir, `.${randomUUID()}.tmp`);
  let handle;
  try {
    handle = await open(temp, constants.O_CREAT | constants.O_EXCL | constants.O_WRONLY | (constants.O_NOFOLLOW ?? 0), 0o600);
    await handle.writeFile(bytes);
    await handle.sync();
    await handle.close(); handle = undefined;
    await link(temp, path); // Atomic no-overwrite publication.
  } catch (error) {
    if (isExists(error)) throw new ForgeError("MEMORY_NOTE_EXISTS", "Memory note already exists; refusing to overwrite.");
    throw error;
  } finally { await handle?.close().catch(() => undefined); await unlink(temp).catch(() => undefined); }
}

async function atomicReplace(path: string, bytes: Uint8Array, dir: string): Promise<void> {
  try {
    const info = await lstat(path);
    if (info.isSymbolicLink() || !info.isFile()) throw new ForgeError("MEMORY_INDEX_UNSAFE", "Memory index must be a regular file.");
  } catch (error) { if (!isNotFound(error)) throw error; }
  const temp = join(dir, `.${randomUUID()}.tmp`);
  let handle;
  try {
    handle = await open(temp, constants.O_CREAT | constants.O_EXCL | constants.O_WRONLY | (constants.O_NOFOLLOW ?? 0), 0o600);
    await handle.writeFile(bytes); await handle.sync(); await handle.close(); handle = undefined;
    await rename(temp, path);
  } finally { await handle?.close().catch(() => undefined); await unlink(temp).catch(() => undefined); }
}

function validateProposal(value: MemoryProposal): void {
  if (!isRecord(value) || !MEMORY_TYPES.has(value.type) || (value.scope !== "global" && value.scope !== "project")) throw new ForgeError("MEMORY_PROPOSAL_INVALID", "Memory proposal type or scope is invalid.");
  assertText(value.title, "title", 200);
  assertText(value.problem, "problem", 8_000);
  assertText(value.decision, "decision", 8_000);
  assertText(value.reason, "reason", 8_000);
  validateStringList(value.rejectedOptions, "rejectedOptions");
  validateStringList(value.limitations, "limitations");
  validateStringList(value.evidence, "evidence");
  if (!Number.isFinite(value.confidence) || value.confidence < 0 || value.confidence > 1) throw new ForgeError("MEMORY_CONFIDENCE_INVALID", "Memory confidence must be between 0 and 1.");
  assertNoObviousSecrets([value.title, value.problem, value.decision, value.reason, ...value.rejectedOptions, ...value.limitations, ...value.evidence]);
  if (["solution", "research", "failure", "workflow"].includes(value.type) && value.evidence.length === 0) throw new ForgeError("MEMORY_EVIDENCE_REQUIRED", `${value.type} memories require at least one evidence/source reference. Save decisions only with the reason and rejected options that were actually discussed.`);
}

function validateMemoryDraft(value: unknown): asserts value is MemoryDraft {
  if (!isRecord(value) || value.userConfirmed !== false) throw new ForgeError("MEMORY_DRAFT_INVALID", "A memory draft must be explicitly marked as not yet confirmed.");
  validateMemoryNote({ ...value, userConfirmed: true });
}

function validateMemoryNote(value: unknown): asserts value is MemoryNote {
  if (!isRecord(value) || value.schemaVersion !== 1 || typeof value.id !== "string" || !VALID_ID.test(value.id) || !MEMORY_TYPES.has(value.type as MemoryType)) throw new ForgeError("MEMORY_NOTE_INVALID", "Memory note schema version, ID, or type is invalid.");
  assertText(value.title, "title", 200); assertText(value.problem, "problem", 8_000); assertText(value.decision, "decision", 8_000); assertText(value.reason, "reason", 8_000);
  validateStringList(value.rejectedOptions, "rejectedOptions"); validateStringList(value.limitations, "limitations"); validateStringList(value.evidence, "evidence");
  if (typeof value.confidence !== "number" || !Number.isFinite(value.confidence) || value.confidence < 0 || value.confidence > 1) throw new ForgeError("MEMORY_NOTE_INVALID", "Confidence must be between 0 and 1.");
  if (typeof value.createdAt !== "string" || !Number.isFinite(Date.parse(value.createdAt)) || !(value.lastVerifiedAt === null || (typeof value.lastVerifiedAt === "string" && Number.isFinite(Date.parse(value.lastVerifiedAt))))) throw new ForgeError("MEMORY_NOTE_INVALID", "Memory dates are invalid.");
  if (!MEMORY_STATUSES.has(value.status as MemoryStatus) || (value.scope !== "global" && value.scope !== "project") || (value.projectId !== null && (typeof value.projectId !== "string" || !/^[a-f0-9]{24}$/.test(value.projectId))) || value.userConfirmed !== true) throw new ForgeError("MEMORY_NOTE_INVALID", "Memory status, scope, project binding or confirmation marker is invalid.");
  if (value.scope === "global" && value.projectId !== null) throw new ForgeError("MEMORY_NOTE_INVALID", "Global memory cannot contain a project ID.");
  assertNoObviousSecrets([value.title, value.problem, value.decision, value.reason, ...value.rejectedOptions, ...value.limitations, ...value.evidence] as string[]);
}

function assertNoObviousSecrets(fields: string[]): void {
  if (fields.some((field) => redactString(field) !== field)) throw new ForgeError("MEMORY_SECRET_SUSPECTED", "A memory field appears to contain a credential or secret. Remove it before saving; redaction heuristics cannot detect every secret.");
}
function assertText(value: unknown, name: string, max: number): asserts value is string {
  if (typeof value !== "string" || value.trim().length < 2 || value.length > max || value.includes("\u0000")) throw new ForgeError("MEMORY_FIELD_INVALID", `Memory ${name} must contain 2–${max} characters and no NUL bytes.`);
}
function validateStringList(value: unknown, name: string): asserts value is string[] {
  if (!Array.isArray(value) || value.length > 100 || value.some((item) => typeof item !== "string" || item.length > 2_000 || item.includes("\u0000"))) throw new ForgeError("MEMORY_FIELD_INVALID", `Memory ${name} must be a list of at most 100 strings, each no longer than 2,000 characters.`);
}
function assertId(id: string): void { if (!VALID_ID.test(id)) throw new ForgeError("MEMORY_ID_INVALID", "Memory ID must be a UUID."); }
function tokenize(value: string): string[] { return normalize(value).split(/[^a-z0-9_-]+/).filter((part) => part.length >= 2).slice(0, 32); }
function normalize(value: string): string { return value.toLocaleLowerCase("en-US"); }
function isRecord(value: unknown): value is Record<string, unknown> { return value !== null && typeof value === "object" && !Array.isArray(value); }
function isNotFound(error: unknown): boolean { return isRecord(error) && error.code === "ENOENT"; }
function isExists(error: unknown): boolean { return isRecord(error) && error.code === "EEXIST"; }
