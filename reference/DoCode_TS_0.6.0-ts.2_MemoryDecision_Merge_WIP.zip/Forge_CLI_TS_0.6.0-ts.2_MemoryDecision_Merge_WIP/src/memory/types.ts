export type MemoryType =
  | "solution"
  | "decision"
  | "research"
  | "user_preference"
  | "project"
  | "failure"
  | "workflow";

export type MemoryStatus = "active" | "outdated" | "disputed";
export type MemoryScope = "global" | "project";
export type MemoryScopeFilter = MemoryScope | "all";
export type ConfidenceScore = number; // Inclusive range 0..1.

/** A user-visible, human-editable fact/decision record. It deliberately excludes raw model thoughts. */
export interface MemoryNote {
  schemaVersion: 1;
  id: string;
  type: MemoryType;
  title: string;
  problem: string;
  decision: string;
  reason: string;
  rejectedOptions: string[];
  limitations: string[];
  evidence: string[];
  confidence: ConfidenceScore;
  createdAt: string;
  lastVerifiedAt: string | null;
  status: MemoryStatus;
  scope: MemoryScope;
  projectId: string | null;
  userConfirmed: true;
}

/** Data shown to the user before memory is persisted. */
export type MemoryProposal = Omit<MemoryNote, "schemaVersion" | "id" | "createdAt" | "lastVerifiedAt" | "status" | "userConfirmed" | "projectId">;

/** A prepared but unconfirmed memory record; it must not be accepted by storage as confirmed. */
export type MemoryDraft = Omit<MemoryNote, "userConfirmed"> & { userConfirmed: false };

export interface MemoryIndexEntry {
  id: string;
  filename: string;
  sha256: string;
  type: MemoryType;
  title: string;
  scope: MemoryScope;
  projectId: string | null;
  lastIndexedAt: string;
}

export interface MemoryIndex {
  schemaVersion: 1;
  entries: MemoryIndexEntry[];
}
