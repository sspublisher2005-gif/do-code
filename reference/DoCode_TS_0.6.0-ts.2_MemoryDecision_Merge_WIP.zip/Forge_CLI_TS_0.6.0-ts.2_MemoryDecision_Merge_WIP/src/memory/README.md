# Local Learning Memory

Memory notes are reviewed facts/decisions, not hidden reasoning or raw transcripts. The Markdown note is authoritative; the JSON index is a rebuildable cache. Global and project-bound storage paths are distinct. `saveMemoryNote` requires explicit confirmation, and project-bound records must match the canonical current project identity.

The note validator rejects common credential-shaped strings, but this is heuristic. The live Decision Arena does not query or attach memory. Do not add automatic memory injection without a separate explicit context-sharing policy.

Current caveats: note create is exclusive/atomic and index replacement uses a temporary file, but there is not yet one cross-process vault lock around all note+index transactions; a concurrent writer can race index rebuild. Bulk import prevalidates entries before writes but is not fully transactional if the disk fails partway through. Keep this feature marked preview until those conditions receive dedicated tests/fixes.
