import { ForgeError } from "../core/errors.js";

export type ConfigProvider = "openai-compatible" | "anthropic" | "google" | "ollama";
export interface ForgeConfig {
  project: { name: string };
  model: {
    provider: ConfigProvider;
    model: string;
    base_url: string;
    api_key_env: string;
    max_output_tokens: number;
    timeout_ms: number;
  };
  privacy: { mode: "ask" | "local-only"; telemetry: false };
  limits: { max_read_bytes: number; max_files: number; max_search_matches: number };
}

type Primitive = string | number | boolean;
type ParsedToml = Record<string, Record<string, Primitive>>;
const ALLOWED: Record<string, readonly string[]> = {
  project: ["name"],
  model: ["provider", "model", "base_url", "api_key_env", "max_output_tokens", "timeout_ms"],
  privacy: ["mode", "telemetry"],
  limits: ["max_read_bytes", "max_files", "max_search_matches"],
};

function stripComment(line: string): string {
  let quoted = false;
  let escaped = false;
  for (let i = 0; i < line.length; i += 1) {
    const char = line[i];
    if (escaped) { escaped = false; continue; }
    if (char === "\\" && quoted) { escaped = true; continue; }
    if (char === '"') quoted = !quoted;
    if (char === "#" && !quoted) return line.slice(0, i).trim();
  }
  if (quoted) throw new ForgeError("CONFIG_PARSE_ERROR", "Unterminated string in TOML configuration.");
  return line.trim();
}

function parsePrimitive(rawValue: string): Primitive {
  const raw = rawValue.trim();
  if (raw.startsWith('"')) {
    try {
      const value: unknown = JSON.parse(raw);
      if (typeof value !== "string") throw new Error("not a string");
      return value;
    } catch {
      throw new ForgeError("CONFIG_PARSE_ERROR", "Invalid quoted string in TOML configuration.");
    }
  }
  if (raw === "true") return true;
  if (raw === "false") return false;
  if (/^-?(?:0|[1-9]\d*)$/.test(raw)) {
    const value = Number(raw);
    if (!Number.isSafeInteger(value)) throw new ForgeError("CONFIG_PARSE_ERROR", "Integer outside the safe range.");
    return value;
  }
  throw new ForgeError("CONFIG_PARSE_ERROR", "Only quoted strings, booleans, and integers are supported in M1 config.");
}

/** Parse the intentionally limited TOML subset emitted by Forge; unsupported syntax fails closed. */
export function parseTomlSubset(text: string): ParsedToml {
  const parsed: ParsedToml = Object.create(null) as ParsedToml;
  let section = "";
  const lines = text.replace(/^\uFEFF/, "").split(/\r?\n/);
  for (let index = 0; index < lines.length; index += 1) {
    const line = stripComment(lines[index] ?? "");
    if (line.length === 0) continue;
    const sectionMatch = /^\[([A-Za-z][A-Za-z0-9_-]*)\]$/.exec(line);
    if (sectionMatch) {
      section = sectionMatch[1] ?? "";
      if (!(section in ALLOWED)) throw new ForgeError("CONFIG_UNKNOWN_SECTION", `Unknown config section on line ${index + 1}.`);
      if (parsed[section]) throw new ForgeError("CONFIG_DUPLICATE_SECTION", `Duplicate config section on line ${index + 1}.`);
      parsed[section] = Object.create(null) as Record<string, Primitive>;
      continue;
    }
    if (!section) throw new ForgeError("CONFIG_PARSE_ERROR", `Config key appears before a section on line ${index + 1}.`);
    const assignment = /^([A-Za-z][A-Za-z0-9_-]*)\s*=\s*(.+)$/.exec(line);
    if (!assignment) throw new ForgeError("CONFIG_PARSE_ERROR", `Invalid config assignment on line ${index + 1}.`);
    const key = assignment[1] ?? "";
    if (!ALLOWED[section]?.includes(key)) throw new ForgeError("CONFIG_UNKNOWN_KEY", `Unknown config key '${section}.${key}'.`);
    const current = parsed[section];
    if (!current) throw new ForgeError("CONFIG_PARSE_ERROR", "Invalid section state.");
    if (Object.hasOwn(current, key)) throw new ForgeError("CONFIG_DUPLICATE_KEY", `Duplicate config key '${section}.${key}'.`);
    current[key] = parsePrimitive(assignment[2] ?? "");
  }
  return parsed;
}

function requiredString(section: Record<string, Primitive>, key: string, fallback: string): string {
  const value = section[key];
  if (value === undefined) return fallback;
  if (typeof value !== "string" || value.trim().length === 0) throw new ForgeError("CONFIG_INVALID_VALUE", `Expected a non-empty string for ${key}.`);
  return value;
}
function requiredInteger(section: Record<string, Primitive>, key: string, fallback: number, min: number, max: number): number {
  const value = section[key];
  if (value === undefined) return fallback;
  if (typeof value !== "number" || !Number.isSafeInteger(value) || value < min || value > max) {
    throw new ForgeError("CONFIG_INVALID_VALUE", `Expected ${key} to be an integer between ${min} and ${max}.`);
  }
  return value;
}

export function validateConfig(parsed: ParsedToml, defaults: ForgeConfig): ForgeConfig {
  for (const sectionName of Object.keys(parsed)) {
    if (!(sectionName in ALLOWED)) throw new ForgeError("CONFIG_UNKNOWN_SECTION", `Unknown config section '${sectionName}'.`);
    for (const key of Object.keys(parsed[sectionName] ?? {})) {
      if (!ALLOWED[sectionName]?.includes(key)) throw new ForgeError("CONFIG_UNKNOWN_KEY", `Unknown config key '${sectionName}.${key}'.`);
    }
  }
  const project = parsed.project ?? {};
  const model = parsed.model ?? {};
  const privacy = parsed.privacy ?? {};
  const limits = parsed.limits ?? {};

  const provider = requiredString(model, "provider", defaults.model.provider);
  if (!["openai-compatible", "anthropic", "google", "ollama"].includes(provider)) {
    throw new ForgeError("CONFIG_INVALID_VALUE", "Unsupported model provider.");
  }
  const baseUrl = requiredString(model, "base_url", defaults.model.base_url);
  let url: URL;
  try { url = new URL(baseUrl); } catch { throw new ForgeError("CONFIG_INVALID_VALUE", "model.base_url must be a valid URL."); }
  if ((url.protocol !== "https:" && !(url.protocol === "http:" && ["localhost", "127.0.0.1", "::1", "[::1]"].includes(url.hostname))) || url.username || url.password || url.search || url.hash) {
    throw new ForgeError("CONFIG_INVALID_VALUE", "model.base_url must use HTTPS or a loopback HTTP endpoint and cannot contain credentials, query, or fragment.");
  }
  const apiKeyEnv = requiredString(model, "api_key_env", defaults.model.api_key_env);
  const allowedKeyEnvByProvider: Record<ConfigProvider, readonly string[]> = {
    "openai-compatible": ["FORGE_MODEL_API_KEY", "OPENAI_API_KEY", "OPENAI_COMPATIBLE_API_KEY", "OPENROUTER_API_KEY", "DEEPSEEK_API_KEY"],
    anthropic: ["FORGE_MODEL_API_KEY", "ANTHROPIC_API_KEY"],
    google: ["FORGE_MODEL_API_KEY", "GOOGLE_API_KEY", "GEMINI_API_KEY"],
    ollama: ["FORGE_MODEL_API_KEY", "OLLAMA_API_KEY"],
  };
  if (!allowedKeyEnvByProvider[provider as ConfigProvider].includes(apiKeyEnv)) {
    throw new ForgeError("CONFIG_INVALID_VALUE", "model.api_key_env must be a documented model-credential environment variable for the selected provider; arbitrary environment variables are rejected.");
  }
  const privacyMode = requiredString(privacy, "mode", defaults.privacy.mode);
  if (privacyMode !== "ask" && privacyMode !== "local-only") throw new ForgeError("CONFIG_INVALID_VALUE", "privacy.mode must be 'ask' or 'local-only'.");
  if (privacy.telemetry !== undefined && privacy.telemetry !== false) throw new ForgeError("CONFIG_INVALID_VALUE", "Forge telemetry is off by default and cannot be enabled in this version.");

  return {
    project: { name: requiredString(project, "name", defaults.project.name) },
    model: {
      provider: provider as ConfigProvider,
      model: requiredString(model, "model", defaults.model.model),
      base_url: baseUrl,
      api_key_env: apiKeyEnv,
      max_output_tokens: requiredInteger(model, "max_output_tokens", defaults.model.max_output_tokens, 1, 128000),
      timeout_ms: requiredInteger(model, "timeout_ms", defaults.model.timeout_ms, 1000, 300000),
    },
    privacy: { mode: privacyMode, telemetry: false },
    limits: {
      max_read_bytes: requiredInteger(limits, "max_read_bytes", defaults.limits.max_read_bytes, 1024, 16 * 1024 * 1024),
      max_files: requiredInteger(limits, "max_files", defaults.limits.max_files, 1, 100000),
      max_search_matches: requiredInteger(limits, "max_search_matches", defaults.limits.max_search_matches, 1, 10000),
    },
  };
}

export function serializeConfig(config: ForgeConfig): string {
  const q = (value: string): string => JSON.stringify(value);
  return [
    "[project]", `name = ${q(config.project.name)}`, "",
    "[model]", `provider = ${q(config.model.provider)}`, `model = ${q(config.model.model)}`,
    `base_url = ${q(config.model.base_url)}`, `api_key_env = ${q(config.model.api_key_env)}`,
    `max_output_tokens = ${config.model.max_output_tokens}`, `timeout_ms = ${config.model.timeout_ms}`, "",
    "[privacy]", `mode = ${q(config.privacy.mode)}`, "telemetry = false", "",
    "[limits]", `max_read_bytes = ${config.limits.max_read_bytes}`, `max_files = ${config.limits.max_files}`,
    `max_search_matches = ${config.limits.max_search_matches}`, "",
  ].join("\n");
}
