import { lstat, readFile, realpath } from "node:fs/promises";
import { join } from "node:path";
import { ForgeError } from "../core/errors.js";
import { DEFAULT_CONFIG } from "./defaults.js";
import { parseTomlSubset, validateConfig, type ForgeConfig } from "./schema.js";

export async function loadConfig(root: string): Promise<{ config: ForgeConfig; exists: boolean; path: string }> {
  const canonicalRoot = await realpath(root);
  const configPath = join(canonicalRoot, "forge.config.toml");
  try {
    const info = await lstat(configPath);
    if (info.isSymbolicLink() || !info.isFile()) throw new ForgeError("CONFIG_UNSAFE_FILE", "forge.config.toml must be a regular file, not a symlink or special file.");
    if (info.size > 128 * 1024) throw new ForgeError("CONFIG_TOO_LARGE", "forge.config.toml exceeds the 128 KiB limit.");
    const source = await readFile(configPath, "utf8");
    return { config: validateConfig(parseTomlSubset(source), DEFAULT_CONFIG), exists: true, path: configPath };
  } catch (error) {
    if (isNotFound(error)) return { config: structuredClone(DEFAULT_CONFIG), exists: false, path: configPath };
    throw error;
  }
}

function isNotFound(error: unknown): boolean {
  return error !== null && typeof error === "object" && "code" in error && error.code === "ENOENT";
}
