import { open, lstat, realpath, link, unlink } from "node:fs/promises";
import { constants } from "node:fs";
import { dirname, basename, join } from "node:path";
import { randomUUID } from "node:crypto";
import { ForgeError } from "../core/errors.js";
import { serializeConfig, type ForgeConfig } from "./schema.js";

export async function createConfigIfMissing(root: string, config: ForgeConfig): Promise<{ created: boolean; path: string }> {
  const canonicalRoot = await realpath(root);
  const target = join(canonicalRoot, "forge.config.toml");
  try {
    const info = await lstat(target);
    if (info.isSymbolicLink() || !info.isFile()) throw new ForgeError("CONFIG_UNSAFE_FILE", "Existing forge.config.toml is not a regular file; it was not changed.");
    return { created: false, path: target };
  } catch (error) {
    if (!isNotFound(error)) throw error;
  }

  const temp = join(dirname(target), `.${basename(target)}.${randomUUID()}.tmp`);
  let handle;
  try {
    handle = await open(temp, constants.O_CREAT | constants.O_EXCL | constants.O_WRONLY, 0o600);
    await handle.writeFile(serializeConfig(config), "utf8");
    await handle.sync();
    await handle.close();
    handle = undefined;
    // Hard-link creation is exclusive: if another process creates the target first, link() fails with EEXIST instead of replacing it.
    try {
      await link(temp, target);
    } catch (error) {
      if (isExists(error)) throw new ForgeError("CONFIG_RACE", "Configuration appeared during initialization; refusing to replace it.");
      throw error;
    }
    await unlink(temp);
    return { created: true, path: target };
  } catch (error) {
    if (handle) await handle.close().catch(() => undefined);
    await unlink(temp).catch(() => undefined);
    throw error;
  }
}

function isNotFound(error: unknown): boolean {
  return error !== null && typeof error === "object" && "code" in error && error.code === "ENOENT";
}
function isExists(error: unknown): boolean {
  return error !== null && typeof error === "object" && "code" in error && error.code === "EEXIST";
}
