import { constants } from "node:fs";
import { chmod, lstat, mkdir, realpath } from "node:fs/promises";
import { join, relative, sep } from "node:path";
import { ForgeError } from "../core/errors.js";

export async function ensureProjectHome(rootInput: string): Promise<{ root: string; home: string }> {
  const root = await realpath(rootInput);
  const rootInfo = await lstat(root);
  if (!rootInfo.isDirectory()) throw new ForgeError("WORKSPACE_INVALID", "Workspace root must be a directory.");
  const home = join(root, ".forge");
  try {
    const info = await lstat(home);
    if (info.isSymbolicLink() || !info.isDirectory()) throw new ForgeError("PROJECT_HOME_UNSAFE", ".forge must be a real directory, not a symlink or special file.");
  } catch (error) {
    if (!isNotFound(error)) throw error;
    try {
      await mkdir(home, { mode: 0o700 });
    } catch (mkdirError) {
      // Another process may have initialized the same project home after our ENOENT check.
      if (!(mkdirError !== null && typeof mkdirError === "object" && "code" in mkdirError && mkdirError.code === "EEXIST")) throw mkdirError;
      const racedInfo = await lstat(home);
      if (racedInfo.isSymbolicLink() || !racedInfo.isDirectory()) throw new ForgeError("PROJECT_HOME_UNSAFE", ".forge must be a real directory, not a symlink or special file.");
    }
  }
  const canonicalHome = await realpath(home);
  const relativeHome = relative(root, canonicalHome);
  if (relativeHome !== ".forge" || relativeHome.startsWith(`..${sep}`)) throw new ForgeError("PROJECT_HOME_ESCAPE", ".forge directory resolves outside the workspace.");
  if (process.platform !== "win32") await chmod(canonicalHome, 0o700).catch(() => undefined);
  return { root, home: canonicalHome };
}

function isNotFound(error: unknown): boolean {
  return error !== null && typeof error === "object" && "code" in error && error.code === "ENOENT";
}
