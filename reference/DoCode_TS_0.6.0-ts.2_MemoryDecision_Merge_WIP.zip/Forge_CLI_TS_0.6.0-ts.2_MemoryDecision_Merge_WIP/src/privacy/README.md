# Privacy boundary

`project-home.ts` creates/validates `.forge/` and sets restrictive POSIX permissions where supported. Project IDs are derived from canonical root identity. Account/project memory sharing is not implemented: default is isolation. Cross-project context can only be imported through a future explicit import workflow that records source project, exact selected items and consent.
