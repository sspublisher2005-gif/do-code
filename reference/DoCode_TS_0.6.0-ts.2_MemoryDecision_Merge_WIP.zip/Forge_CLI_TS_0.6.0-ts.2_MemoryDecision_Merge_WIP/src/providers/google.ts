import { ForgeError } from "../core/errors.js";
import type { ModelProvider, ModelRequest, ModelResponse, TokenUsage } from "../core/types.js";
import { validateBaseUrl } from "./openai-compatible.js";
import { isRecord, requestJson } from "./http-utils.js";

export interface GoogleGenAIOptions { baseUrl: string; apiKey?: string; fetchImpl?: typeof fetch }
export class GoogleGenAIProvider implements ModelProvider {
  readonly id = "google" as const;
  readonly #baseUrl: URL; readonly #apiKey?: string; readonly #fetch: typeof fetch;
  constructor(options: GoogleGenAIOptions) { this.#baseUrl = validateBaseUrl(options.baseUrl, false); if (options.apiKey?.trim()) this.#apiKey = options.apiKey; this.#fetch = options.fetchImpl ?? fetch; }
  async generate(request: ModelRequest): Promise<ModelResponse> {
    validateModelRequest(request);
    if (!this.#apiKey) throw new ForgeError("PROVIDER_KEY_MISSING", "Google GenAI API key is not configured in the selected environment variable.");
    const modelName = request.model.replace(/^models\//, "");
    if (!/^[A-Za-z0-9._:-]{1,200}$/.test(modelName)) throw new ForgeError("PROVIDER_MODEL_INVALID", "Google model identifier contains unsupported characters.");
    const endpoint = new URL(`${this.#baseUrl.pathname.replace(/\/$/, "")}/models/${encodeURIComponent(modelName)}:generateContent`, this.#baseUrl.origin);
    const contents = request.messages.map((m) => ({ role: m.role === "assistant" ? "model" : "user", parts: [{ text: m.content }] }));
    const started = Date.now();
    const { response, payload } = await requestJson(endpoint.toString(), {
      method: "POST", headers: { "content-type": "application/json", "x-goog-api-key": this.#apiKey },
      body: JSON.stringify({ systemInstruction: { parts: [{ text: request.system }] }, contents, generationConfig: { maxOutputTokens: request.maxOutputTokens } }),
    }, { fetchImpl: this.#fetch, timeoutMs: request.timeoutMs, ...(request.signal ? { signal: request.signal } : {}), retries: 2 });
    if (!isRecord(payload) || !Array.isArray(payload.candidates)) throw new ForgeError("PROVIDER_INVALID_RESPONSE", "Google GenAI response shape was not recognized.");
    const first = payload.candidates.find(isRecord); const content = first && isRecord(first.content) && Array.isArray(first.content.parts) ? first.content.parts : [];
    const text = content.filter(isRecord).filter((part) => typeof part.text === "string").map((part) => part.text as string).join("\n");
    if (!text) throw new ForgeError("PROVIDER_INVALID_RESPONSE", "Google GenAI response contained no text output.");
    const rawUsage = isRecord(payload.usageMetadata) ? payload.usageMetadata : {};
    const usage: TokenUsage = { costKnown: false, source: "unknown" };
    if (isNonNegativeInt(rawUsage.promptTokenCount)) usage.inputTokens = rawUsage.promptTokenCount;
    if (isNonNegativeInt(rawUsage.candidatesTokenCount)) usage.outputTokens = rawUsage.candidatesTokenCount;
    if (isNonNegativeInt(rawUsage.cachedContentTokenCount)) usage.cachedInputTokens = rawUsage.cachedContentTokenCount;
    if (usage.inputTokens !== undefined || usage.outputTokens !== undefined) usage.source = "provider_reported";
    const result: ModelResponse = { text, provider: this.id, model: typeof payload.modelVersion === "string" ? payload.modelVersion : request.model, usage, durationMs: Date.now() - started };
    if (typeof payload.responseId === "string") result.requestId = payload.responseId.slice(0, 160);
    else { const requestId = response.headers.get("x-request-id"); if (requestId) result.requestId = requestId.slice(0, 160); }
    return result;
  }
  async healthCheck(options: { networkConsent?: boolean; signal?: AbortSignal } = {}): Promise<{ ok: boolean; detail: string }> {
    if (!options.networkConsent) return { ok: false, detail: "Network check requires explicit networkConsent: true; no request was sent." };
    if (!this.#apiKey) return { ok: false, detail: "Google API key is missing; no request was sent." };
    return { ok: false, detail: "Google GenAI health is checked using an explicitly approved diagnostic generation request, not a separate no-cost probe." };
  }
}
function validateModelRequest(r: ModelRequest): void { if (!r.model.trim() || r.model.length > 256 || !r.system || r.system.length > 100_000 || !r.messages.length || r.messages.length > 100 || !Number.isSafeInteger(r.maxOutputTokens) || r.maxOutputTokens < 1 || r.maxOutputTokens > 128_000 || !Number.isSafeInteger(r.timeoutMs) || r.timeoutMs < 1000 || r.timeoutMs > 300_000) throw new ForgeError("PROVIDER_REQUEST_INVALID", "Model request exceeds provider request bounds."); }
function isNonNegativeInt(v: unknown): v is number { return typeof v === "number" && Number.isSafeInteger(v) && v >= 0; }
