import { ForgeError } from "../core/errors.js";
import type { ModelProvider, ModelRequest, ModelResponse, ProviderId, TokenUsage } from "../core/types.js";
import { redactString } from "../safety/secret-redaction.js";

export interface OpenAICompatibleOptions {
  baseUrl: string;
  apiKey?: string;
  fetchImpl?: typeof fetch;
  allowedLocalHttp?: boolean;
  providerId?: "openai-compatible" | "ollama";
}
interface JsonObject { [key: string]: unknown }
const MAX_PROVIDER_RESPONSE_BYTES = 2 * 1024 * 1024;

export class OpenAICompatibleProvider implements ModelProvider {
  readonly id: "openai-compatible" | "ollama";
  readonly #baseUrl: URL;
  readonly #apiKey?: string;
  readonly #fetch: typeof fetch;

  constructor(options: OpenAICompatibleOptions) {
    this.id = options.providerId ?? "openai-compatible";
    this.#baseUrl = validateBaseUrl(options.baseUrl, options.allowedLocalHttp ?? true);
    if (options.apiKey !== undefined && options.apiKey.trim().length === 0) throw new ForgeError("PROVIDER_KEY_EMPTY", "Provider API key is empty.");
    if (options.apiKey !== undefined) this.#apiKey = options.apiKey;
    this.#fetch = options.fetchImpl ?? fetch;
  }

  async generate(request: ModelRequest): Promise<ModelResponse> {
    validateRequest(request);
    if (!this.#apiKey) throw new ForgeError("PROVIDER_KEY_MISSING", "Provider credentials are not configured in the named environment variable.");
    const endpoint = this.#endpoint("chat/completions");
    const messages = [
      { role: "system", content: request.system },
      ...request.messages.map((message) => ({ role: message.role, content: message.content })),
    ];
    const started = Date.now();
    let response: Response;
    try {
      const timeout = AbortSignal.timeout(request.timeoutMs);
      const signal = request.signal ? AbortSignal.any([request.signal, timeout]) : timeout;
      response = await this.#fetch(endpoint, {
        method: "POST",
        headers: { "content-type": "application/json", authorization: `Bearer ${this.#apiKey}` },
        body: JSON.stringify({ model: request.model, messages, max_tokens: request.maxOutputTokens, stream: false }),
        signal,
        redirect: "error",
      });
    } catch (error) {
      if (request.signal?.aborted) throw new ForgeError("PROVIDER_CANCELLED", "Provider request was cancelled.");
      if (isAbortError(error)) throw new ForgeError("PROVIDER_TIMEOUT", "Provider request timed out.");
      throw new ForgeError("PROVIDER_TRANSPORT_ERROR", "Provider request failed before a valid response was received.");
    }
    if (!response.ok) {
      throw new ForgeError("PROVIDER_HTTP_ERROR", `Provider returned HTTP ${response.status}.`, { status: response.status });
    }
    const payload = await readJsonBounded(response, MAX_PROVIDER_RESPONSE_BYTES);
    if (!isRecord(payload)) throw new ForgeError("PROVIDER_INVALID_RESPONSE", "Provider returned an unexpected response shape.");
    const choices = payload.choices;
    if (!Array.isArray(choices) || !choices[0] || !isRecord(choices[0])) throw new ForgeError("PROVIDER_INVALID_RESPONSE", "Provider response did not contain a completion choice.");
    const message = choices[0].message;
    if (!isRecord(message) || typeof message.content !== "string") throw new ForgeError("PROVIDER_INVALID_RESPONSE", "Provider response content is missing or not text.");
    const usage = normalizeUsage(payload.usage);
    const requestId = typeof payload.id === "string" ? redactString(payload.id).slice(0, 160) : undefined;
    const result: ModelResponse = {
      text: message.content,
      provider: this.id,
      model: typeof payload.model === "string" ? payload.model : request.model,
      usage,
      durationMs: Date.now() - started,
    };
    if (requestId !== undefined) result.requestId = requestId;
    return result;
  }

  async healthCheck(options: { networkConsent?: boolean; signal?: AbortSignal } = {}): Promise<{ ok: boolean; detail: string }> {
    if (!options.networkConsent) {
      return { ok: false, detail: "Network check requires explicit networkConsent: true; no request was sent." };
    }
    if (!this.#apiKey) return { ok: false, detail: "Provider key is missing; no request was sent." };
    try {
      const timeout = AbortSignal.timeout(5000);
      const combined = options.signal ? AbortSignal.any([options.signal, timeout]) : timeout;
      const response = await this.#fetch(this.#endpoint("models"), {
        method: "GET",
        headers: { authorization: `Bearer ${this.#apiKey}` },
        signal: combined,
        redirect: "error",
      });
      return response.ok
        ? { ok: true, detail: `Provider endpoint answered with HTTP ${response.status}.` }
        : { ok: false, detail: `Provider endpoint returned HTTP ${response.status}.` };
    } catch (error) {
      if (options.signal?.aborted) return { ok: false, detail: "Provider health check cancelled." };
      return { ok: false, detail: isAbortError(error) ? "Provider health check timed out." : "Provider endpoint could not be reached." };
    }
  }

  #endpoint(resource: string): string {
    const base = this.#baseUrl.toString().replace(/\/+$/, "");
    return `${base}/${resource}`;
  }
}

export function validateBaseUrl(value: string, allowedLocalHttp = true): URL {
  let url: URL;
  try { url = new URL(value); }
  catch { throw new ForgeError("PROVIDER_URL_INVALID", "Provider base URL is invalid."); }
  const loopbackHosts = new Set(["localhost", "127.0.0.1", "[::1]"]);
  const localHttp = url.protocol === "http:" && allowedLocalHttp && loopbackHosts.has(url.hostname);
  if (url.protocol !== "https:" && !localHttp) throw new ForgeError("PROVIDER_URL_SCHEME_DENIED", "Provider endpoint must use HTTPS; HTTP is allowed only for explicit loopback endpoints.");
  if (url.username || url.password || url.search || url.hash) throw new ForgeError("PROVIDER_URL_CREDENTIALS_DENIED", "Provider base URL must not contain credentials, query parameters, or a fragment.");
  if (url.hostname === "0.0.0.0" || url.hostname === "::" || url.hostname === "[::]") throw new ForgeError("PROVIDER_URL_HOST_DENIED", "Unspecified-address provider endpoints are not allowed.");
  url.pathname = url.pathname.replace(/\/+$/, "");
  if (url.pathname.endsWith("/chat/completions") || url.pathname.endsWith("/models")) throw new ForgeError("PROVIDER_URL_PATH_INVALID", "Configure the API base path, not a specific endpoint path.");
  return url;
}

function normalizeUsage(value: unknown): TokenUsage {
  if (!isRecord(value)) return { costKnown: false, source: "unknown" };
  const usage: TokenUsage = { costKnown: false, source: "unknown" };
  const input = numberField(value, ["prompt_tokens", "input_tokens"]);
  const output = numberField(value, ["completion_tokens", "output_tokens"]);
  const cached = nestedNumber(value, ["prompt_tokens_details", "cached_tokens"]) ?? nestedNumber(value, ["input_tokens_details", "cached_tokens"]);
  if (input !== undefined && input >= 0) usage.inputTokens = input;
  if (output !== undefined && output >= 0) usage.outputTokens = output;
  if (cached !== undefined && cached >= 0) usage.cachedInputTokens = cached;
  if (input !== undefined || output !== undefined) usage.source = "provider_reported";
  const cost = numberField(value, ["cost_usd"]);
  if (cost !== undefined && Number.isFinite(cost) && cost >= 0) {
    usage.costUsd = cost;
    usage.costKnown = true;
    usage.source = "provider_reported";
  }
  return usage;
}

function numberField(record: JsonObject, keys: string[]): number | undefined {
  for (const key of keys) {
    const value = record[key];
    if (typeof value === "number" && Number.isFinite(value)) return value;
  }
  return undefined;
}
function nestedNumber(record: JsonObject, path: string[]): number | undefined {
  let current: unknown = record;
  for (const key of path) {
    if (!isRecord(current)) return undefined;
    current = current[key];
  }
  return typeof current === "number" && Number.isFinite(current) ? current : undefined;
}
function isRecord(value: unknown): value is JsonObject {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}
function validateRequest(request: ModelRequest): void {
  if (!request.model.trim() || request.model.length > 256) throw new ForgeError("PROVIDER_REQUEST_INVALID", "Model identifier is invalid.");
  if (!request.system || request.system.length > 100_000) throw new ForgeError("PROVIDER_REQUEST_INVALID", "System prompt is empty or exceeds the request bound.");
  if (!Array.isArray(request.messages) || request.messages.length < 1 || request.messages.length > 100) throw new ForgeError("PROVIDER_REQUEST_INVALID", "Request message count is outside allowed bounds.");
  let totalChars = request.system.length;
  for (const message of request.messages) {
    if ((message.role !== "user" && message.role !== "assistant") || typeof message.content !== "string") throw new ForgeError("PROVIDER_REQUEST_INVALID", "Malformed message in provider request.");
    totalChars += message.content.length;
    if (totalChars > 500_000) throw new ForgeError("PROVIDER_REQUEST_TOO_LARGE", "Provider request exceeds the 500,000-character input bound.");
  }
  if (!Number.isSafeInteger(request.maxOutputTokens) || request.maxOutputTokens < 1 || request.maxOutputTokens > 128_000) throw new ForgeError("PROVIDER_REQUEST_INVALID", "Output token limit is outside allowed bounds.");
  if (!Number.isSafeInteger(request.timeoutMs) || request.timeoutMs < 1000 || request.timeoutMs > 300_000) throw new ForgeError("PROVIDER_REQUEST_INVALID", "Timeout is outside allowed bounds.");
}
function isAbortError(error: unknown): boolean {
  return error !== null && typeof error === "object" && "name" in error && (error.name === "AbortError" || error.name === "TimeoutError");
}


async function readJsonBounded(response: Response, maxBytes: number): Promise<unknown> {
  const declaredLength = response.headers.get("content-length");
  if (declaredLength && /^\d+$/.test(declaredLength) && Number(declaredLength) > maxBytes) {
    await response.body?.cancel().catch(() => undefined);
    throw new ForgeError("PROVIDER_RESPONSE_TOO_LARGE", `Provider response exceeded the ${maxBytes}-byte limit.`);
  }
  if (!response.body) throw new ForgeError("PROVIDER_INVALID_JSON", "Provider response body is empty.");
  const reader = response.body.getReader();
  const chunks: Uint8Array[] = [];
  let bytes = 0;
  try {
    while (true) {
      const part = await reader.read();
      if (part.done) break;
      bytes += part.value.byteLength;
      if (bytes > maxBytes) {
        await reader.cancel().catch(() => undefined);
        throw new ForgeError("PROVIDER_RESPONSE_TOO_LARGE", `Provider response exceeded the ${maxBytes}-byte limit.`);
      }
      chunks.push(part.value);
    }
  } finally {
    reader.releaseLock();
  }
  let parsed: unknown;
  try { parsed = JSON.parse(Buffer.concat(chunks.map((chunk) => Buffer.from(chunk))).toString("utf8")) as unknown; }
  catch { throw new ForgeError("PROVIDER_INVALID_JSON", "Provider response was not valid JSON."); }
  return parsed;
}
