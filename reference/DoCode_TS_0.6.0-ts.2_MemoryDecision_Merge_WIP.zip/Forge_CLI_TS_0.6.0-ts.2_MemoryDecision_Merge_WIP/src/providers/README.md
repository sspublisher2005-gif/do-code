# Model providers

M1 implements the `ModelProvider` interface with `OpenAICompatibleProvider` only. Anthropic and Google direct adapters and a fully characterized Ollama-specific adapter are future work. Ollama can be pointed at a local OpenAI-compatible endpoint if that API surface is compatible. An explicit local endpoint is not proof that the host has network isolation.
