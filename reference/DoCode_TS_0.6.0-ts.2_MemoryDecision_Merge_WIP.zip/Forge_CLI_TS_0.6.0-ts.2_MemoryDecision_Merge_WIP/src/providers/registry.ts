import { ForgeError } from "../core/errors.js";
import type { ForgeConfig } from "../config/schema.js";
import type { ModelProvider } from "../core/types.js";
import { AnthropicProvider } from "./anthropic.js";
import { GoogleGenAIProvider } from "./google.js";
import { OpenAICompatibleProvider } from "./openai-compatible.js";

export function effectiveProviderBaseUrl(config: ForgeConfig, env: NodeJS.ProcessEnv = process.env): string {
  const configured = env.FORGE_BASE_URL ?? config.model.base_url;
  // If the user changed only the provider field from the untouched default config, select that provider's default endpoint.
  const wasDefaultOpenAI = configured === "https://api.openai.com/v1";
  return wasDefaultOpenAI && config.model.provider === "anthropic" ? "https://api.anthropic.com"
    : wasDefaultOpenAI && config.model.provider === "google" ? "https://generativelanguage.googleapis.com/v1beta"
    : wasDefaultOpenAI && config.model.provider === "ollama" ? "http://127.0.0.1:11434/v1"
    : configured;
}

export function createConfiguredProvider(config: ForgeConfig, env: NodeJS.ProcessEnv = process.env): ModelProvider {
  const baseUrl = effectiveProviderBaseUrl(config, env);
  const key = env[config.model.api_key_env];
  switch (config.model.provider) {
    case "openai-compatible":
      return new OpenAICompatibleProvider({ baseUrl, ...(key ? { apiKey: key } : {}), allowedLocalHttp: true });
    case "ollama": {
      const endpoint = baseUrl || "http://127.0.0.1:11434/v1";
      const url = new URL(endpoint);
      const isLoopback = ["localhost", "127.0.0.1", "[::1]"].includes(url.hostname);
      if (!isLoopback) throw new ForgeError("PRIVACY_OLLAMA_REMOTE_DENIED", "Ollama provider is loopback-only by default. Remote OpenAI-compatible servers should use the openai-compatible provider with explicit consent.");
      return new OpenAICompatibleProvider({ baseUrl: endpoint, apiKey: key ?? "ollama-local", allowedLocalHttp: true, providerId: "ollama" });
    }
    case "anthropic": return new AnthropicProvider({ baseUrl, ...(key ? { apiKey: key } : {}) });
    case "google": return new GoogleGenAIProvider({ baseUrl, ...(key ? { apiKey: key } : {}) });
    default: throw new ForgeError("PROVIDER_NOT_IMPLEMENTED", "Configured model provider is not supported.");
  }
}
