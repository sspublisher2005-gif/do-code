import { ForgeError } from "../core/errors.js";
import type { ModelProvider, ModelRequest, ModelResponse, TokenUsage } from "../core/types.js";
import { validateBaseUrl } from "./openai-compatible.js";
import { isRecord, requestJson } from "./http-utils.js";

export interface AnthropicOptions { baseUrl: string; apiKey?: string; fetchImpl?: typeof fetch }
export class AnthropicProvider implements ModelProvider {
  readonly id = "anthropic" as const;
  readonly #baseUrl: URL; readonly #apiKey?: string; readonly #fetch: typeof fetch;
  constructor(options: AnthropicOptions) {
    this.#baseUrl = validateBaseUrl(options.baseUrl, false);
    if (options.apiKey?.trim()) this.#apiKey = options.apiKey;
    this.#fetch = options.fetchImpl ?? fetch;
  }
  async generate(request: ModelRequest): Promise<ModelResponse> {
    validateModelRequest(request);
    if (!this.#apiKey) throw new ForgeError("PROVIDER_KEY_MISSING", "Anthropic API key is not configured in the selected environment variable.");
    const url = new URL("/v1/messages", this.#baseUrl);
    const started = Date.now();
    const { response, payload } = await requestJson(url.toString(), {
      method: "POST", headers: { "content-type": "application/json", "x-api-key": this.#apiKey, "anthropic-version": "2023-06-01" },
      body: JSON.stringify({ model: request.model, system: request.system, max_tokens: request.maxOutputTokens, messages: request.messages.map((m) => ({ role: m.role, content: m.content })) }),
    }, { fetchImpl: this.#fetch, timeoutMs: request.timeoutMs, ...(request.signal ? { signal: request.signal } : {}), retries: 2 });
    if (!isRecord(payload) || !Array.isArray(payload.content)) throw new ForgeError("PROVIDER_INVALID_RESPONSE", "Anthropic response shape was not recognized.");
    const text = payload.content.filter(isRecord).filter((item) => item.type === "text" && typeof item.text === "string").map((item) => item.text as string).join("\n");
    if (!text) throw new ForgeError("PROVIDER_INVALID_RESPONSE", "Anthropic response contained no text output.");
    const rawUsage = isRecord(payload.usage) ? payload.usage : {};
    const usage: TokenUsage = { costKnown: false, source: "unknown" };
    if (isNonNegativeInt(rawUsage.input_tokens)) usage.inputTokens = rawUsage.input_tokens;
    if (isNonNegativeInt(rawUsage.output_tokens)) usage.outputTokens = rawUsage.output_tokens;
    if (usage.inputTokens !== undefined || usage.outputTokens !== undefined) usage.source = "provider_reported";
    const result: ModelResponse = { text, provider: this.id, model: typeof payload.model === "string" ? payload.model : request.model, usage, durationMs: Date.now() - started };
    if (typeof response.headers.get("request-id") === "string") { const id = response.headers.get("request-id"); if (id) result.requestId = id.slice(0, 160); }
    return result;
  }
  async healthCheck(options: { networkConsent?: boolean; signal?: AbortSignal } = {}): Promise<{ ok: boolean; detail: string }> {
    if (!options.networkConsent) return { ok: false, detail: "Network check requires explicit networkConsent: true; no request was sent." };
    if (!this.#apiKey) return { ok: false, detail: "Anthropic API key is missing; no request was sent." };
    return { ok: false, detail: "Anthropic has no free unauthenticated health probe. Use the explicitly approved diagnostic model request to verify connectivity." };
  }
}
function validateModelRequest(r: ModelRequest): void { if (!r.model.trim() || r.model.length > 256 || !r.system || r.system.length > 100_000 || !r.messages.length || r.messages.length > 100 || !Number.isSafeInteger(r.maxOutputTokens) || r.maxOutputTokens < 1 || r.maxOutputTokens > 128_000 || !Number.isSafeInteger(r.timeoutMs) || r.timeoutMs < 1000 || r.timeoutMs > 300_000) throw new ForgeError("PROVIDER_REQUEST_INVALID", "Model request exceeds provider request bounds."); }
function isNonNegativeInt(v: unknown): v is number { return typeof v === "number" && Number.isSafeInteger(v) && v >= 0; }
