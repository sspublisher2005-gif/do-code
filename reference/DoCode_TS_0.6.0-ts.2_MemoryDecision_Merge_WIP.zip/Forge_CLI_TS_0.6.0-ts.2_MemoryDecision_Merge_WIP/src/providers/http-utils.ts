import { ForgeError } from "../core/errors.js";

export const MAX_PROVIDER_RESPONSE_BYTES = 2 * 1024 * 1024;
export interface JsonRequestOptions { fetchImpl?: typeof fetch; timeoutMs: number; signal?: AbortSignal; retries?: number }
export async function requestJson(url: string, init: RequestInit, options: JsonRequestOptions): Promise<{ response: Response; payload: unknown }> {
  const fetchImpl = options.fetchImpl ?? fetch;
  const maxRetries = Math.min(3, Math.max(0, options.retries ?? 2));
  let lastError: unknown;
  for (let attempt = 0; attempt <= maxRetries; attempt += 1) {
    if (options.signal?.aborted) throw new ForgeError("PROVIDER_CANCELLED", "Provider request was cancelled.");
    let response: Response;
    try {
      const timeout = AbortSignal.timeout(options.timeoutMs);
      const signal = options.signal ? AbortSignal.any([options.signal, timeout]) : timeout;
      response = await fetchImpl(url, { ...init, signal, redirect: "error" });
    } catch (error) {
      lastError = error;
      if (options.signal?.aborted) throw new ForgeError("PROVIDER_CANCELLED", "Provider request was cancelled.");
      if (isAbortError(error)) throw new ForgeError("PROVIDER_TIMEOUT", "Provider request timed out.");
      if (attempt >= maxRetries) throw new ForgeError("PROVIDER_TRANSPORT_ERROR", "Provider request failed before a valid response was received.");
      await backoff(attempt, options.signal);
      continue;
    }
    if ((response.status === 429 || response.status >= 500) && attempt < maxRetries) {
      const retryAfter = response.headers.get("retry-after");
      await response.body?.cancel().catch(() => undefined);
      const parsed = retryAfter && /^\d+(?:\.\d+)?$/.test(retryAfter) ? Math.min(3000, Number(retryAfter) * 1000) : undefined;
      await backoff(attempt, options.signal, parsed);
      continue;
    }
    if (!response.ok) throw new ForgeError("PROVIDER_HTTP_ERROR", `Provider returned HTTP ${response.status}.`, { status: response.status });
    const payload = await readJsonBounded(response, MAX_PROVIDER_RESPONSE_BYTES);
    return { response, payload };
  }
  void lastError;
  throw new ForgeError("PROVIDER_TRANSPORT_ERROR", "Provider request failed after bounded retries.");
}

export async function readJsonBounded(response: Response, maxBytes = MAX_PROVIDER_RESPONSE_BYTES): Promise<unknown> {
  const declaredLength = response.headers.get("content-length");
  if (declaredLength && /^\d+$/.test(declaredLength) && Number(declaredLength) > maxBytes) {
    await response.body?.cancel().catch(() => undefined);
    throw new ForgeError("PROVIDER_RESPONSE_TOO_LARGE", `Provider response exceeded the ${maxBytes}-byte limit.`);
  }
  if (!response.body) throw new ForgeError("PROVIDER_INVALID_JSON", "Provider response body is empty.");
  const reader = response.body.getReader(); const chunks: Uint8Array[] = []; let bytes = 0;
  try {
    while (true) {
      const part = await reader.read(); if (part.done) break; bytes += part.value.byteLength;
      if (bytes > maxBytes) { await reader.cancel().catch(() => undefined); throw new ForgeError("PROVIDER_RESPONSE_TOO_LARGE", `Provider response exceeded the ${maxBytes}-byte limit.`); }
      chunks.push(part.value);
    }
  } finally { reader.releaseLock(); }
  try { return JSON.parse(Buffer.concat(chunks.map((chunk) => Buffer.from(chunk))).toString("utf8")) as unknown; }
  catch { throw new ForgeError("PROVIDER_INVALID_JSON", "Provider response was not valid JSON."); }
}
export function isRecord(value: unknown): value is Record<string, unknown> { return value !== null && typeof value === "object" && !Array.isArray(value); }
export function isAbortError(error: unknown): boolean { return error !== null && typeof error === "object" && "name" in error && (error.name === "AbortError" || error.name === "TimeoutError"); }
async function backoff(attempt: number, signal?: AbortSignal, overrideMs?: number): Promise<void> {
  const delay = overrideMs ?? Math.min(1500, 150 * 2 ** attempt + Math.floor(Math.random() * 100));
  if (signal?.aborted) throw new ForgeError("PROVIDER_CANCELLED", "Provider request was cancelled.");
  await new Promise<void>((resolve, reject) => {
    const cleanup = () => signal?.removeEventListener("abort", abort);
    const timer = setTimeout(() => { cleanup(); resolve(); }, delay);
    const abort = () => { clearTimeout(timer); cleanup(); reject(new ForgeError("PROVIDER_CANCELLED", "Provider request was cancelled.")); };
    signal?.addEventListener("abort", abort, { once: true });
    if (signal?.aborted) abort();
  });
}
