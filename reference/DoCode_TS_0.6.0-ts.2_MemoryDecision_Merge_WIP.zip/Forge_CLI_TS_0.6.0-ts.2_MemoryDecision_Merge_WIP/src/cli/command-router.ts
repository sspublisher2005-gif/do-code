import { ForgeError } from "../core/errors.js";
import { auditCommand } from "./commands/audit.js";
import { configShowCommand } from "./commands/config.js";
import { doctorCommand } from "./commands/doctor.js";
import { filesCommand } from "./commands/files.js";
import { initCommand } from "./commands/init.js";
import { modelTestCommand } from "./commands/model-test.js";
import { indexCommand } from "./commands/index.js";
import { contextCommand } from "./commands/context.js";
import { agentsCommand } from "./commands/agents.js";
import { planCommand } from "./commands/plan.js";
import { runCommand } from "./commands/run.js";
import { missionCommand } from "./commands/mission.js";
import { applyCommand } from "./commands/apply.js";
import { resumeCommand } from "./commands/resume.js";
import { verifyCommand } from "./commands/verify.js";
import { undoCommand } from "./commands/undo.js";
import { freezeCommand, unfreezeCommand } from "./commands/freeze.js";
import { sandboxCommand } from "./commands/sandbox.js";
import { memoryCommand } from "./commands/memory.js";
import { pilotCommand } from "./commands/pilot.js";
import { printLine } from "./output.js";

export const VERSION = "0.6.0-ts.2";

export const HELP = `Forge CLI v${VERSION} — evidence-first local coding harness

USAGE
  forge [--root <directory>] <command> [arguments]

COMMANDS
  forge --help
  forge --version
  forge init
  forge doctor
  forge config show
  forge model test [--live --approve-context-sharing]
  forge files list [directory] [--no-recursive]
  forge files read <workspace-relative-path>
  forge files search <literal-query> [directory]
  forge audit [--tail <1-1000>]
  forge index [--max-files N --max-file-bytes N --max-total-bytes N]
  forge context ["task relevance query"] [--max-files N --max-chars N]
  forge agents [list]
  forge plan "task description" --live --approve-context-sharing
  forge run "task description" --live --approve-context-sharing
  forge mission [list|show <mission-uuid>]
  forge apply <mission-uuid> [--approve]
  forge verify <mission-uuid>
  forge resume <mission-uuid>
  forge undo <mission-uuid> [checkpoint-uuid] [--approve]
  forge freeze [status|now <reason>]
  forge unfreeze --approve
  forge sandbox status
  forge sandbox self-test
  forge memory [propose|list|search|show|edit|forget|verify|reindex|export|import|open|reset]
  forge pilot "decision" [--option "..."] [--live --approve-context-sharing]

GLOBAL OPTIONS
  --root <directory>    Operate on this project root (default: current directory)
  --help                Show help
  --version             Show the development version

SAFETY
  - No telemetry. init/doctor/config/audit/file commands do not call a model.
  - Live model calls require BOTH --live and --approve-context-sharing.
  - File commands are read-only. Model-generated patches are only proposed until forge apply <id> --approve.
  - General host shell/tests remain blocked until a production-qualified sandbox is available. sandbox self-test runs only a fixed probe in a disposable Linux namespace; it is not a coding execution path.
  - forge freeze now <reason> blocks new live model workflows and patch application; unfreeze requires explicit approval.
`;

export async function routeCommand(rawArgs: string[], cwd = process.cwd()): Promise<void> {
  const args = [...rawArgs];
  let root = cwd;
  const rootIndex = args.indexOf("--root");
  if (rootIndex >= 0) {
    const value = args[rootIndex + 1];
    if (!value) throw new ForgeError("CLI_USAGE", "--root requires a directory path.");
    root = value;
    args.splice(rootIndex, 2);
  }
  const command = args.shift();
  if (!command || command === "--help" || command === "-h" || command === "help") {
    printLine(HELP);
    return;
  }
  if (command === "--version" || command === "-v" || command === "version") {
    printLine(VERSION);
    return;
  }
  switch (command) {
    case "init":
      if (args.length > 0) throw new ForgeError("CLI_USAGE", "Usage: forge init [--root <directory>]");
      await initCommand(root);
      return;
    case "doctor":
      if (args.length > 0) throw new ForgeError("CLI_USAGE", "Usage: forge doctor [--root <directory>]");
      await doctorCommand(root);
      return;
    case "config":
      if (args.shift() !== "show" || args.length > 0) throw new ForgeError("CLI_USAGE", "Usage: forge config show");
      await configShowCommand(root);
      return;
    case "model":
      if (args.shift() !== "test") throw new ForgeError("CLI_USAGE", "Usage: forge model test [--live --approve-context-sharing]");
      await modelTestCommand(root, args);
      return;
    case "files":
      await filesCommand(root, args);
      return;
    case "audit":
      await auditCommand(root, args);
      return;
    case "index":
      await indexCommand(root, args);
      return;
    case "context":
      await contextCommand(root, args);
      return;
    case "agents":
      await agentsCommand(args);
      return;
    case "plan":
      await planCommand(root, args);
      return;
    case "run":
      await runCommand(root, args);
      return;
    case "mission":
      await missionCommand(root, args);
      return;
    case "apply":
      await applyCommand(root, args);
      return;
    case "verify":
      await verifyCommand(root, args);
      return;
    case "resume":
      await resumeCommand(root, args);
      return;
    case "undo":
      await undoCommand(root, args);
      return;
    case "freeze":
      await freezeCommand(root, args);
      return;
    case "unfreeze":
      await unfreezeCommand(root, args);
      return;
    case "sandbox":
      await sandboxCommand(args);
      return;
    case "memory":
      await memoryCommand(root, args);
      return;
    case "pilot":
      await pilotCommand(root, args);
      return;
    default:
      printLine(HELP);
      throw new ForgeError("CLI_COMMAND_UNKNOWN", `Unknown command '${command}'.`);
  }
}
