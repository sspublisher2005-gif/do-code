import { loadConfig } from "../../config/load.js";
import { appendAudit } from "../../audit/jsonl.js";
import { printJson } from "../output.js";

export async function configShowCommand(root: string): Promise<void> {
  const loaded = await loadConfig(root);
  printJson({ exists: loaded.exists, path: "forge.config.toml", config: loaded.config });
  await appendAudit(root, { event: "config.show", outcome: "succeeded", details: { configExists: loaded.exists } });
}
