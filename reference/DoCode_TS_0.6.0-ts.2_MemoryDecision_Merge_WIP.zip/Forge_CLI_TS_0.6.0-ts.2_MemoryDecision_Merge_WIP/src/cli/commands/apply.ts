import { beginPatchApply, readProposedPatch, recordPatchApplied, recordPatchApplyFailure } from "../../agents/workflow.js";
import { applyPatch, previewPatch } from "../../tools/patch-apply.js";
import { ForgeError } from "../../core/errors.js";
import { printLine } from "../output.js";
export async function applyCommand(root: string, args: string[]): Promise<void> {
  const id=args.shift(); if(!id) throw new ForgeError("CLI_USAGE","Usage: forge apply <mission-uuid> [--approve]");
  const unknown=args.filter((a)=>a!=="--approve"); if(unknown.length) throw new ForgeError("CLI_USAGE",`Unknown apply option '${unknown[0]}'.`);
  const approval=args.includes("--approve"); const {patch,evidenceId}=await readProposedPatch(root,id);
  if(!approval){ printLine(await previewPatch(root,patch)); printLine("\nDRY RUN ONLY: no files changed. Re-run with --approve to apply after reviewing the entire proposal."); return; }
  await beginPatchApply(root,id);
  let result;
  try { result=await applyPatch(root,patch,true); } catch (error) { await recordPatchApplyFailure(root,id,error).catch(() => undefined); throw error; }
  await recordPatchApplied(root,id,result.checkpointId,result.changedPaths);
  printLine(`Applied patch ${patch.id}.`); printLine(`Checkpoint: ${result.checkpointId}`); printLine(`Files changed: ${result.changedPaths.join(", ")}`); printLine(`Bytes written: ${result.bytesWritten}`); printLine(`Saved proposal evidence: ${evidenceId}`);
  printLine("No test command was run. Mission remains in verification and cannot be reported complete until required checks have evidence.");
}
