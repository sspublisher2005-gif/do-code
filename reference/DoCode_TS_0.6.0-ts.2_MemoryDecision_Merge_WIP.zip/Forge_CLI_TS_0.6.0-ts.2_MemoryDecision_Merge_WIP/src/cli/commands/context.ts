import { appendAudit } from "../../audit/jsonl.js";
import { buildRepositoryIndex, buildTaskContextPack, loadRepositoryIndex, renderRepoMap, saveRepositoryIndex } from "../../context/repository.js";
import { ForgeError } from "../../core/errors.js";
import { loadConfig } from "../../config/load.js";
import { printLine } from "../output.js";

export async function contextCommand(root: string, args: string[]): Promise<void> {
  let maxFiles = 12; let maxChars = 50_000; const parts: string[] = [];
  while (args.length) {
    const arg = args.shift() ?? "";
    if (arg === "--max-files" || arg === "--max-chars") {
      const raw = args.shift(); if (!raw || !/^\d+$/.test(raw)) throw new ForgeError("CLI_USAGE", `${arg} requires a positive integer.`);
      const value = Number(raw); if (!Number.isSafeInteger(value) || value < 1) throw new ForgeError("CLI_USAGE", `${arg} requires a positive integer.`);
      if (arg === "--max-files") maxFiles = Math.min(50, value); else maxChars = Math.min(200_000, value);
    } else if (arg.startsWith("-")) throw new ForgeError("CLI_USAGE", `Unknown context option '${arg}'.`); else parts.push(arg);
  }
  if (!parts.length) {
    let index; try { index = await loadRepositoryIndex(root); } catch (e) { if (!(e instanceof ForgeError) || e.code !== "INDEX_NOT_FOUND") throw e; const { config }=await loadConfig(root); index=await buildRepositoryIndex(root,{maxFiles:config.limits.max_files,maxFileBytes:config.limits.max_read_bytes}); await saveRepositoryIndex(root,index); }
    printLine(renderRepoMap(index)); return;
  }
  const task = parts.join(" "); if (task.length > 20_000) throw new ForgeError("CONTEXT_TASK_INVALID", "Context task exceeds 20,000 characters.");
  try { await loadRepositoryIndex(root); } catch (e) { if (!(e instanceof ForgeError) || e.code !== "INDEX_NOT_FOUND") throw e; const { config }=await loadConfig(root); await saveRepositoryIndex(root, await buildRepositoryIndex(root,{maxFiles:config.limits.max_files,maxFileBytes:config.limits.max_read_bytes})); }
  const pack = await buildTaskContextPack(root, task, { maxFiles, maxChars });
  printLine(`Context pack preview for: ${task}`); printLine(`Selected files: ${pack.files.length}; chars: ${pack.usedChars}/${pack.maxChars}; estimated tokens: ${pack.estimatedTokens}`);
  for (const file of pack.files) printLine(`\n===== ${file.path} (${file.bytes} bytes, sha256 ${file.sha256.slice(0,12)}…) =====\nReason: ${file.reason}\n${file.content}`);
  for (const omitted of pack.omitted.slice(0, 50)) printLine(`OMITTED ${omitted.path}: ${omitted.reason}`);
  printLine("\nThis is a local preview. Forge does not send this pack to a provider unless a live workflow explicitly requests context-sharing consent.");
  await appendAudit(root, { event: "context.pack_preview", outcome: "succeeded", details: { files: pack.files.length, chars: pack.usedChars, omitted: pack.omitted.length, taskSha256: (await import("node:crypto")).createHash("sha256").update(task).digest("hex") } });
}
