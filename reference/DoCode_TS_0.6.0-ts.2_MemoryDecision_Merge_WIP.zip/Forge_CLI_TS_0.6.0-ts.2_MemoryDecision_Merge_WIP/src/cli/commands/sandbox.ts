import { probeSandboxEnvironment } from "../../sandbox/probe.js";
import { ForgeError } from "../../core/errors.js";
import { printJson, printLine } from "../output.js";
import { createLinuxNamespacePrototypeDriver } from "../../sandbox/linux/namespace-driver.js";
import { mkdtemp, mkdir, readFile, rm, writeFile, access } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import net, { type AddressInfo } from "node:net";
export async function sandboxCommand(args: string[]): Promise<void> {
  const op = args.shift() ?? "status";
  if (op === "status" && !args.length) {
    const result = await probeSandboxEnvironment();
    const prototype = process.platform === "linux" ? await createLinuxNamespacePrototypeDriver().then((driver) => driver.probe()).catch(() => undefined) : undefined;
    printJson({ ...result, namespacePrototype: prototype ?? { available: false }, productionReady: false });
    printLine("Coding/test command execution remains BLOCKED. The Linux namespace prototype is diagnostic/self-test only; it lacks Landlock, seccomp-bpf enforcement, and independent review.");
    return;
  }
  if (op === "self-test" && !args.length) {
    if (process.platform !== "linux") throw new ForgeError("SANDBOX_PLATFORM_UNSUPPORTED", "The namespace prototype self-test is Linux-only. No command ran.");
    const driver = await createLinuxNamespacePrototypeDriver();
    const capabilities = await driver.probe();
    if (!capabilities.filesystemIsolation || !capabilities.networkIsolation) throw new ForgeError("SANDBOX_UNAVAILABLE", "Linux user/mount/network namespaces are unavailable or denied by the current kernel. No test command ran.");
    const root = await mkdtemp(join(tmpdir(), "forge-sandbox-self-test-"));
    try {
      await writeFile(join(root, "README.md"), "forge-sandbox-self-test-ok\n", { flag: "wx", mode: 0o600 });
      await writeFile(join(root, ".env"), "API_KEY=fixture-not-a-secret\n", { flag: "wx", mode: 0o600 });
      await mkdir(join(root, ".forge"), { mode: 0o700 });
      await writeFile(join(root, ".forge", "token"), "fixture-token\n", { flag: "wx", mode: 0o600 });
      const server = net.createServer((socket: { end: (data?: string) => void }) => socket.end("host-network-reached"));
      await new Promise<void>((resolvePromise, rejectPromise) => { server.once("error", rejectPromise); server.listen(0, "127.0.0.1", () => resolvePromise()); });
      try {
        const address = server.address();
        if (!address || typeof address === "string") throw new ForgeError("SANDBOX_SELF_TEST_FAILED", "Could not determine the local TCP test port.");
        const port = (address as AddressInfo).port;
        const script = `test "$PWD" = /workspace; grep -q forge-sandbox-self-test-ok README.md; test ! -e .env; test ! -d .forge; test ! -w /usr/bin; printf sandbox-self-test-write > inside.txt; test -f inside.txt; if (printf escaped > /root/escape.txt) 2>/dev/null; then exit 5; else echo outside-write-blocked; fi; if (printf network > /dev/tcp/127.0.0.1/${port}) 2>/dev/null; then echo host-network-connected; exit 6; else echo host-network-blocked; fi; echo sandbox-self-test-passed`;
        const run = await driver.run({ executable: "/bin/bash", argv: ["-eu", "-c", script], workspaceRoot: root, writablePaths: [], environment: {}, network: "deny_all", limits: { timeoutMs: 5000, memoryBytes: 512 * 1024 * 1024, cpuQuotaPercent: 100, maxProcesses: 32, maxOutputBytes: 16 * 1024 } });
        if (run.exitCode !== 0 || run.cancelled || !run.stdout.includes("sandbox-self-test-passed") || !run.stdout.includes("outside-write-blocked") || !run.stdout.includes("host-network-blocked")) throw new ForgeError("SANDBOX_SELF_TEST_FAILED", `Sandbox self-test failed (exit ${String(run.exitCode)}); diagnostics: ${run.stderr.slice(0, 800)}`);
        try {
          await access(join(root, "inside.txt"));
          throw new ForgeError("SANDBOX_SELF_TEST_FAILED", "Sandbox write escaped its disposable workspace. Do not use this prototype.");
        } catch (error) {
          if (error instanceof ForgeError) throw error;
          if (!(error !== null && typeof error === "object" && "code" in error && error.code === "ENOENT")) throw error;
        }
        if ((await readFile(join(root, "README.md"), "utf8")) !== "forge-sandbox-self-test-ok\n") throw new ForgeError("SANDBOX_SELF_TEST_FAILED", "Sandbox altered the host-side fixture unexpectedly.");
        printJson({ status: "passed", driver: driver.id, filesystemNamespace: capabilities.filesystemIsolation, networkNamespace: capabilities.networkIsolation, credentialFilter: capabilities.credentialIsolation, resourceLimits: capabilities.resourceLimits, processCancellation: capabilities.processTreeCancellation, landlock: false, seccompBpf: false, productionReady: false, details: ["writes stayed in disposable workspace", "host system paths were read-only", "sensitive fixture files were excluded", "connection to a live host localhost listener was blocked", "outside-workspace write was blocked", "execution remained a prototype and was not registered for coding tasks"] });
      } finally {
        await new Promise<void>((resolvePromise) => server.close(() => resolvePromise()));
      }
    } finally {
      await rm(root, { recursive: true, force: true });
    }
    return;
  }
  throw new ForgeError("SANDBOX_NOT_IMPLEMENTED", "Usage: forge sandbox status | forge sandbox self-test. General command execution remains disabled.");
}
