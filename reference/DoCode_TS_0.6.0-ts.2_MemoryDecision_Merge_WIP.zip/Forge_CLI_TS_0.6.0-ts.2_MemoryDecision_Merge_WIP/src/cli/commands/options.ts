import { ForgeError } from "../../core/errors.js";
import type { WorkflowConsent } from "../../agents/workflow.js";

export function parseWorkflowOptions(argsInput: string[]): { positionals: string[]; consent: WorkflowConsent } {
  const args = [...argsInput]; const positionals: string[] = [];
  const consent: WorkflowConsent = { live: false, approveContextSharing: false };
  while (args.length) {
    const arg = args.shift() ?? "";
    if (arg === "--live") consent.live = true;
    else if (arg === "--approve-context-sharing") consent.approveContextSharing = true;
    else if (arg === "--max-files" || arg === "--max-chars" || arg === "--max-output-tokens" || arg === "--max-duration-ms" || arg === "--max-cost-usd") {
      const raw = args.shift(); if (!raw || !/^\d+$/.test(raw)) throw new ForgeError("CLI_USAGE", `${arg} requires a positive integer.`);
      const value = Number(raw); if (!Number.isSafeInteger(value) || value < 1) throw new ForgeError("CLI_USAGE", `${arg} requires a positive integer.`);
      if (arg === "--max-files") { if (value > 50) throw new ForgeError("CLI_USAGE", "--max-files cannot exceed 50."); consent.maxFiles = value; }
      else if (arg === "--max-chars") { if (value > 200_000) throw new ForgeError("CLI_USAGE", "--max-chars cannot exceed 200000."); consent.maxChars = value; }
      else if (arg === "--max-output-tokens") { if (value > 128_000) throw new ForgeError("CLI_USAGE", "--max-output-tokens cannot exceed 128000."); consent.maxOutputTokens = value; }
      else if (arg === "--max-duration-ms") { if (value < 1000 || value > 8 * 60 * 60_000) throw new ForgeError("CLI_USAGE", "--max-duration-ms must be between 1000 and 28800000."); consent.maxDurationMs = value; }
      else { if (value <= 0 || value > 10000 || !/^\d+(?:\.\d{1,4})?$/.test(raw)) throw new ForgeError("CLI_USAGE", "--max-cost-usd must be a positive number no greater than 10000 with at most 4 decimal places."); consent.maxCostUsd = Number(raw); }
    } else if (arg.startsWith("-")) throw new ForgeError("CLI_USAGE", `Unknown option '${arg}'.`);
    else positionals.push(arg);
  }
  return { positionals, consent };
}
export function requireTask(positionals: string[]): string { const task = positionals.join(" ").trim(); if (!task) throw new ForgeError("CLI_USAGE", "A task description is required in quotes."); if (task.length > 20_000) throw new ForgeError("CLI_USAGE", "Task description exceeds 20,000 characters."); return task; }
export function isUuid(s: string): boolean { return /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(s); }
