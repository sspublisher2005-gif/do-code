import { runCodingTask } from "../../agents/workflow.js";
import { MissionStore } from "../../persistence/mission-store.js";
import { ForgeError } from "../../core/errors.js";
import { printLine } from "../output.js";
import { isUuid, parseWorkflowOptions, requireTask } from "./options.js";
export async function runCommand(root: string, args: string[]): Promise<void> {
  const { positionals, consent } = parseWorkflowOptions(args); if (!positionals.length) throw new ForgeError("CLI_USAGE", "Usage: forge run \"task description\" [--live --approve-context-sharing] or forge run <mission-uuid> [--live --approve-context-sharing]");
  let task = positionals.join(" "); let missionId: string | undefined;
  const possibleId = positionals[0] ?? "";
  if (positionals.length === 1 && isUuid(possibleId)) { missionId=possibleId; const store=await MissionStore.open(root); task=(await store.get(possibleId)).objective; }
  else task = requireTask(positionals);
  if (!consent.live || !consent.approveContextSharing) throw new ForgeError("CONSENT_REQUIRED", "Coding proposals send task and selected repository context to a model. Pass both --live and --approve-context-sharing. No source was sent.");
  const result = await runCodingTask(root, task, consent, missionId);
  printLine(`Mission: ${result.mission.id}`); printLine(`Status: ${result.mission.status}`); printLine(`Patch ID: ${result.patch.id}`); printLine(`Patch evidence: ${result.patchEvidenceId}`); printLine(`Proposed files (${result.patch.files.length}):`);
  for(const f of result.patch.files) printLine(`- ${f.path}: ${Buffer.byteLength(f.newContent,"utf8")} bytes — ${f.reason}`);
  printLine(`\nContext files: ${result.contextFiles.join(", ")}`); printLine(`Model requests: ${result.usage.requestCount}; input tokens: ${result.usage.inputTokens}; output tokens: ${result.usage.outputTokens}; cost: ${typeof result.usage.costUsd === "number" ? `$${result.usage.costUsd}` : "unknown"}`);
  printLine("\nARCHITECT PLAN\n" + result.plan); printLine("\nTEST PLAN (NOT EXECUTED)\n" + result.testPlan); printLine("\nSECURITY REVIEW (ADVISORY)\n" + result.securityReview); printLine("\nADVISORY REVIEW\n" + result.review); if (result.devopsReview) printLine("\nDEVOPS REVIEW (ADVISORY)\n" + result.devopsReview);
  printLine(`\nNo files were written and no test commands were run. Preview: forge apply ${result.mission.id}`); printLine(`To apply the validated proposal: forge apply ${result.mission.id} --approve`);
}
