import { planTask } from "../../agents/workflow.js";
import { ForgeError } from "../../core/errors.js";
import { printLine } from "../output.js";
import { parseWorkflowOptions, requireTask } from "./options.js";
export async function planCommand(root: string, args: string[]): Promise<void> {
  const { positionals, consent } = parseWorkflowOptions(args); const task = requireTask(positionals);
  if (!consent.live || !consent.approveContextSharing) throw new ForgeError("CONSENT_REQUIRED", "Forge planning sends task and selected repository context to a model. Pass both --live and --approve-context-sharing to proceed. Otherwise use 'forge context' for a local-only preview.");
  const result = await planTask(root, task, consent);
  printLine(`Mission created: ${result.mission.id}`); printLine(`Status: ${result.mission.status}`); printLine(`Context files: ${result.contextFiles.join(", ") || "none"}`); printLine(`Model requests: ${result.usage.requestCount}; input tokens: ${result.usage.inputTokens}; output tokens: ${result.usage.outputTokens}; cost: ${typeof result.usage.costUsd === "number" ? `$${result.usage.costUsd}` : "unknown"}`);
  printLine("\nRESEARCH NOTES\n" + result.research); printLine("\nIMPLEMENTATION PLAN\n" + result.plan); printLine("\nNo source files were modified and no tests were executed.");
}
