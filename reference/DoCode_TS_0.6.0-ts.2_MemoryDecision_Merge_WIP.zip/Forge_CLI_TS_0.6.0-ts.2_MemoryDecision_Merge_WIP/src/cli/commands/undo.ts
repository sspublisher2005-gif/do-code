import { listCheckpoints, undoCheckpoint } from "../../tools/patch-apply.js";
import { ForgeError } from "../../core/errors.js";
import { printLine } from "../output.js";
export async function undoCommand(root: string, args: string[]): Promise<void> {
  const id=args.shift(); if(!id) throw new ForgeError("CLI_USAGE","Usage: forge undo <mission-uuid> [checkpoint-uuid] [--approve]");
  const approval=args.includes("--approve"); const remaining=args.filter(a=>a!=="--approve"); const supplied=remaining.shift(); if(remaining.length) throw new ForgeError("CLI_USAGE","Too many arguments for forge undo.");
  const checkpoints=await listCheckpoints(root,id); const checkpoint=supplied ?? checkpoints.at(-1);
  if(!checkpoint) throw new ForgeError("CHECKPOINT_NOT_FOUND","No checkpoint exists for this mission.");
  if(!checkpoints.includes(checkpoint)) throw new ForgeError("CHECKPOINT_NOT_FOUND","Specified checkpoint is not listed for this mission.");
  if(!approval){printLine(`Rollback preview for mission ${id}`);printLine(`Checkpoint: ${checkpoint}`);printLine("Rollback will restore only files whose current hashes match the post-patch hashes.");printLine("No files were modified. Re-run with --approve to restore.");return;}
  const result=await undoCheckpoint(root,id,checkpoint,true);printLine(`Rollback completed for ${result.restoredPaths.length} file(s): ${result.restoredPaths.join(", ")}`);
}
