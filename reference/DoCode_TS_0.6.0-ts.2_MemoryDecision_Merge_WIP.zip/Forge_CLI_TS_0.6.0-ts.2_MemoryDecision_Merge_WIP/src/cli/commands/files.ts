import { loadConfig } from "../../config/load.js";
import { appendAudit } from "../../audit/jsonl.js";
import { ForgeError } from "../../core/errors.js";
import { SafeFileTools } from "../../tools/safe-files.js";
import { printLine } from "../output.js";

export async function filesCommand(root: string, args: string[]): Promise<void> {
  const [operation, ...rest] = args;
  const { config } = await loadConfig(root);
  const files = await SafeFileTools.create(root, {
    maxReadBytes: config.limits.max_read_bytes,
    maxFiles: config.limits.max_files,
    maxSearchMatches: config.limits.max_search_matches,
  });
  if (operation === "list") {
    const target = rest[0] ?? ".";
    const recursive = !rest.includes("--no-recursive");
    const entries = await files.list(target, recursive);
    for (const entry of entries) printLine(`${entry.kind === "directory" ? "DIR " : "FILE"} ${entry.path}${entry.kind === "file" ? ` (${entry.sizeBytes} bytes)` : ""}`);
    printLine(`${entries.length} entr${entries.length === 1 ? "y" : "ies"} shown (bounded by config.limits.max_files).`);
    await appendAudit(root, { event: "files.list", outcome: "succeeded", details: { count: entries.length } });
    return;
  }
  if (operation === "read") {
    const target = rest[0];
    if (!target || target.startsWith("--")) throw new ForgeError("CLI_USAGE", "Usage: forge files read <workspace-relative-path>");
    const content = await files.read(target);
    process.stdout.write(content.endsWith("\n") ? content.replace(/[^\x09\x0A\x0D\x20-\x7E\u00A0-\uFFFF]/g, (ch) => `\\u${(ch.codePointAt(0) ?? 0).toString(16).padStart(4, "0")}`) : `${content.replace(/[^\x09\x0A\x0D\x20-\x7E\u00A0-\uFFFF]/g, (ch) => `\\u${(ch.codePointAt(0) ?? 0).toString(16).padStart(4, "0")}`)}\n`);
    await appendAudit(root, { event: "files.read", outcome: "succeeded", details: { bytes: Buffer.byteLength(content, "utf8") } });
    return;
  }
  if (operation === "search") {
    const query = rest[0];
    if (!query || query.startsWith("--")) throw new ForgeError("CLI_USAGE", "Usage: forge files search <literal-query> [workspace-relative-directory]");
    const target = rest[1] ?? ".";
    const matches = await files.search(query, target);
    for (const match of matches) printLine(`${match.path}:${match.line}: ${match.text}`);
    printLine(`${matches.length} match(es) (literal, bounded search).`);
    await appendAudit(root, { event: "files.search", outcome: "succeeded", details: { matches: matches.length } });
    return;
  }
  throw new ForgeError("CLI_USAGE", "Usage: forge files <list|read|search> ...");
}
