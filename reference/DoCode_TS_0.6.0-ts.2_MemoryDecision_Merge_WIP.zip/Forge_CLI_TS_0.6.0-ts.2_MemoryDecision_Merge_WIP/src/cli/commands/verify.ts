import { MissionStore } from "../../persistence/mission-store.js";
import { EvidenceStore } from "../../evidence/store.js";
import { evaluateCompletion } from "../../verification/completion-gate.js";
import { appendAudit } from "../../audit/jsonl.js";
import { ForgeError } from "../../core/errors.js";
import { printJson, printLine } from "../output.js";
import type { VerificationCheck } from "../../core/types.js";
export async function verifyCommand(root: string, args: string[]): Promise<void> {
  const id=args.shift(); if(!id||args.length) throw new ForgeError("CLI_USAGE","Usage: forge verify <mission-uuid>");
  const store=await MissionStore.open(root); const mission=await store.get(id); const evidenceStore=await EvidenceStore.open(root); const evidenceInspection=await evidenceStore.inspect(id); const refs=evidenceInspection.refs;
  const checks: VerificationCheck[] = [
    { id:"patch-present", name:"Patch proposal evidence is present and hash-valid", status:refs.some(r=>r.kind==="patch")?"passed":"failed", required:true, evidenceIds:refs.filter(r=>r.kind==="patch").map(r=>r.id) },
    { id:"tests", name:"Project test suite", status:"incomplete", required:true, evidenceIds:[] as string[], details:"Not run: no verified OS sandbox driver is available in this build environment." },
    { id:"typecheck", name:"TypeScript/typecheck command", status:"incomplete", required:true, evidenceIds:[], details:"Not run against the user's project. Forge does not execute host commands outside a verified sandbox." },
    { id:"browser", name:"Browser E2E", status:"incomplete", required:false, evidenceIds:[], details:"Not run. Browser test requires a verified sandbox and HTTP-served fixture." },
    { id:"security", name:"Security policy and path-bound patch", status:refs.some(r=>r.kind==="patch")?"passed":"incomplete", required:true, evidenceIds:refs.filter(r=>r.kind==="patch").map(r=>r.id), details:"This check only confirms a hash-verified patch proposal exists. It is not an independent security audit." },
  ];
  const startedAt=new Date().toISOString();
  const blockers = ["No enforced OS sandbox was available, so test and code execution verification were not performed."];
  if (evidenceInspection.corruptArtifacts.length) blockers.push(`${evidenceInspection.corruptArtifacts.length} evidence artifact(s) failed integrity/schema checks: ${evidenceInspection.corruptArtifacts.slice(0,10).join(", ")}`);
  const result=evaluateCompletion({ missionId:id, checks, criteria: mission.acceptanceCriteria.map(c=>({criterionId:c.id,required:c.required,passed:false,evidenceIds:[]})), reviewPassed:false, blockingSecurityWarnings:blockers, startedAt, finishedAt:new Date().toISOString(), policyVersion:"forge-verification-1" });
  const ref=await evidenceStore.put({missionId:id,kind:"test_log",producedBy:"forge-verify",content:JSON.stringify(result,null,2),mediaType:"application/json",metadata:{status:result.status,completionAllowed:result.completionAllowed,checks:checks.length}});
  await store.update(id,m=>{m.evidenceIds.push(ref.id);return m;});
  if ((await store.get(id)).status === "verifying") await store.transition(id, "needs_review");
  await appendAudit(root,{event:"mission.verification",outcome:"info",missionId:id,resultId:result.id,details:{status:result.status,completionAllowed:result.completionAllowed,checks:checks.length,executionPerformed:false,corruptEvidence:evidenceInspection.corruptArtifacts.length}});
  printJson({ ...result, corruptEvidenceArtifacts: evidenceInspection.corruptArtifacts }); printLine("Forge has not claimed this mission is complete. Host commands were not executed; tests, typecheck and browser E2E remain unverified.");
}
