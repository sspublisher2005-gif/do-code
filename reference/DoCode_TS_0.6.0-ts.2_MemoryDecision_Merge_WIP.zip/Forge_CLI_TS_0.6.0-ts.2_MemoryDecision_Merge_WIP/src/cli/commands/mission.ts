import { MissionStore } from "../../persistence/mission-store.js";
import { ForgeError } from "../../core/errors.js";
import { printJson, printLine } from "../output.js";
export async function missionCommand(root: string, args: string[]): Promise<void> {
  const op=args.shift() ?? "list"; const store=await MissionStore.open(root);
  if(op==="list") { if(args.length) throw new ForgeError("CLI_USAGE","Usage: forge mission list"); const missions=await store.list(); if(!missions.length) printLine("No valid missions exist in this workspace."); for(const m of missions) printLine(`${m.id}  ${m.status.padEnd(18)}  ${m.objective.replace(/\s+/g," ").slice(0,100)}`); return; }
  if(op==="show" || op==="status") { const id=args.shift(); if(!id||args.length) throw new ForgeError("CLI_USAGE","Usage: forge mission show <mission-uuid>"); const m=await store.get(id); printJson(m); return; }
  throw new ForgeError("CLI_USAGE","Usage: forge mission [list|show <mission-uuid>]");
}
