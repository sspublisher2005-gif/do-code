import { MissionStore } from "../../persistence/mission-store.js";
import { ForgeError } from "../../core/errors.js";
import { printLine, printJson } from "../output.js";
export async function resumeCommand(root: string, args: string[]): Promise<void> {
  const id=args.shift(); if(!id||args.length) throw new ForgeError("CLI_USAGE","Usage: forge resume <mission-uuid>");
  const store=await MissionStore.open(root); let mission=await store.get(id);
  if(mission.status==="running"){ await store.transition(id,"interrupted"); mission=await store.get(id); }
  if(mission.status==="interrupted"){ await store.transition(id,"needs_review"); mission=await store.get(id); printLine("Recovered an interrupted mission. Forge did not replay any step or write operation."); }
  printLine(`Mission ${mission.id}: ${mission.status}`);
  printLine("Resume is inspection-only. Review current file hashes and the mission record before deciding whether to rerun a proposal or rollback.");
  printJson({ objective: mission.objective, steps: mission.steps.map(s=>({id:s.id,ordinal:s.ordinal,kind:s.kind,status:s.status,attempt:s.attempt,outputEvidenceIds:s.outputEvidenceIds,failureCode:s.failureCode})), evidenceIds: mission.evidenceIds });
}
