import { appendAudit } from "../../audit/jsonl.js";
import { loadConfig } from "../../config/load.js";
import { ForgeError } from "../../core/errors.js";
import { createConfiguredProvider, effectiveProviderBaseUrl } from "../../providers/registry.js";
import { printLine } from "../output.js";

export async function modelTestCommand(root: string, args: string[]): Promise<void> {
  const allowed = new Set(["--live", "--approve-context-sharing"]);
  for (const arg of args) if (!allowed.has(arg)) throw new ForgeError("CLI_USAGE", `Unknown model test option '${arg}'.`);
  const { config } = await loadConfig(root);
  const live = args.includes("--live"); const approved = args.includes("--approve-context-sharing");
  const endpoint = new URL(effectiveProviderBaseUrl(config)); const local = ["localhost", "127.0.0.1", "[::1]"].includes(endpoint.hostname);
  if (!live) {
    printLine("Configuration check only — no model/network request was sent.");
    printLine(`Provider: ${config.model.provider}`); printLine(`Model: ${config.model.model}`); printLine(`Endpoint origin: ${endpoint.origin}`);
    printLine("Use --live --approve-context-sharing to send a minimal diagnostic prompt to the configured provider.");
    await appendAudit(root, { event: "model.test_configuration", outcome: "info", details: { networkUsed: false, provider: config.model.provider, endpointOrigin: endpoint.origin } });
    return;
  }
  if (!approved) throw new ForgeError("CONSENT_REQUIRED", "Live model test blocked. Add --approve-context-sharing to approve sending a minimal diagnostic prompt to the configured provider.");
  if (config.privacy.mode === "local-only" && !local) throw new ForgeError("PRIVACY_REMOTE_BLOCKED", "privacy.mode is local-only; configured endpoint is remote. No request was sent.");
  const key = process.env[config.model.api_key_env];
  if (!key && !local) throw new ForgeError("PROVIDER_KEY_MISSING", `Set ${config.model.api_key_env} in the current shell; Forge will not save it to disk.`);
  const provider = createConfiguredProvider(config, { ...process.env, ...(key ? { [config.model.api_key_env]: key } : {}) });
  printLine(`Live diagnostic request approved for ${config.model.provider} endpoint ${endpoint.origin}; model ${config.model.model}.`);
  printLine("Only the diagnostic prompt is sent; no repository source is attached. Provider billing and retention policies may apply.");
  const response = await provider.generate({ model: config.model.model, role: "orchestrator", system: "You are testing a model connection. Do not request or reveal secrets. Reply with the exact text FORGE_MODEL_TEST_OK and nothing else.", messages: [{ role: "user", content: "Reply exactly: FORGE_MODEL_TEST_OK" }], maxOutputTokens: 32, timeoutMs: config.model.timeout_ms });
  const passed = response.text.trim() === "FORGE_MODEL_TEST_OK";
  await appendAudit(root, { event: "model.test", outcome: passed ? "succeeded" : "failed", details: { provider: response.provider, model: response.model, endpointOrigin: endpoint.origin, outputMatched: passed, durationMs: response.durationMs, inputTokens: response.usage.inputTokens ?? "unknown", outputTokens: response.usage.outputTokens ?? "unknown", costKnown: response.usage.costKnown } });
  printLine(`Model request: ${passed ? "PASS" : "RESPONSE RECEIVED, UNEXPECTED CONTENT"}`);
  printLine(`Provider: ${response.provider}; model: ${response.model}; duration: ${response.durationMs} ms`);
  printLine(`Token usage: input=${response.usage.inputTokens ?? "unknown"}, output=${response.usage.outputTokens ?? "unknown"}; cost=${response.usage.costKnown ? `$${response.usage.costUsd}` : "unknown"}`);
  if (!passed) throw new ForgeError("MODEL_TEST_MISMATCH", "Provider responded, but the deterministic diagnostic text did not match.");
}
