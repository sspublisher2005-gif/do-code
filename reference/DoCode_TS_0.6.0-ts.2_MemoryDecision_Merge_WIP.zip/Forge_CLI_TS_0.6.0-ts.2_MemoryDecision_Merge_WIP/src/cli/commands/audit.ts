import { readAuditTail } from "../../audit/jsonl.js";
import { printJson, printLine } from "../output.js";
import { ForgeError } from "../../core/errors.js";

export async function auditCommand(root: string, args: string[]): Promise<void> {
  let count = 20;
  const tailIndex = args.indexOf("--tail");
  if (tailIndex >= 0) {
    const raw = args[tailIndex + 1];
    if (!raw || !/^\d+$/.test(raw)) throw new ForgeError("CLI_USAGE", "Usage: forge audit --tail <1-1000>");
    count = Number(raw);
  } else if (args.length > 0) throw new ForgeError("CLI_USAGE", "Usage: forge audit [--tail <1-1000>]");
  const result = await readAuditTail(root, count);
  if (result.truncated) printLine("Warning: audit tail begins at the 10 MiB retention window; older events were not read.");
  if (result.corruptLines > 0) printLine(`Warning: ${result.corruptLines} invalid/truncated audit line(s) were skipped.`);
  printJson(result.events);
}
