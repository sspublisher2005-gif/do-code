import { freezeWorkspace, unfreezeWorkspace, readFreezeState } from "../../safety/freeze.js";
import { ForgeError } from "../../core/errors.js";
import { printJson, printLine } from "../output.js";
export async function freezeCommand(root: string, args: string[]): Promise<void> {
  const op = args.shift() ?? "status";
  if (op === "status") {
    if (args.length) throw new ForgeError("CLI_USAGE", "Usage: forge freeze [status|now <reason>]");
    const current = await readFreezeState(root);
    if (!current) { printLine("Workspace is not frozen."); return; }
    printLine("Workspace is FROZEN. Remote model requests and patch application are blocked."); printJson(current); return;
  }
  if (op === "now") {
    const reason = args.join(" ").trim() || "Manual operator freeze";
    if (reason.length > 2000) throw new ForgeError("CLI_USAGE", "Freeze reason cannot exceed 2000 characters.");
    const value = await freezeWorkspace(root, reason); printLine("Workspace frozen. Live model workflows and patch application are now blocked."); printJson(value); return;
  }
  throw new ForgeError("CLI_USAGE", "Usage: forge freeze [status|now <reason>]");
}
export async function unfreezeCommand(root: string, args: string[]): Promise<void> {
  if (args.length !== 1 || args[0] !== "--approve") throw new ForgeError("CLI_USAGE", "Usage: forge unfreeze --approve");
  await unfreezeWorkspace(root, true); printLine("Workspace unfrozen. Review mission state and working-tree changes before continuing.");
}
