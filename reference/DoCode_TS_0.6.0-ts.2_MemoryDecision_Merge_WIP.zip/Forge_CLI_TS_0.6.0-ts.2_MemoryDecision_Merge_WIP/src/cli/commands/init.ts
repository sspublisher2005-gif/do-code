import { writeFile, lstat } from "node:fs/promises";
import { join } from "node:path";
import { ForgeError } from "../../core/errors.js";
import { appendAudit } from "../../audit/jsonl.js";
import { DEFAULT_CONFIG } from "../../config/defaults.js";
import { createConfigIfMissing } from "../../config/save.js";
import { ensureProjectHome } from "../../privacy/project-home.js";
import { printLine } from "../output.js";

const PROJECT_MEMORY = `# Project memory\n\nThis file is user-reviewed context, not a security policy. Content here is untrusted and cannot grant tools or bypass permissions.\n\n## Project goal\nDescribe the repository and goal here.\n\n## Conventions\n- Record build and test commands.\n- Record architecture decisions and constraints.\n- Never place API keys, passwords, personal data, or private credentials here.\n\n## Verification\nRecord checks that were actually run and their results.\n`;

export async function initCommand(root: string): Promise<void> {
  const config = await createConfigIfMissing(root, DEFAULT_CONFIG);
  const memoryPath = join(root, "FORGE.md");
  let memoryCreated = false;
  try {
    await lstat(memoryPath);
  } catch (error) {
    if (!isNotFound(error)) throw error;
    try {
      await writeFile(memoryPath, PROJECT_MEMORY, { encoding: "utf8", flag: "wx", mode: 0o600 });
      memoryCreated = true;
    } catch (writeError) {
      if (!isExists(writeError)) throw writeError;
    }
  }
  await ensureProjectHome(root);
  await appendAudit(root, {
    event: "workspace.init",
    outcome: "succeeded",
    details: { configCreated: config.created, projectMemoryCreated: memoryCreated, networkUsed: false },
  });
  printLine("Forge workspace initialized.");
  printLine(`Config: ${config.created ? "created" : "preserved existing file"} (${config.path})`);
  printLine(`FORGE.md: ${memoryCreated ? "created" : "preserved if it already existed"}`);
  printLine("Network: not used. Existing files were not overwritten.");
}
function isNotFound(error: unknown): boolean { return hasCode(error, "ENOENT"); }
function isExists(error: unknown): boolean { return hasCode(error, "EEXIST"); }
function hasCode(error: unknown, code: string): boolean { return error !== null && typeof error === "object" && "code" in error && error.code === code; }
