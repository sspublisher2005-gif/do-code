import { printLine } from "../output.js";
import { ForgeError } from "../../core/errors.js";
const agents = [
  ["orchestrator", "Owns mission lifecycle and policy routing; not a separate security boundary."],
  ["researcher", "Analyzes bounded repository context and records unknowns."],
  ["architect", "Produces a sequenced implementation plan."],
  ["coder", "Produces a proposal only; cannot directly write files."],
  ["tester", "Recommends exact tests; reports tests only when executed with evidence."],
  ["reviewer", "Reviews proposal; advisory, cannot approve writes."],
  ["security", "Reviews security risks; deterministic policy remains authoritative."],
  ["devops", "Assesses release/build concerns; cannot invent CI evidence."],
] as const;
export async function agentsCommand(args: string[]): Promise<void> {
  if (args.length && args[0] !== "list") throw new ForgeError("CLI_USAGE", "Usage: forge agents [list]");
  printLine("Forge agent roles (sequential and provider-backed; not eight independent OS-isolated agents):");
  for (const [name, description] of agents) printLine(`- ${name}: ${description}`);
  printLine("The orchestrator and deterministic safety broker are authoritative. Model outputs are untrusted suggestions, never permission grants.");
}
