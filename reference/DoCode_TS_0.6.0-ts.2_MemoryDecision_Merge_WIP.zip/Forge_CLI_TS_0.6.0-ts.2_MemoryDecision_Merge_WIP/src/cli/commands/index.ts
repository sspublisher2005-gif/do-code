import { appendAudit } from "../../audit/jsonl.js";
import { buildRepositoryIndex, renderRepoMap, saveRepositoryIndex } from "../../context/repository.js";
import { ForgeError } from "../../core/errors.js";
import { printLine } from "../output.js";

export async function indexCommand(root: string, args: string[]): Promise<void> {
  let maxFiles = 5000; let maxFileBytes = 512 * 1024; let maxTotalBytes = 32 * 1024 * 1024;
  while (args.length) {
    const arg = args.shift(); const raw = args.shift();
    if (!raw || !/^\d+$/.test(raw)) throw new ForgeError("CLI_USAGE", `${arg ?? "option"} requires an integer.`);
    const value = Number(raw); if (!Number.isSafeInteger(value) || value < 1) throw new ForgeError("CLI_USAGE", `${arg ?? "option"} requires a positive integer.`);
    if (arg === "--max-files") maxFiles = Math.min(5000, value);
    else if (arg === "--max-file-bytes") maxFileBytes = Math.min(2 * 1024 * 1024, value);
    else if (arg === "--max-total-bytes") maxTotalBytes = Math.min(100 * 1024 * 1024, value);
    else throw new ForgeError("CLI_USAGE", `Unknown index option '${arg ?? ""}'.`);
  }
  const index = await buildRepositoryIndex(root, { maxFiles, maxFileBytes, maxTotalBytes });
  const path = await saveRepositoryIndex(root, index);
  printLine(renderRepoMap(index)); printLine(`\nIndex metadata saved locally: ${path}`); printLine("No repository file contents were persisted in the index; context packs read bounded file excerpts on demand.");
  await appendAudit(root, { event: "repository.indexed", outcome: "succeeded", details: { files: index.fileCount, bytes: index.totalBytes, edges: index.edges.length, mode: index.mode } });
}
