import { appendAudit } from "../../audit/jsonl.js";
import { createInterface } from "node:readline/promises";
import { stdin, stdout } from "node:process";
import { ForgeError } from "../../core/errors.js";
import { redactString } from "../../safety/secret-redaction.js";
import { editMemoryNote, exportMemory, findMemoryNote, forgetMemoryNote, importMemory, listMemoryNotes, memoryVaultPath, parseMarkdown, proposeMemory, reindexMemory, renderMarkdown, resetMemory, saveMemoryNote, searchMemory, verifyMemoryNote } from "../../memory/markdown-store.js";
import type { MemoryProposal, MemoryScope, MemoryScopeFilter, MemoryStatus, MemoryType } from "../../memory/types.js";
import { printJson, printLine } from "../output.js";

const MEMORY_HELP = `Forge local memory — structured decisions and verified lessons, never raw thoughts

USAGE
  forge memory
  forge memory propose --type <type> --title <text> --problem <text> --decision <text> --reason <text> [options]
  forge memory list [--scope global|project|all]
  forge memory search <query> [--scope global|project|all]
  forge memory show <uuid>
  forge memory edit <uuid>
  forge memory forget <uuid> --confirm
  forge memory verify <uuid>
  forge memory reindex --confirm [--scope global|project|all]
  forge memory export <new-file.json> [--scope global|project|all]
  forge memory import <file.json> --confirm
  forge memory open
  forge memory reset --confirm [--scope global|project|all]

TYPES
  solution | decision | research | user_preference | project | failure | workflow

RULES
  - A proposal is printed before it can be saved. Non-interactive use requires --confirm.
  - Solution/research/failure/workflow notes require at least one evidence/source reference.
  - User preferences are never inferred from a single unconfirmed event.
  - Global notes and current-project notes are stored separately; notes are never sent to a model by these commands.
  - Markdown notes are Obsidian-compatible; index.json is a rebuildable local index.
`;

export async function memoryCommand(root: string, args: string[]): Promise<void> {
  const subcommand = args.shift();
  if (!subcommand || subcommand === "help" || subcommand === "--help") { printLine(MEMORY_HELP); return; }
  if (subcommand === "propose" || subcommand === "add") { await proposeCommand(root, args); return; }
  if (subcommand === "list") {
    const options = parseCommon(args);
    const notes = await listMemoryNotes(root, options.scope);
    printJson(notes.map((note) => ({ id: note.id, title: note.title, type: note.type, status: note.status, scope: note.scope, confidence: note.confidence, createdAt: note.createdAt, lastVerifiedAt: note.lastVerifiedAt })));
    return;
  }
  if (subcommand === "search") {
    const options = parseCommon(args);
    const query = options.positionals.join(" ").trim();
    const hits = await searchMemory(root, query, options.scope);
    printJson(hits.map(({ note, score }) => ({ score, id: note.id, title: note.title, type: note.type, status: note.status, scope: note.scope, confidence: note.confidence, decision: note.decision })));
    return;
  }
  if (subcommand === "show") {
    const id = args.shift();
    if (!id || args.length) throw usage("forge memory show <uuid>");
    const found = await findMemoryNote(root, id);
    printLine(found.raw);
    return;
  }
  if (subcommand === "edit") {
    const id = args.shift();
    if (!id || args.length) throw usage("forge memory edit <uuid>");
    const result = await editMemoryNote(root, id);
    printLine(result.detail);
    printLine(result.path);
    if (result.edited) await recordMemoryAudit(root, "memory.note_edited", { memoryId: id });
    return;
  }
  if (subcommand === "forget") {
    const id = args.shift();
    const confirmed = removeFlag(args, "--confirm");
    if (!id || args.length) throw usage("forge memory forget <uuid> --confirm");
    if (!confirmed) throw new ForgeError("MEMORY_CONFIRM_REQUIRED", "Deleting a memory is destructive. Re-run with --confirm after reviewing the note with 'forge memory show'.");
    const found = await findMemoryNote(root, id);
    await forgetMemoryNote(root, id);
    await recordMemoryAudit(root, "memory.note_forgotten", { memoryId: id, scope: found.note.scope, type: found.note.type });
    printLine(`Forgot memory '${found.note.title}' (${id}). Note removed from local storage.`);
    return;
  }
  if (subcommand === "verify") {
    const id = args.shift();
    if (!id || args.length) throw usage("forge memory verify <uuid>");
    const result = await verifyMemoryNote(root, id);
    await recordMemoryAudit(root, "memory.note_verified", { memoryId: id, integrity: result.integrity });
    printLine("Memory integrity verified: note schema, scope metadata, and indexed SHA-256 match. This does not prove the remembered claim is factually current.");
    printJson({ id, title: result.note.title, status: result.note.status, integrity: result.integrity, sha256: result.sha256, indexed: result.indexed });
    return;
  }
  if (subcommand === "reindex") {
    const confirmed = removeFlag(args, "--confirm");
    const options = parseCommon(args);
    if (!confirmed) throw new ForgeError("MEMORY_CONFIRM_REQUIRED", "Reindex rewrites the cache to match Markdown notes. Review the vault first, then add --confirm.");
    const count = await reindexMemory(root, options.scope);
    await recordMemoryAudit(root, "memory.index_rebuilt", { scope: options.scope, count });
    printLine(`Rebuilt memory index for ${count} note(s). Markdown remains the source of truth.`);
    return;
  }
  if (subcommand === "export") {
    const options = parseCommon(args);
    const destination = options.positionals[0];
    if (!destination || options.positionals.length !== 1) throw usage("forge memory export <new-file.json> [--scope global|project|all]");
    const result = await exportMemory(root, destination, options.scope);
    await recordMemoryAudit(root, "memory.exported", { scope: options.scope, count: result.count });
    printLine(`Exported ${result.count} confirmed memory note(s) to ${result.path}. Treat this file as private: it may contain project information.`);
    return;
  }
  if (subcommand === "import") {
    const confirmed = removeFlag(args, "--confirm");
    const source = args.shift();
    if (!source || args.length) throw usage("forge memory import <file.json> --confirm");
    if (!confirmed) throw new ForgeError("MEMORY_CONFIRM_REQUIRED", "Import may add many memory records. Inspect the export first and re-run with --confirm.");
    const count = await importMemory(root, source, { confirmed: true });
    await recordMemoryAudit(root, "memory.imported", { count });
    printLine(`Imported ${count} note(s). Project-bound notes from other projects are rejected; IDs were regenerated to avoid collisions.`);
    return;
  }
  if (subcommand === "open") {
    if (args.length) throw usage("forge memory open");
    printLine(`Local memory vault: ${memoryVaultPath()}`);
    printLine("This command reveals the folder path only; it does not launch an external application or upload memory.");
    return;
  }
  if (subcommand === "reset") {
    const confirmed = removeFlag(args, "--confirm");
    const options = parseCommon(args);
    if (!confirmed) throw new ForgeError("MEMORY_CONFIRM_REQUIRED", "Reset deletes all notes in the selected scope. Review 'forge memory list' and re-run with --confirm.");
    const count = await resetMemory(root, options.scope);
    await recordMemoryAudit(root, "memory.reset", { scope: options.scope, count });
    printLine(`Deleted ${count} memory note(s) from scope '${options.scope}'.`);
    return;
  }
  throw usage("forge memory <propose|list|search|show|edit|forget|verify|reindex|export|import|open|reset>");
}

async function proposeCommand(root: string, args: string[]): Promise<void> {
  const parsed = parseProposalArgs(args);
  const proposal: MemoryProposal = {
    type: parsed.type,
    title: parsed.title,
    problem: parsed.problem,
    decision: parsed.decision,
    reason: parsed.reason,
    rejectedOptions: parsed.rejectedOptions,
    limitations: parsed.limitations,
    evidence: parsed.evidence,
    confidence: parsed.confidence,
    scope: parsed.scope,
  };
  // Never store raw model reasoning or obvious credential-shaped strings as memory.
  const checkFields = [proposal.title, proposal.problem, proposal.decision, proposal.reason, ...proposal.rejectedOptions, ...proposal.limitations, ...proposal.evidence];
  if (checkFields.some((field) => redactString(field) !== field)) throw new ForgeError("MEMORY_SECRET_SUSPECTED", "The memory proposal appears to contain a credential or secret. Remove it before saving; redaction heuristics cannot detect every secret.");
  const prepared = await proposeMemory(root, proposal);
  printLine("MEMORY PROPOSAL — not saved yet");
  printLine(renderMarkdown(prepared));
  let approved = parsed.confirm;
  if (!approved && stdin.isTTY && stdout.isTTY) {
    const rl = createInterface({ input: stdin, output: stdout });
    try { const answer = await rl.question("Save this exact memory locally? [y/N] "); approved = answer.trim().toLowerCase() === "y"; }
    finally { rl.close(); }
  }
  if (!approved) {
    await recordMemoryAudit(root, "memory.proposal_declined", { scope: proposal.scope, type: proposal.type });
    printLine("Not saved. Re-run with --confirm only after reviewing the proposal, or run interactively and answer y.");
    return;
  }
  const saved = await saveMemoryNote(root, prepared, { confirmed: true });
  await recordMemoryAudit(root, "memory.note_saved", { memoryId: saved.note.id, scope: saved.note.scope, type: saved.note.type });
  printLine(`Saved confirmed memory: ${saved.note.id}`);
  printLine(`Path: ${saved.path}`);
  printLine("No memory profile or note content was sent to a model provider.");
}


function parseProposalArgs(args: string[]): {
  type: MemoryType; title: string; problem: string; decision: string; reason: string; rejectedOptions: string[]; limitations: string[]; evidence: string[]; confidence: number; scope: MemoryScope; confirm: boolean;
} {
  let type: MemoryType | undefined; let title = ""; let problem = ""; let decision = ""; let reason = ""; let confidence: number | undefined; let scope: MemoryScope = "global"; let confirm = false;
  const rejectedOptions: string[] = []; const limitations: string[] = []; const evidence: string[] = [];
  for (let i = 0; i < args.length; i += 1) {
    const arg = args[i] ?? "";
    const take = (): string => { const value = args[++i]; if (!value || value.startsWith("--")) throw usage(`${arg} requires a value`); return value; };
    switch (arg) {
      case "--type": type = take() as MemoryType; break;
      case "--title": title = take(); break;
      case "--problem": problem = take(); break;
      case "--decision": decision = take(); break;
      case "--reason": reason = take(); break;
      case "--rejected": rejectedOptions.push(take()); break;
      case "--limitation": limitations.push(take()); break;
      case "--evidence": evidence.push(take()); break;
      case "--confidence": { const raw = take(); if (!/^(?:0(?:\.\d+)?|1(?:\.0+)?)$/.test(raw)) throw usage("--confidence must be between 0 and 1"); confidence = Number(raw); break; }
      case "--scope": { const value = take(); if (value !== "global" && value !== "project") throw usage("--scope must be global or project"); scope = value; break; }
      case "--confirm": confirm = true; break;
      default: throw usage(`Unknown memory proposal option '${arg}'`);
    }
  }
  if (!type || !["solution", "decision", "research", "user_preference", "project", "failure", "workflow"].includes(type)) throw usage("--type must be solution|decision|research|user_preference|project|failure|workflow");
  if (!title || !problem || !decision || !reason || confidence === undefined) throw usage("memory propose requires --type, --title, --problem, --decision, --reason, and --confidence");
  return { type, title, problem, decision, reason, rejectedOptions, limitations, evidence, confidence, scope, confirm };
}


function parseCommon(args: string[]): { scope: MemoryScopeFilter; positionals: string[] } {
  const positionals: string[] = []; let scope: MemoryScopeFilter = "all";
  for (let i = 0; i < args.length; i += 1) {
    const arg = args[i] ?? "";
    if (arg === "--scope") {
      const value = args[i + 1];
      if (!value || !["global", "project", "all"].includes(value)) throw usage("--scope must be global, project, or all");
      scope = value as MemoryScopeFilter; i += 1;
    } else if (arg.startsWith("--")) throw usage(`Unknown option '${arg}'`);
    else positionals.push(arg);
  }
  return { scope, positionals };
}
function removeFlag(args: string[], flag: string): boolean {
  const index = args.indexOf(flag);
  if (index < 0) return false;
  args.splice(index, 1);
  if (args.includes(flag)) throw usage(`${flag} may be supplied only once`);
  return true;
}
async function recordMemoryAudit(root: string, event: string, details: Record<string, string | number | boolean | null>): Promise<void> {
  try {
    await appendAudit(root, { event, outcome: "succeeded", details });
  } catch {
    // Memory mutations already have their own atomic/local storage rules. Do not tell the user a save failed
    // after it has succeeded simply because the optional operational audit trail could not be appended.
    printLine("Warning: the memory operation completed, but its audit event could not be recorded. Run 'forge doctor' and inspect the local audit directory.");
  }
}

function usage(message: string): ForgeError { return new ForgeError("CLI_USAGE", message); }
