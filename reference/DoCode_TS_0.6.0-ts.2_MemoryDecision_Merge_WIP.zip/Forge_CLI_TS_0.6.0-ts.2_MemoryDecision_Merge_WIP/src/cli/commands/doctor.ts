import { lstat } from "node:fs/promises";
import { join } from "node:path";
import { loadConfig } from "../../config/load.js";
import { printLine } from "../output.js";
import { probeSandboxEnvironment } from "../../sandbox/probe.js";
import { readFreezeState } from "../../safety/freeze.js";

export async function doctorCommand(root: string): Promise<void> {
  const config = await loadConfig(root);
  const checks: Array<{ name: string; status: "PASS" | "WARN"; detail: string }> = [];
  checks.push({ name: "Node.js", status: Number(process.versions.node.split(".")[0]) >= 22 ? "PASS" : "WARN", detail: process.versions.node });
  checks.push({ name: "Workspace config", status: config.exists ? "PASS" : "WARN", detail: config.exists ? "forge.config.toml loaded and validated" : "missing; defaults shown, run forge init" });
  const providers = new Set(["openai-compatible", "anthropic", "google", "ollama"]);
  const providerSupported = providers.has(config.config.model.provider);
  checks.push({ name: "Configured provider", status: providerSupported ? "PASS" : "WARN", detail: providerSupported ? `${config.config.model.provider} adapter is implemented; network connectivity/model quality not tested here` : "configured provider adapter is unavailable" });
  checks.push({ name: "Provider key", status: process.env[config.config.model.api_key_env] ? "PASS" : "WARN", detail: process.env[config.config.model.api_key_env] ? "named environment variable is set (value not displayed)" : "not set; offline commands still work" });
  checks.push({ name: "Telemetry", status: "PASS", detail: "disabled" });
  const sandbox = await probeSandboxEnvironment();
  const sandboxTools = Object.entries(sandbox.candidates).filter(([, item]) => item.executable).map(([name]) => name);
  checks.push({ name: "Sandbox execution", status: "WARN", detail: `BLOCKED: no verified sandbox driver. Discovered tools: ${sandboxTools.join(", ") || "none"}. Forge will not execute workspace commands.` });
  try {
    const freeze = await readFreezeState(root);
    checks.push({ name: "Workspace freeze", status: freeze ? "WARN" : "PASS", detail: freeze ? `frozen since ${freeze.frozenAt}; reason: ${freeze.reason}` : "not frozen" });
  } catch { checks.push({ name: "Workspace freeze", status: "WARN", detail: "freeze state could not be validated; safety-sensitive operations remain blocked" }); }
  try {
    const info = await lstat(join(root, ".forge"));
    checks.push({ name: "Private state directory", status: info.isDirectory() && !info.isSymbolicLink() ? "PASS" : "WARN", detail: info.isDirectory() && !info.isSymbolicLink() ? "directory exists" : "unsafe or missing" });
  } catch { checks.push({ name: "Private state directory", status: "WARN", detail: "missing; run forge init or forge audit to initialize" }); }
  for (const check of checks) printLine(`${check.status.padEnd(4)} ${check.name}: ${check.detail}`);
  printLine("Doctor performs local diagnostics only; it does not call a model, expose credentials, or prove sandbox/network isolation.");
}
