#!/usr/bin/env node
import { fileURLToPath } from "node:url";
import { resolve } from "node:path";
import { realpathSync } from "node:fs";
import { appendAudit } from "../audit/jsonl.js";
import { errorCode, safeErrorMessage } from "../core/errors.js";
import { redactString } from "../safety/secret-redaction.js";
import { printError } from "./output.js";
import { routeCommand } from "./command-router.js";

export async function main(argv = process.argv.slice(2)): Promise<void> {
  const rootIndex = argv.indexOf("--root");
  let root = process.cwd();
  if (rootIndex >= 0 && argv[rootIndex + 1]) root = resolve(argv[rootIndex + 1] ?? process.cwd());
  const normalized = [...argv];
  if (rootIndex >= 0) normalized.splice(rootIndex, 2);
  const commandName = normalized.slice(0, 2).join(" ");
  try {
    await routeCommand(argv, process.cwd());
  } catch (error) {
    const code = errorCode(error);
    const message = redactString(safeErrorMessage(error));
    printError(code, message);
    try {
      await appendAudit(root, {
        event: "cli.command_failure",
        outcome: code.includes("DENIED") || code.includes("CONSENT") || code.includes("SENSITIVE") ? "denied" : "failed",
        details: { code, command: commandName.slice(0, 80) },
      });
    } catch { /* Audit failure must not mask the primary error; report it only through doctor later. */ }
    process.exitCode = 1;
  }
}

// npm/pnpm/yarn install the `forge` executable as a symlink on POSIX.
// Resolve both paths before comparing so the packaged CLI actually starts.
const invokedPath = process.argv[1] ? realpathSync(resolve(process.argv[1])) : "";
const modulePath = fileURLToPath(import.meta.url);
if (invokedPath === modulePath) await main();
