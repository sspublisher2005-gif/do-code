import { safeTerminalText } from "../util/terminal.js";

export function printLine(value = ""): void {
  process.stdout.write(`${safeTerminalText(value)}\n`);
}
export function printJson(value: unknown): void {
  process.stdout.write(`${JSON.stringify(value, null, 2)}\n`);
}
export function printError(code: string, message: string): void {
  process.stderr.write(`forge: ${safeTerminalText(code)}: ${safeTerminalText(message)}\n`);
}
