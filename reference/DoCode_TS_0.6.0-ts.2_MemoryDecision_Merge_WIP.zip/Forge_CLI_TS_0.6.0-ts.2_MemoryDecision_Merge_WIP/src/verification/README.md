# Verification evidence — partly represented in M1

`completion-gate.ts` is a deterministic helper. A private content-addressed evidence store, artifact provenance, integrity checks, verification runner and complete mission integration are planned for M2+. No mission can currently be run autonomously from the CLI.
