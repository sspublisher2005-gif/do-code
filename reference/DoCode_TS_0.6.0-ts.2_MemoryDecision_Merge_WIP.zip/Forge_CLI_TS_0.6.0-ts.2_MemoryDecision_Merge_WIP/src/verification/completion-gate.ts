import { newId } from "../core/ids.js";
import type { VerificationCheck, VerificationResult } from "../core/types.js";

export interface CriterionEvidence {
  criterionId: string;
  required: boolean;
  passed: boolean;
  evidenceIds: string[];
}

export function evaluateCompletion(input: {
  missionId: string;
  checks: VerificationCheck[];
  criteria: CriterionEvidence[];
  reviewPassed: boolean;
  blockingSecurityWarnings: string[];
  startedAt: string;
  finishedAt?: string;
  policyVersion: string;
}): VerificationResult {
  const failedRequired = input.checks.some((check) => check.required && check.status === "failed");
  const incompleteRequired = input.checks.some((check) => check.required && (check.status !== "passed" || check.evidenceIds.length === 0));
  const missingCriteria = input.criteria.some((criterion) => criterion.required && (!criterion.passed || criterion.evidenceIds.length === 0));
  const warningList = input.blockingSecurityWarnings.map((warning) => warning.slice(0, 1000));
  let status: VerificationResult["status"] = "passed";
  if (failedRequired || warningList.length > 0) status = "failed";
  else if (incompleteRequired || missingCriteria || !input.reviewPassed || input.checks.length === 0 || input.criteria.length === 0) status = "incomplete";
  const result: VerificationResult = {
    id: newId(),
    missionId: input.missionId,
    status,
    startedAt: input.startedAt,
    finishedAt: input.finishedAt ?? new Date().toISOString(),
    checks: input.checks,
    unresolvedWarnings: warningList,
    completionAllowed: status === "passed",
    policyVersion: input.policyVersion,
  };
  return result;
}
