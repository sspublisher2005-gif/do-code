import { constants as fsConstants } from "node:fs";
import { chmod, lstat, mkdir, open, realpath } from "node:fs/promises";
import { join } from "node:path";
import { ForgeError } from "../core/errors.js";
import type { AgentMessage } from "../core/types.js";
import { ensureProjectHome } from "../privacy/project-home.js";
import { redactString } from "../safety/secret-redaction.js";

const MAX_MESSAGE_CHARS = 200_000;
const MAX_TRANSCRIPT_BYTES = 20 * 1024 * 1024;
export async function appendAgentMessage(rootInput: string, message: AgentMessage): Promise<AgentMessage> {
  const { home } = await ensureProjectHome(rootInput);
  if (!/^[0-9a-f-]{36}$/i.test(message.missionId)) throw new ForgeError("MESSAGE_MISSION_ID_INVALID", "Transcript mission ID is invalid.");
  const dir = join(home, "transcripts");
  try { await mkdir(dir, { mode: 0o700 }); } catch (e) { if (!hasCode(e, "EEXIST")) throw e; }
  const di = await lstat(dir); if (!di.isDirectory() || di.isSymbolicLink()) throw new ForgeError("TRANSCRIPT_PATH_UNSAFE", "Transcript directory must be a real directory.");
  await chmod(dir, 0o700).catch(() => undefined);
  const path = join(dir, `${message.missionId}.jsonl`);
  const info = await lstat(path).catch((e: unknown) => { if (hasCode(e, "ENOENT")) return undefined; throw e; });
  if (info && (!info.isFile() || info.isSymbolicLink() || info.size > MAX_TRANSCRIPT_BYTES)) throw new ForgeError("TRANSCRIPT_UNSAFE", "Transcript is a symlink, special file, or exceeds its size limit.");
  const safe = { ...message, content: redactString(message.content.slice(0, MAX_MESSAGE_CHARS)) };
  safe.redacted = safe.redacted || safe.content !== message.content;
  const line = `${JSON.stringify(safe)}\n`;
  const handle = await open(path, fsConstants.O_CREAT | fsConstants.O_APPEND | fsConstants.O_WRONLY | (fsConstants.O_NOFOLLOW ?? 0), 0o600);
  try { const now = await handle.stat(); if (!now.isFile() || now.size + Buffer.byteLength(line, "utf8") > MAX_TRANSCRIPT_BYTES) throw new ForgeError("TRANSCRIPT_LIMIT", "Transcript reached its 20 MiB limit; rotate it after backup."); await handle.chmod(0o600); await handle.writeFile(line, "utf8"); await handle.sync(); } finally { await handle.close(); }
  return safe;
}
function hasCode(error: unknown, code: string): boolean { return error !== null && typeof error === "object" && "code" in error && error.code === code; }
