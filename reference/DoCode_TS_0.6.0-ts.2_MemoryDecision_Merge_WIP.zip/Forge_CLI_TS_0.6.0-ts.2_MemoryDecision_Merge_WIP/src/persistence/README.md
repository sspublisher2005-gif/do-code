# Mission persistence — planned for M2

Do not persist mission state by serializing arbitrary class instances. Planned format: versioned JSON schema, project-root identity, atomic same-directory temp+fsync+exclusive replacement, checksum, process/lock owner, lock expiry and migration rules. Corrupt, unknown-version, stale-ambiguous or concurrently resumed state must fail closed and require review. Do not silently rerun a write-bearing step on resume.
