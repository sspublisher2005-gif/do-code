import { hostname } from "node:os";
import { createHash, randomUUID } from "node:crypto";
import { constants as fsConstants } from "node:fs";
import { chmod, lstat, mkdir, open, readFile, readdir, realpath, rename, unlink } from "node:fs/promises";
import { join } from "node:path";
import { ForgeError } from "../core/errors.js";
import { newId, projectIdFor } from "../core/ids.js";
import { ensureProjectHome } from "../privacy/project-home.js";
import type { AgentRole, Mission, MissionStatus, Step, StepKind } from "../core/types.js";
import { assertMissionTransition } from "../core/mission-state.js";
import { redactString } from "../safety/secret-redaction.js";

const STORE_VERSION = 1;
const MAX_STATE_BYTES = 8 * 1024 * 1024;
const LOCK_STALE_MS = 60_000;
const LOCK_DIR = "locks";
const MISSION_DIR = "missions";
const FLOW: Array<{ kind: StepKind; assignedRole: AgentRole; dependsOn: number[] }> = [
  { kind: "research", assignedRole: "researcher", dependsOn: [] },
  { kind: "plan", assignedRole: "architect", dependsOn: [0] },
  { kind: "implement", assignedRole: "coder", dependsOn: [1] },
  { kind: "test", assignedRole: "tester", dependsOn: [2] },
  { kind: "review", assignedRole: "reviewer", dependsOn: [2] },
  { kind: "security", assignedRole: "security", dependsOn: [2, 4] },
  { kind: "devops", assignedRole: "devops", dependsOn: [1] },
];

interface MissionEnvelope { storeVersion: 1; sha256: string; mission: Mission }
interface LockRecord { token: string; pid: number; host: string; createdAt: string; root: string }

export class MissionStore {
  readonly #root: string;
  readonly #projectId: string;
  readonly #dir: string;
  readonly #lockDir: string;

  private constructor(root: string, projectId: string, dir: string, lockDir: string) {
    this.#root = root; this.#projectId = projectId; this.#dir = dir; this.#lockDir = lockDir;
  }

  static async open(rootInput: string): Promise<MissionStore> {
    const { root, home } = await ensureProjectHome(rootInput);
    const dir = join(home, MISSION_DIR); const lockDir = join(home, LOCK_DIR);
    await ensurePrivateDir(dir); await ensurePrivateDir(lockDir);
    return new MissionStore(root, await projectIdFor(root), dir, lockDir);
  }

  async create(objective: string, options: { dryRun?: boolean; maxDurationMs?: number; maxCostUsd?: number } = {}): Promise<Mission> {
    const trimmed = objective.trim();
    if (!trimmed || trimmed.length > 20_000) throw new ForgeError("MISSION_OBJECTIVE_INVALID", "Mission objective must contain 1–20,000 characters.");
    if (redactString(trimmed) !== trimmed) throw new ForgeError("MISSION_SECRET_SUSPECTED", "Mission objective resembles a credential. Remove secrets before persisting a mission or sending context to a model.");
    const now = new Date().toISOString(); const id = newId();
    const steps: Step[] = FLOW.map((item, ordinal) => ({
      id: newId(), missionId: id, ordinal, kind: item.kind, assignedRole: item.assignedRole,
      status: "pending", dependsOn: [], attempt: 0,
      inputEvidenceIds: [], outputEvidenceIds: [], toolCallIds: [], createdAt: now,
    }));
    // Use stable actual step IDs in dependency edges.
    for (const step of steps) step.dependsOn = FLOW[step.ordinal]?.dependsOn.map((i) => steps[i]?.id ?? "") .filter(Boolean) ?? [];
    const mission: Mission = {
      schemaVersion: 1, id, projectId: this.#projectId, repoRoot: this.#root, objective: trimmed,
      status: "draft", createdAt: now, updatedAt: now, steps,
      acceptanceCriteria: [
        { id: newId(), description: "Requested behavior is implemented", required: true, verificationKinds: ["test", "review"] },
        { id: newId(), description: "Relevant checks pass with recorded evidence", required: true, verificationKinds: ["test", "typecheck"] },
        { id: newId(), description: "No blocking security findings remain", required: true, verificationKinds: ["security"] },
      ],
      maxDurationMs: options.maxDurationMs ?? 30 * 60_000, dryRun: options.dryRun ?? true,
      approvedCapabilities: ["read_workspace"], evidenceIds: [],
    };
    if (options.maxCostUsd !== undefined) {
      if (!Number.isFinite(options.maxCostUsd) || options.maxCostUsd <= 0 || options.maxCostUsd > 10_000) throw new ForgeError("MISSION_BUDGET_INVALID", "maxCostUsd must be greater than zero and no more than 10,000.");
      mission.maxCostUsd = options.maxCostUsd;
    }
    await this.#write(mission);
    return structuredClone(mission);
  }

  async get(id: string): Promise<Mission> {
    const path = this.#path(id);
    let source: string;
    try {
      const info = await lstat(path);
      if (!info.isFile() || info.isSymbolicLink() || info.size > MAX_STATE_BYTES) throw new ForgeError("MISSION_STATE_UNSAFE", "Mission state is a symlink, special file, or exceeds the state-size limit.");
      const handle = await open(path, fsConstants.O_RDONLY | (fsConstants.O_NOFOLLOW ?? 0));
      try { source = await handle.readFile("utf8"); } finally { await handle.close(); }
    } catch (error) {
      if (hasCode(error, "ENOENT")) throw new ForgeError("MISSION_NOT_FOUND", "Mission does not exist in this project.");
      throw error;
    }
    let parsed: unknown;
    try { parsed = JSON.parse(source) as unknown; } catch { throw new ForgeError("MISSION_STATE_CORRUPT", "Mission state is not valid JSON. It was not modified."); }
    if (!isEnvelope(parsed)) throw new ForgeError("MISSION_STATE_CORRUPT", "Mission state envelope is invalid. It was not modified.");
    const canonical = JSON.stringify(parsed.mission);
    const digest = createHash("sha256").update(canonical).digest("hex");
    if (parsed.sha256 !== digest) throw new ForgeError("MISSION_STATE_INTEGRITY", "Mission state checksum mismatch. It was not modified.");
    validateMission(parsed.mission, this.#root, this.#projectId);
    return structuredClone(parsed.mission);
  }

  async list(): Promise<Mission[]> {
    const names = (await readdir(this.#dir)).filter((name: string) => /^[0-9a-f-]{36}\.json$/i.test(name)).sort();
    const result: Mission[] = [];
    for (const name of names) {
      try { result.push(await this.get(name.slice(0, -5))); }
      catch { /* Corrupt or cross-project state is not presented as a valid mission. `forge doctor` reports the storage warning. */ }
    }
    return result;
  }

  async update(id: string, mutate: (mission: Mission) => Mission): Promise<Mission> {
    return this.withLock(id, async () => {
      const current = await this.get(id);
      const next = mutate(structuredClone(current));
      if (next.id !== current.id || next.projectId !== this.#projectId || next.repoRoot !== this.#root) throw new ForgeError("MISSION_IDENTITY_CHANGED", "Mission identity and project binding cannot be changed.");
      next.updatedAt = new Date().toISOString();
      validateMission(next, this.#root, this.#projectId);
      await this.#write(next);
      return structuredClone(next);
    });
  }

  async transition(id: string, to: MissionStatus): Promise<Mission> {
    return this.update(id, (mission) => {
      assertMissionTransition(mission.status, to);
      mission.status = to; return mission;
    });
  }

  async withLock<T>(id: string, operation: () => Promise<T>): Promise<T> {
    this.#assertId(id);
    const lockPath = join(this.#lockDir, `${id}.lock`);
    const token = randomUUID();
    const record: LockRecord = { token, pid: process.pid, host: hostname(), createdAt: new Date().toISOString(), root: this.#root };
    let lockHandle;
    try {
      lockHandle = await open(lockPath, fsConstants.O_CREAT | fsConstants.O_EXCL | fsConstants.O_WRONLY, 0o600);
      await lockHandle.writeFile(JSON.stringify(record), "utf8"); await lockHandle.sync(); await lockHandle.close();
    } catch (error) {
      if (!hasCode(error, "EEXIST")) throw error;
      await this.#recoverStaleLock(lockPath);
      try { lockHandle = await open(lockPath, fsConstants.O_CREAT | fsConstants.O_EXCL | fsConstants.O_WRONLY, 0o600); await lockHandle.writeFile(JSON.stringify(record), "utf8"); await lockHandle.sync(); await lockHandle.close(); }
      catch (second) {
        if (hasCode(second, "EEXIST")) throw new ForgeError("MISSION_LOCKED", "Another Forge process holds this mission lock. Concurrent resume/update is refused.");
        throw second;
      }
    }
    try { return await operation(); }
    finally {
      try {
        const current = JSON.parse(await readFile(lockPath, "utf8")) as Partial<LockRecord>;
        if (current.token === token && current.pid === process.pid) await unlink(lockPath);
      } catch { /* Never delete a lock unless its ownership token is verified. */ }
    }
  }

  #path(id: string): string { this.#assertId(id); return join(this.#dir, `${id}.json`); }
  #assertId(id: string): void { if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(id)) throw new ForgeError("MISSION_ID_INVALID", "Mission ID must be a UUID generated by Forge."); }

  async #write(mission: Mission): Promise<void> {
    const target = this.#path(mission.id); const temp = `${target}.${randomUUID()}.tmp`;
    const canonical = JSON.stringify(mission);
    const envelope: MissionEnvelope = { storeVersion: STORE_VERSION, sha256: createHash("sha256").update(canonical).digest("hex"), mission };
    const data = `${JSON.stringify(envelope)}\n`;
    const handle = await open(temp, fsConstants.O_CREAT | fsConstants.O_EXCL | fsConstants.O_WRONLY, 0o600);
    try { await handle.writeFile(data, "utf8"); await handle.sync(); } finally { await handle.close(); }
    try { await rename(temp, target); await chmod(target, 0o600).catch(() => undefined); }
    catch (error) { await unlink(temp).catch(() => undefined); throw error; }
  }

  async #recoverStaleLock(path: string): Promise<void> {
    let before;
    let raw: string;
    try { before = await lstat(path); raw = await readFile(path, "utf8"); }
    catch (error) { if (hasCode(error, "ENOENT")) return; throw error; }
    if (before.isSymbolicLink() || !before.isFile() || before.size > 4096) throw new ForgeError("MISSION_LOCK_UNSAFE", "Mission lock is not a safe regular file.");
    let lock: LockRecord;
    try { lock = JSON.parse(raw) as LockRecord; } catch { throw new ForgeError("MISSION_LOCK_CORRUPT", "Mission lock is corrupt. It will not be removed automatically."); }
    const age = Date.now() - Date.parse(lock.createdAt);
    if (lock.host !== hostname() || lock.root !== this.#root || !Number.isInteger(lock.pid) || age < LOCK_STALE_MS) throw new ForgeError("MISSION_LOCKED", "Mission lock is recent or belongs to another host/workspace; refusing stale-lock recovery.");
    let alive = true;
    try { process.kill(lock.pid, 0); } catch (error) { alive = !hasCode(error, "ESRCH"); }
    if (alive) throw new ForgeError("MISSION_LOCKED", "Mission lock owner process appears to be alive; concurrent operation refused.");
    const after = await lstat(path).catch(() => undefined);
    if (!after || after.isSymbolicLink() || after.ino !== before.ino || after.size !== before.size) throw new ForgeError("MISSION_LOCK_CHANGED", "Mission lock changed during recovery; refusing to remove it.");
    const current = await readFile(path, "utf8");
    if (current !== raw) throw new ForgeError("MISSION_LOCK_CHANGED", "Mission lock content changed during recovery.");
    await unlink(path);
  }
}

async function ensurePrivateDir(path: string): Promise<void> {
  try { await mkdir(path, { recursive: false, mode: 0o700 }); }
  catch (error) { if (!hasCode(error, "EEXIST")) throw error; }
  const info = await lstat(path);
  if (!info.isDirectory() || info.isSymbolicLink()) throw new ForgeError("MISSION_STORE_UNSAFE", "Mission storage path must be a real directory, not a symlink.");
  await chmod(path, 0o700).catch(() => undefined);
}

function isEnvelope(value: unknown): value is MissionEnvelope {
  if (!value || typeof value !== "object") return false;
  const v = value as Record<string, unknown>;
  return v.storeVersion === 1 && typeof v.sha256 === "string" && /^[a-f0-9]{64}$/.test(v.sha256) && isMission(v.mission);
}
function isMission(value: unknown): value is Mission {
  if (!value || typeof value !== "object") return false;
  const v = value as Record<string, unknown>;
  return v.schemaVersion === 1 && typeof v.id === "string" && typeof v.projectId === "string" && typeof v.repoRoot === "string" && typeof v.objective === "string" && typeof v.status === "string" && Array.isArray(v.steps) && Array.isArray(v.acceptanceCriteria) && Array.isArray(v.evidenceIds);
}
function validateMission(m: Mission, root: string, projectId: string): void {
  if (m.repoRoot !== root || m.projectId !== projectId) throw new ForgeError("MISSION_PROJECT_MISMATCH", "Mission state belongs to a different project or canonical root.");
  if (m.objective.length > 20_000 || m.steps.length > 500 || m.acceptanceCriteria.length > 500 || m.evidenceIds.length > 10_000) throw new ForgeError("MISSION_STATE_LIMIT", "Mission exceeds persisted resource limits.");
  const ids = new Set<string>();
  for (const step of m.steps) {
    if (!step || typeof step.id !== "string" || typeof step.kind !== "string" || !Array.isArray(step.dependsOn) || !Array.isArray(step.toolCallIds) || !Array.isArray(step.outputEvidenceIds)) throw new ForgeError("MISSION_STATE_CORRUPT", "Mission contains an invalid step schema.");
    if (ids.has(step.id)) throw new ForgeError("MISSION_STATE_CORRUPT", "Mission contains duplicate step IDs."); ids.add(step.id);
    if (step.missionId !== m.id) throw new ForgeError("MISSION_STATE_CORRUPT", "A step is bound to a different mission.");
  }
  for (const step of m.steps) if (step.dependsOn.some((id) => !ids.has(id))) throw new ForgeError("MISSION_STATE_CORRUPT", "Mission references a missing dependency step.");
}
function hasCode(error: unknown, code: string): boolean { return error !== null && typeof error === "object" && "code" in error && error.code === code; }
