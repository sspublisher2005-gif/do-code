
declare namespace NodeJS {
  interface ProcessEnv { [key: string]: string | undefined }
  interface Process {
    env: ProcessEnv;
    platform: Platform;
    arch: string;
    pid: number;
    versions: { node: string };
    argv: string[];
    cwd(): string;
    exitCode?: number;
    stdin: any;
    stdout: any;
    stderr: any;
    kill(pid: number, signal?: number | Signals): boolean;
  }
  type Platform = "aix" | "android" | "darwin" | "freebsd" | "haiku" | "linux" | "openbsd" | "sunos" | "win32" | "cygwin" | "netbsd" | "unknown";
  type Signals = string;
  interface Timeout { unref(): Timeout; ref(): Timeout; }
}

declare var process: NodeJS.Process;

declare interface Buffer extends Uint8Array {
  readonly length: number;
  toString(encoding?: BufferEncoding): string;
  subarray(begin?: number, end?: number): Buffer;
}

declare interface BufferConstructor {
  from(data: string | ArrayBufferLike | ArrayLike<number>, encoding?: BufferEncoding): Buffer;
  alloc(size: number, fill?: string | number | Uint8Array, encoding?: BufferEncoding): Buffer;
  concat(list: readonly Buffer[], totalLength?: number): Buffer;
  byteLength(data: string | ArrayBufferView | ArrayBufferLike, encoding?: BufferEncoding): number;
  isBuffer(value: unknown): value is Buffer;
}

declare var Buffer: BufferConstructor;

type BufferEncoding =
  | "utf8"
  | "utf-8"
  | "ascii"
  | "base64"
  | "hex"
  | "latin1"
  | "binary"
  | "ucs2"
  | "utf16le";

declare module "node:crypto" {
  export function createHash(algorithm: string): { update(data: string | ArrayBufferView | ArrayBufferLike, inputEncoding?: BufferEncoding): any; digest(encoding?: BufferEncoding): any };
  export function randomUUID(): string;
}

declare module "node:fs" {
  export const constants: any;
  export function realpathSync(path: string): string;
}

declare module "node:fs/promises" {
  export const access: any;
  export const chmod: any;
  export const copyFile: any;
  export const lstat: any;
  export const link: any;
  export const mkdir: any;
  export const mkdtemp: any;
  export const open: any;
  export const readdir: any;
  export const readFile: any;
  export const realpath: any;
  export const rename: any;
  export const rm: any;
  export const stat: any;
  export const unlink: any;
  export const writeFile: any;
  export const utimes: any;
}

declare module "node:path" {
  export const basename: any;
  export const delimiter: string;
  export const dirname: any;
  export const extname: any;
  export const isAbsolute: any;
  export const join: any;
  export const relative: any;
  export const resolve: any;
  export const sep: string;
}

declare module "node:os" {
  export const hostname: any;
  export const tmpdir: any;
  export const homedir: any;
}

declare module "node:url" {
  export const fileURLToPath: any;
}

declare module "node:child_process" {
  export interface ChildProcess {
    pid: number | null;
    stdout?: any;
    stderr?: any;
    exitCode: number | null;
    signalCode: string | null;
    kill(signal?: string | number): boolean;
    unref(): void;
    on(event: string, listener: (...args: any[]) => void): this;
    once(event: string, listener: (...args: any[]) => void): this;
  }
  export function spawn(...args: any[]): ChildProcess;
}

declare module "node:net" {
  export interface AddressInfo { address: string; port: number; family: string; }
  const net: any;
  export default net;
}


declare module "node:process" {
  export const stdin: any;
  export const stdout: any;
}

declare module "node:readline/promises" {
  export function createInterface(options: any): any;
}
